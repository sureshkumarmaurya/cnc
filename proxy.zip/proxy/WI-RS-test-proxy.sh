./cloud_sql_proxy -instances=wildlifeinsights-external:asia-south1:rsi-test2=tcp:0.0.0.0:8432 -credential_file=./WL-wildlifeinsights-external-238c4fa181ed.json &
