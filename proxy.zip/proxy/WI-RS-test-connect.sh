psql "host=127.0.0.1  port=8432 sslmode=disable dbname=wi-api user=wi-api"
