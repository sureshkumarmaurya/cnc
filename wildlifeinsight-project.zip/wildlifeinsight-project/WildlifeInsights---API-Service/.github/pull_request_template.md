<!--
Thank you for your contributions to this repository.

To finalise this Pull Request before submission, please fill in the relevant
sections below and use the checklist to ensure all applicable tasks have been
completed.

This checklist is not meant to replace automated tests and CI checks, but as an
aid for developers while preparing code for review.

You do not need to check all the boxes below at once: feel free to add more
commits as necessary to cover all the relevant checks. Moreover, some checks may
not apply for specific Pull Requests - use your judgement :).

If you're done and ready for review, please check the last box.
-->

#### What is the purpose of this change?

<!--
Add a brief explanation of the change here.
-->

#### Is there a reference to a GitHub issue or Pivotal Tracker story that can help reviewers understand the context of this change?

<!--
Link relevant issues and stories here.
-->

#### How can a reviewer test this Pull Request?

<!--
Are there any special instructions on how to test any new functionality or
fixes? Ideally these would be clearly documented in the repo or elsewhere as
applicable.

Are there REST requests or GraphQL queries or mutations that can help test the
Pull Request manually, besides any Swagger or GraphQL documentation or automated
tests?
-->

#### Checklist

<!--
Feel free to add comments inline in the list below to explain specific bits that
would be helpful to reviewers.
-->

* [ ] have you made sure `tsc` transpiles the code successfully?
* [ ] does the service start successfully?
* [ ] if the Pull Request introduces new environment variables, have these been
      documented (`README.md` and `dev.env`) and configured properly
      (`config/*`, `k8s/**/*yml`)?
* [ ] if the Pull Request introduces new entities, views, etc. of if it changes
      or drops existing ones, have migrations been added and tested?
* [ ] have tests for all changes been added if applicable?
* [ ] have any new features been documented (developer and end user
      documentation, as applicable)?
* [ ] does any new code pass `tslint` checks?
* [ ] have relevant inline comments been added where appropriate? think about
      other engineers (or yourself!) reading particularly tricky bits of code
      in a few months: will it be easy to understand why the code is written
      in a specific way?
* [ ] has the PR been tested for functional and performance regressions?
* [ ] has the CHANGELOG been updated?

If the Pull Request introduces new REST endpoints or GraphQL queries or
mutations:

* [ ] have all the relevant Swagger decorators been added for
      documentation to be generated?
* [ ] if relevant, have examples of how to use the endpoints/queries/mutations
      been documented for API users and frontend engineers?

If all above looks good:

* [ ] I'm done, this Pull Request is ready for review :)
