
export interface IFileUploadObject {
  id: string;
  linkPublic: string;
  contentType: string;
  name: string;
}
