const nr = require('newrelic');

import { NestFactory } from '@nestjs/core';
import { AppModule } from 'app.module';
import { SwaggerModule, DocumentBuilder } from '@nestjs/swagger';
import * as config from 'config';
import * as helmet from 'helmet';
import * as cors from 'cors';
import { ValidationPipe } from 'pipes/validation.pipe';
import { HttpExceptionFilter } from 'filters/http-exception.filter';

const logger = require('logger');

async function bootstrap() {
  const app = await NestFactory.create(AppModule);
  app.use(helmet());
  app.use(cors());

  const options = new DocumentBuilder()
    .setTitle('Wildlife Insights API')
    .setDescription('Wildlife Insights API')
    .setVersion('1.0')
    .addBearerAuth('Authorization', 'header')
    .setHost(config.get('swagger.host'))
    .build();

  const document = SwaggerModule.createDocument(app, options);
  SwaggerModule.setup('/swagger', app, document);

  app.useGlobalPipes(new ValidationPipe());
  app.useGlobalFilters(new HttpExceptionFilter());

  await app.listen(3000);
}
bootstrap();
