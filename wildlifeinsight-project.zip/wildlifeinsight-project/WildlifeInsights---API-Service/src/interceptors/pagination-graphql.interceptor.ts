import { validate } from 'class-validator';

import { NestInterceptor, ExecutionContext } from '@nestjs/common';
import { Observable } from 'rxjs';
import { GqlExecutionContext } from '@nestjs/graphql';

export class PaginationGraphqlInterceptor implements NestInterceptor {

  async intercept(
    context: ExecutionContext,
    call$: Observable<any>,
  ): Promise<Observable<any>> {
    const args = context.getArgByIndex(1);
    // if (args.pagination) {
    //   if (args.pagination.sort) {
    //     args.pagination.sort = args.pagination.sort.map((stat: string) => {
    //       if (stat.startsWith('-')) {
    //         return { sort: stat.slice(1, stat.length), order: 'DESC' };
    //       }
    //       if (stat.startsWith('+'))  {
    //         return { sort: stat.slice(1, stat.length), order: 'ASC' };
    //       }
    //       return { sort: stat, order: 'ASC' };
    //     });
    //   }
    // }
    return call$;
  }
}
