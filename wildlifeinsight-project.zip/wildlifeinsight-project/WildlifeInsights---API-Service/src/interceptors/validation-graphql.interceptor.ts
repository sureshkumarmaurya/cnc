import { NestInterceptor, ExecutionContext } from '@nestjs/common';
import { Observable } from 'rxjs';
import { ValidationGraphql } from 'utils/validate.graphql';

export class ValidationGraphqlInterceptor implements NestInterceptor {
  constructor(private classType, private property: string = 'body') {}

  async intercept(
    context: ExecutionContext,
    call$: Observable<any>,
  ): Promise<Observable<any>> {
    const args = context.getArgByIndex(1);

    if (args[this.property]) {
      await ValidationGraphql.validate(this.classType, args[this.property]);
    }
    return call$;
  }
}
