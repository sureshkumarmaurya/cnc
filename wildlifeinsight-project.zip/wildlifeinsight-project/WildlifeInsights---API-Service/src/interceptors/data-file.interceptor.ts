import {
  ExecutionContext,
  Injectable,
  NestInterceptor,
  Inject,
} from '@nestjs/common';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { Repository } from 'typeorm';

export interface Response<T> {
  data: T;
}

@Injectable()
export class DataFileInterceptor<T> implements NestInterceptor<T, Response<T>> {
  constructor(
    @Inject('ExifTagsRepositoryToken')
    private readonly exifTagsRepository: Repository<any>,
  ) {
    this.setPropertyTagNames();
  }

  tagNames = <any>{};

  intercept(
    context: ExecutionContext,
    call$: Observable<any>,
  ): Observable<any> {
    return call$.pipe(map((data: any) => this.enrichByTagName(data)));
  }

  // Set property class tagName value
  async setPropertyTagNames() {
    this.tagNames = await this.getExifTags();
  }

  // Iterates data.exifDataFilePivots for add new tagName key and value
  enrichByTagName(data: any) {
    const { exifDataFilePivots } = data;
    data.exifDataFilePivots = exifDataFilePivots.map((item) => {
      const exifTag = this.tagNames.find(tag => item.exifTagId === tag.id);
      if (exifTag) {
        item.tagName = exifTag.tagName;
      }
      return item;
    });
    return data;
  }

  // Retrieves through exifTagsRepository id and tagName values
  async getExifTags(): Promise<any> {
    return await this.exifTagsRepository
      .createQueryBuilder('e')
      .select(['e.id', 'e.tagName'])
      .getMany();
  }
}
