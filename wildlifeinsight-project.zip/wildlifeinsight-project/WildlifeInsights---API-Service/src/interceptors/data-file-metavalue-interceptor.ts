import {
  ExecutionContext,
  Injectable,
  NestInterceptor,
  Inject,
} from '@nestjs/common';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { Repository } from 'typeorm';

export interface Response<T> {
  data: T;
}

@Injectable()
export class DataFileMetavalueInterceptor<T>
  implements NestInterceptor<T, Response<T>> {
  constructor(
    @Inject('DataFileMetakeysRepositoryToken')
    private readonly dateFileMetakeysRepository: Repository<any>,
  ) {}
  dateFileMetakeys = <any>{};

  intercept(
    context: ExecutionContext,
    call$: Observable<any>,
  ): Observable<any> {
    const dateFileId = context.switchToHttp().getRequest().params.dataFileId;
    this.setDateFileMetaKeys(dateFileId);
    return call$.pipe(map((data: any) => this.enrichData(data)));
  }

  // Iterates data and insert the corresponding data_file_metakey.key_name
  enrichData(data: any) {
    data.data.map((item) => {
      item.keyName = this.getDataFileMetakeyKeyNameById(item.keyId);
      return item;
    });
    return data;
  }

  // Returns the key_name of data_file_metakeys imported values
  getDataFileMetakeyKeyNameById(dataFileMetakeyId: number) {
    const match = this.dateFileMetakeys.find(
      item => item.id === dataFileMetakeyId,
    );
    if (match) {
      return match.keyName;
    }
  }

  // Set dateFileMetakeys property class
  async setDateFileMetaKeys(dateFileId) {
    return this.dateFileMetakeys = await this.getDateFileMetakeys(dateFileId);
  }

  // Retrieves through getDateFileMetakeys the data_file_metakeys values
  async getDateFileMetakeys(dateFileId: number): Promise<any> {
    return await this.dateFileMetakeysRepository
      .createQueryBuilder('d')
      .getMany();
  }
}
