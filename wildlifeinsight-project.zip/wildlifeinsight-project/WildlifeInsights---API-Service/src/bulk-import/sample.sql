BEGIN;
WITH seq AS (
     SELECT id FROM sequences WHERE name = 'KEN-007-D0001-1' AND deployment_id = 2
     ),
     data_file AS (
     INSERT INTO data_files(filepath, thumbnail_url, filename, "timestamp", deployment_id, media_types_id) VALUES (
     	    '/this/would/be/a/path', '/this/would/be/a/thumbnail/path', 'SAMPLE_IMAGE_001.JPG', '1999-01-08 04:05:06', 2, 1
     	    ) RETURNING id
     ),
     identification_output AS (
     INSERT INTO identification_outputs(blank_yn, data_file_id, identification_methods_id, participants_id) VALUES (
     	    FALSE, (SELECT id FROM data_file), 1, 1
     	    ) RETURNING id
     )
     SELECT 1;
COMMIT;
