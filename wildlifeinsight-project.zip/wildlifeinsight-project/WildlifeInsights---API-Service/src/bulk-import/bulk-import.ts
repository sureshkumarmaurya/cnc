/**
 * Bulk import script: see README_bulk-data-import.md for details
 *
 * Usage: npm run bulk-import <organization_id> <data_file>
 *
 * Where organization_id is the numeric ID of the organization for which data
 * will be imported, and data_file is either the path to a file, or the URI
 * where a data file could be accessed via HTTP/HTTPS
 */
import { importProject } from './import-data';
const logger = require('logger');

run();

function run() {
  // Parse CLI arguments and exit if no suitable arguments were passed
  const organizationId: number = process.argv && process.argv.length > 4 ?
  +process.argv[2] :
  null;

  const participantId: number = process.argv && process.argv.length > 4 ?
  +process.argv[3] :
  null;

  const dataFile: string = process.argv && process.argv.length > 4 ?
  process.argv[4] :
    null;

  const target: string = process.argv && process.argv.length > 4 ?
  process.argv[5] :
  null;

  if (organizationId === null || participantId === null || dataFile === null) {
    console.error(`Usage: ${process.argv[0]} <organizationId> <participantId> </path/to/payload.json> <target>`);
    console.error('<organizationId>: the numeric id of the organization under which the projects should be created.');
    console.error('<participantId>: the numeric id of the user who will be first owner of the projects.');
    console.error('</path/to/payload.json>: path to the file containing JSON data for the projects to be created.');
    console.error('<target>: name of the batch uploads target.');
    process.exit(1);
  }

  // If suitable arguments have been passed on the CLI, try loading data_file
  // and importing its data into the organization with numeric ID
  // organization_id
  logger.info(`Importing data from ${dataFile} for organization with id ${organizationId}, with user with id ${participantId} as first owner.`);

  let data;

  // Try interpreting data_file CLI argument as URI first; if this doesn't work,
  // try to interpret argument as name of local file, and load data from it.

  try {
    logger.info(`Reading JSON data from file ${dataFile}`);
    data = require(`${dataFile}`); // Will prob. parse the JSON instead
  } catch (error) {
    logger.error(error);
    process.exit(1);
  }

  // We should have data from a file: try to import this.
  importProject(organizationId, participantId, data, target).then(
    () => logger.info('Data was imported successfully.'),
    logErrorAndExit,
  );
}

function logErrorAndExit(err) {
  console.error('Error importing data', err);
  process.exit(1);
}
