import { BatchUploads } from 'modules/database/entities/batch-uploads.entity';
import { ParticipantTypes } from 'modules/database/entities/participant-types.entity';
import { createConnection } from 'typeorm';
import { Organizations } from 'modules/database/entities/organizations.entity';
import { Projects } from 'modules/database/entities/projects.entity';
import { Participants } from 'modules/database/entities/participants.entity';
import { Devices } from 'modules/database/entities/devices.entity';
import { BaitTypes } from 'modules/database/entities/bait-types.entity';
import { Locations } from 'modules/database/entities/locations.entity';
import { DataFiles } from 'modules/database/entities/data-files.entity';
import { Deployments } from 'modules/database/entities/deployments.entity';
import { Sequences } from 'modules/database/entities/sequences.entity';
import { MediaTypes } from 'modules/database/entities/media-types.entity';
import { IdentificationOutputs } from 'modules/database/entities/identification-outputs.entity';
import { IdentifiedObjects } from 'modules/database/entities/identified-objects.entity';
import { DataFileSequencePivot } from 'modules/database/entities/data-file-sequence-pivot.entity';
import { IdentificationMethods } from 'modules/database/entities/identification-methods.entity';
import { Taxonomies } from 'modules/database/entities/taxonomies.entity';
import { SlugUtils, NameUtils } from 'utils/slug.utils';
import { profileOp } from 'utils/performance.utils';
import { PairedDeployments } from 'modules/database/entities/paired-deployments.entity';
import { Features } from 'modules/database/entities/features.entity';
import { Initiatives } from 'modules/database/entities/initiatives.entity';
import { IdentifiedIndividuals } from 'modules/database/entities/identified-individuals.entity';
import { ParticipantTypeProjectPivot } from 'modules/database/entities/participant-type-project-pivot.entity';
import { Roles } from 'modules/database/entities/roles.entity';
import { Countries } from 'modules/database/entities/countries.entity';

const config = require('config');
const logger = require('logger');
const tempy = require('tempy');
const uuidv4 = require('uuid/v4');
const fs = require('fs');

const gcs = require('@google-cloud/storage')({
  keyFilename: process.env.GOOGLE_APPLICATION_CREDENTIALS,
});

const gcPubSub = require('@google-cloud/pubsub');

const createWIBuckets = async (slug) => {
  const gcStorage = require('@google-cloud/storage');
  const storage = new gcStorage();

  const mainBucket = { slug: `${slug}__main` };
  const thumBucket = { slug: `${slug}__thumbnails` };
  logger.debug(`mainBucket: ${mainBucket.slug}`);
  logger.debug(`thumBucket: ${thumBucket.slug}`);
  mainBucket['exists'] = await gcs.bucket(mainBucket.slug).exists();
  thumBucket['exists'] = await gcs.bucket(thumBucket.slug).exists();
  logger.debug(`mainBucketExists: ${mainBucket['exists']}`);
  logger.debug(`thumBucketExists: ${thumBucket['exists']}`);
  await Promise.all([mainBucket, thumBucket].map(async (bucket) => {
    logger.debug(`Bucket ${bucket.slug} exists: ${bucket['exists']}`);
    await storage
      .createBucket(bucket.slug)
      .then(() => logger.debug(`Bucket ${bucket.slug} created`))
      .catch(err => logger.error(`Error creating bucket ${bucket.slug}: ${err}`));
  }));
  return { mainBucket, thumBucket };
};

async function triggerBatchDataFileMove(
  topicName: string,
  data: object,
) {
  const pubsub = new gcPubSub();

  const dataBuffer = Buffer.from(JSON.stringify(data));

  const messageId = await pubsub
    .topic(topicName)
    .publisher()
    .publish(dataBuffer)
    .then((results) => {
      const messageId = results[0];
      logger.info(`Message ${messageId} published.`);
      return messageId;
    })
    .catch(err => logger.error('ERROR:', err));

  logger.debug(`Message ${messageId} published.`);
}

const publishBatchedMessages = async (
  topicName: string,
  data: object,
  maxMessages: number,
  maxWaitTime: number,
) => {
  // Create a client
  const pubsub = new gcPubSub();

  // Publish the message as a string, e.g. "Hello, world!" or JSON.stringify(someObject)
  const dataBuffer = Buffer.from(JSON.stringify(data));

  const [messageId] = await pubsub
  .topic(topicName)
  .publisher(/*{
    batching: {
      maxMessages: maxMessages,
      maxMilliseconds: maxWaitTime,
    },
  }*/)
  .publish(dataBuffer)
  .then((results) => {
    const messageId = results[0];
    logger.info(`Message ${messageId} published.`);
  })
  .catch(err => logger.error('ERROR:', err));

  logger.debug(`Message ${messageId} published.`);
};

/**
 * Import project data and associated deployment data
 * @param organizationId Numeric ID of the organization for which projects and
 * deployments should be created.
 * @param participantId Numeric ID of the participant who should be made first
 * owner of the project being greated.
 * @param data Manifest of a project and its associated deployments, as
 * generated via the bulk-import data preparation scripts (see
 * README_bulk-data-import.md for details)
 * @param target Name of the directory in the import bucket where to
 * output artifacts
 */
export const importProject = async (organizationId: number, participantId: number, data, target: string) => {
  const connection = await createConnection({
    type: 'postgres',
    url: config.get('postgres.url'),
    entities: [`${__dirname}/../modules/database/entities/*.entity{.ts,.js}`],
    synchronize: false,
    migrationsRun: false,
  });

  const organizationsRepository = connection.getRepository(Organizations);
  const projectsRepository = connection.getRepository(Projects);
  const devicesRepository = connection.getRepository(Devices);
  const locationsRepository = connection.getRepository(Locations);
  const deploymentsRepository = connection.getRepository(Deployments);
  const batchUploadsRepository = connection.getRepository(BatchUploads);
  const baitTypesRepository = connection.getRepository(BaitTypes);
  const pairedDeploymentsRepository = connection.getRepository(PairedDeployments);
  const initiativesRepository = connection.getRepository(Initiatives);
  const participantsRepository = connection.getRepository(Participants);
  const participantTypeProjectPivot = connection.getRepository(ParticipantTypeProjectPivot);
  const participantTypesRepository = connection.getRepository(ParticipantTypes);
  const rolesRepository = connection.getRepository(Roles);
  const countriesRepository = connection.getRepository(Countries);

  if (data) {
    const organization = await organizationsRepository.findOne({ where: { id: organizationId } });
    if (!organization) {
      logger.error(`No organization found with numeric id supplied (${organizationId})`);
      process.exit(1);
    }

    const participant = await participantsRepository.findOne({ where: { id: participantId } });
    if (!participant) {
      logger.error(`No participant found with numeric id supplied (${participantId})`);
      process.exit(1);
    }

    const projectOwnerRole = await rolesRepository.findOne({ where: { name: 'PROJECT_OWNER' } });
    const principalInvestigator = await participantTypesRepository.findOne({ where: { typeName: 'PRINCIPAL INVESTIGATOR' } });

    const batchUploadJob = await batchUploadsRepository.findOne({
      where: { target },
    });
    logger.debug(`Batch uploads job found: ${JSON.stringify(batchUploadJob)}`);

    // Look up initial owner: this is the user whose id is currently associated
    // to the batch uploads job
    const initialOwner = await participantsRepository.findOne({ where: { id: batchUploadJob.participantId } });

    for (const datum of data) {
      // First check whether a project with the same slug (which has an unique
      // constraint in db) exists, and if so reuse it
      const projectSlug = SlugUtils.convertAndPrefix(datum.project_name);
      let project = await projectsRepository.findOne({
        where: { slug: projectSlug },
      });

      // Need to figure out how to inject the storage module properly
      logger.debug('Persisting project buckets');
      const projectBuckets = await createWIBuckets(projectSlug);

      if (project === undefined) {
        const projectCreationStart = process.hrtime();
        project = new Projects();
        project.slug = projectSlug;
        project.name = NameUtils.prefix(datum.project_name);
        project.shortName = NameUtils.trimShortName(datum.project_id);
        project.objectives = datum.project_objectives;
        project.embargo = datum.embargo;
        project.organization = organization;
        project.metadataLicense = datum.metadata_license;
        project.dataFilesLicense = datum.image_license;

        // Parent initiative
        let parentInitiative : Initiatives;
        if (datum.initiative_id) {
          parentInitiative = await initiativesRepository.findOne({
            where: {
              id: datum.initiative_id,
            },
          });

          if (parentInitiative) {
            project.initiative = parentInitiative;
          } else {
            logger.warn(`Initiative with id ${datum.initiative_id} was specified as parent of this project, but no such initiative exists.`);
          }
        }

        // For bulk import fields that don't map to individual db fields,
        // iterate over known keys, collect values that are actually in the
        // source data, and finally store this object in the `metadata` JSONB
        // field
        const projectMetadata = {};

        ['project_species',
          'project_species_individual',
          'project_sensor_layout',
          'project_sensor_layout_targeted_type',
          'project_bait_use',
          'project_bait_type',
          'project_stratification',
          'project_stratification_type',
          'project_sensor_method',
          'project_individual_animals',
          'project_blank_images',
          'project_sensor_cluster',
          'project_admin',
          'project_admin_email',
          'country_code']
          .forEach((key) => {
            if (datum[key]) {
              projectMetadata[key] = datum[key];
            }
          });
        project.metadata = projectMetadata;

        logger.debug('Persisting project to DB');
        project = await projectsRepository.save(project);
        logger.debug(profileOp('Project created via API', projectCreationStart));
      } else {
        logger.info(`Project with slug "${SlugUtils.convertAndPrefix(datum.project_name)}" is already defined: adding deployments to this.`);
      }

      // Make the user associated to the batch uploads job the first owner of
      // the project being created
      const ptpp = new ParticipantTypeProjectPivot();
      ptpp.participant = initialOwner;
      ptpp.role = projectOwnerRole;
      ptpp.project = project;
      ptpp.participantType = principalInvestigator;
      await participantTypeProjectPivot.save(ptpp);

      const projectDeploymentsCreationStart = process.hrtime();

      for await (const deploymentData of datum.deployments) {
        // First check whether a project with the same slug (which has an unique
        // constraint in db) exists, and if so reuse it
        const deployment = await deploymentsRepository.findOne({
          where: {
            project,
            deploymentIdentifier: deploymentData.code,
          },
        });

        if (deployment === undefined) {
          const deploymentCreationStart = process.hrtime();

          logger.debug('Looking up whether a location already exists for the deployment being created');
          let location : Locations = await locationsRepository.findOne({
            projectId: project.id,
            placename: deploymentData.location.placename,
          });
          if (location == null) {
            logger.debug('Creating a new location for this deployment');
            location = new Locations();
            location.latitude = deploymentData.location.latitude;
            location.longitude = deploymentData.location.longitude;
            location.placename = deploymentData.location.placename;
            location.geodeticDatum = deploymentData.location.geodeticDatum || 'WGS84';
            location.project = project;

            const country = await countriesRepository
              .createQueryBuilder('country')
              .innerJoinAndSelect('country.geoRegion', 'geo_region')
              .where('ST_Intersects(geo_region.region::geometry, ST_SetSRID(ST_Point(:longitude, :latitude), 4326))',
                     {
                longitude: deploymentData.location.longitude,
                latitude:  deploymentData.location.latitude,
              })
              .getOne();

            const countryCode = (country) ? country.iso3166A3 : datum.country_code;

            if (countryCode.length !== 3) {
              logger.warn(
`No country data could be retrieved by reverse-geocoding the location's coordinates
(latitude: ${deploymentData.location.latitude}, longitude: ${deploymentData.location.longitude}),
and the country code (${countryCode}) supplied for the project (${datum.project_name})
is not a valid ISO3166-alpha3 code.`);
            } else {
              location.country = countryCode;
            }

            await locationsRepository.save(location);
          }

          logger.debug('Creating device for this deployment');
          for (const camera of deploymentData.camera) {
            // check if a matching camera already exists
            let device : Devices = await devicesRepository.findOne({
              organization,
              name: camera.camera_id,
            });
            if (device == null) {
              // logger.debug(camera);
              device = new Devices();
              device.name = camera.camera_id;
              device.make = camera.make;
              device.model = camera.model;
              device.serialNumber = camera.serial_number;
              if (camera.year_purchased) {
                // The batch uploads dictionary variable for this is
                // year_purchased, but it should actually store the date of
                // purchase. Except when it doesn't, and stores the year.
                // Moreover, we store date *and* year in the database (don't ask),
                // so here we first make sure that the value we save in the
                // `device.purchaseDate` field is an actual date, setting year and
                // month to 1st of January arbitrarily, then we extract the year
                // for the `device.purchaseYear` field.
                if (camera.year_purchased.match(/^\d\d\d\d$/)) {
                  camera.year_purchased = `${camera.year_purchased}-01-01`;
                }
                device.purchaseDate = camera.year_purchased;
                device.purchaseYear = camera.year_purchased ? new Date(camera.year_purchased).getFullYear() : null;
              }
              device.organization = organization;
              await devicesRepository.save(device);
            }
          }

          logger.debug('Creating deployments');
          const deployment = new Deployments();

          deployment.project = project;
          logger.debug(`Linking camera with id ${deploymentData.camera[0].camera_id} to deployment`);
          deployment.device = await devicesRepository.findOne({
            organization,
            name: deploymentData.camera[0].camera_id,
          });
          deployment.deploymentName = deploymentData.deployment_id;
          deployment.deploymentIdentifier = deploymentData.deployment_id;
          deployment.location = location;
          deployment.startDatetime = deploymentData.start_datetime ? deploymentData.start_date : null;
          deployment.endDatetime = deploymentData.end_datetime ? deploymentData.end_date : null;
          deployment.quietPeriod = deploymentData.quiet_period ? deploymentData.quiet_period : null;
          deployment.sensorFailureDetails = deploymentData.sensor_failure_details;
          deployment.sensorOrientation = deploymentData.sensor_orientation;

          // Bait type
          logger.debug('Looking up bait type');
          const baitType : BaitTypes = await baitTypesRepository.findOne({
            where: {
              typeName: deploymentData.bait_type,
            },
          });
          deployment.baitType = baitType;

          // Deployment array If this deployment is part of a deployment of an
          // array of paired deployments, first try to look up a deployment with
          // same name from those already defined; if none exists, create one.
          // We assume that start_date and end_date of all paired deployments
          // are the same, so we just set these from the start_date and end_date
          // of the first deployment in the array from which we create the
          // paired deployment here.
          let pairedDeployment : PairedDeployments;
          if (deploymentData.array_name) {
            pairedDeployment = await pairedDeploymentsRepository.findOne({
              where: {
                name: deploymentData.array_name,
              },
            });

            if (pairedDeployment) {
              deployment.pairedDeployments = pairedDeployment;
            } else {
              pairedDeployment = new PairedDeployments();
              pairedDeployment.name = deploymentData.array_name;
              pairedDeployment.startDate = deploymentData.start_date;
              pairedDeployment.endDate = deploymentData.end_date;
              pairedDeploymentsRepository.save(pairedDeployment);
            }
          }

          // For bulk import fields that don't map to individual db fields,
          // iterate over known keys, collect values that are actually in the
          // source data, and finally store this object in the `metadata` JSONB
          // field
          const deploymentMetadata = {};

          ['event', 'feature_type_methodology', 'sensor_height', 'height_other', 'orientation_other', 'recorded_by']
            .forEach((key) => {
              if (deploymentData[key]) {
                deploymentMetadata[key] = deploymentData[key];
              }
            });

          /**
           * Fields that map to a singleton array in `deployments.metadata` need
           * a special treatment - that is, inserted as part of an array rather
           * than as plain values.
           */
          ['feature_type']
            .forEach((key) => {
              if (deploymentData[key]) {
                deploymentMetadata[key] = [deploymentData[key]];
              }
            });

          deployment.metadata = deploymentMetadata;

          const savedDeployment = await deploymentsRepository.save(deployment);
          const deploymentImageData = deploymentData.images;

          logger.debug(profileOp('Deployment created via API', deploymentCreationStart));
        } else {
          logger.info(`Deployment with deploymentIdentifier "${deploymentData.code}" is already defined: skipping creation.`);
        }
      }
      logger.debug(profileOp('All project deployments created via API', projectDeploymentsCreationStart));
      logger.debug(process.env.NODE_ENV);
    }

    try {
      // Once deployments have been created, set status of the batch upload job
      // to `DEPLOYMENTS_CREATED`
      logger.debug(`Project and deployments created. Updating status of batch uploads job ${target} to status 'DEPLOYMENTS_CREATED'`);
      batchUploadJob.status = 'DEPLOYMENTS_CREATED';
      await batchUploadsRepository.save(batchUploadJob);
    } catch (err) {
      logger.error(`Could not update status of batch uploads job ${target}: ${err}`);
    }
  }
  process.exit(0);
};

/**
 * Import dataFiles (& sequences) to db, then trigger cloud function that does
 * the actual moving of data file blobs to the final storage bucket.
 * @param organizationId Numeric ID of the organization for which projects and
 * deployments should be created.
 * @param data Manifest of a project and its associated deployments, as
 * generated via the bulk-import data preparation scripts (see
 * README_bulk-data-import.md for details)
 * @param target Name of the directory in the import bucket where to
 * output artifacts
 */
export const importDataFiles = async (organizationId: number, data: any, target: string, imageBatchSizeLimit: number) => {
  const connection = await createConnection({
    type: 'postgres',
    url: config.get('postgres.url'),
    entities: [`${__dirname}/../modules/database/entities/*.entity{.ts,.js}`],
    synchronize: false,
    migrationsRun: false,
  });

  const organizationsRepository = connection.getRepository(Organizations);
  const projectsRepository = connection.getRepository(Projects);
  const deploymentsRepository = connection.getRepository(Deployments);
  const sequencesRepository = connection.getRepository(Sequences);
  const dataFilesRepository = connection.getRepository(DataFiles);
  const mediaTypesRepository = connection.getRepository(MediaTypes);
  const identificationMethodsRepository = connection.getRepository(IdentificationMethods);
  const taxonomiesRepository = connection.getRepository(Taxonomies);
  const participantsRepository = connection.getRepository(Participants);
  const batchUploadsRepository = connection.getRepository(BatchUploads);

  if (data) {
    logger.debug(`Looking up organization with id ${organizationId}`);

    const orgLookupStart = process.hrtime();

    const organization = await organizationsRepository.findOne({
      where: { id: organizationId },
    });

    logger.debug(profileOp('Organization data fetched from API', orgLookupStart));

    logger.debug(`Organization data: ${JSON.stringify(organization)}`);

    if (organization === undefined) {
      logger.error(`No organization found with numeric id supplied (${organizationId})`);
      process.exit(1);
    }

    // Retrieve UUIDs of all the taxonomy entries for humans. This will be used
    // when processing each data file, to set its `humanIdentified` status
    // according to whether humans have been identified in each data file being
    // imported.
    const humanTaxonomiesUUIDs = await taxonomiesRepository.find({
      where: {
        genus: 'Homo',
      },
    }).then((taxonomies) => {
      return taxonomies.map(i => i.uniqueIdentifier);
    });

    // All identificationOutputs are associated to the stock Wildlife Insights
    // Import Bot user during batch uploads. If this user cannot be found in the
    // database, inform the user and stop the import process.
    const wiImportBotUser = await participantsRepository.findOne({ where: { email: config.get('batchUploads.importBotUser.email') } });
    if (!wiImportBotUser) {
      logger.error(
        `Cannot find an import bot user. We have searched for a user whose email
        address is ${config.get('batchUploads.importBotUser.email')} as
        configured in the API service's configuration. Please make sure a user
        with this email address exists, or update the API service's
        configuration to match the email address of a suitable existing user.`);
      process.exit(1);
    }

    // image metadata is pushed to transferTargets, which is then used to
    // orchestrate copying of images to buckets (image and thumbnail)
    const transferTargets = [];

    for (const datum of data) {
      const projectSlug = SlugUtils.convertAndPrefix(datum.project_name);
      const projectBuckets = await createWIBuckets(projectSlug);
      const mainBucket = `${projectSlug}__main`;
      const thumBucket = `${projectSlug}__thumbnails`;
      const project = await projectsRepository.findOne({
        where: { slug: projectSlug },
      });

      if (project === undefined) {
        logger.error(`No project found with needed slug (${projectSlug})`);
        process.exit(1);
      }

      const jpgMediaType = await mediaTypesRepository.findOne({
        where: { mime: 'image/jpeg' },
      });

      const expertIdentification = await identificationMethodsRepository.findOne({
        where: { type_name: 'Expert identification' },
      });

      const allTaxonomies = await taxonomiesRepository.createQueryBuilder('taxonomy').getMany();

      // logger.debug(`All taxonomies: ${all_taxonomies}`);
      // logger.debug(`Project data: ${JSON.stringify(project)}`);

      // CHANGE
      const localSequences = [];
      const localImages = [];

      for await (const deploymentData of datum.deployments) {
        // logger.debug(`Deployment data: ${JSON.stringify(deploymentData)}`);

        // First check whether a project with the same slug (which has an unique
        // constraint in db) exists, and if so reuse it
        const deployment = await deploymentsRepository.findOne({
          where: {
            project,
            deploymentIdentifier: deploymentData.deployment_id,
          },
        });
        // logger.debug(`Project data: ${JSON.stringify(project)}`);
        // logger.debug(`Deployment: ${JSON.stringify(deployment)}`);

        ///////////////
        // SEQUENCES //
        ///////////////

        const dedup = list => list.filter((v, i) => list.indexOf(v) === i);
        const sequencesData = dedup(deploymentData.images.map(image => image.sequence));

        // can't do that thing below!! -- Type '{}[]' is not assignable to type 'string[]'
        // It'd really be much better to get unique sequences :-|
        // const unique_sequences_data: string[] = [...new Set(sequences_data.map(String))];
        logger.debug(`Sequences: ${sequencesData}`);

        for await (const sequenceData of sequencesData) { // unique_sequences_data) {
          logger.debug(`Processing sequence: ${sequenceData}`);
          if (sequenceData) {
            let sequence = await sequencesRepository.findOne({
              where: {
                deployment,
                name: sequenceData,
              },
            });

            if (sequence === undefined) {
              sequence = new Sequences();
              sequence.name = sequenceData;
              sequence.sequenceIdentifier = sequenceData; // Uhm
              sequence.deployment = deployment;
              sequence = await sequencesRepository.save(sequence);
            }
            localSequences.push(sequence);
            logger.debug(`sequence: ${JSON.stringify(sequence)}`);
          }
        }

        const imagesData = deploymentData.images;

        logger.debug(`Importing ${imagesData.length} images to deployment ${deployment.id}`);

        logger.debug(`Using sequences ${JSON.stringify(localSequences)}`);

        for await (const imageData of imagesData) {
          if (localImages.length >= imageBatchSizeLimit) {
            break;
          }

          // logger.debug(`Processing image: ${JSON.stringify(imageData)}`);
          const imageUuid = uuidv4();

          // Construct filepath
          // deployment/1/0111b5d2-3555-44a2-b0bb-431afd283723.jpg
          const imageFilepath = `deployment/${deployment.id}/${imageUuid}.jpg`; // Should consider extension explicitly

          // Costruct thumbnail_url
          // https://storage.googleapis.com/refill_supplies_in_the_fridge__thumbnails/deployment/1/256e3e96-076e-463c-aeb2-6b74a8e9f561.jpg
          const imageThumbnailUrl = `https://storage.googleapis.com/${project.slug}__thumbnails/deployment/${deployment.id}/${imageUuid}.jpg`;

          const image = new DataFiles();
          // image.filename was set from image_data.raw_name originally, but this field is not in the bulk import dictionary
          image.filename = imageUuid;
          image.dataFileId = imageData.image_id;
          image.originalLocationUrl = imageData.location;
          image.deployment = deployment;
          image.filepath = imageFilepath;
          image.thumbnailUrl = imageThumbnailUrl;
          image.mediaType = jpgMediaType;
          image.highlighted  = imageData.highlighted ? true : false;
          image.timestamp = imageData.timestamp;

          // For bulk import fields that don't map to individual db fields,
          // iterate over known keys, collect values that are actually in the
          // source data, and finally store this object in the `metadata` JSONB
          // field
          const imageMetadata = {};

          ['identified_by']
            .forEach((key) => {
              if (imageData[key]) {
                imageMetadata[key] = imageData[key];
              }
            });
          image.metadata = imageMetadata;

          // Set image status to BLANK if applicable
          if (imageData.is_blank && (imageData.is_blank === '1' || imageData.is_blank === true)) {
            image.status = 'BLANK';
          }

          // Attach to sequence
          // let sequence = await sequencesRepository.findOne({
          //   where: {
          //     deployment: deployment,
          //     name: image_data.sequence
          //   }
          // });

          const sequence = localSequences.filter(seq => seq.name === imageData.sequence)[0];

          let dataFileSequencePivots;
          if (sequence === undefined) {
            dataFileSequencePivots = null;
          } else {
            logger.debug(`Attaching dataFile to sequence ${JSON.stringify(sequence)}`);
            dataFileSequencePivots = new DataFileSequencePivot();
            dataFileSequencePivots.sequence = sequence;
            dataFileSequencePivots.position = imageData.position;
            image.dataFileSequencePivots = [dataFileSequencePivots];
          }

          let humansIdentifiedInDataFile = false;

          if (imageData.identifications) {
            image.status = 'VERIFIED';
            image.identifiedByExpert = true;
            // Identification output
            const identificationOutputs = new IdentificationOutputs();
            identificationOutputs.blankYn = (
              imageData.identifications.length < 1 ||
              imageData.identifications === undefined ||
              imageData.is_blank === true // this is part of the technical debt above
            ) ? true : false;
            identificationOutputs.identificationMethod = expertIdentification;
            identificationOutputs.participantId = wiImportBotUser.id;
            // IdentifiedObjects
            const identificationsData = imageData.identifications;
            const identifiedObjects = [];
            for await (const identifiedObjectData of identificationsData) {
              const taxonomy = allTaxonomies.filter(taxonomy => taxonomy.uniqueIdentifier === identifiedObjectData.wi_taxon_id)[0];

              if (taxonomy === undefined) {
                logger.error(`No matching taxonomy found for UUID ${identifiedObjectData.wi_taxon_id}: please check taxonomy data in source dataset`);
              } else {
                const identifiedObject = new IdentifiedObjects();
                identifiedObject.taxonomy = taxonomy;
                identifiedObject.taxonomyId = taxonomy.uniqueIdentifier;

                // If this is an identification of a human, set humanIdentified
                // to true so that we can then set this flag for the data file
                // itself
                if (humanTaxonomiesUUIDs.includes(identifiedObject.taxonomyId)) {
                  humansIdentifiedInDataFile = true;
                }

                identifiedObject.sex = identifiedObjectData.sex;
                identifiedObject.relativeAge = identifiedObjectData.age;

                if (identifiedObjectData.individual_id) {
                  const identifiedIndividual = new IdentifiedIndividuals();
                  identifiedIndividual.name = identifiedObjectData.individual_id;
                  identifiedIndividual.identifiedAnimals = identifiedObject;
                }

                // Since we don't have db fields for the color and
                // individual_animal_notes fields of the bulk import dictionary,
                // we store this information in the `remarks` text field
                const identifiedObjectRemarks : object = {};
                ['color', 'individual_animal_notes'].forEach((remark) => {
                  if (identificationsData[remark]) {
                    identifiedObjectRemarks[remark] = identifiedObjectData[remark];
                  }
                });

                identifiedObject.remarks = JSON.stringify(identifiedObjectRemarks);

                /**
                 * If the identification being processed is that of an animal or
                 * a human, the source data will typically include a count N of
                 * individuals of the same species seen in the data file, in the
                 * `number_of_animals` field.
                 *
                 * In this case, we duplicate the identification N times.
                 *
                 * Otherwise (if the data is missing or is invalid, such as
                 * non-integer, zero or negative - although any of the latter
                 * would be rejected by the validator), we assume that only one
                 * 'individual' has been identified.
                 *
                 * This also covers the common case when the identification is
                 * representing an event (such as `Setup_Pickup` or `Misfire`
                 * entries of the `taxonomies` table) or uncertainty about the
                 * number and type of identified objects (`Unknown` entry of the
                 * taxonomy table).
                 */
                if (identifiedObjectData.number_of_animals && identifiedObjectData.number_of_animals > 0) {
                  for (let i = 0; i < identifiedObjectData.number_of_animals; i++) {
                    identifiedObjects.push(identifiedObject);
                  }
                } else {
                  identifiedObjects.push(identifiedObject);
                }

                image.status = identificationOutputs.blankYn ? 'BLANK' : 'VERIFIED';
              }
            }
            identificationOutputs.identifiedObjects = identifiedObjects;

            image.identificationOutputs = [identificationOutputs];
          }

          // set the data file's `humanIdentified` flag
          image.humanIdentified = humansIdentifiedInDataFile;

          localImages.push(image);

          // temporary hack to test downloading source blobs via gs
          if (imageData.location.match(/^https:\/\/storage.cloud.google.com\/cameratraprepo-vcm\//)) {
            imageData.location = imageData.location.replace('https://storage.cloud.google.com/cameratraprepo-vcm/', 'gs://cameratraprepo-vcm/');
          }

          transferTargets.push({
            id: imageData.image_id,
            source: imageData.location,
            sink_bucket: mainBucket,
            sink_path: `${imageFilepath}`,
            process: {
              move: true,
              exif: true,
              tfrecord: true,
            },
            extra_metadata: image.identificationOutputs && image.identificationOutputs[0] && image.identificationOutputs[0].identifiedObjects ? image.identificationOutputs[0].identifiedObjects.map((item) => {
              const data = {
                genus: item.taxonomy.genus,
                species: item.taxonomy.species,
                is_blank: image.identificationOutputs[0].blankYn,
              };

              if (!data.genus) { delete data.genus; }
              if (!data.species) { delete data.species; }

              return data;
            }) : [],
          });
        }
      }

      logger.debug(`Number of images to load: ${localImages.length}`);
      // Let's see...

      const chunkedLocalImages = [];
      while (localImages.length) {
        chunkedLocalImages.push(localImages.splice(0, 50));
      }

      for (let i = 0; i < chunkedLocalImages.length; i++) {
        await dataFilesRepository.save(chunkedLocalImages[i]);
      }
    }
    // let all_images = await dataFilesRepository.save(localImages);
    logger.debug('All images loaded into db');

    try {
      // Once ingestion of images has been queued via PubSub, set status of the
      // batch upload job to `IMAGE_INGESTION_STARTED`
      logger.debug(`Ingestion of data files queued. Updating status of batch uploads job ${target} to status 'IMAGE_INGESTION_STARTED'`);
      const batchUploadJob = await batchUploadsRepository.findOne({
        where: { target },
      });
      batchUploadJob.status = 'IMAGE_INGESTION_STARTED';
      await batchUploadsRepository.save(batchUploadJob);
    } catch (err) {
      logger.error(`Could not update status of batch uploads job ${target}: ${err}`);
    }

    logger.debug('Triggering image blob import via cloud pubsub');

    // Split list of data files metadata for the batch_move_data_files cloud
    // function in batches of 100 each, and trigger the cloud function for each
    // of these.
    let batchIndex = 0;
    while (transferTargets.length) {
      const dataFiles = transferTargets.splice(0, 50);
      await triggerBatchDataFileMove(
        'projects/wildlifeinsights-external/topics/batch_move_data_files',
        {
          batch_index: batchIndex,
          data_files: dataFiles,
        },
      );
      fs.writeFileSync(`/tmp/target_${target}_${batchIndex}.json`, JSON.stringify(dataFiles));
      batchIndex++;
    }

    process.exit(0);
  }
};
