import { AuthenticatedUserDto } from './authenticated-user.dto';
import { PaginationModel } from 'utils/pagination.model';

export type InfoDto = {
  params?: any,
  authenticatedUser?: AuthenticatedUserDto,
  pagination?: PaginationModel,
  others?: any,
};
