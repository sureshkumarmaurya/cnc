import { ParticipantsDto } from 'modules/database/dto/participants.dto';
import { RolesDto } from 'modules/database/dto/roles.dto';
import { ProjectsDto } from 'modules/database/dto/projects.dto';
import { OrganizationsDto } from 'modules/database/dto/organizations.dto';
import { InitiativesDto } from 'modules/database/dto/initiatives.dto';

export class AuthenticatedUserDto {
  user: ParticipantsDto;
  generalRole: RolesDto;
  projectRole?: {
    project?: ProjectsDto,
    role?: RolesDto,
    isImplicit: boolean,
  }[];
  organizationRole?: {
    organization?: OrganizationsDto,
    role?: RolesDto,
  }[];
  initiativeRole?: {
    initiative?: InitiativesDto,
    role?: RolesDto,
    isImplicit: boolean,
  }[];
}
