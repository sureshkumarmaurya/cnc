import { ParticipantTypes } from '../modules/database/entities/participant-types.entity';
import { Permissions } from '../modules/database/entities/permissions.entity';
import { createConnection, Repository, Connection, EntityMetadata } from 'typeorm';
import { Roles } from '../modules/database/entities/roles.entity';
import { Organizations } from '../modules/database/entities/organizations.entity';
import { Projects } from '../modules/database/entities/projects.entity';
import { Participants } from '../modules/database/entities/participants.entity';
import { SlugUtils } from '../utils/slug.utils';
import { Devices } from '../modules/database/entities/devices.entity';
import { Sensors } from '../modules/database/entities/sensors.entity';
import { BaitTypes } from '../modules/database/entities/bait-types.entity';
import { hash } from 'bcrypt';
import { OrganizationParticipantPivot } from '../modules/database/entities/organization-participant-pivot.entity';
import { ROLES } from '../utils/roles.enum';
import { Providers } from '../modules/database/entities/providers.entity';
import { ParticipantTypeModule } from '../modules/api/v1/participantTypes/participant-type.module';
import { ParticipantTypeProjectPivot } from '../modules/database/entities/participant-type-project-pivot.entity';
import { Locations } from '../modules/database/entities/locations.entity';
import { MediaTypes } from '../modules/database/entities/media-types.entity';
import { Deployments } from '../modules/database/entities/deployments.entity';
import { PythonShell } from 'python-shell';
import { IdentificationMethods } from '../modules/database/entities/identification-methods.entity';
import { Sequences } from '../modules/database/entities/sequences.entity';
import { DataFiles } from '../modules/database/entities/data-files.entity';
import { DataFileSequencePivot } from '../modules/database/entities/data-file-sequence-pivot.entity';
import { DataFileMetakeys } from '../modules/database/entities/data-file-metakeys.entity';
import { IdentificationOutputs } from '../modules/database/entities/identification-outputs.entity';
import { SequenceIdentificationOutputs } from '../modules/database/entities/sequence-identification-outputs.entity';
import { IdentifiedObjects } from '../modules/database/entities/identified-objects.entity';
import { SequenceIdentifiedObjects } from '../modules/database/entities/sequence-identified-objects.entity';
import { IdentificationMethodTaxonomyPivot } from '../modules/database/entities/identification-method-taxonomy-pivot.entity';
import { Taxonomies } from '../modules/database/entities/taxonomies.entity';
import { Languages } from '../modules/database/entities/languages.entity';
import * as crypto from 'crypto';

const config = require('config');
const logger = require('logger');
const data = require('./seed');

const run = async (clearDatabase) => {
  const connection = await createConnection({
    type: 'postgres',
    url: config.get('postgres.url'),
    entities: [`${__dirname}/../modules/database/entities/*.entity{.ts,.js}`],
    synchronize: false,
    migrationsRun: false,
  });

  if (clearDatabase) {
    logger.debug('Removing all data');
    await connection.dropDatabase();
    await connection.synchronize();
  }

  logger.debug('Generating data');
  const models = {};

  const permissionsRepository = connection.getRepository(Permissions);
  const rolesRepository = connection.getRepository(Roles);
  const participantTypesRepository = connection.getRepository(ParticipantTypes);
  const organizationsRepository = connection.getRepository(Organizations);
  const projectsRepository = connection.getRepository(Projects);
  const participantsRepository = connection.getRepository(Participants);
  const devicesRepository = connection.getRepository(Devices);
  const baitTypesRepository = connection.getRepository(BaitTypes);
  const locationsRepository = connection.getRepository(Locations);
  const mediaTypesRepository = connection.getRepository(MediaTypes);
  const deploymentsRepository = connection.getRepository(Deployments);
  const identificationMethodsRepository = connection.getRepository(IdentificationMethods);
  const sequencesRepository = connection.getRepository(Sequences);
  const dataFilesRepository = connection.getRepository(DataFiles);
  const dataFileMetakeysRepository = connection.getRepository(DataFileMetakeys);
  const identificationOutputsRepository = connection.getRepository(IdentificationOutputs);
  const identificationMethodTaxonomyPivotRepository = connection.getRepository(IdentificationMethodTaxonomyPivot);
  const taxonomiesRepository = connection.getRepository(Taxonomies);
  const sequenceIdentificationOutputsRepository = connection.getRepository(SequenceIdentificationOutputs);
  const languagesRepository = connection.getRepository(Languages);

  // await new Promise((resolve, reject) => {
  //   logger.debug('Loading taxonomy');
  //   PythonShell.run(`${__dirname}/ingest_api_taxonomy.py`, { args: [config.get('postgres.url')] }, (err) => {
  //     if (err) {
  //       reject(err);
  //       return;
  //     }
  //     logger.debug('Loaded successfully taxonomy');
  //     resolve();
  //   });
  // });

  logger.debug('Loading taxonomies');

  if (data && data.taxonomies) {
    let t;
    for (let i = 0, length = data.taxonomies.length; i < length; i++) {
      t = data.taxonomies[i];
      let taxonomy = new Taxonomies();
      taxonomy = Object.assign(taxonomy, t);
      // logger.debug('Importing', t.scientificName)
      await taxonomiesRepository.save(taxonomy);
    }
    logger.debug('Taxonomies were succesfully created');
  }

  if (data) {
    logger.debug('Loading catalog data');
    if (data.permissions) {
      logger.debug('Creating permissions');
      let p;
      for (let i = 0, length = data.permissions.length; i < length; i++) {
        p = data.permissions[i];
        let permission = new Permissions();
        permission = Object.assign(permission, p);
        await permissionsRepository.save(permission);
      }
      logger.debug(`Created ${data.permissions.length} permissions`);
    }
    if (data.roles) {
      logger.debug('Creating roles');
      let r;
      for (let i = 0, length = data.roles.length; i < length; i++) {
        r = data.roles[i];
        let role = new Roles();
        role = Object.assign(role, r);
        if (r.permissions) {
          const permissions: any = await Promise.all(r.permissions.map(p => permissionsRepository.findOne({ where: { slug: p } })));
          role.permissions = permissions.filter(p => p !== null);
        }
        // logger.debug(role.permissions);
        await rolesRepository.save(role);
      }
      logger.debug(`Created ${data.roles.length} roles`);
    }
    if (data.participantTypes) {
      logger.debug('Creating participant types');
      let p;
      for (let i = 0, length = data.participantTypes.length; i < length; i++) {
        p = data.participantTypes[i];
        let model = new ParticipantTypes();
        model = Object.assign(model, p);
        await participantTypesRepository.save(model);
      }
      logger.debug(`Created ${data.participantTypes.length} participant types`);
    }
    if (data.baitTypes) {
      logger.debug('Creating bait types');
      let p;
      for (let i = 0, length = data.baitTypes.length; i < length; i++) {
        p = data.baitTypes[i];
        let model = new BaitTypes();
        model = Object.assign(model, p);
        await baitTypesRepository.save(model);
      }
      logger.debug(`Created ${data.baitTypes.length} bait types`);
    }
    if (data.mediaTypes) {
      logger.debug('Creating media types');
      let p;
      for (let i = 0, length = data.mediaTypes.length; i < length; i++) {
        p = data.mediaTypes[i];
        let model = new MediaTypes();
        model = Object.assign(model, p);
        if (p.DataFileMetakeys) {
          model.dataFileMetakeys = [];
          for (let j = 0, lengthMetakeys = p.dataFileMetakeys.length; j < lengthMetakeys; j++) {
            let metakey = new DataFileMetakeys();
            metakey = Object.assign(metakey, p.dataFileMetakeys[j]);
            model.dataFileMetakeys.push(metakey);
          }
        }
        await mediaTypesRepository.save(model);
      }
      logger.debug(`Created ${data.mediaTypes.length} media types`);
    }
    if (data.identificationMethods) {
      logger.debug('Creating identification methods');
      let p;
      for (let i = 0, length = data.identificationMethods.length; i < length; i++) {
        p = data.identificationMethods[i];
        let model = new IdentificationMethods();
        model = Object.assign(model, p);
        await identificationMethodsRepository.save(model);
      }
      logger.debug(`Created ${data.identificationMethods.length} identification methods`);
    }
    if (data.cvModelTaxonomyPivots) {
      logger.debug('Associating CV tags to taxonomies');
      let p;
      for (let i = 0, length = data.cvModelTaxonomyPivots.length; i < length; i++) {
        p = data.cvModelTaxonomyPivots[i];
        const cvModel = await identificationMethodsRepository.findOne(
          {
            where: { name: p.name },
          },
        );
        const modelId = cvModel.id;
        logger.debug('Ingesting data for model', p.name);
        logger.debug('Model ID is', modelId);

        const cvTags = p.tags;
        // logger.debug('tags:', cv_tags);
        let q;
        for (let j = 0, qlength = cvTags.length; j < qlength; j++) {
          try {
            q = cvTags[j];
            // logger.debug('Associating tag', q.label);
            const taxonomy = await taxonomiesRepository.findOne({
              where: {
                genus: q.genus,
                species: q.species,
              },
            });

            const finalTaxonomy = identificationMethodTaxonomyPivotRepository.create({
              identificationMethodId: modelId,
              taxonomyId: taxonomy.uniqueIdentifier,
              tag: q.label,
            });
            await identificationMethodTaxonomyPivotRepository.save(finalTaxonomy);
            logger.debug('Associated taxonomy:', finalTaxonomy);
          } catch (error) {
            // logger.error("There was a problem associating", q.label)
          }
        }
      }
    }

    if (data.languages) {
      logger.debug('Creating languages');

      for (let i = 0; i < data.languages.length; i++) {
        const language = new Languages();
        const item = data.languages[i];

        language.code = item.code;
        language.name = item.name;

        await languagesRepository.save(language);
        logger.debug(`Added ${item.name} language`);
      }
    }

  }

  const principalInvestigatorType = await participantTypesRepository.findOne({ where: { name: 'PRINCIPAL INVESTIGATOR' } });

  const organizationOwnerRole = await rolesRepository.findOne({ where: { slug: ROLES.ORGANIZATION_OWNER } });
  const organizationViewerRole = await rolesRepository.findOne({ where: { slug: ROLES.ORGANIZATION_VIEWER } });
  const projectViewerRole = await rolesRepository.findOne({ where: { slug: ROLES.PROJECT_VIEWER } });
  const projectOwnerRole = await rolesRepository.findOne({ where: { slug: ROLES.PROJECT_OWNER } });

  let providerLocal = new Providers();
  providerLocal.provider = 'local';
  logger.debug('Creating users');
  const vizzAdminUser = new Participants();
  vizzAdminUser.email = 'wi-project@vizzuality.com';
  vizzAdminUser.firstName = 'Vizzuality (Admin)';
  vizzAdminUser.password = await hash('1234', 10);
  vizzAdminUser.active = true;
  vizzAdminUser.whitelisted = true;
  vizzAdminUser.providers = [providerLocal];
  vizzAdminUser.role = await rolesRepository.findOne({ where: { slug: config.get('auth.defaultRole') } });
  await participantsRepository.save(vizzAdminUser);

  providerLocal = new Providers();
  providerLocal.provider = 'local';
  const vizzViewerUser = new Participants();
  vizzViewerUser.email = 'wi-project+viewer@vizzuality.com';
  vizzViewerUser.firstName = 'Vizzuality (Viewer)';
  vizzViewerUser.password = await hash('1234', 10);
  vizzViewerUser.active = true;
  vizzViewerUser.whitelisted = true;
  vizzViewerUser.providers = [providerLocal];
  vizzViewerUser.role = await rolesRepository.findOne({ where: { slug: config.get('auth.defaultRole') } });
  await participantsRepository.save(vizzViewerUser);

  providerLocal = new Providers();
  providerLocal.provider = 'local';
  const wiUser = new Participants();
  wiUser.email = 'wi@info.com';
  wiUser.firstName = 'Wildlife';
  wiUser.password = await hash('1234', 10);
  wiUser.active = true;
  wiUser.whitelisted = true;
  wiUser.providers = [providerLocal];
  wiUser.role = await rolesRepository.findOne({ where: { slug: config.get('auth.defaultRole') } });
  await participantsRepository.save(wiUser);

  // Wildlife Insights import bot user; non-login user; identificationOutputs
  // are associated to this user during batch uploads.
  // We generate a random string as password, set the user as non-active and
  // non-whitelisted in order to prevent any temptations of using this as a
  // login user :)
  const randomPasswordBuf = crypto.randomBytes(256);
  providerLocal = new Providers();
  providerLocal.provider = 'local';
  const wiImportBotUser = new Participants();
  wiImportBotUser.email = config.get('batchUploads.importBotUser.email');
  wiImportBotUser.firstName = config.get('batchUploads.importBotUser.firstName');
  wiImportBotUser.password = await hash(randomPasswordBuf.toString('hex'), 10);
  wiImportBotUser.active = false;
  wiImportBotUser.whitelisted = false;
  wiImportBotUser.providers = [providerLocal];
  wiImportBotUser.role = await rolesRepository.findOne({ where: { slug: config.get('auth.defaultRole') } });
  await participantsRepository.save(wiImportBotUser);

  logger.debug('Creating organizations');
  const vizzOrg = new Organizations();
  vizzOrg.name = 'Vizzuality';
  vizzOrg.city = 'Madrid';
  vizzOrg.postalCode = '28010';
  vizzOrg.state = 'Spain';
  vizzOrg.email = 'info@vizzuality.com';
  vizzOrg.streetAddress = 'C/ Fuencarral 123';
  vizzOrg.organizationUrl = 'http://vizzuality.com';
  const owner = new OrganizationParticipantPivot();
  owner.role = organizationOwnerRole;
  owner.participant = vizzAdminUser;

  const viewer = new OrganizationParticipantPivot();
  viewer.role = organizationViewerRole;
  viewer.participant = vizzViewerUser;
  vizzOrg.organizationParticipantPivot = [owner, viewer];

  await organizationsRepository.save(vizzOrg);

  const wiOrg = new Organizations();
  wiOrg.name = 'Wildlife';
  wiOrg.city = 'New York';
  wiOrg.postalCode = '1001';
  wiOrg.state = 'New York';
  wiOrg.email = 'info@wildlifeinsights.com';
  wiOrg.streetAddress = 'Other';
  wiOrg.organizationUrl = 'https://www.wildlifeinsights.org/WMS/#/login/login';
  // wiOrg.owner =  wiUser;

  await organizationsRepository.save(wiOrg);

  // Creating projects
  const projectParticipants = [];
  let pp1 = new ParticipantTypeProjectPivot();
  pp1.participant = vizzAdminUser;
  pp1.role = projectOwnerRole;
  pp1.startDate = new Date();
  pp1.participantType = principalInvestigatorType;
  pp1.endDate = new Date(Date.now() + 365 * 24 * 60 * 60 * 1000);
  projectParticipants.push(pp1);
  pp1 = new ParticipantTypeProjectPivot();
  pp1.participant = vizzViewerUser;
  pp1.role = projectViewerRole;
  pp1.startDate = new Date();
  pp1.participantType = principalInvestigatorType;
  pp1.endDate = new Date(Date.now() + 365 * 24 * 60 * 60 * 1000);
  projectParticipants.push(pp1);

  logger.debug('Creating project');
  const project = new Projects();
  project.slug = SlugUtils.convert('Refill supplies in the fridge');
  project.name = 'Refill supplies in the fridge';
  project.startDate = new Date();
  project.endDate = new Date(Date.now() + (365 * 24 * 60 * 60 * 1000));
  project.projectCreditLine = 'Cash';
  project.acknowledgements = 'Ack';
  project.dataCitation = 'None';
  project.methodology = 'Manual';
  project.embargo = 0;
  project.status = 'CREATED';
  project.organization = vizzOrg;
  project.participantTypeProjectPivot = projectParticipants;
  await projectsRepository.save(project);

  logger.debug('Creating devices');

  const device1 = new Devices();
  device1.name = 'Canon camera';
  device1.purchaseDate = new Date();
  device1.purchaseYear = 2018;
  device1.model = 'EOS 1300D';
  device1.organization = vizzOrg;
  const sensor1 = new Sensors();
  sensor1.name = 'Camera';
  device1.sensors = [sensor1];
  await devicesRepository.save(device1);

  const device2 = new Devices();
  device2.name = 'Nikon camera';
  device2.purchaseDate = new Date();
  device2.purchaseYear = 2018;
  device2.model = 'D5300';
  device2.organization = vizzOrg;
  await devicesRepository.save(device2);

  const device3 = new Devices();
  device3.name = 'JXWANG';
  device3.purchaseDate = new Date();
  device3.purchaseYear = 2018;
  device3.model = 'JXWANG';
  device3.organization = wiOrg;
  await devicesRepository.save(device3);

  logger.debug('Creating locations');
  const location1 = new Locations();
  location1.placename = 'Santo Domingo de Piron';
  location1.geodeticDatum = 'Geodetic';
  location1.fieldNumber = '0001';
  location1.country = 'Spain';
  location1.project = project;
  await locationsRepository.save(location1);

  logger.debug('Creating deployments');
  const deployment1 = new Deployments();
  deployment1.project = project;
  deployment1.deploymentName = '"The rocks" field';
  deployment1.deploymentIdentifier = '"The rocks" field';
  deployment1.location = location1;
  await deploymentsRepository.save(deployment1);

  logger.debug('Creating sequences');
  const sequence1 = new Sequences();
  sequence1.name = 'Sequence';
  sequence1.deployment = deployment1;
  await sequencesRepository.save(sequence1);

  logger.debug('Creating datafiles');
  const dataFile1 = new DataFiles();
  dataFile1.deploymentId = deployment1.id;
  dataFile1.filename = 'fridge.jpg';
  dataFile1.filepath = 'deployment/1/0111b5d2-3555-44a2-b0bb-431afd283723.jpg';
  dataFile1.filesize = '3504';
  dataFile1.timestamp = new Date('2018-10-09T09:30:14.336Z');
  dataFile1.participantId = vizzAdminUser.id;
  dataFile1.mediaType = await mediaTypesRepository.findOne({ where: { mime: 'image/jpeg' } });
  const dataFileSequence = new DataFileSequencePivot();
  dataFileSequence.position = 1;
  dataFileSequence.sequence = sequence1;
  dataFile1.dataFileSequencePivots = [dataFileSequence];
  dataFile1.thumbnailUrl = 'https://storage.googleapis.com/refill_supplies_in_the_fridge__thumbnails/deployment/1/0111b5d2-3555-44a2-b0bb-431afd283723.jpg';
  await dataFilesRepository.save(dataFile1);

  const dataFile2 = new DataFiles();
  dataFile2.deploymentId = deployment1.id;
  dataFile2.filename = 'american-fridge.jpeg';
  dataFile2.filepath = 'deployment/1/256e3e96-076e-463c-aeb2-6b74a8e9f561.jpeg';
  dataFile2.filesize = '7904';
  dataFile2.timestamp = new Date('2018-10-09T10:28:14.336Z');
  dataFile2.participantId = vizzAdminUser.id;
  dataFile2.mediaType = await mediaTypesRepository.findOne({ where: { mime: 'image/jpeg' } });
  const dataFileSequence2 = new DataFileSequencePivot();
  dataFileSequence2.position = 2;
  dataFileSequence2.sequence = sequence1;
  dataFile2.dataFileSequencePivots = [dataFileSequence2];
  dataFile2.thumbnailUrl = 'https://storage.googleapis.com/refill_supplies_in_the_fridge__thumbnails/deployment/1/256e3e96-076e-463c-aeb2-6b74a8e9f561.jpeg';
  await dataFilesRepository.save(dataFile2);

  logger.debug('Creating identifications');
  const identification1 = new IdentificationOutputs();
  identification1.blankYn = false;
  identification1.participantId = vizzAdminUser.id;
  identification1.dataFileId = dataFile1.id;
  identification1.identificationMethodId = 1;
  identification1.timestamp = new Date();
  identification1.identifiedObjects = [];
  const identification1Object1 = new IdentifiedObjects();
  identification1Object1.sex = 'Female';
  identification1Object1.taxonomyId = 'be58ea40-e3c0-4373-9bbf-0bca7f828f55';
  identification1.identifiedObjects.push(identification1Object1);

  await identificationOutputsRepository.save(identification1);

  const identification2 = new IdentificationOutputs();
  identification2.blankYn = false;
  identification2.participantId = vizzAdminUser.id;
  identification2.dataFileId = dataFile2.id;
  identification2.identificationMethodId = 1;
  identification2.timestamp = new Date();
  identification2.identifiedObjects = [];
  const identification2Object1 = new IdentifiedObjects();
  identification2Object1.sex = 'Male';
  identification2Object1.taxonomyId = '2a0f799e-124d-4722-88a2-1671282d730d';
  identification2.identifiedObjects.push(identification2Object1);

  await identificationOutputsRepository.save(identification2);

  console.log('Adding sequence identifications');

  const sequenceIdentification1 = new SequenceIdentificationOutputs();
  sequenceIdentification1.blankYn = false;
  sequenceIdentification1.participantId = vizzAdminUser.id;
  sequenceIdentification1.sequenceId = sequence1.id;
  sequenceIdentification1.identificationMethodId = 1;
  sequenceIdentification1.timestamp = new Date();
  sequenceIdentification1.identifiedObjects = [];
  const sequenceIdentification1Object1 = new SequenceIdentifiedObjects();
  sequenceIdentification1Object1.sex = 'Male';
  sequenceIdentification1Object1.taxonomyId = '2a0f799e-124d-4722-88a2-1671282d730d';
  sequenceIdentification1.identifiedObjects.push(sequenceIdentification1Object1);

  await sequenceIdentificationOutputsRepository.save(sequenceIdentification1);

  process.exit(0);
};

console.log('Running seed data');

let clear = false;
if (process.argv && process.argv.length > 2 && process.argv[2] === 'true') {
  clear = true;
}

run(clear).then(
  () => console.log('Seed data imported!!'),
  (err) => {
    console.error('Error importing seed data', err);
    process.exit(1);
  },
);
