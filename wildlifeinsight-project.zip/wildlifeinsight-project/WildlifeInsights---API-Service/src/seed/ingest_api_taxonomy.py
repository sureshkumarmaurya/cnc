#!/usr/bin/env python
import csv
import requests
import json
import psycopg2
from urllib.parse import urlparse
import sys
try:
    db_url = sys.argv[1]
except IndexError:
    print("Provide a postgres URL.")
    sys.exit()

connection_parameters = urlparse(db_url)
# print(connection_parameters)
db_config = {
    'host': connection_parameters.hostname,
    'port': connection_parameters.port,
    'user': connection_parameters.username,
    'password': connection_parameters.password,
    'dbname': connection_parameters.path.lstrip('/')
}
# print(db_config)
db_conn = psycopg2.connect(
    **db_config
)

# sys.exit()
clean_fields = lambda field: field.strip('"').strip("'").lstrip().rstrip() if type(field) is str else field
clean_dict = lambda dic: {k: clean_fields(v) for k, v in dic.items() if v}

## Importing IUCN categories

raw_iucn_data = [
    ["Extinct", "EX"],
    ["Extinct in the Wild", "EW"],
    ["Critically Endangered [Possibly Extinct]", "PE"],
    ["Critically Endangered", "CR"],
    ["Endangered", "EN"],
    ["Vulnerable", "VU"],
    ["Near Threatened", "NT"],
    ["Least Concern", "LC"],
    ["Data Deficient", "DD"],
    ["Not Evaluated", "NE"],
    ["Not Recognized", "NR"]
]

clean_iucn_data = list(map(lambda row: {
    'category_name': row[0],
    'abbreviation': row[1]
}, raw_iucn_data))

def register_iucn_cats(db_conn, iucn_data):
    db_cursor = db_conn.cursor()
    db_cursor.executemany("""
    INSERT INTO iucn_red_list_categories (category_name, abbreviation)
    VALUES (%s, %s)""",
                      [(
                          category['category_name'],
                          category['abbreviation']
                      ) for category in iucn_data]
    )
    db_conn.commit()
    db_cursor.close()
    return None

print("Importing IUCN categories")
try:
    register_iucn_cats(db_conn, clean_iucn_data)
    print("IUCN categories correctly imported")
except:
    print("There was a problem importing IUCN categories")


# Getting ids from DB
db_cursor = db_conn.cursor()
db_cursor.execute("SELECT * FROM iucn_red_list_categories")
db_conn.commit()
iucn_query = db_cursor.fetchall()
iucn_categories_dict = dict(map(lambda tup: (tup[2], tup[0]), iucn_query))

print("Importing species taxonomy")

def get_from_api(api_query):
    return json.loads(
        requests.get('http://api.naturalsciences.org/api/v1/taxonomy/search?q=' + api_query).text
    )

def clean_species(species):
    species = clean_dict(species)
    return {
        'class': species['class'].lower().capitalize() if species['class'] != "" else None,
        'order': species['_order'].lower().capitalize() if species['_order'] != "" else None,
        'family': species['family'].lower().capitalize() if species['family'] != "" else None,
        'genus': species['genus'].lower().capitalize() if species['genus'] != "" else None,
        'species': species['species'].lower() if species['species'] != "" else None,
        'authority': species['taxon_authority'].replace('(', '').replace(')', '') if species.get('taxon_authority', None) else None,
        'common_names': {
            'english': (species.get('common_names', [{'common_name': None}]))[0].get('common_name', None)
        } if species.get('common_names', []) != [] else {'english': None },
        'red_list_criteria': iucn_categories_dict.get(
            species.get('iucn_code', 'NR'),
            iucn_categories_dict['NR']
        )
    }

def create_sc_name(sp):
    gen, species, auth = sp.get('genus'), sp.get('species'), sp.get('authority')
    if auth is not None:
        sc_name =  gen + " " + species + " " + "(" + auth + ")"
    else:
        sc_name =  gen + " " + species

    out = sp.copy()
    out.update({'scientific_name': sc_name})
    return out

    
def insert_species(sp_dict, db_conn = db_conn):
    # print(f"Importing into taxonomies: {sp_dict['genus']} {sp_dict['species']}")
    # print(f"importing species: {sp_dict}")
    db_cursor = db_conn.cursor()
    db_cursor.execute("""
INSERT INTO taxonomies(class, "order", family, genus, species, taxon_level, authority, common_name_english, iucn_category_id, scientific_name) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
""", (
    sp_dict['class'],
    sp_dict['order'],
    sp_dict['family'],
    sp_dict['genus'],
    sp_dict['species'],
    'species',
    sp_dict['authority'],
    sp_dict['common_names']['english'],
    sp_dict['red_list_criteria'],
    sp_dict['scientific_name']
)
    )
    db_conn.commit()
    db_cursor.close()
    return


mammal_data = get_from_api('Mammalia')
aves_data   = get_from_api('Aves')
taxonomy_data = mammal_data + aves_data
clean_species_data = [create_sc_name(clean_species(species)) for species in taxonomy_data]

class Hashabledict(dict):
    def __hash__(self):
        return hash(frozenset(self))

def remove_sp(sp_dict):
    genus_dict = sp_dict.copy() # Making a copy
    del genus_dict['species']
    del genus_dict['authority']
    del genus_dict['common_names']
    del genus_dict['red_list_criteria']
    del genus_dict['scientific_name']
    return genus_dict

def remove_gen_sp(sp_dict):
    family_dict = sp_dict.copy() # Making a copy
    del family_dict['genus']
    del family_dict['species']
    del family_dict['authority']
    del family_dict['common_names']
    del family_dict['red_list_criteria']
    del family_dict['scientific_name']
    return family_dict


genuses = [remove_sp(sp) for sp in clean_species_data]
families = [remove_gen_sp(sp) for sp in clean_species_data]

# dedup_dict_list = lambda L: list({v['scientific_name']:v for v in L}.values())
dedup_dict_list = lambda d: [i for n, i in enumerate(d) if i not in d[n + 1:]]
clean_genus_data = dedup_dict_list(genuses)
print(clean_genus_data[:20])
clean_family_data = dedup_dict_list(families)

print(len(clean_species_data))
print(len(clean_genus_data))
print(len(clean_family_data))

def insert_genus(genus_dict, db_conn = db_conn):
    # print(f"importing species: {genus_dict}")
    db_cursor = db_conn.cursor()
    db_cursor.execute(
        'INSERT INTO taxonomies(class, "order", family, genus, taxon_level, scientific_name ) VALUES (%s, %s, %s, %s, %s, %s)',
        (
            genus_dict['class'],
            genus_dict['order'],
            genus_dict['family'],
            genus_dict['genus'],
            'genus',
            genus_dict['genus']
        )
    )
    db_conn.commit()
    db_cursor.close()
    return

def insert_family(family_dict, db_conn = db_conn):
    # print(f"importing species: {genus_dict}")
    db_cursor = db_conn.cursor()
    db_cursor.execute(
        'INSERT INTO taxonomies(class, "order", family, taxon_level, scientific_name ) VALUES (%s, %s, %s, %s, %s)',
        (
            family_dict['class'],
            family_dict['order'],
            family_dict['family'],
            'family',
            family_dict['family']
        )
    )
    db_conn.commit()
    db_cursor.close()
    return


[insert_species(sp) for sp in clean_species_data]
print("Importing genus taxonomies")
[insert_genus(g) for g in clean_genus_data]
[insert_family(f) for f in clean_family_data]

print("Inserting unknown species")

insert_species(
    {
        'class': 'Unknown',
        'order': 'Unknown',
        'family': 'Unknown',
        'genus': 'Unknown',
        'species': 'Unknown',
        'authority': '',
        'common_names': {'english': 'Unknown species'},
        'red_list_criteria': None,
        'scientific_name': 'Unknown species'
    }
)
