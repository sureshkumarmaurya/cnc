import { BeforeRemove, BeforeUpdate, getManager } from 'typeorm';
import { Roles } from 'modules/database/entities/roles.entity';
import { ROLES } from './roles.enum';

const logger = require('logger');

export type EntityType = 'project' | 'organization' | 'initiative';

export abstract class EntityParticipantPivot {
  protected pivotEntity : string;
  abstract roleId : number;

  constructor(protected alias: EntityType) {
    switch (alias) {
      case 'organization':
        this.pivotEntity = 'OrganizationParticipantPivot';
        break;
      case 'initiative':
        this.pivotEntity = 'InitiativeParticipantPivot';
        break;
      case 'project':
        this.pivotEntity = 'ParticipantTypeProjectPivot';
        break;
    }
  }

  @BeforeRemove()
  @BeforeUpdate()
  /**
   * Ensure that user roles on entities are not deleted or updated if the
   * deletion or update being processed is for a user whose current role is
   * owner, as this would 'orphan' the entity.
   *
   * This function is executed as a TypeORM listener (`@BeforeRemove()` and
   * `@BeforeUpdate()`).
   *
   * As the logic is mostly identical for each of organizations, initiatives and
   * projects, this is implemented in the base class for all of the entity
   * type/participant pivot entity classes.
   *
   * This also means that we employ some tricks at the edge of kosher, foregoing
   * strict typing in places to keep the implementation simple.
   */
  async enforceMinimumOfOneOwner() : Promise<void> {
    // This would be organizationId, initiativeId or projectId, depending on the
    // type of entity whose pivot we are dealing with.
    const idField = `${this.alias}Id`;

    const entityManager = getManager();

    // ORGANIZATION_OWNER, INITIATIVE_OWNER or PROJECT_OWNER
    const ownerRoleSlug = `${this.alias.toUpperCase()}_OWNER`;

    // Get the numeric id of the role, which is needed in queryParams below
    const entityTypeOwnerRole = await entityManager.getRepository<Roles>('Roles')
      .findOne({ slug: ROLES[ownerRoleSlug] });

    // Perform checks only if current user is an entity owner
    if (this.roleId === entityTypeOwnerRole.id) {
      const queryParams = {
        roleId: entityTypeOwnerRole.id,
        [idField]: this[idField],
      };

      // For projects and initiatives we need to make sure we only count users
      // with an *explicit* role on the entity.
      if (['project', 'initiative'].includes(this.alias)) {
        queryParams['isImplicit'] = false;
      }
      const [, ownerCount] = await entityManager.getRepository(this.pivotEntity)
        .findAndCount(queryParams);
      logger.debug(`Number of users with role ${ownerRoleSlug} on entity with id ${this[idField]}: ${ownerCount}`);

      // Reject deletion or update request if this would orphan the entity of
      // all its owners. In practice this also stops updates from owner to owner
      // role, but this is not a problem, as it would effectively be a no-op
      // anyway.
      if (ownerCount === 1) {
        throw new Error(`Cannot revoke or change user role as this is the only user with ${ownerRoleSlug} role on ${this.alias} with id ${this[idField]}.`);
      }
    }
  }
}
