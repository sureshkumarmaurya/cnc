import * as slug from 'slug';

slug.defaults.modes['rfc3986'] = {
  replacement: '_',
  symbols: true,
  remove: null,
  lower: true,
  charmap: slug.charmap,
  multicharmap: slug.multicharmap,
};

slug.defaults.mode = 'rfc3986';

export class SlugUtils {
  static convertAndPrefix(text: string): string {
    return this.prefixEnvironment(slug(text)).substr(0, 47);
  }

  static convert(text: string): string {
    return slug(text);
  }

  static prefixEnvironment(text: string): string {
    return process.env.NODE_ENV === 'prod' ? text : `staging_${text}`;
  }
}

export class NameUtils {
  static prefix(text: string): string {
    return this.prefixEnvironment(text).substr(0, 47);
  }

  static prefixEnvironment(text: string): string {
    return process.env.NODE_ENV === 'prod' ? text : `staging-${text}`;
  }

  static trimShortName(shortName: string): string {
    return shortName ? shortName.substr(0, 40) : '';
  }
}
