import { Injectable } from '@nestjs/common';
import * as Sparkpost from 'sparkpost';

const config = require('config');
const logger = require('logger');

@Injectable()
export class MailService {

  client: any;
  publicUrl: string;
  homeUrl: string;
  logoUrl: string;

  constructor() {
    this.publicUrl = config.get('auth.publicUrl');
    this.homeUrl = config.get('dashboardUrl');
    this.logoUrl = `${this.homeUrl}/static/logo@2x.png`;

    try {
      this.client = new Sparkpost(config.get('sparkpost'), { debug: true });
    } catch (err) {
      logger.error('Sparkpost client error: ', err);
    }
  }

  async sendTransactionalEmail (data, recipients, templateId) {
    logger.debug(`Sending mail: ${templateId} to `, recipients);
    const reqOpts = {
      recipients,
      substitution_data: {
        logoUrl: this.logoUrl,
        homeUrl: this.homeUrl,
        ...data,
      },
      content: {
        template_id: templateId,
      },
    };
    return new Promise((resolve, reject) => {
      logger.debug(reqOpts);
      this.client.transmissions.send(reqOpts, (error, res) => {
        if (error) {
          reject(error);
        } else {
          resolve(res);
        }
      });
    });
  }
}
