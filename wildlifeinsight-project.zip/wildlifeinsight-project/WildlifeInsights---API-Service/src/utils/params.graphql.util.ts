function parseVariable(tree, variableStack) {
  let value;
  if (tree.value.name.value in variableStack) {
    value = variableStack[tree.value.name.value];
  } else {
    value = null;
  }
  return value;
}

export const parseGraphqlParams = (ctx = { fieldNodes: null, variableValues: {} }) => {
  const args = ctx.fieldNodes[0].arguments;
  const { variableValues } = ctx;

  const serializedArgs = args.map((a: any) => {
    const { kind } = a.value;
    let value;
    if (kind === 'ObjectValue') {
      value =  a.value.fields;
    } else if (kind === 'Variable') {
      value = parseVariable(a, variableValues);
    } else {
      value = a.value.value;
    }
    return  { [a.name.value]: value };
  });

  return serializedArgs.reduce(((r, c) => Object.assign(r, c)), {});
};
