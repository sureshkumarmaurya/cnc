import { CreateRoleChangesDto } from 'modules/api/v1/role-changes/dto/create-role-changes.dto';
import { PERMISSIONS } from 'utils/permissions.enum';
import { RoleChanges } from 'modules/database/entities/role-changes.entity';
import { RoleChangesService } from 'modules/api/v1/role-changes/role-changes.service';
import { CryptoUtils } from 'utils/crypto.utils';
import { Repository } from 'typeorm';
import { Roles } from 'modules/database/entities/roles.entity';
import { Inject } from '@nestjs/common';
import { AuthenticatedUserDto } from 'dto/authenticated-user.dto';
import { PermissionsDto } from 'modules/database/dto/permissions.dto';

const logger = require('logger');

type ManageEntityInput = {
  operation: 'create' | 'update' | 'delete',
  email: string,
  role: string,
  entityId: string,
};

type EntityType = 'organization' | 'project' | 'initiative';

enum PermissionsRolesMatrix {
  INVITE_USER_AS_VIEWER = 'VIEWER',
  INVITE_USER_AS_EDITOR = 'EDITOR',
  INVITE_USER_AS_OWNER = 'OWNER',
}

export class RolesUtils {
  constructor(
    @Inject('RolesRepositoryToken') private readonly rolesRepository: Repository<Roles>,
  ) {}

  getRequestedPermission = (operation: String, role: String, entityType: EntityType) => {
    if (operation === 'delete') { return `${entityType.toUpperCase()}_REVOKE_USER_ACCESS`; }
    if (operation === 'update') { return `${entityType.toUpperCase()}_CHANGE_USER_ROLE`; }
    if (operation === 'create') { return `${entityType.toUpperCase()}_INVITE_USER_AS_${role.toUpperCase()}`; }
  }

  getRoleChangesDto = (manageEntityInput: ManageEntityInput, entityType: EntityType, invitationInitiatorId: number) => {
    const { operation, email, role, entityId } = manageEntityInput;
    const body = new CreateRoleChangesDto();

    try {
      body.email = email;
      body.role = (`${entityType}_${role}`).toUpperCase();
      body.changeType = operation;
      body.status = 'new';

      if (operation === 'create') { body.activationToken = CryptoUtils.encrypt(email); }
      body.invitationInitiatorId = invitationInitiatorId;

      if (entityType === 'organization') { body.organizationId = parseInt(entityId, 10); }
      if (entityType === 'project') {      body.projectId = parseInt(entityId, 10); }
      if (entityType === 'initiative') {   body.initiativeId = parseInt(entityId, 10); }

      return body;
    } catch (error) {
      logger.error(error);
      return false;
    }
  }

  generateManageResponse = (result) => {
    const response = {
      create: 0,
      update: 0,
      delete: 0,
    };

    result.forEach((item: RoleChanges) => {
      if (!response[item.changeType]) { response[item.changeType] = 1; }
      else { response[item.changeType]++; }
    });
    return response;
  }

  manageEntityParticipants = async (body, authenticatedUser, entityType: EntityType, roleChangesService: RoleChangesService) => {
    const managePromises = [];
    const { [`${entityType}Role`]: entityRoles, user: { id: invitationInitiatorId } } = authenticatedUser;

    body.forEach((manageAction: ManageEntityInput) => {
      const entityRole = entityRoles.find(item => item[entityType].id === parseInt(manageAction.entityId, 10));
      const requestedPermission = this.getRequestedPermission(manageAction.operation, manageAction.role, entityType);
      const doesUserHavePermissions = entityRole && entityRole.role.permissions
        .findIndex(permissionItem => permissionItem.slug === PERMISSIONS[requestedPermission]) !== -1;

      if (!doesUserHavePermissions) { return; }

      const createRoleChangesDto: CreateRoleChangesDto | false = this.getRoleChangesDto(manageAction, entityType, invitationInitiatorId);

      if (createRoleChangesDto) {
        managePromises.push(new Promise((resolve) => {
          roleChangesService.create(createRoleChangesDto).then((res) => {
            resolve(res);
          }).catch(e => resolve(false));
        }));
      }
    });

    const result = await Promise.all(managePromises);
    return this.generateManageResponse(result);
  }

  /**
   * Given a list of participants with access to (i.e. any role on) an entity,
   * check which of their roles the current user can revoke or change (and, if
   * so, to which other roles).
   *
   * See https://www.pivotaltracker.com/story/show/168503378 for context.
   */
  addAllowableRoleChangeOperationsToParticipantData = async (entityType: EntityType, entityId: number, authenticatedUser: AuthenticatedUserDto, participants) => {
    let canRoleBeRevoked: Boolean = false;
    let roleCanBeChangedTo = [];
    /**
      * Get current user permissions for entity: `entityType` with id:
      * `entityId`
      */

    logger.debug(`Checking current user's permissions to manage roles for the entity type: ${entityType}, id: ${entityId}`);
    const entityObject = authenticatedUser[`${entityType}Role`].find(item =>
      item[entityType].id === entityId,
    );

    if (!entityObject || !entityObject.role) { throw new Error('Invalid entity object'); }
    const { role: { permissions, slug: currentUserRole } } = entityObject;

    try {
      /**
       * Filtering permissions for user management permissions with Roles
       * comparison `PermissionsRolesMatrix`.
       */
      const rolesSlugs = [];
      permissions.forEach((permission: PermissionsDto) => {
        /**
         * Relevant permission slugs are `organization.revoke_user_access`,
         * `initiative.revoke_user_access`, `project.revoke_user_access`. The
         * "pure" version strips the entity name from permission slugs (which
         * have the general form `<entityType>.<action>`).
         */
        const purePermissionSlug = permission.slug.split('.')[1].toUpperCase();
        // Check if role can be revoked
        if (purePermissionSlug === 'REVOKE_USER_ACCESS') {
          canRoleBeRevoked = true;
        }
        // Check if role can be changed, and if so, to which other role(s)
        const roleChangePermission = PermissionsRolesMatrix[purePermissionSlug];
        if (roleChangePermission) { rolesSlugs.push(`${entityType}_${roleChangePermission}`.toUpperCase()); }
      });

      roleCanBeChangedTo = (rolesSlugs.length > 0) ? await this.rolesRepository.createQueryBuilder('role')
        .where('role.slug IN (:...slugs)')
        .setParameter('slugs', rolesSlugs)
        .getMany() : [];

    } catch (err) {
      logger.error(`Error while checking current user's permissions to manage roles for the entity type: ${entityType}, id: ${entityId}`, err);
    }

    /**
     * Add information on which role changes (`roleCanBeChangedTo` and
     * `canRoleBeRevoked`) can be performed by the current user for each of the
     * users (`EntityParticipant`) who currently have any role on the entity.
     */
    return participants.map((participant) => {
      const userRole = participant.role;

      let revokeUserRole = canRoleBeRevoked;
      let roleChanges = [...roleCanBeChangedTo];

      /**
       * Add current user role (UI requirements)
       */
      if (!roleChanges.find(role => role.slug === userRole.slug)) {
        roleChanges.push(userRole);
      }

      if (currentUserRole !== `${entityType.toUpperCase()}_OWNER`) {
        roleChanges = [userRole];
      }

      /**
       * The current user is allowed to revoke their own entity role, except if
       * they are the only owner of the current entity.
       *
       * In this case, likewise, the user can't demote themselves to the role of
       * editor or viewer.
       */
      if (participant.participant.id === authenticatedUser.user.id) {
        if (currentUserRole === `${entityType.toUpperCase()}_OWNER`) {
          const lastEntityOwner = participants.filter(item => item.role.slug === `${entityType.toUpperCase()}_OWNER`).length === 1;
          if (lastEntityOwner) {
            revokeUserRole = false;
            roleChanges = [userRole];
          }
        } else {
          revokeUserRole = true;
        }
      }

      return ({
        ...participant,
        canRoleBeRevoked: revokeUserRole,
        roleCanBeChangedTo: roleChanges,
      });

    });
  }
}
