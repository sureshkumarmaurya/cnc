export function getLatLong(latitudeLongitudeValue) {
  try {
    if (latitudeLongitudeValue === null || latitudeLongitudeValue === undefined) { return '0.0000'; }
    else {
      var latitudeLongitudeString = latitudeLongitudeValue.toString();
      let latitudeLongitudeStringValue = latitudeLongitudeString.split('.')[1];
      let latitudeLongitudeLength = latitudeLongitudeStringValue ? latitudeLongitudeStringValue.length : 0;

      if (latitudeLongitudeLength == 0) {
        return latitudeLongitudeString + '.0000';
      }
      if (latitudeLongitudeLength < 4) {
        return latitudeLongitudeString + '0'.repeat(4 - latitudeLongitudeLength);
      }
      if (latitudeLongitudeLength > 8) {
        return parseFloat(latitudeLongitudeString).toFixed(8);
      }
      if ((latitudeLongitudeLength > 4 && latitudeLongitudeLength < 8) || (latitudeLongitudeLength == 4 || latitudeLongitudeLength == 8)) {
        return latitudeLongitudeString;
      }
    }
  }
  catch (err) {
    console.log('error is ', err);
  }
}