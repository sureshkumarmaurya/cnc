/* tslint:disable */

import { PaginationUtil } from './pagination.util';
import { NotFoundException } from '@nestjs/common';
import { Repository, SelectQueryBuilder } from 'typeorm';
import { InfoDto } from 'dto/info.dto';
import { PaginationModel } from './pagination.model';

const logger = require('logger');

export abstract class GenericService<E, C, U> {

  constructor(protected readonly repository: Repository<any>, protected alias: string = 'master') { }

  // Start find all
  findAll(pagination: PaginationModel, info?: InfoDto, filters: any = null): Promise<[E[], number]> {
    logger.debug(`Finding all ${this.repository.metadata.name}`);
    let query = this.repository.createQueryBuilder(this.alias);
    info = { ...info, pagination };
    query = this.setFilters(query, filters, info);
    query = PaginationUtil.addPagination(query, this.alias, pagination);
    return query.getManyAndCount();
  }

  setFilters(query: SelectQueryBuilder<E>, filters: any, info: InfoDto) {
    return query;
  }
  // End find all

  // Get by Id

  setFiltersGetById(query: SelectQueryBuilder<E>, info: InfoDto): SelectQueryBuilder<E> {
    return query;
  }

  async getById(id: number, pagination: PaginationModel, info?: InfoDto): Promise<E> {
    logger.debug('Getting by id');
    let query = this.repository.createQueryBuilder(this.alias);
    info.pagination = pagination;
    query = this.setFiltersGetById(query, info);
    query.andWhere(`${this.alias}.id = :id`).setParameter('id', id);
    query = PaginationUtil.addIncludesFields(query, this.alias, pagination);

    const model = await query.getOne();
    if (!model) {
      throw new NotFoundException(`${this.alias} not found`);
    }
    return model;
  }

  // END Get by id

  // Start create

  abstract async setDataCreate(create: C, info: InfoDto): Promise<E>;

  async validateBeforeCreate(createModel: C, info: InfoDto): Promise<void> { }

  async actionAfterCreate(data: E, createModel?: C): Promise<void> { }

  async create(createModel: C, info?: InfoDto): Promise<E> {
    logger.debug(`Creating ${this.alias}`);

    await this.validateBeforeCreate(createModel, info);
    const model = await this.setDataCreate(createModel, info);

    return new Promise((resolve, reject) => {
      this.repository.save(model)
        .then((result) => {
          if (this.actionAfterCreate) this.actionAfterCreate(result, createModel);
          resolve(result);
        })
        .catch(e => reject(e));
    });
  }

  // End create

  // Start update

  abstract async setDataUpdate(model: E, update: U, info: InfoDto): Promise<E>;

  async validateBeforeUpdate(id: number, updateModel: U, info?: InfoDto): Promise<void> { }

  setFiltersUpdate(query: SelectQueryBuilder<E>, info: InfoDto): SelectQueryBuilder<E> {
    return query;
  }

  async actionAfterUpdate(data: E, updateModel?: U): Promise<void> { }

  async update(id: number, updateModel: U, info?: InfoDto): Promise<E> {
    logger.debug(`Updating ${this.alias}`);

    await this.validateBeforeUpdate(id, updateModel, info);
    let query = this.repository.createQueryBuilder(this.alias);
    query = this.setFiltersUpdate(query, info);
    query.andWhere(`${this.alias}.id = :id`).setParameter('id', id);
    let model = await query.getOne();
    if (!model) {
      throw new NotFoundException(`${this.alias} not found`);
    }

    model = await this.setDataUpdate(model, updateModel, info);

    return new Promise((resolve, reject) => {
      this.repository.save(model)
        .then((result) => {
          if (this.actionAfterUpdate) this.actionAfterUpdate(result, updateModel);
          resolve(result);
        })
        .catch(e => reject(e));
    });
  }

  // End update

  // Start delete

  setFiltersDelete(query: SelectQueryBuilder<E>, info: InfoDto): SelectQueryBuilder<E> {
    return query;
  }

  async remove(id: number, info?: InfoDto): Promise<E> {

    logger.debug('Remove');
    let query = this.repository.createQueryBuilder(this.alias);
    query = this.setFiltersDelete(query, info);

    query.andWhere(`${this.alias}.id = :id`).setParameter('id', id);
    const model = await query.getOne();
    if (!model) {
      throw new NotFoundException(`${this.alias} not found`);
    }
    await this.repository.remove(model);
    model.id = id;
    return model;
  }

  async removeMany(idList: Array<number>, info?: InfoDto): Promise<Array<number>> {
    logger.debug(`Remove multiple  ${this.alias}`);

    const query = this.repository.createQueryBuilder(this.alias)
      .where(`${this.alias}.id IN (:...idList)`, { idList });

    const foundRecords = await query.getMany();

    if (foundRecords && foundRecords.length) {
      return this.repository.remove(foundRecords);
    }
    return foundRecords;

  }

  // End delete

}
