import { AES, enc } from 'crypto-js';
const logger = require('logger');
const config = require('config');

let salt: string;

try {
  salt = config.get('encryptionSalt');
} catch (error) {
  logger.error('Could not get salt from environment variable');
}

if (!salt) { logger.error('Encryption Salt value not found'); }

export class CryptoUtils {
  static encrypt = (message: string) => AES.encrypt(message, salt).toString();
  static decrypt = (message: string) => AES.decrypt(message.toString(), salt).toString(enc.Utf8);
}
