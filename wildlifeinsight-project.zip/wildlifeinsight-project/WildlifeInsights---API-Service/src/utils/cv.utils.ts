const fs = require('fs').promises;
const logger = require('logger');
const config = require('config');
const rp = require('request-promise');
const gm = require('gm').subClass({ imageMagick: true });
const { google } = require('googleapis');
const ml = google.ml('v1');

/**
 * Not sure if the cvOptions param to CVUtils.identify() was meant to be used
 * to pass on metadata such as lat/lon/countryCode, but since this doesn't
 * appear to have ever been used for anything else, we are retrofitting it for
 * this kind of metadata.
 */
export interface CVOptions {
  lat: number;
  lon: number;
  country: string;
}

export class CVUtils {
  private async predict(mleRequestJson: object) {
    const result: any = await new Promise((resolve, reject) => {
      ml.projects.predict(mleRequestJson, (err, result) => {
        if (err) {
          // logger.debug(err);
          logger.debug('ERROR');
          reject(err);
          return;
        }
        resolve(result);
      });
    });
    return result.data;
  }

  static async identify(path: string, modelEndpoint: string, modelName: string, cvOptions?: CVOptions) {
    logger.debug(`Performing identification for ${path} with model ${modelName}`);
    // const fileData = await fs.readFile(path);
    // const data = new Buffer(fileData).toString('base64');
    // logger.debug(`data buffer: ${data.substring(0,10)}`);
    // const auth = await google.auth.getClient({
    //   scopes: ['https://www.googleapis.com/auth/cloud-platform']
    // });
    // logger.debug(`auth: ${JSON.stringify(auth)}`);
    // const instances = [{
    //   'image_bytes': {
    //     'b64': data
    //   },
    //   'key': '1'
    // }];
    // const mleRequestJson = {
    //   'auth': auth,
    //   'name': 'projects/cameratraprepo/models/' + modelName,
    //   'resource': {'instances': instances}
    // }
    // logger.debug(`mleRequestJson: ${mleRequestJson}`);
    // const predictions = await ml.projects.predict(mleRequestJson);
    // logger.debug(`predictions: ${JSON.stringify(predictions.data)}`);

    // const cvEndpoint = config.get('cv.url');
    logger.debug('modelEndpoint', modelEndpoint);
    const dataFilePayload = await fs.readFile(path);
    const options = {
      method: 'POST',
      uri: modelEndpoint,
      formData: {
        model_name: {
          value: modelName,
          options: {
            filename: null,
            contentType: null,
          },
        },
        payload: {
          value: dataFilePayload,
          options: {
            filename: 'image_file.jpg',
            contentType: 'image/jpg', // Will need to get this from the image
          },
        },
        lat: cvOptions.lat,
        lon: cvOptions.lon,
        country: cvOptions.country,
      },
      headers: {}, // multipart gets added automatically
    };
    logger.debug('Sending request for CV identification for image in path: ', path);
    const identification = await rp(options);
    logger.debug('identification: ', identification);
    const idObject = JSON.parse(identification)['data'];
    logger.debug('Identifications: ', idObject);
    return idObject;
  }

  static async createThumbnail(path: string, options?: object) {
    try {
      await new Promise((resolve, reject) => {
        gm(path)
          .resize(300, 300)
          .write(`${path}-thumb`, (err, stdout) => {
            if (err) {
              logger.error(err);
            }
            gm(`${path}-thumb`)
              .write(`${path}-thumb`, (err, stdout) => {
                if (err) {
                  logger.error(err);
                  reject(err);
                }
                resolve();
              });
          });
      });
      return `${path}-thumb`;
    } catch (err) {
      logger.error(err);
    }
  }
}
