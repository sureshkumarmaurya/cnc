/**
 * Handle exporting project metadata for a list of projects
 */
import { Inject } from '@nestjs/common';
import { Repository, getManager } from 'typeorm';
import { Projects } from 'modules/database/entities/projects.entity';
import { BatchDownloads } from 'modules/database/entities/batch-downloads.entity';
import { EBatchDownloadStatus } from 'modules/database/dto/batch-downloads.dto';
import { BatchDownloadsImages } from 'modules/database/entities/batch-downloads-images.entity';
import { BatchDownloadsDeployments } from 'modules/database/entities/batch-downloads-deployments.entity';
import { BatchDownloadsCameras } from 'modules/database/entities/batch-downloads-cameras.entity';
import { BatchDownloadsProjects } from 'modules/database/entities/batch-downloads-projects.entity';
import { BatchDownloadService, URLComponents, EntityType } from 'modules/api/v1/batch-downloads/batch-download.service';
import { exec } from 'ts-process-promises';
import { ReadStream } from 'fs';
import { StorageService } from 'modules/google/storage.service';

const storage = require('@google-cloud/storage');
const config = require('config');
const logger = require('logger');
const fs = require('fs');
const csv = require('fast-csv');
const util = require('util');
const stream = require('stream');

export class ProjectExporter {
  readonly sqliteFileName: string = 'data.sqlite';

  projects: Promise<BatchDownloadsProjects[]>;
  deployments: Promise<BatchDownloadsDeployments[]>;
  cameras: Promise<BatchDownloadsCameras[]>;
  images: Promise<BatchDownloadsImages[]>;
  isPublicBundle: boolean;
  isGoogleCloudPlatformAccount: boolean;

  constructor(
    @Inject('ProjectsRepositoryToken') private readonly projectsRepository: Repository<Projects>,
    @Inject('BatchDownloadsProjectsRepositoryToken') private readonly batchDownloadsProjectsRepository: Repository<BatchDownloadsProjects>,
    @Inject('BatchDownloadsDeploymentsRepositoryToken') private readonly batchDownloadsDeploymentsRepository: Repository<BatchDownloadsDeployments>,
    @Inject('BatchDownloadsCamerasRepositoryToken') private readonly batchDownloadsCamerasRepository: Repository<BatchDownloadsCameras>,
    @Inject('BatchDownloadsImagesRepositoryToken') private readonly batchDownloadsImagesRepository: Repository<BatchDownloadsImages>,
  ) {
    this.isPublicBundle = false;
  }

  /**
   * Main export process
   * @param batchDownloadJob Job data for this batch export process
   * @param projectsInDownloadBundle List of project
   */
  async export(batchDownloadJob: BatchDownloads): Promise<BatchDownloads> {
    logger.debug(`Setting job status to 'Running' for batch download job with id ${batchDownloadJob.id} and payload ${JSON.stringify(batchDownloadJob)}`);

    // set value for isPublicBundle
    this.isPublicBundle = batchDownloadJob.isPublic;

    // set initial job status
    await this.updateJobStatus(batchDownloadJob.id, EBatchDownloadStatus.Running);

    const entityType = BatchDownloadService.getEntityType(batchDownloadJob);
    const entityTypeValue = (entityType === EntityType.Global) ? null : BatchDownloadService.getEntityTypeValue(batchDownloadJob);
    const metadataFileName = BatchDownloadService.getBatchDownloadUrl(batchDownloadJob.uuid, URLComponents.Slug, this.isPublicBundle, entityType, entityTypeValue);
    const metadataFilePath = `/tmp/${metadataFileName}`;

    const metadataFolder = BatchDownloadService.getBundleBaseFilenameFromMetadata(batchDownloadJob.uuid, entityType, entityTypeValue);

    const metadataFolderPath = `/tmp/${metadataFolder}`;

    // Get path to data file on bucket, trimming the leading '/' as this is not needed
    const metadataFilePathOnBucket =
      `${BatchDownloadService.getBatchDownloadUrl(batchDownloadJob.uuid, URLComponents.BasePath, this.isPublicBundle, entityType, entityTypeValue).slice(1)}/${metadataFileName}`;

    let resultBatchDownloadJob: BatchDownloads;

    try {
      fs.mkdirSync(metadataFolderPath);

      logger.debug(`Querying project, deployment, camera and image metadata for projects with id: ${batchDownloadJob.projectsInDownloadBundle}`);
      resultBatchDownloadJob = await this.packageTermsAndConditionsDocument(metadataFolderPath)
        .then(pe => pe.exportMetadataToCSVFiles(metadataFolderPath, batchDownloadJob.projectsInDownloadBundle))
        .then(pe => pe.packageImagesDownloadTutorialDocument(metadataFolderPath))
        .then(pe => pe.createMetadataArchive(metadataFilePath, metadataFolder))
        .then(pe => pe.writeDataToBucket(metadataFilePath, metadataFilePathOnBucket, config.get('batchDownloads.bucketName')))
        .then(async (pe) => {
          return pe.updateJobStatus(batchDownloadJob.id, EBatchDownloadStatus.Finished)
            .then(pe => pe.setFinishedTimestamp(batchDownloadJob.id));
        });

      await exec(`rm -rf ${metadataFolderPath} ${metadataFilePath}`);

      if (!this.isPublicBundle) {
        this.addReaderMemberToBuckets(batchDownloadJob.participant.email, batchDownloadJob.projectsInDownloadBundle);
      }
    } catch (err) {
      logger.error(err);
    }

    return resultBatchDownloadJob;
  }

  /**
   * General async stream pipeline, used to stream all of projects, deployments,
   * cameras and images data from a TypeORM stream to a filesystem stream
   * @param dbReadStream The TypeORM raw read stream
   * @param csvWriteStream The fs write stream to which CSV content should be piped
   * @param csvOptions Options for the fast-csv streamer
   * @param dataToCSVTransform Mapping of source data/field names to CSV field names
   */
  async runDataToCSVPipeline(dbReadStream, csvWriteStream, csvOptions, dataToCSVTransform) {
    const pipeline = util.promisify(stream.pipeline);
    await pipeline(
      dbReadStream,
      csv.format(csvOptions).transform(dataToCSVTransform),
      csvWriteStream,
    );
  }

  /**
   * Get project data for a list of projects
   * @param projectIds Array of numeric ids of project to export
   */
  async getProjectsStream(projectsInDownloadBundle: number[]): Promise<ReadStream> {
    return this.batchDownloadsProjectsRepository
      .createQueryBuilder('p')
      .where('p.project_internal_id IN (:...projectIds)')
      .setParameter('projectIds', projectsInDownloadBundle)
      .stream();
  }

    /**
   * Get project data for a list of projects
   * @param projectIds Array of numeric ids of project to export
   */
  async getProjects(projectsInDownloadBundle: number[]) {
    return await this.batchDownloadsProjectsRepository
      .createQueryBuilder('p')
      .where('p.project_internal_id IN (:...projectIds)')
      .setParameter('projectIds', projectsInDownloadBundle)
      .getMany();
  }

  async getImages(projectsInDownloadBundle: number[]): Promise<ReadStream> {
    const qb = this.batchDownloadsImagesRepository.createQueryBuilder('i');
    qb.where('i.project_internal_id IN (:...projectIds)').setParameter('projectIds', projectsInDownloadBundle);

    /**
     * If this is a public download bundle, we want to exclude from the bundle
     * all the images that belong to a deployment which is still under active
     * embargo.
     */
    if (this.isPublicBundle) {
      const deploymentIds = await this.getEmbargoFreeDeploymentsWithinProjects(projectsInDownloadBundle);
      qb.andWhere('i.deployment_internal_id IN (:...deploymentIds)');
      qb.setParameter('deploymentIds', deploymentIds);
    }

    return qb.stream();
  }

  async getDeployments(projectsInDownloadBundle: number[]): Promise<ReadStream> {
    return this.batchDownloadsDeploymentsRepository
    .createQueryBuilder('d')
    .where('d.project_internal_id IN (:...projectIds)')
    .setParameter('projectIds', projectsInDownloadBundle)
    .stream();
  }

  /**
   * List all deployments which are embargo free, within the projects passed as
   * parameter
   * @param projectsInDownloadBundle The projects whose deployments we should
   * check for embargo free ones
   */
  async getEmbargoFreeDeploymentsWithinProjects(projectsInDownloadBundle: number[]) {
    const deploymentIds = await this.batchDownloadsDeploymentsRepository.createQueryBuilder('d')
      .select('d.deployment_internal_id')
      .where('d.project_internal_id IN (:...projectIds)').setParameter('projectIds', projectsInDownloadBundle)
      .andWhere('d.embargo_free IS TRUE')
      .getRawMany();

    // tslint:disable-next-line
    return deploymentIds.map(({ deployment_internal_id }) => deployment_internal_id);
  }

  async getCameras(projectsInDownloadBundle: number[]): Promise<ReadStream> {
    return this.batchDownloadsCamerasRepository
    .createQueryBuilder('c')
    .select('DISTINCT(c.device_id)', 'c_device_id')
    .addSelect('c.project_internal_id', 'c_project_internal_id')
    .addSelect('c.device_make', 'c_device_make')
    .addSelect('c.device_model', 'c_device_model')
    .addSelect('c.device_serial_number', 'c_device_serial_number')
    .addSelect('c.device_purchase_year', 'c_device_purchase_year')
    .where('c.project_internal_id IN (:...projectIds)')
    .setParameter('projectIds', projectsInDownloadBundle)
    .stream();
  }

  async exportProjectsToCSV(basePath: string, projectsInDownloadBundle: number[]) {
    const filePath = `${basePath}/projects.csv`;
    logger.debug(`Exporting projects to CSV file ${filePath}`);

    const csvOptions = {
      headers: [
        'project_id',
        'project_name',
        'project_objectives',
        'project_species',
        'project_species_individual',
        'project_sensor_layout',
        'project_sensor_layout_targeted_type',
        'project_bait_use',
        'project_bait_type',
        'project_stratification',
        'project_stratification_type',
        'project_sensor_method',
        'project_individual_animals',
        'project_blank_images',
        'project_sensor_cluster',
        'project_admin',
        'project_admin_email',
        'project_admin_organization',
        'country_code',
        'embargo',
        'initiative_id',
        'metadata_license',
        'image_license',
        'project_url',
        'data_citation',
      ],
    };

    const dataToCSVTransform = row => ({
      project_id: row.p_project_internal_id,
      project_name: row.p_project_name,
      project_objectives: row.p_project_objectives,
      project_species: row.p_project_species,
      project_species_individual: row.p_project_species_individual,
      project_sensor_layout: row.p_project_sensor_layout,
      project_sensor_layout_targeted_type: row.p_project_sensor_layout_targeted_type,
      project_bait_use: row.p_project_bait_use,
      project_bait_type: (row.p_project_bait_type) ? row.p_project_bait_type : 'None',
      project_stratification: row.p_project_stratification,
      project_stratification_type: row.p_project_stratification_type,
      project_sensor_method: row.p_project_sensor_method,
      project_individual_animals: row.p_project_individual_animals,
      project_blank_images: row.p_project_blank_images,
      project_sensor_cluster: row.p_project_sensor_cluster,
      project_admin: row.p_project_admin,
      project_admin_email: row.p_project_admin_email,
      project_admin_organization: row.p_project_admin_organization,
      country_code: row.p_country_code,
      embargo: row.p_embargo,
      initiative_id: row.p_initiative_id,
      metadata_license: row.p_metadata_license,
      image_license: row.p_image_license,
      project_url: row.p_project_url,
      /**
       * The following line pulls data in from the projects.acknowledgements db
       * field to the data_citation output field. This is so that we use the
       * acknowledgements field (which can be populated by project owners), if
       * this contains any text, rather than the generated data_citation field
       * from the projects_batch_upload_vw view.
       *
       * If the acknowledgements field
       * doesn't contain any text, we output the project name only (it's tricky
       * to handle all the cases: admin name defined or not, start year defined
       * or not, etc.).
       *
       * Finally, we append the public URL of the project (within the Discover
       * interface).
       *
       * If this needs to be changed and the generated citation is
       * wanted, we can switch the following line to row.project_data_citation.
      */
      data_citation: row.p_data_citation && row.p_data_citation.length > 0 ?
        `${row.p_data_citation} (${config.get('dashboardUrl')}/discover/${row.p_project_internal_id}/${row.p_slug})` :
        // As we can't use a template string inside a template string, we
        // disable tslint for the next line.
        // tslint:disable-next-line:prefer-template
        `${row.p_project_admin_organization}${row.p_project_start_year ? ' (' + row.p_project_start_year + ')' : ''}, ${row.p_project_name} (${config.get('dashboardUrl')}/discover/${row.p_project_internal_id}/${row.p_slug})`,
    });

    const dbStream = await this.getProjectsStream(projectsInDownloadBundle);
    const projectsCSV = fs.createWriteStream(filePath);
    await this.runDataToCSVPipeline(dbStream, projectsCSV, csvOptions, dataToCSVTransform);
  }

  async exportDeploymentsToCSV(basePath: string, projectsInDownloadBundle: number[]) {
    const filePath = `${basePath}/deployments.csv`;
    logger.debug(`Exporting deployments to CSV file ${filePath}`);

    const csvOptions = {
      headers: [
        'project_id',
        'deployment_id',
        'placename',
        'longitude',
        'latitude',
        'start_date',
        'end_date',
        'event',
        'array_name',
        'bait_type',
        'bait_description',
        'feature_type',
        'feature_type_methodology',
        'camera_id',
        'quiet_period',
        'camera_functioning',
        'sensor_height',
        'height_other',
        'sensor_orientation',
        'orientation_other',
        'recorded_by',
      ],
    };

    const dataToCSVTransform = row => ({
      project_id: row.d_project_internal_id,
      deployment_id: row.d_deployment_id,
      placename: row.d_placename,
      longitude: this.isPublicBundle ? row.d_longitude_blurred : row.d_longitude,
      latitude: this.isPublicBundle ? row.d_latitude_blurred : row.d_latitude,
      start_date: row.d_start_date,
      end_date: row.d_end_date,
      event: row.d_event,
      array_name: row.d_array_name,
      bait_type: row.d_bait_type,
      bait_description: row.d_bait_description,
      feature_type: row.d_feature_type,
      feature_type_methodology: row.d_feature_type_methodology,
      camera_id: row.d_camera_id,
      quiet_period: row.d_quiet_period,
      camera_functioning: row.d_camera_functioning,
      sensor_height: row.d_sensor_height,
      height_other: row.d_height_other,
      sensor_orientation: row.d_sensor_orientation,
      orientation_other: row.d_orientation_other,
      recorded_by: row.d_recorded_by,
    });

    const dbStream = await this.getDeployments(projectsInDownloadBundle);
    const deploymentsCSV = fs.createWriteStream(filePath);
    await this.runDataToCSVPipeline(dbStream, deploymentsCSV, csvOptions, dataToCSVTransform);
  }

  async exportCamerasToCSV(basePath: string, projectsInDownloadBundle: number[]) {
    const filePath = `${basePath}/cameras.csv`;
    logger.debug(`Exporting cameras to CSV file ${filePath}`);

    const csvOptions = {
      headers: [
        'project_id',
        'camera_id',
        'make',
        'model',
        'serial_number',
        'year_purchased',
      ],
    };

    const dataToCSVTransform = row => ({
      project_id: row.c_project_internal_id,
      camera_id: row.c_device_id,
      make: row.c_device_make,
      model: row.c_device_model,
      serial_number: row.c_device_serial_number,
      year_purchased: row.c_device_purchase_year,
    });

    const dbStream = await this.getCameras(projectsInDownloadBundle);

    const camerasCSV = fs.createWriteStream(filePath);

    await this.runDataToCSVPipeline(dbStream, camerasCSV, csvOptions, dataToCSVTransform);
  }

  async exportImagesToCSV(basePath: string, projectsInDownloadBundle: number[]) {
    const filePath = `${basePath}/images.csv`;
    logger.debug(`Exporting images to CSV file ${filePath}`);

    const csvOptions = {
      headers: [
        'project_id',
        'deployment_id',
        'image_id',
        'location',
        'is_blank',
        'identified_by',
        'wi_taxon_id',
        'class',
        'order',
        'family',
        'genus',
        'species',
        'common_name',
        'uncertainty',
        'timestamp',
        'age',
        'sex',
        'animal_recognizable',
        'individual_id',
        'number_of_animals',
        'individual_animal_notes',
        'highlighted',
        'color',
        'license',
      ],
    };

    const dataToCSVTransform = row => ({
      project_id: row.i_project_internal_id,
      deployment_id: row.i_deployment_id,
      image_id: row.i_image_id,
      location: this.isPublicBundle ? null : StorageService.getImageUrl(row.i_project_slug, row.i_filepath),
      is_blank: row.i_is_blank,
      identified_by: row.i_identified_by,
      wi_taxon_id: row.i_wi_taxon_id,
      class: row.i_class,
      order: row.i_order,
      family: row.i_family,
      genus: row.i_genus,
      species: row.i_species,
      common_name: row.i_common_name,
      uncertainty: row.i_uncertainty,
      timestamp: row.i_timestamp,
      age: row.i_age,
      sex: row.i_sex,
      animal_recognizable: row.i_animal_recognizable,
      individual_id: row.i_individual_id,
      number_of_animals: row.i_number_of_animals,
      individual_animal_notes: null,
      highlighted: row.i_highlighted,
      color: null,
      license: row.i_license,
    });

    const dbStream = await this.getImages(projectsInDownloadBundle);
    const imagesCSV = fs.createWriteStream(filePath);

    await this.runDataToCSVPipeline(dbStream, imagesCSV, csvOptions, dataToCSVTransform);
  }

  async exportMetadataToCSVFiles(basePath: string, projectsInDownloadBundle: number[]): Promise<ProjectExporter> {
    await Promise.all([
      this.exportProjectsToCSV(basePath, projectsInDownloadBundle),
      this.exportDeploymentsToCSV(basePath, projectsInDownloadBundle),
      this.exportCamerasToCSV(basePath, projectsInDownloadBundle),
      this.exportImagesToCSV(basePath, projectsInDownloadBundle),
    ]);

    return this;
  }

  /**
   * Pack CSV files and Sqlite file into output zip file
   * @param metadataFolderPath Path to folder with artifacts
   * @param metadataFilePath Path to output file
   */
  async createMetadataArchive(metadataFilePath: string, metadataFolder: string): Promise<ProjectExporter> {
    try {
      // Add metadata folder to zip file
      await exec(`cd /tmp && zip -r ${metadataFilePath} ${metadataFolder}`);
    } catch (err) {
      logger.error(err);
    }

    return this;
  }

  /**
   * Copy terms and conditions file to download folder
   * @param metadataFolderPath Path to folder with artifacts
   * @param metadataFilePath Path to output file
   */
  async packageTermsAndConditionsDocument(metadataFolderPath: string): Promise<ProjectExporter> {
    try {
      await exec(`cp ${config.get('downloadDocs')}/Wildlife-Insights-Terms-of-Use-and-Privacy-Policy.pdf ${metadataFolderPath}`);
    } catch (err) {
      logger.error(err);
    }

    return this;
  }

  /**
   * Copy images download tutorial file to download folder and set tutorial dynamic variables
   * @param metadataFolderPath Path to folder with artifacts
   * @param projectSlug Slug of the project
   */
  async packageImagesDownloadTutorialDocument(metadataFolderPath: string): Promise<ProjectExporter> {
    if (!this.isPublicBundle) {
      try {
        await exec(`cp ${config.get('downloadDocs')}/Wildlife-Insights-Images-Download-Tutorial.txt ${metadataFolderPath}`);
      } catch (err) {
        logger.error(err);
      }
    }

    return this;
  }

  async updateJobStatus(jobId: number, status: EBatchDownloadStatus): Promise<ProjectExporter> {
    const entityManager = getManager();
    await entityManager.getRepository('BatchDownloads')
      .createQueryBuilder()
      .update(BatchDownloads)
      .set({ status })
      .where({ id: jobId })
      .execute();

    return this;
  }

  async setFinishedTimestamp(jobId: number): Promise<any> {
    const entityManager = getManager();
    /**
     * Bobby Tables would shiver in horror looking at the following unsanitized
     * query in a template string, but:
     * 1. it seems that using .createQueryBuilder().update(<Entity>).set()
     *    cannot be used to set the field to 'now()' - and rightly so, because
     *    TypeORM would block setting a timestamptz field to a string that
     *    doesn't appear to be a timestamptz; and
     * 2. TS will enforce jobId to be a number
     */
    await entityManager.query(`UPDATE batch_downloads SET finished_timestamp = now() WHERE id = ${jobId}`);

    return await entityManager.getRepository('BatchDownloads')
      .createQueryBuilder()
      .where({ id: jobId })
      .getOne();
  }

  /**
   * Write given file to destination bucket
   * @param filePath Path to file to be written to bucket
   * @param filePathOnBucket Path to file on the destination bucket
   * @param destinationBucket Name of destination bucket
   */
  async writeDataToBucket(filePath: string, filePathOnBucket: string, destinationBucket: string): Promise<ProjectExporter> {
    const file = new storage({
        keyFilename: process.env.GOOGLE_APPLICATION_CREDENTIALS,
      })
      .bucket(destinationBucket)
      .file(filePathOnBucket);

    await file.save(fs.readFileSync(filePath), (err) => {
      if (err) {
        console.log(err);
      } else {
        console.log(`Project metadata zip file successfully written to bucket ${destinationBucket}.`);
      }
    });

    return this;
  }

  /**
   * Add to project(s) bucket(s) the user who requested the private download bundle
   * @param email
   * @param projectsInDownloadBundle
   */
  private async addReaderMemberToBuckets(email: string, projectsInDownloadBundle: number[]): Promise<void> {
    const projects = await this.getProjects(projectsInDownloadBundle);
    const bucketRoleSubjects = projects.map((project) => {
      const bucket = `${project.slug}${config.get('storage.buckets.mainBucketSuffix')}`;
      const bucketRoleSubject = { email, bucket };
      return bucketRoleSubject;
    });

    await StorageService.addReaderMembers(bucketRoleSubjects);
  }

}
