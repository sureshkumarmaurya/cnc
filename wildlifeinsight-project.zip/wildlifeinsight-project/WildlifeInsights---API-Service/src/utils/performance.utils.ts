/**
 * Compute time delta in milliseconds for profiling
 * @param operation_description Which task is being profiled
 * @param start_time [seconds, nanoseconds] timestamp from invocation of
 * process.hrtime() at the beginning of the task being profiled
 * @returns Object with operation description and time delta in ms
 */
export function profileOp(operationDescription: string, startTime: [number, number]): { type: string, task: string, time_ms: number} {
  const diff = process.hrtime(startTime);

  return {
    type: 'profiling',
    task: operationDescription,
    time_ms: (diff[0] * 1e9 + diff[1]) / 1e6,
  };
}
