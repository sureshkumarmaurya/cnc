import * as exif from 'exiftool';

const fs = require('fs').promises;

const logger = require('logger');

export class ExifUtils {
  static async metadata(path: string) {
    logger.debug('Obtaining metadata of image in path: ', path);
    const data = await fs.readFile(path);
    logger.debug('Image read successfully. Obtaining tags');
    const metadata = await new Promise((resolve, reject) => {
      exif.metadata(data, (err, metadata) => {
        if (err) {
          logger.error('Error obtaining metadatas', err);
          reject(err);
        }
        logger.debug('metadata', metadata);
        resolve(metadata);
      });
    });
    return metadata;
  }
}
