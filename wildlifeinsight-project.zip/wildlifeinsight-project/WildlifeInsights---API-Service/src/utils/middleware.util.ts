import { pathToRegexp } from 'path-to-regexp';

interface IRegexpChecker {
  exec(regexpString: string);
}

interface IExcludeRoute {
  path: string;
  method: string;
}

export class MiddlewareUtil {
  private routeChecker;
  constructor() {
    this.routeChecker = pathToRegexp;
  }

  runMiddlewareWithExcludePathList(excludeRoutes: IExcludeRoute[], middlewareFunction) {
    const requestExcludeInfoList: IRegexpChecker[] = excludeRoutes.map(({ path, method }: IExcludeRoute): IRegexpChecker => {
      return  this.routeChecker(`${method}${path}`.toLowerCase());
    });
    return (req, res, next) => {
      const requestInfo = `${req.method}${req.baseUrl}`.toLowerCase();
      for (let index = 0; index < requestExcludeInfoList.length; index++) {
        const checkResult = requestExcludeInfoList[index].exec(requestInfo);
        if (checkResult && checkResult.length) {
          return next();
        }
      }
      return middlewareFunction(req, res, next);
    };
  }
}
