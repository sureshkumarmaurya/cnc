export interface PaginationModel {
  fields?: string[];
  includes?: string[];
  pageSize?: number;
  pageNumber?: number;
  sort?: any[];
}
