import { plainToClass } from 'class-transformer';
import { BadRequestException } from '@nestjs/common';
import { validate } from 'class-validator';

export class ValidationGraphql {
  static async validate(classType, data) {
    const object = plainToClass(classType, data);
    const errors = await validate(object);
    if (errors.length > 0) {
      const formatedErrors = errors.map((error) => {
        const messageKeys = Object.keys(error.constraints);
        return {
          status: 400,
          title: error.property,
          detail: error.constraints[messageKeys[0]],
        };
      });
      throw new BadRequestException({ errors: formatedErrors });
    }
  }

}
