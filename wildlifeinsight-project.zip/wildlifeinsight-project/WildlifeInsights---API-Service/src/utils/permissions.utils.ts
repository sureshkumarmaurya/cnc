import { AuthenticatedUserDto } from 'dto/authenticated-user.dto';
import { PermissionsDto } from 'modules/database/dto/permissions.dto';
import { ProjectsDto } from 'modules/database/dto/projects.dto';
import { OrganizationsDto } from 'modules/database/dto/organizations.dto';

const logger = require('logger');

export class PermissionsUtils {

  static validatePermissionsInProject(user: AuthenticatedUserDto, projectId: number, permissions: string[]): boolean {
    logger.debug(`Checking whether the user's role on project with id ${projectId} includes all the permissions requested: ${permissions}`);

    if (permissions) {
      const projRole = user.projectRole.find(projRole => projRole.project.id === projectId);
      if (!projRole) {
        return false;
      }
      // check if the role includes all the permissions requested
      const userPermissionsOnProject = projRole.role.permissions.map(permission => permission.slug);
      logger.debug(`User with id ${user.user.id} has the following permissions on project with id ${projectId}: ${userPermissionsOnProject}`);

      const userHasRequestedPermissionsOnProject = permissions
        .map(p => projRole.role.permissions
          .some((per: PermissionsDto) => per.slug === p))
        .reduce((prev, current) => prev && current, true);

      return userHasRequestedPermissionsOnProject;
    }
    return true;
  }

  static validatePermissionsInInitiative(user: AuthenticatedUserDto, initiativeId: number, permissions: string[]): boolean {
    logger.debug(`Checking whether the user's role on initiative with id ${initiativeId} includes all the permissions requested: ${permissions}`);

    if (permissions) {
      const initiativeRole = user.initiativeRole.find(initiativeRole => initiativeRole.initiative.id === initiativeId);
      if (!initiativeRole) {
        return false;
      }
      // check if the role includes all the permissions requested
      const userPermissionsOnInitiative = initiativeRole.role.permissions.map(permission => permission.slug);
      logger.debug(`User with id ${user.user.id} has the following permissions on initiative with id ${initiativeId}: ${userPermissionsOnInitiative}`);

      const userHasRequestedPermissionsOnInitiative = permissions
        .map(p => initiativeRole.role.permissions
          .some((per: PermissionsDto) => per.slug === p))
        .reduce((prev, current) => prev && current, true);

      return userHasRequestedPermissionsOnInitiative;
    }
    return true;
  }

  static validatePermissionsInOrganization(user: AuthenticatedUserDto, organizationId: number, permissions: string[]): boolean {
    logger.debug(`Checking whether the user's role on organization with id ${organizationId} includes all the permissions requested: ${permissions}`);

    if (permissions) {
      const orgRole = user.organizationRole.find(orgRole => orgRole.organization.id === organizationId);
      if (!orgRole) {
        return false;
      }
      // check if the role includes all the permissions requested
      const userPermissionsOnOrganization = orgRole.role.permissions.map(permission => permission.slug);
      logger.debug(`User with id ${user.user.id} has the following permissions on organization with id ${organizationId}: ${userPermissionsOnOrganization}`);

      const userHasRequestedPermissionsOnOrganization =  permissions
        .map(p => orgRole.role.permissions
          .some((per: PermissionsDto) => per.slug === p))
        .reduce((prev, current) => prev && current, true);

      return userHasRequestedPermissionsOnOrganization;
    }
    return true;
  }

  static validatePermissionsInGenericRole(user: AuthenticatedUserDto, permissions: string[]): boolean {
    logger.debug(`Checking whether the user's generalRole includes all the permissions requested: ${permissions}`);

    if (permissions) {
      // check if the user's generic role includes all the permissions requested
      const userPermissions = user.generalRole.permissions.map(permission => permission.slug);
      logger.debug(`User with id ${user.user.id} has the following permissions granted by their generic role: ${userPermissions}`);

      const userHasRequestedPermissions = permissions
        .map(p => user.generalRole.permissions
          .some((per: PermissionsDto) => per.slug === p))
        .reduce((prev, current) => prev && current, true);
      return userHasRequestedPermissions;
    }
    return true;
  }

  /**
   * Get a list of projects within all organizations, on which the given user
   * has the requested permission.
   */
  static getProjectsInAllOrganizationsWithPermission(user: AuthenticatedUserDto, permission: string): ProjectsDto[] {
    logger.debug('Obtaining projects in all organization of the user with permission: ', permission);

    if (permission) {

      const projects = user.projectRole
        .filter(projRole => projRole.role.permissions
          .some(per => per.slug === permission));
      // check if the role contains all permissions
      return projects.map(projRole => projRole.project);
    }
    return [];
  }

  /**
   * Get a list of projects within an organization on which the given user has
   * the requested permission.
   */
  static getProjectsInOrganizationWithPermission(user: AuthenticatedUserDto, permission: string, organizationId: number): ProjectsDto[] {
    logger.debug(`Obtaining projects in organization ${organizationId} of the user with permission: `, permission);

    if (permission && organizationId) {
      const projects = user.projectRole
        .filter(projRole => projRole.project.organizationId === organizationId &&
          projRole.role.permissions
            .some(per => per.slug === permission));
      // check if the role contains all permissions
      return projects.map(projRole => projRole.project);
    }
    return [];
  }

  /**
   * Get a list of projects within an initiative on which the given user has
   * the requested permission.
   */
  static getProjectsInInitiativeWithPermission(user: AuthenticatedUserDto, permission: string, initiativeId: number): ProjectsDto[] {
    logger.debug(`Obtaining projects in initiative ${initiativeId} of the user with permission: `, permission);
    if (permission && initiativeId) {
      const projects = user.projectRole
        .filter(projRole => projRole.project.initiativeId === initiativeId && projRole.role.permissions
          .some(per => per.slug === permission));
      // check if the role contains all permissions
      return projects.map(projRole => projRole.project);
    }
    return [];
  }

  /**
   * Get a list of organizations on which the given user has the requested
   * permission.
   */
  static getOrganizationsWithPermission(user: AuthenticatedUserDto, permission: string): OrganizationsDto[] {
    logger.debug('Obtaining organizations  of the user with permission: ', permission);

    if (permission) {
      const organizations = user.organizationRole
        .filter(organizationRole => organizationRole.role.permissions
          .some(per => per.slug === permission));
      // check if the role contains all permissions
      return organizations.map(organizationRole => organizationRole.organization);
    }
    return [];
  }

}
