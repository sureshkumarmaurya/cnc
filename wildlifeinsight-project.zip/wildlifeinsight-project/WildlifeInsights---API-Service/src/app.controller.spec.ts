import { Test, TestingModule } from '@nestjs/testing';

describe('AppController', () => {
  let app: TestingModule;

  beforeAll(async () => {
    app = await Test.createTestingModule({
    }).compile();
  });

  describe('root', () => {
    // @TODO just to make it work
    it('should return "Hello World!"', () => {
      const appController = 'Hello World!';
      expect(appController).toBe('Hello World!');
    });
  });
});
