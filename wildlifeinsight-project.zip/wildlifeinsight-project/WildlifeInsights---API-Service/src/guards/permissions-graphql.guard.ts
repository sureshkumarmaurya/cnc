import { AuthenticatedUserDto } from 'dto/authenticated-user.dto';

import { Injectable, CanActivate, ExecutionContext } from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { PermissionsUtils } from 'utils/permissions.utils';
import { GqlExecutionContext } from '@nestjs/graphql';

const logger = require('logger');

@Injectable()
export class PermissionsGraphQlGuard implements CanActivate {
  constructor(private readonly reflector: Reflector) {}

  canActivate(context: ExecutionContext): boolean {
    const ctx = GqlExecutionContext.create(context);
    const request = ctx.getContext(); // request
    const params = context.getArgByIndex(1);
    const user:AuthenticatedUserDto = request.req.user;

    const permissions = this.reflector.get<string[]>('permissions', context.getHandler());

    if (!permissions || permissions.length === 0) {
      return true;
    }
    if (params.projectId !== undefined) {
      return PermissionsUtils.validatePermissionsInProject(user, parseInt(params.projectId, 10), permissions);
    }
    if (params.organizationId !== undefined) {
      return PermissionsUtils.validatePermissionsInOrganization(user, parseInt(params.organizationId, 10), permissions);
    }

    return PermissionsUtils.validatePermissionsInGenericRole(user, permissions);

  }
}
