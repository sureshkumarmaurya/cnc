import { Injectable, CanActivate, ExecutionContext, UnauthorizedException } from '@nestjs/common';
import { AuthenticatedUserDto } from 'dto/authenticated-user.dto';

const logger = require('logger');

@Injectable()
export class SuperAdminGuard implements CanActivate {
  constructor() {}

  canActivate(context: ExecutionContext): boolean {
    logger.debug('Checking permissions');
    const req = context.switchToHttp().getRequest();
    const user: AuthenticatedUserDto = req.user;
    logger.debug(user);
    if (!user) {
      throw new UnauthorizedException();
    }

    if (!user.generalRole || !user.generalRole.superAdmin) {
      throw new UnauthorizedException();
    }
    return true;
  }
}
