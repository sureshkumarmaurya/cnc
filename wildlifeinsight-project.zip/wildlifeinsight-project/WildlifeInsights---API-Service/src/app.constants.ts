export const PROJECT_HEADER = 'wi-project';

export const DATA_FILE_STATUS_CV = 'CV';
export const DATA_FILE_STATUS_BLANK = 'BLANK';
export const DATA_FILE_STATUS_VERIFIED = 'VERIFIED';
export const DATA_FILE_STATUS_UNKNOWN = 'UNKNOWN';
