
import { Injectable, Inject } from '@nestjs/common';
import * as Monitoring from '@google-cloud/monitoring';

const logger = require('logger');

export enum MetricKind {
  METRIC_KIND_UNSPECIFIED,
  GAUGE,
  DELTA,
  CUMULATIVE,
}

export enum ValueType {
  VALUE_TYPE_UNSPECIFIED,
  BOOL,
  INT64,
  DOUBLE,
  STRING,
  DISTRIBUTION,
  MONEY,
}

export class LabelDescriptor {
  constructor(
    private key: string,
    private valueType: ValueType,
    private description: string,
  ) {}
}

export class MetricDescriptor {
  constructor(
    private description: string,
    private displayName: string,
    private _type: string,
    private labels: LabelDescriptor[],
    private metricKind: MetricKind,
    private valueType: ValueType,
    private unit?: string,
  ) {}

  get type () {
    return this._type;
  }

}

export class CustomMetric {

  // https://cloud.google.com/monitoring/api/ref_v3/rest/v3/projects.metricDescriptors
  constructor(
    private _metricDescriptor: MetricDescriptor,
  ) {}

  get metricDescriptor() {
    return this._metricDescriptor;
  }

}

/**
 * Metrics Service
 */
@Injectable()
export class MetricsService {
  private metrics: any;
  private _projectId: string;
  private _metricsName: string;

  /**
   * Metrics Service
   * @constructor
   * @description initializes the metrics client (it uses the GOOGLE_APPLICATION_CREDENTIALS env variable)
   */
  constructor() {
    this.metrics = new Monitoring.MetricServiceClient({
      keyFilename: process.env.GOOGLE_APPLICATION_CREDENTIALS,
    });
    this._projectId = require(process.env.GOOGLE_APPLICATION_CREDENTIALS).project_id;
    this._metricsName = this.metrics.projectPath(this._projectId);
  }

  get projectId() {
    return this._projectId;
  }

  get metricsName() {
    return this._metricsName;
  }

  /**
   * createCustomMetrics
   * @description creates a custom Stackdriver metric
   * @param {CustomMetric} customMetric The customMetric
   * @return {Promise} customMetric creation promise
   */
  createCustomMetric(customMetric: CustomMetric): Promise<CustomMetric> {
    logger.debug(`Creating ${customMetric.metricDescriptor.type} metric`);
    try {
      return this.metrics.createMetricDescriptor({
        name: this.metricsName,
        metricDescriptor: customMetric.metricDescriptor,
      });
    } catch (error) {
      logger.error(error);
      throw new Error(error);
    }
  }

  /**
   * writeMetricData
   * @description writeMetricData
   * @param {CustomMetric} metricType
   * @param {object} metricLabels
   * @param {any} point
   */
  writeMetricData(metricType: string, metricLabels: object, value: any): Promise<any> {
    logger.debug(`Writing data in ${metricType} metric`);
    try {
      return this.metrics.createTimeSeries({
        name: this.metricsName,
        timeSeries: [{
          metric: {
            type: metricType,
            labels: metricLabels,
          },
          resource: {
            type: 'global',
            labels: {
              project_id: this.projectId,
            },
          },
          points: [{
            interval: {
              endTime: {
                seconds: Date.now() / 1000,
              },
            },
            value: {
              doubleValue: value,
            },
          }],
        }],
      });
    } catch (error) {
      logger.error(error);
      throw new Error(error);
    }
  }

}
