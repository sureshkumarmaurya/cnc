import { Test, TestingModule } from '@nestjs/testing';
import { CloudFunctionsService } from './cloudfunctions.service';
import { MetricsService } from './metrics.service';
import { GCP as _GCP } from './google.constants';

describe('CloudFunctionsService', () => {
  let cloudFunctionsService: CloudFunctionsService;
  const projectId = `wi__testing__${Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15)}`;
  
  beforeEach(async () => {
    const module = await Test.createTestingModule({
      providers: [CloudFunctionsService, MetricsService],
    }).compile();

    cloudFunctionsService = module.get<CloudFunctionsService>(CloudFunctionsService);
  });

  describe('getCloudFunctions', () => {
    it('should return functions', async () => {
      const result = {name: ''};
      // mocking sometimes? 
      // jest.spyOn(cloudFunctionsService, 'getCloudFunctions').mockImplementation(() => result);

      const functions = await cloudFunctionsService.getCloudFunctions();
      functions.forEach(fn => {
        expect(fn.name).toContain(_GCP.projectId);
      });
      console.log(`✅✅ Functions listed successfully`);
    });
  });

  describe('createWICloudFunctions', () => {
    it('should return functions', async () => {
      const result = {name: ''};
      // mocking sometimes? 
      // jest.spyOn(cloudFunctionsService, 'getCloudFunctions').mockImplementation(() => result);

      const functions = await cloudFunctionsService.createWICloudFunctions(projectId);
      functions.forEach(fn => {
        expect(fn.name).toContain(_GCP.projectId);
      });
      console.log(`✅✅ Functions created and listed successfully`);
    }, 120000);
  },);

});
