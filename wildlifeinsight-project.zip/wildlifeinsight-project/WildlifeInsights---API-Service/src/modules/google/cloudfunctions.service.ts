
/* tslint:disable */

import { Injectable } from '@nestjs/common';
import { GCF as _GC, GCP as _GCP } from './google.constants';
import { CloudFunctionMetadata, CloudFunctionQuery, CloudFunctionConfig,
   CloudFunction, Operation } from 'googleapis-nodejs-functions';
const { GCF } = require('googleapis-nodejs-functions');

const logger = require('logger');

export class CloudFunctionSpec {
  constructor(
    private _name: string,
    private _config: CloudFunctionConfig,
  ) {}

  get name () {
    return this._name;
  }

  get config () {
    return this._config;
  }

  set config (config: CloudFunctionConfig) {
    this._config = config;
  }

}

/**
 * Functions Service
 */
@Injectable()
export class CloudFunctionsService {

  // private static readonly FUNCTIONS_CONFIG: CloudFunctionSpec[] = _GC.FUNCTIONS_CONFIG.slice()
  // .map(functionToCreate => new CloudFunctionSpec(functionToCreate.type, functionToCreate.config));

  // initializes the storage client (it uses the GOOGLE_APPLICATION_CREDENTIALS env variable)
  static gcf = new GCF({
    keyFilename: process.env.GOOGLE_APPLICATION_CREDENTIALS,
    projectId: _GCP.projectId,
  });

  /**
   * @constructor
   */
  constructor() {
  }

  /**
   * createFunction
   * @description creates a gcf cloud function
   * @param {string} name The function name
   * @param {CloudFunctionConfig} config? The cloudFunction config
   * @return {Promise<Operation>} operation
   */
  private async createCloudFuntion(name: string, config?: CloudFunctionConfig): Promise<Operation> {
    logger.debug(`[GCF OPERATION] Creating function ${name} `);
    try {
      return await CloudFunctionsService.gcf.createCloudFunction(name, config).then(value => value[0]);
    } catch (error) {
      logger.error(error);
      throw new Error(error);
    }
  }

  private async getCloudFunctionWhenReady(operationName: string): Promise<CloudFunction> {
    const operation = await CloudFunctionsService.gcf.operation(operationName).then(value => value[0]);
    if (operation.done) {
      if (operation.response) {
        return await CloudFunctionsService.gcf.cloudFunction(operation.response.name);
      }
      // opeartion.done equals to true but no response means error
      throw new Error(`${operation.error.code} - ${operation.error.message}`);
    }
    // timeout of 3000ms to check the operation again
    await new Promise(resolve => setTimeout(resolve, 3000));
    return await this.getCloudFunctionWhenReady(operationName);
  }

   /**
   * deleteCloudFunction
   * @description deletes a cloud function
   * @param {string} name The cloud function name
   * @return {Promise<any>} cloud function deletion promise
   */
  private async deleteCloudFunction(name: string): Promise<void> {
    logger.debug(`[GCF OPERATION] Deleting cloud function ${name} `);
    try {
      const cloudFunction = CloudFunctionsService.gcf.cloudFunction(name);
      await cloudFunction.delete();
    } catch (error) {
      logger.error(error);
      throw new Error(error);
    }
  }

  /****************************************************************
   ********************* PUBLIC METHODS **************************
   ****************************************************************/

  /**
   * getCloudFunctions
   * @description list gcf functions
   * @param {CloudFunctionQuery} query? cloud function query
   * @return {Promise<CloudFunction>} function creation promise
   */
  public async getCloudFunctions(query?: CloudFunctionQuery): Promise<CloudFunction[]> {
    try {
      // @TODO archelogos -> filter by WIprojectId? two different methods?
      const fns: CloudFunction[] = await (CloudFunctionsService.gcf.getCloudFunctions() as Promise<[CloudFunction[], any]>).then(value => value[0]);
      return fns;
    } catch (err) {
      logger.error(err);
      throw Error(err);
    }
  }

  /**
   * createWICloudFunctions
   * @description creates cloud functions for a WI project
   * @param {string} wiProject The WI project
   * @param {Array<CloudFunctionSpec>} functionsToCreate functions specs to create
   * @return {Promise<CloudFunction[]>} cloud function array
   */
  public async createWICloudFunctions(wiProject: string, functionsToCreate?: CloudFunctionSpec[]): Promise<CloudFunction[]> {
    logger.debug(`Creating cloud functions for project: ${wiProject}`);
    try {
      functionsToCreate = functionsToCreate || _GC.FUNCTIONS_CONFIG.slice().map(functionToCreate => new CloudFunctionSpec(functionToCreate.type, Object.assign({}, functionToCreate.config)));
      functionsToCreate.map(fnTC => {
        const eventTrigger = Object.assign({}, fnTC.config.eventTrigger);
        eventTrigger.resource = eventTrigger.resource.replace(/{bucketId}/g, `${wiProject}__main`);
        eventTrigger.resource = eventTrigger.resource.replace(/{topicId}/g, `${_GCP.projectId}/topics/${wiProject}`);
        fnTC.config.eventTrigger = eventTrigger;
        if (process.env.NODE_ENV !== 'prod') {
          fnTC.config.sourceArchiveUrl = `${fnTC.config.sourceArchiveUrl.split('.')[0]}-staging.${fnTC.config.sourceArchiveUrl.split('.')[1]}`;
        }
        return fnTC;
      });
      // we got the operations at this point, but we want to wait until they've been completed
      const cloudFunctionsOperations: Operation[] = await Promise.all(functionsToCreate.map(cloudFunctionSpec => this.createCloudFuntion(`${wiProject}__${cloudFunctionSpec.name}`, cloudFunctionSpec.config)));
      // // get cloudFunctions
      const cloudFunctions: CloudFunction[] = await Promise.all(cloudFunctionsOperations.map(cloudFunctionsOperation => this.getCloudFunctionWhenReady(cloudFunctionsOperation.name)));
      return cloudFunctions;
    } catch (error) {
      logger.error(error);
      throw new Error(error);
    }
  }

   /**
   * deleteWICloudFunctions
   * @description deletes WI project's cloud functions
   * @param {string} wiProject The WI project
   * @param {Array<CloudFunctionSpec>} functionsToCreate cloud functions specs to create
   * @return {Array<Promise<[ApiResponse]>>} cloud functions deletion promise array
   */
  public async deleteWICloudFunctions(wiProject: string, functionsToDelete?: CloudFunctionSpec[]): Promise<any[]> {
    logger.debug(`Deleting cloud functions for project: ${wiProject}`);
    try {
      functionsToDelete = functionsToDelete || _GC.FUNCTIONS_CONFIG.slice().map(functionToDelete => new CloudFunctionSpec(functionToDelete.type, Object.assign({}, functionToDelete.config)));
      return await Promise.all(functionsToDelete.map(cloudFunctionSpec => this.deleteCloudFunction(`${wiProject}__${cloudFunctionSpec.name}`)));
    } catch (error) {
      logger.error(error);
      throw new Error(error); // error deleting, retry here?
    }
  }

}
