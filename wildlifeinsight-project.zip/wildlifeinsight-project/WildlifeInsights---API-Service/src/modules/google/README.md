# Google Cloud Module for WI

## StorageService

### Usage

#### Create Buckets

```ts
import { StorageService } from './storage.service';

const storageService = new StorageService();
const projectId = 'wi__project-example';

try {
    const buckets = await storageService.createWIBuckets(projectId);
} catch (err) {
    console.log(`error creating buckets for project ${projectId}`);
    try {
        await storageService.deleteWIBuckets(projectId);
    } catch (err) {
        console.log(`error deleting, retry?`);
    }
}
```

#### Upload File to Temp

```ts
import { StorageService } from './storage.service';

const storageService = new StorageService();
const projectId = 'wi__project-example';
const deploymentId = '12345';
const userId = '12345';
const fileName = 'test.txt'

try {
    const file = await storageService.uploadToTempBucket(projectId, deploymentId, userId, fileName);
} catch (err) {
    console.log(`error uploading file`);
}
```

#### File Deletion

```ts
import { StorageService } from './storage.service';

const storageService = new StorageService();
const projectId = 'wi__project-example';
const fileName = 'deployment/1/test.txt';

try {
    const deleteOperation = await storageService.deleteWIFile(projectId, fileName);
} catch (err) {
    console.log(`error deleting file`);
}
```

#### Get SignedUrl for getting the image

```ts
import { StorageService } from './storage.service';

const storageService = new StorageService();
const projectId = 'wi__project-example';
const fileName = 'deployment/1/test.txt';

try {
    const signedUrl = await storageService.getSignedUrlWIFile(projectId, fileName);
} catch (err) {
    console.log(`error getting signedUrl`);
}
```

#### Get SignedUrl for uploading an image

```ts
import { StorageService } from './storage.service';

const storageService = new StorageService();
const projectId = 'wi__project-example';
const deploymentId = '12345';
const userId = '12345';
const fileName = 'test.txt'

try {
    const signedUrl = await storageService.getSignedUrlForUpload(wiProject, deploymentId, userId, fileName);
} catch (err) {
    console.log(`error getting signedUrl`);
}
```

#### Download binary

```ts
import { StorageService } from './storage.service';

const storageService = new StorageService();
const projectId = 'wi__project-example';
const fileName = 'deployment/1/test.txt';

try {
    const signedUrl = await storageService.downloadFile(wiProject, fileName);
} catch (err) {
    console.log(`error getting signedUrl`);
}
```

## CloudFunctionsService

### Usage

#### Create CloudFunctions for a project

```ts
import { CloudFunctionsService } from './cloudfunctions.service';

const cloudFunctionsService = new CloudFunctionsService();
const projectId = 'wi__project-example';

try {
    // it can take a while... it checks the operation a few times
    const cloudFunctions = await cloudFunctionsService.createWICloudFunctions(projectId);;
} catch (err) {
    console.log(`error creating cloud functions for project ${projectId}`);
    throw new Error(err);
}
```

#### Get CloudFunctions

```ts
import { CloudFunctionsService } from './cloudfunctions.service';

const cloudFunctionsService = new CloudFunctionsService();
const projectId = 'wi__project-example';

try {
    const cloudFunctions = await cloudFunctionsService.getCloudFunctions();
} catch (err) {
    console.log(`error getting cloud functions`);
}
```

## Pubsub Service

### Usage

#### Create Topics and Subscriptions for a project

```ts
import { PubSubService } from './pubsub.service';

const pubSubService = new PubSubService();
const projectId = 'wi__project-example';

try {
    const ok = await pubSubService.createWITopics(projectId);;
} catch (err) {
    console.log(`error creating pubsub topics and subscriptions for project ${projectId}`);
    throw new Error(err);
}
```

#### Get Subscriptions

```ts
import { PubSubService } from './pubsub.service';

const pubSubService = new PubSubService();
const projectId = 'wi__project-example';

try {
    const subscriptions = await pubSubService.getSubscriptions();
} catch (err) {
    console.log(`error getting subscriptions`);
}
```

