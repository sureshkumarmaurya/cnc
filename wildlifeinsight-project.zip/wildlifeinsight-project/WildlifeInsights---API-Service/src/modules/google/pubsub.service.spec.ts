import { Test, TestingModule } from '@nestjs/testing';
import { PubSubService } from './pubsub.service';
import { MetricsService } from './metrics.service';
import { GCP as _GCP } from './google.constants';

describe('PubSubService', () => {
  let pubSubService: PubSubService;
  const projectId = `wi__testing__${Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15)}`;

  beforeEach(async () => {
    const module = await Test.createTestingModule({
      providers: [PubSubService, MetricsService],
    }).compile();

    pubSubService = module.get<PubSubService>(PubSubService);
  });

  describe('getSubscriptions', () => {
    it('should return subscriptions', async () => {
      const result = {name: ''};
      // mocking sometimes? 
      // jest.spyOn(pubSubService, 'getSubscriptions').mockImplementation(() => result);

      const subscriptions = await pubSubService.getSubscriptions();
      subscriptions.forEach(s => {
        expect((s as any).name).toContain(_GCP.projectId);
      });
      console.log(`✅✅ subscriptions listed successfully`);
    });
  });

  describe('createWITopics', () => {
    it('should return true', async () => {
      const result = {name: ''};
      // mocking sometimes? 
      // jest.spyOn(pubSubService, 'getSubscriptions').mockImplementation(() => result);

      const success = await pubSubService.createWITopics(projectId);
      console.log(success);
      expect(success).toBe(true);
      console.log(`✅✅ topics created successfully`);
    }, 120000);
  });

});
