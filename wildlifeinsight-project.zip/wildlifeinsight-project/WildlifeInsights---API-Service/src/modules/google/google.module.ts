import { Module, HttpModule } from '@nestjs/common';
import { StorageService } from './storage.service';
import { MetricsService } from './metrics.service';
import { CloudFunctionsService } from './cloudfunctions.service';
import { CloudBuildService } from './cloudbuild.service';
import { DatabaseModule } from 'modules/database/database.module';
@Module({
  imports: [HttpModule, DatabaseModule],
  providers: [StorageService, MetricsService, CloudFunctionsService, CloudBuildService],
  exports: [StorageService, MetricsService, CloudFunctionsService, CloudBuildService],
})
export class GoogleModule {}
