/* tslint:disable */
import { Inject, Injectable, BadRequestException, HttpService } from '@nestjs/common';
import { Repository } from 'typeorm';
import { BatchDownloads } from 'modules/database/entities/batch-downloads.entity';
import { EBatchDownloadStatus } from 'modules/database/dto/batch-downloads.dto';
import { MetricKind, ValueType, MetricsService } from './metrics.service';
import { GCS as _GC } from './google.constants';
import * as path from 'path';
import {
  Bucket,
  File,
  ApiResponse,
  BucketConfig,
  BucketQuery,
  UploadOptions,
  SignedUrlConfig,
} from '@google-cloud/storage';
import { Projects } from 'modules/database/entities/projects.entity';

const credentials = require(process.env.GOOGLE_APPLICATION_CREDENTIALS);
const scopes = ['https://www.googleapis.com/auth/cloud-platform'];
const { spawn } = require('child_process');
const logger = require('logger');
const config = require('config');
const moment = require('moment');
const { google } = require('googleapis');
const Storage = require('@google-cloud/storage');
const storageUserMemberPrefix = 'user:';
const mainBucketSuffix = config.get('storage.buckets.mainBucketSuffix');

export enum WIBucketType {
  main = 'main',
  thumbnail = 'thumbnail'
}

export class BucketSpec {
  constructor(
    private _type: string,
    private _config: BucketConfig,
  ) {}

  get type () {
    return this._type;
  }

  get config () {
    return this._config;
  }

}

export const newBucketMetricConfig = {
  type: 'custom.googleapis.com/buckets/new_buckets',
  description: 'Created Buckets for Projects',
  displayName: 'Created Buckets',
  metricKind: MetricKind.GAUGE,
  valueType: ValueType.INT64,
  labels: [
    {
      key: 'project_id',
      valueType: ValueType.STRING,
      description: 'The ID of the project.',
    },
  ],
};

export interface BucketRoleSubject {
  bucket: string;
  email: string;
}

/**
 * Storage Service
 * @metrics custom.googleapis.com/buckets/new_buckets; type INT; label {string} projectId
 */
@Injectable()
export class StorageService {

  // private static readonly BUCKET_CONFIG: BucketSpec[] = _GC.BUCKETS_CONFIG.slice()
  // .map(bucketToCreate => new BucketSpec(bucketToCreate.type, bucketToCreate.config));

  // initializes the storage client (it uses the GOOGLE_APPLICATION_CREDENTIALS env variable)
  static gcs = new Storage({
    keyFilename: process.env.GOOGLE_APPLICATION_CREDENTIALS,
  });

  /**
   * @constructor
   */
  constructor(
    private readonly metrics: MetricsService,
    private readonly httpService: HttpService,

    @Inject('BatchDownloadsRepositoryToken') private readonly batchDownloadsRepository: Repository<BatchDownloads>,
    @Inject('ProjectsRepositoryToken') private readonly projectsRepository: Repository<Projects>,
  ) {}

  /**
   * createBucket
   * @description creates a gcs bucket
   * @param {string} name The bucket name
   * @param {BucketConfig} config? The bucket config
   * @return {Promise<Bucket>} bucket creation promise
   */
  private async createBucket(name: string, config?: BucketConfig): Promise<Bucket> {
    logger.debug(`[GCS OPERATION] Creating bucket ${name} `);
    try {
      return await StorageService.gcs.createBucket(name, config).then(value => value[0]);
    } catch (error) {
      logger.error(error);
      throw new Error(error);
    }
  }

  /**
   * deleteBucket
   * @description deletes a gcs bucket
   * @param {string} name The bucket name
   * @return {Promise<any>} bucket deletion promise
   */
  private async deleteBucket(name: string): Promise<ApiResponse> {
    logger.debug(`[GCS OPERATION] Deleting bucket ${name} `);
    try {
      const bucket = StorageService.gcs.bucket(name);
      await bucket.deleteFiles();
      return await StorageService.gcs.bucket(name).delete().then(value => value[1]);
    } catch (error) {
      logger.error(error);
      throw new Error(error);
    }
  }

  /**
   * getBucket
   * @description get a bucket
   * @param {string} name The bucket name
   * @return {Bucket} Bucket
   */
  private getBucket(name: string): Bucket {
    logger.debug(`Getting bucket ${name}`);
    try {
      return StorageService.gcs.bucket(name);
    } catch (error) {
      logger.error(error);
      throw new Error(error);
    }
  }

  /**
   * getFile
   * @description get a File
   * @param {string} bucketName bucketName
   * @param {string} fileName file name
   * @return {Promise<File> } File promise or null
   */
  private async getFile(bucketName: string, fileName: string): Promise<File> {
    logger.debug('[GCS OPERATION] Get File');
    try {
      const bucket = this.getBucket(bucketName);
      return bucket.file(fileName);
    } catch (error) {
      logger.error(error);
      throw new Error(error);
    }
  }

  /**
   * existFile
   * @description
   * @param {string} bucketName bucketName
   * @param {string} fileName file name
   * @return {Promise<boolean> } boolean
   */
  private async existFile(bucketName: string, fileName: string): Promise<boolean> {
    logger.debug('[GCS OPERATION] Exist File');
    try {
      const bucket = this.getBucket(bucketName);
      const file = bucket.file(fileName);
      return await file.exists().then(value => value[0]);
    } catch (error) {
      logger.error(error);
      throw new Error(error);
    }
  }

  /**
   * uploadFile
   * @description upload a file to a bucket
   * @param {string} bucketName bucketName
   * @param {string} localPath file path
   * @param {UploadOptions?} options file upload options
   * @return {Promise<File>} File promise
   */
  private async uploadFile(bucketName: string, localPath: string, options?: UploadOptions): Promise<File> {
    logger.debug('[GCS OPERATION] Creating File');
    try {
      const bucket = this.getBucket(bucketName);
      return await bucket.upload(localPath, options).then(value => value[0]);
    } catch (error) {
      logger.error(error);
      throw new Error(error);
    }
  }

  /**
   * copyFile
   * @description copy a file to the same bucket or a different
   * @param {File} source bucketName
   * @param {string | Bucket | File} destination file path
   * @return {Promise<File>} File promise
   */
  private async copyFile(source: File, destination: string | Bucket | File): Promise<File> {
    logger.debug('[GCS OPERATION] Copying File');
    try {
      return await source.copy(destination).then(value => value[0]);
    } catch (error) {
      logger.error(error);
      throw new Error(error);
    }
  }

  /**
   * deleteFile
   * @description delete a file from a bucket
   * @param {File} file file
   * @return {Promise<File>} File promise
   */
  private async deleteFile(file: File): Promise<ApiResponse> {
    logger.debug('[GCS OPERATION] Deleting File');
    try {
      return await file.delete().then(value => value[0]);
    } catch (error) {
      logger.error(error);
      throw new Error(error);
    }
  }

  /**
   * getSignedUrl
   * @description delete a file signedUrl
   * @param {File} file file
   * @param {SignedUrlConfig} config? signedUrlConfig -> {action, expires}
   * @return {Promise<File>} File promise
   */
  private async getSignedUrl(file: File, config?: SignedUrlConfig): Promise<string> {
    logger.debug('[GCS OPERATION] SignedUrl File');
    try {
      const signedUrlConfig = Object.assign({}, _GC.SIGNED_URL_READ_CONFIG, config);
      signedUrlConfig.expires = signedUrlConfig.expires || Date.now() + 60 * 60 * 1000;
      return await file.getSignedUrl(signedUrlConfig).then(value => value[0]);
    } catch (error) {
      logger.error(error);
      throw new Error(error);
    }
  }

  /**
   * deleteFiles
   * @description deleteFiles
   * @param {string} bucketName the bucket name
   * @param {string} prefix files with a match prefix
   * @return {Promise<void>} void
   */
  private async deleteFiles(bucketName: string, prefix: string): Promise<void> {
    logger.debug('[GCS OPERATION] Delete Files');
    try {
      const bucket = this.getBucket(bucketName);
      return await bucket.deleteFiles({
        prefix,
      }).then(value => value[0]);
    } catch (error) {
      logger.error(error);
      throw new Error(error);
    }
  }

  /**
   * getAccessToken
   * @description get the access token for authenticated requests
   * @return {Promise<string>} string
   */
  private async getAccessToken(): Promise<string> {
    const jwt = new google.auth.JWT(credentials.client_email, null, credentials.private_key, scopes);
    const token = await jwt.authorize().then(data => `${data.token_type} ${data.access_token}`);
    return token; // -> Authorization: token for the XML API (in a different method)
  }

  /**
   * setLifecycle
   * @description setLifecycle for a bucket
   * @param {string} bucketName the bucket name
   * @return {Promise<void>} string
   */
  private async setLifecycle(bucketName: string, lifecycleConfig?: string): Promise<any> {
    // wait. buckets need some time to be totally created
    await new Promise(resolve => setTimeout(resolve, 5000));
    logger.debug(`[GCS OPERATION] Setting lifecycle to -> ${bucketName}`);
    const token = await this.getAccessToken();
    try {
      const response = await this.httpService.put(
        `https://storage.googleapis.com/${bucketName}?lifecycle`,
        lifecycleConfig || `
        <LifecycleConfiguration>
          <Rule>
            <Action>
              <Delete/>
            </Action>
            <Condition>
              <Age>30</Age>
              <IsLive>false</IsLive>
            </Condition>
          </Rule>
        </LifecycleConfiguration>`,
        {
          method: 'PUT',
          headers: {
            Authorization: token,
            'Content-Type': 'text/xml',
          },
        },
      ).toPromise();
      return response;
    } catch (e) {
      logger.error(e);
      return await this.setLifecycle(bucketName, lifecycleConfig);
    }
  }

  /****************************************************************
   ********************* PUBLIC METHODS **************************
   ****************************************************************/

  /**
   * getBuckets
   * @description get the project's storage buckets
   * @param {BucketQuery} query
   * @return {Promise<Bucket[]>} bucket list promise
   */
  public async getBuckets(query?: BucketQuery): Promise<Bucket[]> {
    logger.debug('Getting buckets');
    try {
      return await StorageService.gcs.getBuckets(query).then(value => value[0]);
    } catch (error) {
      logger.error(error);
      throw new Error(error);
    }
  }

  /**
   * createWIBuckets
   * @description creates buckets for a WI project
   * @param {string} wiProject The WI project
   * @param {Array<BucketSpec>} bucketsToCreate buckets specs to create
   * @return {Promise<Bucket[]>} buckets creation promise array
   */
  public async createWIBuckets(wiProject: string, bucketsToCreate?: BucketSpec[]): Promise<Bucket[]> {
    logger.debug(`Creating buckets for project: ${wiProject}`);
    try {
      bucketsToCreate = bucketsToCreate || _GC.BUCKETS_CONFIG.slice().map(bucketToCreate => new BucketSpec(bucketToCreate.type, Object.assign({}, bucketToCreate.config)));
      const buckets = bucketsToCreate.map(bucketSpec => this.createBucket(`${wiProject}__${bucketSpec.type}`, bucketSpec.config));
      // @TODO set lifecycle to the main bucket -> XML API (https://cloud.google.com/storage/docs/xml-api/put-bucket-lifecycle)
      await this.setLifecycle(`${wiProject}__main`);
      try {
        this.notifyNewBucketCreation(wiProject, bucketsToCreate.length);
      } catch (e) {
        logger.error(e);
      }
      return await Promise.all(buckets);
    } catch (error) {
      logger.error(error);
      throw new Error(error);
    }
  }

  /**
   * deleteWIBuckets
   * @description deletes WI project's buckets
   * @param {string} wiProject The WI project
   * @param {Array<BucketSpec>} bucketsToDelete buckets specs to create
   * @return {Array<Promise<[ApiResponse]>>} buckets deletion promise array
   */
  public async deleteWIBucketsPhysically(wiProject: string, bucketsToDelete?: BucketSpec[]): Promise<any[]> {
    logger.debug(`Deleting buckets for project: ${wiProject}`);
    try {
      bucketsToDelete = bucketsToDelete || _GC.BUCKETS_CONFIG.slice().map(bucketToCreate => new BucketSpec(bucketToCreate.type, bucketToCreate.config));
      return await Promise.all(bucketsToDelete.map(bucketSpec => this.deleteBucket(`${wiProject}__${bucketSpec.type}`)));
    } catch (error) {
      logger.error(error);
      throw new Error(error); // error deleting, retry here?
    }
  }

  public async deleteWIBucketsLogically(wiProject: string, bucketsToDelete?: BucketSpec[]): Promise<void> {
    logger.debug(`Deleting buckets for project: ${wiProject}`);
    try {
      await this.deleteFiles(`${wiProject}__main`, '/');
    } catch (error) {
      logger.error(error);
      throw new Error(error); // error deleting, retry here?
    }
  }

  public async restoreWIBuckets(wiProject: string): Promise<void> {
    logger.debug(`Restoring project files from ${wiProject} main bucket`);
    try {
      spawn('gsutil', ['cp', '-r', '-A', `gs://${wiProject}__main/`, `gs://${wiProject}__main`]);
    } catch (error) {
      logger.error(error);
      throw new Error(error);
    }
  }

  /**
   * uploadToTempBucket
   * @description upload a file to the wi__global__temp bucket (first step of the workflow) (Set lifecycle)
   * @param {string} localPath file path
   * @return {Promise<[File]>} File upload promise
   */
  public async uploadToTempBucket(wiProject:string, deploymentId: string, userId: string, localPath: string, noProcess?: boolean, noCV?: boolean): Promise<string> {
    logger.debug('Uploading file to Global Temp Bucket');
    try {
      const destination = `project/${wiProject}/deployment/${deploymentId}/user/${userId}/${localPath.split('/')[localPath.split('/').length - 1]}`;
      // if (noProcess) {
      //   destination = `noprocess/${destination}`;
      // }
      // _GC is the alias for constants from google.constants
      const bucket = process.env.NODE_ENV === 'prod' ? _GC.WI_GLOBAL_TEMP_BUCKET : `${_GC.WI_GLOBAL_TEMP_BUCKET}-staging`;
      await this.uploadFile(bucket, localPath, {
        destination,
        metadata: {
          metadata: {
            noProcess: noProcess.toString(),
            noCV: noCV.toString(),
          },
        },
      });
      return `deployment/${deploymentId}/${localPath.split('/')[localPath.split('/').length - 1]}`;
    } catch (error) {
      logger.error(error);
      throw new Error(error);
    }
  }

  public async uploadToBuckets(
    wiProject		: string,
    deploymentId	: string,
    localPath		: string,
    localThumbPath      : string,
  ): Promise<string[]> {
    logger.debug('Uploading main file to project bucket');
    try {
      const destination = `deployment/${deploymentId}/${localPath.split('/')[localPath.split('/').length - 1]}`;
      logger.debug('project', wiProject);

      const mainBucket = `${wiProject}__main`;
      const thumbsBucket = `${wiProject}__thumbnails`;

      logger.debug('mainBucket:', mainBucket);
      logger.debug('thumbsBucket:', thumbsBucket);
      await this.uploadFile(mainBucket, localPath, { destination });
      await this.uploadFile(thumbsBucket, `${localPath}-thumb`, { destination });

      // Making thumb public
      const gcsThumbsBucket = StorageService.gcs.bucket(thumbsBucket);
      const thumbnail = gcsThumbsBucket.file(destination);
      await thumbnail.makePublic();
      // logger.debug('thumbnail:', thumbnail);
      const thumbnailUrl = `https://storage.googleapis.com/${wiProject}__thumbnails/${thumbnail.name}`;
      logger.debug('thumbnailUrl', thumbnailUrl);

      return [destination, thumbnailUrl];
    } catch (error) {
      logger.error(error);
      throw new Error(error);
    }
  }

  /**
   * getSignedUrlForUpload
   * @description getSignedUrlForUpload
   * @param {string} wiProject
   * @param {string} deploymentId
   * @param {string} userId
   * @param {string} fileName
   * @return {Promise<string>} signedUrl
   */
  public async getSignedUrlForUpload(wiProject: string, deploymentId: string, userId: string, fileName: string, contentType: string, clientId?: string): Promise<string> {
    logger.debug('Getting signedUrl for upload');
    try {
      const bucket = process.env.NODE_ENV === 'prod' ? _GC.WI_GLOBAL_TEMP_BUCKET : `${_GC.WI_GLOBAL_TEMP_BUCKET}-staging`;
      const file = await this.getFile(bucket, `project/${wiProject}/deployment/${deploymentId}/user/${userId}/${fileName}`);
      const config: any = { contentType };
      if (clientId) {
        config.extensionHeaders = { 'x-goog-meta-client-id': clientId };
      }
      return await this.getSignedUrl(file, Object.assign({}, _GC.SIGNED_URL_WRITE_CONFIG, config));
    } catch (error) {
      logger.error(error);
      throw new Error(error);
    }
  }

  /**
   * deleteWIFile
   * @description delete file from project bucket
   * @param {string} wiProject
   * @param {string} fileName file name
   * @param {WIBucketType} bucketType Whether to delete a file in the project's main or thumbnail bucket
   * @return {Promise<any>} File delete operation
   */
  public async deleteWIFile(wiProject: string, fileName: string, bucketType: WIBucketType = WIBucketType.main): Promise<any> {
    const bucket = `${wiProject}__${bucketType}`;
    logger.debug(`Deleting file '${fileName}' from bucket '${bucket}' of project ${wiProject}`);
    try {
      const exist = await this.existFile(bucket, fileName);
      if (!exist) {
        throw new Error(`File ${fileName} does not exist`);
      }
      const file = await this.getFile(`${wiProject}__${bucketType}`, fileName);
      return await this.deleteFile(file);
    } catch (error) {
      logger.error(error);
      throw new Error(error);
    }
  }

  public async restoreWIFile(wiProject: string, fileName: string): Promise<any> {
    logger.debug(`Restore file from ${wiProject} main bucket`);
    try {
      const gsutil = spawn('gsutil', ['ls', '-a', `gs://${wiProject}__main/${fileName}`]);
      const archiveUrl = await new Promise((resolve, reject) => {
        let data = new Buffer(0);
        gsutil.stdout.on('data', (d) => {
          data += d;
        });
        gsutil.stderr.on('data', (err) => {
          reject(err);
        });
        gsutil.on('close', (code) => {
          resolve(data.toString('utf8').split('\n')[0]);
        });
      });
      spawn('gsutil', ['cp', archiveUrl, `gs://${wiProject}__main/${fileName}`]);
    } catch (error) {
      logger.error(error);
      throw new Error(error);
    }
  }

  /**
   * deleteWIDeployment
   * @description delete deployment files
   * @param {string} wiProject
   * @param {string} deploymentId deployment name
   * @return {Promise<any>} File delete operation
   */
  public async deleteWIDeployment(wiProject: string, deploymentId: string): Promise<void> {
    logger.debug(`Deleting deployment files from ${wiProject} main bucket`);
    try {
      const bucketName = `${wiProject}__main`;
      const prefix = `deployment/${deploymentId}`;
      return await this.deleteFiles(bucketName, prefix);
    } catch (error) {
      logger.error(error);
      throw new Error(error);
    }
  }

  public async restoreWIDeployment(wiProject: string, deploymentId: string): Promise<void> {
    logger.debug(`Restoring deployment files from ${wiProject} main bucket`);
    try {
      spawn('gsutil', ['cp', '-r', '-A', `gs://${wiProject}__main/deployment/${deploymentId}`, `gs://${wiProject}__main`]);
    } catch (error) {
      logger.error(error);
      throw new Error(error);
    }
  }

  /**
   * getSignedUrlWIFile
   * @description getSignedUrl
   * @param {string} wiProject
   * @param {string} fileName file name
   * @param {SignedUrlConfig} config signedUrlConfig
   * @return {Promise<string>} signedUrl
   */
  public async getSignedUrlWIFile(wiProject: string, fileName: string, config?: SignedUrlConfig): Promise<string> {
    logger.debug(`Getting signedUrl from ${wiProject} main bucket`);
    try {
      const exist = await this.existFile(`${wiProject}__main`, `${fileName}`);
      if (!exist) {
        throw new Error(`File ${fileName} does not exist`);
      }
      const file = await this.getFile(`${wiProject}__main`, `${fileName}`);
      return await this.getSignedUrl(file, config);
    } catch (error) {
      logger.error(error);
      throw new Error(error);
    }
  }

  /**
   * downloadFile
   * @description downloadFile
   * @param {string} wiProject
   * @param {string} fileName file name
   * @return {Promise<string>} localPath
   */
  public async downloadFile(wiProject: string, fileName: string): Promise<string> {
    logger.debug(`Downloading file from ${wiProject} main bucket`);
    try {
      const exist = await this.existFile(`${wiProject}__main`, `${fileName}`);
      if (!exist) {
        throw new Error(`File ${fileName} does not exist`);
      }
      const file = StorageService.gcs.bucket(`${wiProject}__main`).file(fileName);
      const tempLocalPath = `/tmp/${path.parse(file.name).base}`;
      await file.download({ destination: tempLocalPath });
      return tempLocalPath;
    } catch (error) {
      logger.error(error);
      throw new Error(error);
    }
  }

    public async downloadFileGeneric(bucket: string, fileName: string): Promise<string> {
    logger.debug(`Downloading file from bucket ${bucket}`);
    try {
      const exist = await this.existFile(`${bucket}`, `${fileName}`);
      if (!exist) {
        throw new Error(`File ${fileName} does not exist`);
      }
      const file = StorageService.gcs.bucket(`${bucket}`).file(fileName);
      // Poor man's GUUID
      const tempLocalPath = `/tmp/${ Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15)}_${path.parse(file.name).base}`;
      await file.download({ destination: tempLocalPath });
      return tempLocalPath;
    } catch(error) {
      logger.error(error);
      throw new Error(error);
    }
  }

  /**
   * _notifyNewBucketCreation
   * @description notifiy new bucket creation
   * @param {string} wiProject The WI project
   * @param {any} value metric value
   */
  private notifyNewBucketCreation(wiProject: string, value: any): void {
    this.metrics.writeMetricData(
      newBucketMetricConfig.type,
      {
        project_id: wiProject,
      },
      value,
    );
  }

  /**
   * Revoke all GCP storage reader roles related to batch downloads. By
   * scheduling this operation regularly, we ensure that no stale permissions
   * are kept around indefinitely.
   */
  async revokeGCPRoleBindingsForBatchDownloads() {
    const buckets: string[] = await this.getBucketsFromWhichToRevokeStorageRoles();
    await Promise.all(buckets.map(async (bucket:string) => {
      const bucketMembers: string[] = await StorageService.getBucketReaderMembers(bucket);
      if (bucketMembers.length > 0) {
        // remove member one by one sequentially
        await bucketMembers.reduce(async(promise, bucketMember) => {
          await promise;
          await StorageService.removeReaderMember(bucketMember, bucket);
        }, Promise.resolve());
      }
    }));
  }

  /**
   * Grant reader roles to relevant users on all applicable buckets. WI users
   * who have requested a data download within N days (configured in `/config`)
   * are granted a read-only role on all the buckets included in download
   * bundles still available to the user.
   */
  async grantGCPRoleBindingsForBatchDownloads() {
    const bucketRoleSubjects : BucketRoleSubject[] = await this.getRolesToBeGranted();
    if (bucketRoleSubjects.length > 0) {
      await StorageService.addReaderMembers(bucketRoleSubjects);
    }
  }

  /**
   * Compute which users should get access to which buckets.
   * For each batch download job which was created less than N days ago, this
   * function returns the bucket name of all the projects included in the
   * download job (these can be more than one if the job is linked to an
   * initiative or a project) and the email address of the user who should have
   * read access on it by virtue of an active batch download job.
   */
  async getRolesToBeGranted(): Promise<BucketRoleSubject[]> {
    try {
      logger.info('Retrieving data to add reader members');
      const startRequestedTimestamp = moment().format('YYYY-MM-DD HH:mm:ss');
      const endRequestedTimestamp = moment().subtract(config.get('storage.privateReadOnlyAccess.grantReadOnlyAccessForDays'), 'days').format('YYYY-MM-DD HH:mm:ss');

      /**
       * Get all necessary project(s) data to build bucketRoleSubjects from
       * batch_downloads table: a single project's data if the batch_download
       * requested was for a project entity or data for zero or more projects,
       * if the batch_download requested was for an organization or initiative.
      */
      const allEntitiesProjectsData = await this.batchDownloadsRepository.createQueryBuilder('bd')
        .select(['project.slug', 'participant.email'])
        .leftJoin('bd.participant', 'participant')
        .leftJoin('bd.initiative', 'initiative')
        .leftJoin('bd.organization', 'organization')
        .leftJoin(Projects, 'project', 'organization.id = project.organizations_id OR initiative.id = project.initiative_id OR bd.project_id = project.id')
        .where('bd.isPublic = false')
        .andWhere('bd.status = :finished', { finished: EBatchDownloadStatus.Finished })
        .andWhere('bd.requestedTimestamp <= :start', { start: startRequestedTimestamp })
        .andWhere('bd.requestedTimestamp >= :end', { end: endRequestedTimestamp })
        .groupBy('project.slug')
        .addGroupBy('participant.email')
        .getRawMany();

      const bucketRoleSubjects : BucketRoleSubject[] = await Promise.all(allEntitiesProjectsData.map(async(item) => {
        return {
          bucket: `${item.project_slug}${mainBucketSuffix}`,
          email:  `${item.participant_email}`,
        };
      }));

      return bucketRoleSubjects;
    } catch (error) {
      throw new BadRequestException(`Error retrieving data to add reader members, ${error}`);
    }
  }

  // Compute list of buckets from all application projects
  async getBucketsFromWhichToRevokeStorageRoles() : Promise<string[]> {
    try {
      const projects = await this.projectsRepository.createQueryBuilder('p')
        .select('p.slug')
        .getRawMany();

      return projects.map((project) => {
        return `${project.p_slug}${mainBucketSuffix}`;
      });
    } catch (error) {
      throw new BadRequestException(`Error retrieving project's bucket, ${error}`);
    }
  }

  // get google storage image blob url
  public static getImageUrl(projectSlug: string, imageFilePath: string): string {
    if (projectSlug.length > 0 && imageFilePath.length > 0) {
      return `gs://${projectSlug}${config.get('storage.buckets.mainBucketSuffix')}/${imageFilePath}`;
    }
  }

  /**
   * Create and apply GCS policy bindings for each bucket/user tuple.
   *
   * Policy bindings are applied sequentially because we have no way to know
   * whether adding a new user to a policy binding will succeed, so we need
   * to try adding users one by one, letting attempts fail for individual users,
   * and moving on to the next user.
   *
   * Adding new users to a policy binding will usually fail if the email address
   * we have for a user does not match that of any active GCP account.
   *
   * Email addresses who are linked to a Gmail account will be granted a role
   * even if the user doesn't have a GCP account (though the user will then
   * have to create such an account before they are actually able to see blobs
   * in the buckets they have been granted access to - their roles are sort of
   * rehydrated once they create a GCP account).
   */
  public static async addReaderMembers(bucketRoleSubjects : BucketRoleSubject[]): Promise<void> {
    // add members one by one sequentially
    await bucketRoleSubjects.reduce(async(promise, data) => {
      await promise;
      logger.info(`Adding ${data.email} as reader member to bucket: ${data.bucket}`);
      try {
        const bucket = StorageService.gcs.bucket(data.bucket);
        const [policy] = await bucket.iam.getPolicy();
        policy.bindings.push({
          role: `${config.get('storage.privateReadOnlyAccess.amiRoles.wiBatchDownloadsReader')}`,
          members: [`${storageUserMemberPrefix}${data.email}`],
        });
        await bucket.iam.setPolicy(policy);
      } catch (error) {
        logger.error(`Error adding ${data.email} as read member, ${error}`);
      }
    }, Promise.resolve());
  }

  /**
   * Remove a member from a reader policy binding for a given bucket
   */
  public static async removeReaderMember(email: string, bucketName: string): Promise<void> {
    logger.info(`Removing ${email} from ${bucketName}`);
    try {
      const bucket = StorageService.gcs.bucket(bucketName);
      const [policy] = await bucket.iam.getPolicy();
      const readers = [`${storageUserMemberPrefix}${email}`];
      const readerRole = config.get('storage.privateReadOnlyAccess.amiRoles.wiBatchDownloadsReader');
      const index = policy.bindings.findIndex(binding => binding.role === readerRole);
      const role = policy.bindings[index];

      if (role) {
        role.members = role.members.filter(
          member => readers.indexOf(member) === -1,
        );

        // Updates the policy object with the new (or empty) role-member group
        if (role.members.length === 0) {
          policy.bindings.splice(index, 1);
        } else {
          policy.bindings.index = role;
        }

        // Updates the bucket's IAM policy
        await bucket.iam.setPolicy(policy);
      }
    } catch (error) {
      logger.error(`Error removing ${email} as reader member, ${error}`);
    }
  }

  /**
   * Get list of all members with batch downloads-specific reader role on a
   * given bucket.
   */
  public static async getBucketReaderMembers(bucketName: string): Promise<string[]> {
    logger.info(`Getting ${bucketName} readers members`);
    try {
      const members = await StorageService.gcs.bucket(bucketName).iam.getPolicy();
      if (members) {
        const bucketReaderMembers = members[0].bindings;

        return await bucketReaderMembers
          .filter((wiReaderMembers) => {
            return wiReaderMembers.role === config.get('storage.privateReadOnlyAccess.amiRoles.wiBatchDownloadsReader');
          })[0].members
          .filter((member: string) => {
            return member.includes(storageUserMemberPrefix);
          })
          .map((member: string) => {
            return member.replace(storageUserMemberPrefix, '');
          });
      }
    } catch (error) {
      logger.error(`Error reading members of ${bucketName} ${error}`);
      return [];
    }
  }

}
