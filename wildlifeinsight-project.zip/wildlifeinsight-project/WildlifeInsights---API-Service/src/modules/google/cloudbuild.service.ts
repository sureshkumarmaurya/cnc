
import { Injectable } from '@nestjs/common';
import { GCB as _GC, GCP as _GCP } from './google.constants';
import { BuildTriggerQuery, BuildTriggerConfig, BuildTrigger } from 'googleapis-nodejs-cloudbuild';

const { GCB } = require('googleapis-nodejs-cloudbuild');
const logger = require('logger');

export class BuildTriggerSpec {
  constructor(
    private _config: BuildTriggerConfig,
  ) { }

  get config() {
    return this._config;
  }

  set config(config: BuildTriggerConfig) {
    this._config = config;
  }

}

/**
 * Cloud Build Service
 */
@Injectable()
export class CloudBuildService {

  // private static readonly BUILD_TRIGGERS_CONFIG: BuildTriggerSpec[] = _GC.BUILD_TRIGGERS_CONFIG.slice()
  // .map(triggerToCreate => new BuildTriggerSpec(triggerToCreate));

  // initializes the storage client (it uses the GOOGLE_APPLICATION_CREDENTIALS env variable)
  static gcb = new GCB({
    keyFilename: process.env.GOOGLE_APPLICATION_CREDENTIALS,
    projectId: _GCP.projectId,
  });

  /**
   * @constructor
   */
  constructor() {
  }

  /**
   * createBuildTrigger
   * @description creates a gcb trigger
   * @param {BuildTriggerConfig} config? The buildTrigger config
   * @return {Promise<BuildTrigger>} operation
   */
  private async createBuildTrigger(config: BuildTriggerConfig): Promise<BuildTrigger> {
    logger.debug('[GCB OPERATION] Creating trigger');
    try {
      return await CloudBuildService.gcb.createBuildTrigger(config).then(value => value[0]);
    } catch (error) {
      logger.error(error);
      throw new Error(error);
    }
  }

  /**
   * deleteTrigger
   * @description deletes a build trigger
   * @param {string} id The trigger id
   * @return {Promise<any>} tigger deletion promise
   */
  private async deleteTrigger(id: string): Promise<void> {
    logger.debug(`[GCB OPERATION] Deleting trigger ${id} `);
    try {
      const trigger = CloudBuildService.gcb.buildTrigger(id);
      return await trigger.delete();
    } catch (error) {
      logger.error(error);
      throw new Error(error);
    }
  }

  /****************************************************************
   ********************* PUBLIC METHODS **************************
   ****************************************************************/

  /**
   * getBuildTriggers
   * @description list gcb triggers
   * @param {BuildTriggerQuery} query? build trigger query
   * @return {Promise<BuildTrigger[]>} trigger creation promise
   */
  public async getBuildTriggers(query?: BuildTriggerQuery): Promise<BuildTrigger[]> {
    try {
      const bts: BuildTrigger[] = await (CloudBuildService.gcb.getBuildTriggers(query) as Promise<[BuildTrigger[], any]>).then(value => value[0]);
      return bts;
    } catch (err) {
      logger.error(err);
      throw Error(err);
    }
  }

  /**
   * createWIBuildTriggers
   * @description creates cloud build triggers for a WI project
   * @param {string} wiProject The WI project
   * @param {Array<BuildTriggerSpec>} triggersToCreateInput triggers specs to create
   * @return {Promise<BuildTrigger[]>} cloud trigger array
   */
  public async createWIBuildTriggers(wiProject: string, triggersToCreateInput?: BuildTriggerSpec[]): Promise<BuildTrigger[]> {
    logger.debug(`Creating build triggers for project: ${wiProject}`);
    const branch = process.env.NODE_ENV === 'prod' ? 'master' : 'develop';
    try {
      const triggersToCreate = triggersToCreateInput || _GC.BUILD_TRIGGERS_CONFIG.slice().map(triggerToCreate => new BuildTriggerSpec(Object.assign({}, triggerToCreate)));
      triggersToCreate.map((btTC) => {
        btTC.config.description = btTC.config.description.replace(/{projectId}/g, `${wiProject}`);
        const substitutions = Object.assign({}, btTC.config.substitutions);
        substitutions._FUNCTION_NAME = substitutions._FUNCTION_NAME.replace(/{projectId}/g, `${wiProject}`);
        substitutions._TRIGGER_RESOURCE = substitutions._TRIGGER_RESOURCE.replace(/{projectId}/g, `${wiProject}`);
        btTC.config.substitutions = substitutions;
        btTC.config.triggerTemplate.branchName = btTC.config.triggerTemplate.branchName.replace(/{branchId}/g, `${branch}`);
        return btTC;
      });
      const buildTriggers: BuildTrigger[] = await Promise.all(triggersToCreate.map(buildTriggerSpec => this.createBuildTrigger(buildTriggerSpec.config)));
      return buildTriggers;
    } catch (error) {
      logger.error(error);
      throw new Error(error);
    }
  }

  /**
 * deleteWIBuildTriggers
 * @description deletes cloud build triggers
 * @param {string} triggersToDelete triggers' ids
 * @return {Array<Promise<[ApiResponse]>>} triggers deletion promise array
 */
  public async deleteWIBuildTriggers(triggersToDelete: string[]): Promise<any[]> {
    logger.debug(`Deleting triggers for project: ${triggersToDelete}`);
    try {
      return await Promise.all(triggersToDelete.map(triggerId => this.deleteTrigger(triggerId)));
    } catch (error) {
      logger.error(error);
      throw new Error(error); // error deleting, retry here?
    }
  }

}
