
/* tslint:disable */

import { Injectable } from '@nestjs/common';
import { PUBSUB as _GC, GCP as _GCP } from './google.constants';
import {
  PubSub,
  Topic,
  Subscription,
} from '@google-cloud/pubsub';
const PubSub = require('@google-cloud/pubsub');

const logger = require('logger');

export interface SubscriptionSpec {
  name: string;
  config?: Topic.CreateSubscriptionOptions;
}

export class TopicSpec {
  constructor(
    private _name: string,
    private _subscriptionsConfig: SubscriptionSpec[],
  ) {}

  get name () {
    return this._name;
  }

  get subscriptionsConfig () {
    return this._subscriptionsConfig;
  }

}

/**
 * PubSub Service
 */
@Injectable()
export class PubSubService {

  private static readonly TOPICS_CONFIG: TopicSpec[] = _GC.TOPICS_CONFIG
  .map(topicsToCreate => new TopicSpec(topicsToCreate.type, topicsToCreate.subscriptionsConfig));

  // initializes the storage client (it uses the GOOGLE_APPLICATION_CREDENTIALS env variable)
  static pubsub = new PubSub({
    keyFilename: process.env.GOOGLE_APPLICATION_CREDENTIALS,
    projectId: _GCP.projectId,
  });

  /**
   * @constructor
   */
  constructor() {
  }

  /**
   * createTopic
   * @description creates a pubsub topic
   * @param {string} name The topic name
   * @return {Promise<Topic>} operation
   */
  private async createTopic(name: string): Promise<Topic> {
    logger.debug(`[PUBSUB OPERATION] Creating topic ${name} `);
    try {
      return await PubSubService.pubsub.createTopic(name).then(value => value[0]);
    } catch (error) {
      logger.error(error);
      throw new Error(error);
    }
  }

  /**
   * createSubscription
   * @description creates a pubsub subscription
   * @param {topic} name The topic to be subscribed to
   * @param {SubscriptionSpec} options {name, config}
   * @return {Promise<Subscription>} operation
   */
  private async createSubscription(topic: Topic, options: SubscriptionSpec): Promise<Subscription> {
    logger.debug(`[PUBSUB OPERATION] Creating subscription to ${topic} `);
    try {
      return await topic.createSubscription(options.name, options.config).then(value => value[0]);
    } catch (error) {
      logger.error(error);
      throw new Error(error);
    }
  }

  /****************************************************************
   ********************* PUBLIC METHODS **************************
   ****************************************************************/

  /**
   * getSubscriptions
   * @description list subscriptions
   * @param {PubSub.GetSubscriptionsOptions} options?
   * @return {Promise<Subscription[]>}
   */
  public async getSubscriptions(options?: PubSub.GetSubscriptionsOptions): Promise<Subscription[]> {
    try {
      const subscriptions = await PubSubService.pubsub.getSubscriptions(options).then(value => value[0]);
      return subscriptions;
    } catch (err) {
      logger.error(err);
      throw Error(err);
    }
  }

  /**
   * createWITopics
   * @description creates pubsub topics and associated subscriptions
   * @param {string} wiProject The WI project
   * @param {Array<TopicSpec>} topicsToCreate topics specs to create
   * @return {Promise<boolean>} topic array
   */
  public async createWITopics(wiProject: string, topicsToCreate?: TopicSpec[]): Promise<boolean> {
    logger.debug(`Creating pubsub topics and subscriptions for project: ${wiProject}`);
    try {
      topicsToCreate = topicsToCreate || PubSubService.TOPICS_CONFIG;
      for (const topicToCreate of topicsToCreate) {
        const topic = await this.createTopic(`${wiProject}.${topicToCreate.name}`);
        if (topicToCreate.subscriptionsConfig && topicToCreate.subscriptionsConfig.length && topicToCreate.subscriptionsConfig.length > 0) {
          for (const subscriptionToCreate of topicToCreate.subscriptionsConfig) {
            subscriptionToCreate.name = `${wiProject}.${topicToCreate.name}.${subscriptionToCreate.name}`;
            await this.createSubscription(topic, subscriptionToCreate);
          }
        }
      }
      return true;
    } catch (error) {
      logger.error(error);
      throw new Error(error);
    }
  }

}
