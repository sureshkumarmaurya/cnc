
import { LabelDescriptor, MetricDescriptor, CustomMetric, MetricsService } from './metrics.service';
import { newBucketMetricConfig } from './storage.service';
const logger = require('logger');

const metricsService = new MetricsService();

// storage Event
try {
  logger.debug('Creating Storage Event');
  metricsService.createCustomMetric(
    new CustomMetric(
      new MetricDescriptor(
        newBucketMetricConfig.description,
        newBucketMetricConfig.displayName,
        newBucketMetricConfig.type,
        newBucketMetricConfig.labels.map(label => new LabelDescriptor(label.key, label.valueType, label.description)),
        newBucketMetricConfig.metricKind,
        newBucketMetricConfig.valueType,
      ),
    ),
  );
} catch (e) {
  logger.error(e);
  throw new Error(e);
}
