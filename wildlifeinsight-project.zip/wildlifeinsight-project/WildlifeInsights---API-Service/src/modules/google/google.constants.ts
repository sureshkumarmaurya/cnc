// Google Cloud Platform
export const GCP = {
  projectId: 'cameratraprepo',
};

// Google Cloud Storage
// Naming convention: 'bucketType' actually means type of the bucket in this case, see variable below
// <wiProject>__<bucketType>
export const GCS = {
  WI_GLOBAL_TEMP_BUCKET: 'wi__global__temp', // staging -> wi__global__temp-staging
  // main bucket -> versioning enabled
  // lifecycle -> archive: after 30 days go to coldline -> after 90 days delete
  BUCKETS_CONFIG: [
    {
      type: 'main',
      config: {
        multiregional: true,
        versioning: {
          enabled: true,
        },
      },
    },
    {
      type: 'thumbnails',
      config: {
        multiregional: true,
      },
    },
  ],
  SIGNED_URL_READ_CONFIG: {
    action: 'read',
    expires: null,
  },
  SIGNED_URL_WRITE_CONFIG: {
    action: 'write',
    expires: null,
  },
};

// Google Cloud PUBSUB
// Naming convention: 'eventType' actually means 'pubsub topic name/step' in this case, see variable below
// <wiProject>.<eventType>
// export const PUBSUB = {
//   TOPICS_CONFIG: [
//     {
//       type: 'object-ok',
//       description: 'output from step_one. Subscriber config when creating the function',
//       subscriptionsConfig: []
//     }
//   ]
// }
export const PUBSUB = {
  TOPICS_CONFIG: [],
};

// Google Cloud Functions
// Naming convention: 'functionType' actually means 'background process step' in this case, see variable below
// <wiProject>__<functionType>
export const GCF = {
  FUNCTIONS_CONFIG: [
    {
      type: 'check_object',
      description: 'created file and blur',
      config: {
        runtime: 'nodejs6',
        sourceArchiveUrl: 'gs://wi__global__code/check_object.zip',
        eventTrigger: {
          service: 'storage.googleapis.com',
          eventType: 'google.storage.object.finalize',
          resource: 'projects/_/buckets/{bucketId}',
        },
        entryPoint: 'entrypoint',
        availableMemoryMb: 2048,
      },
    },
  ],
};

// Google Cloud Build
export const GCB = {
  BUILD_TRIGGERS_CONFIG: [
    {
      description: '{projectId}',
      triggerTemplate: {
        projectId: 'cameratraprepo',
        repoName: 'check-object',
        branchName: '{branchId}',
      },
      substitutions: {
        _FUNCTION_NAME: '{projectId}__check_object',
        _TRIGGER_EVENT: 'google.storage.object.finalize',
        _TRIGGER_RESOURCE: '{projectId}__main',
      },
      filename: 'cloudbuild-steps.yaml',
    },
  ],
};

// {
//   type: 'step_two_A',
//   description: 'thumbnail',
//   config: {
//     runtime: 'nodejs6',
//     sourceArchiveUrl: 'gs://wi__global__code/step_two_A.zip',
//     eventTrigger: {
//       service: 'pubsub.googleapis.com',
//       eventType: 'google.pubsub.topic.publish',
//       resource: 'projects/{topicId}.object-ok'
//     },
//     entryPoint: 'entrypoint'
//   }
// },
// {
//   type: 'step_two_B',
//   description: 'identification',
//   config: {
//     runtime: 'nodejs6',
//     sourceArchiveUrl: 'gs://wi__global__code/step_two_B.zip',
//     eventTrigger: {
//       service: 'pubsub.googleapis.com',
//       eventType: 'google.pubsub.topic.publish',
//       resource: 'projects/{topicId}.object-ok'
//     },
//     entryPoint: 'entrypoint'
//   }
// }
