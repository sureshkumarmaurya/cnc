import { Test, TestingModule } from '@nestjs/testing';
import { StorageService } from './storage.service';
import { MetricsService } from './metrics.service';
import { CloudFunctionsService } from './cloudfunctions.service';
import { CloudBuildService } from './cloudbuild.service';
// import { PubSubService } from './pubsub.service';

describe('e2e', () => {
  let storageService: StorageService;
  let cloudFunctionsService: CloudFunctionsService;
  let cloudBuildService: CloudBuildService;
  // let pubSubService: PubSubService;

  const projectId = 'staging_project_2';

  beforeEach(async () => {
    const module = await Test.createTestingModule({
      providers: [StorageService, MetricsService, CloudFunctionsService, CloudBuildService],
    }).compile();

    storageService = module.get<StorageService>(StorageService);
    cloudFunctionsService = module.get<CloudFunctionsService>(CloudFunctionsService);
    cloudBuildService = module.get<CloudBuildService>(CloudBuildService);
    // pubSubService = module.get<PubSubService>(PubSubService);

  });

  // describe('createWiProject', () => {
  //   it('', async () => {

  //     //const success = await pubSubService.createWITopics(projectId);
  //     const buckets = await storageService.createWIBuckets(projectId);
  //     const functions = await cloudFunctionsService.createWICloudFunctions(projectId);
  //     const triggers = await cloudBuildService.createWIBuildTriggers(projectId);

  //   }, 120000);
  // });

  // describe('deleteWiProject', () => {
  //   it('', async () => {

  //     const triggerId = 'eb6a67e3-5e20-4633-9f36-c0424d96f9fa'; // @TODO
  //     await cloudFunctionsService.deleteWICloudFunctions(projectId);
  //     await storageService.deleteWIBuckets(projectId);
  //     await cloudBuildService.deleteWIBuildTriggers([triggerId]);

  //   }, 120000);
  // });

});
