import { Test, TestingModule } from '@nestjs/testing';
import { CloudBuildService } from './cloudbuild.service';
import { MetricsService } from './metrics.service';
import { GCP as _GCP } from './google.constants';

describe('CloudBuildService', () => {
  let cloudbuildService: CloudBuildService;
  const projectId = `wi__testing__${Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15)}`;
  
  beforeEach(async () => {
    const module = await Test.createTestingModule({
      providers: [CloudBuildService, MetricsService],
    }).compile();

    cloudbuildService = module.get<CloudBuildService>(CloudBuildService);
  });

  describe('getBuildTriggers', () => {
    it('should return triggers', async () => {
      const result = {name: ''};
      // mocking sometimes? 

      const triggers = await cloudbuildService.getBuildTriggers();
      triggers.forEach(tg => {
        expect(tg.metadata.triggerTemplate.projectId).toBe(_GCP.projectId);
      });
      console.log(`✅✅ Build Triggers listed successfully`);
    });
  });

  describe('createWIBuildTrigger', () => {
    it('should return trigger', async () => {
      const result = {name: ''};
      // mocking sometimes? 

      const triggers = await cloudbuildService.createWIBuildTriggers(projectId);
      triggers.forEach(tg => {
        expect(tg.metadata.triggerTemplate.projectId).toBe(_GCP.projectId);
      });
      console.log(`✅✅ Triggers created and listed successfully`);
    }, 120000);
  },);

});
