import { DatabaseModule } from 'modules/database/database.module';
import { FunctionController, baitTypesRelations } from './function.controller';
import { Module, RequestMethod, MiddlewareConsumer } from '@nestjs/common';
import { FunctionService } from './function.service';
import { GoogleModule } from 'modules/google/google.module';
import { FunctionAuthenticationMiddleware } from './function-authentication.middleware';

@Module({
  imports: [DatabaseModule, GoogleModule],
  controllers: [FunctionController],
  providers: [FunctionService],
})
export class FunctionModule {
  public configure(consumer: MiddlewareConsumer) {
    consumer
      .apply(FunctionAuthenticationMiddleware)
      .forRoutes({ path: '/function*', method: RequestMethod.ALL });
  }
}
