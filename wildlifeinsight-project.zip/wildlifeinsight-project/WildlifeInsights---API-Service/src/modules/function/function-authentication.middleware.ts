import { NestMiddleware, MiddlewareFunction, Injectable, UnauthorizedException } from '@nestjs/common';

const config = require('config');
const logger = require('logger');

@Injectable()
export class FunctionAuthenticationMiddleware implements NestMiddleware {

  resolve(): MiddlewareFunction {
    return (req, _, next) => {
      logger.debug('Checking authentication');
      if (!req.query || !req.query.token) {
        throw new UnauthorizedException('Not authenticated. Token not found in query param');
      }
      if (req.query.token !== config.get('auth.functionToken')) {
        throw new UnauthorizedException('Not authenticated. Incorrect token.');
      }
      next();
    };
  }
}
