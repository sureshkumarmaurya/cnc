import { StorageService } from 'modules/google/storage.service';
import { Repository, Connection, EntityManager } from 'typeorm';
import { DataFiles } from 'modules/database/entities/data-files.entity';
import { Projects } from 'modules/database/entities/projects.entity';
import { Deployments } from 'modules/database/entities/deployments.entity';
import { MediaTypes } from 'modules/database/entities/media-types.entity';
import { ExifTags } from 'modules/database/entities/exif-tags.entity';
import { Inject, BadRequestException, NotFoundException } from '@nestjs/common';
import { MessageDto } from './dto/message.dto';
import { ExifUtils } from 'utils/exif.utils';
import { ExifDataFilePivot } from 'modules/database/entities/exif-data-file-pivot.entity';
import { Participants } from '../database/entities/participants.entity';
import { Taxonomies } from 'modules/database/entities/taxonomies.entity';
import { IdentificationOutputs } from 'modules/database/entities/identification-outputs.entity';
import { IdentificationMethods } from 'modules/database/entities/identification-methods.entity';
import { IdentifiedObjects } from 'modules/database/entities/identified-objects.entity';
import { IdentificationMessageDto } from './dto/identification-message.dto';
import { DATA_FILE_STATUS_CV } from 'app.constants';

const fs = require('fs').promises;

const logger = require('logger');

export class FunctionService {

  constructor(
    @Inject('TaxonomiesRepositoryToken') private readonly taxonomiesRepository: Repository<Taxonomies>,
    @Inject('DataFilesRepositoryToken') private readonly dataFilesRepository: Repository<DataFiles>,
    @Inject('ProjectsRepositoryToken') private readonly projectsRepository: Repository<Projects>,
    @Inject('DeploymentsRepositoryToken') private readonly deploymentsRepository: Repository<Deployments>,
    @Inject('MediaTypesRepositoryToken') private readonly mediaTypesRepository: Repository<MediaTypes>,
    @Inject('ExifTagsRepositoryToken') private readonly exifTagsRepository: Repository<ExifTags>,
    @Inject('ParticipantsRepositoryToken') private readonly participantsRepository: Repository<Participants>,
    @Inject('IdentificationMethodsRepositoryToken') private readonly identificationMethodsRepository: Repository<IdentificationMethods>,
    @Inject('IdentificationOutputsRepositoryToken') private readonly identificationOutputsRepository: Repository<IdentificationOutputs>,
    @Inject('DbConnectionToken') private readonly connection: Connection,
    private readonly storageService: StorageService,
  ) { }

  private async obtainExifTags(path: string): Promise<ExifDataFilePivot[]> {
    const exifDataFiles = [];
    try {
      const metadata: Object = await ExifUtils.metadata(path);
      for (const key in metadata) {
        logger.debug('Searching if exist exif tag: ', key);
        let exifTag = await this.exifTagsRepository.findOne({ where: { tagName: key } });
        if (!exifTag) {
          exifTag = new ExifTags();
          exifTag.tagName = key;
          await this.exifTagsRepository.save(exifTag);
        }
        const exifDataFile = new ExifDataFilePivot();
        exifDataFile.exifTagId = exifTag.id;
        exifDataFile.value = metadata[key];
        exifDataFiles.push(exifDataFile);
      }

    } catch (err) {
      logger.error('Error obtaining tags', err);
    }

    return exifDataFiles;
  }

  public async addIdentification(messageDto: IdentificationMessageDto) {
    logger.debug('Adding identification. Message:', messageDto);
    const project = await this.projectsRepository.findOne({ where: { slug: messageDto.wiProject } });
    if (!project) {
      throw new NotFoundException('Project not found');
    }

    const deployment = await this.deploymentsRepository.createQueryBuilder('deployment')
      .where('deployment.projectId = :projectId').andWhere('deployment.id = :deploymentId')
      .setParameters({ deploymentId: parseInt(messageDto.deploymentId, 10), projectId: project.id }).getOne();
    if (!deployment) {
      throw new NotFoundException(`Deployment not found with id ${messageDto.deploymentId}`);
    }

    const dataFile = await this.dataFilesRepository.createQueryBuilder('dataFile').where('dataFile.filepath = :filepath')
      .andWhere('dataFile.deploymentId = :deploymentId').setParameters({
        deploymentId: deployment.id,
        filepath: messageDto.dataFile,
      }).getOne();

    if (!dataFile) {
      throw new NotFoundException(`Data file not found with filepath ${messageDto.dataFile} and deployment ${deployment.id}`);
    }

    const taxonomy = await this.taxonomiesRepository.createQueryBuilder('taxonomy')
      .andWhere('lower(taxonomy.species) like :taxonomy').setParameter('taxonomy', messageDto.identification.label.toLocaleLowerCase()).getOne();
    if (!taxonomy) {
      throw new NotFoundException('Taxonomy not found');
    }

    const identificationMethod = await this.identificationMethodsRepository.findOne({ where: { name: `${messageDto.model.name}-${messageDto.model.version}` } });
    if (!identificationMethod) {
      throw new NotFoundException('Model not found');
    }
    logger.debug('Creating identification');
    let identification = new IdentificationOutputs();
    identification.identificationMethodId = identificationMethod.id;
    identification.blankYn = false;
    identification.timestamp = new Date();
    identification.identifiedObjects = [];
    identification.dataFileId = dataFile.id;
    const idObject = new IdentifiedObjects();
    idObject.taxonomyId = taxonomy.uniqueIdentifier;
    identification.identifiedObjects.push(idObject);
    identification = await this.identificationOutputsRepository.save(identification);

    return await this.connection.manager.transaction(async (entityManager: EntityManager) => {
      identification = await entityManager.save(IdentificationOutputs, identification);
      const dataFileUpdate = await entityManager.findOne(DataFiles, dataFile.id);
      logger.debug('Updating data-file status');
      dataFileUpdate.status = DATA_FILE_STATUS_CV;

      await entityManager.save(DataFiles, dataFileUpdate);
      return identification;
    });
  }

  public async setThumbnail(messageDto: MessageDto) {
    logger.debug('Creating message', messageDto);

    const project = await this.projectsRepository.findOne({ where: { slug: messageDto.wiProject } });
    if (!project) {
      throw new NotFoundException('Project not found');
    }

    const deployment = await this.deploymentsRepository.createQueryBuilder('deployment')
      .where('deployment.projectId = :projectId').andWhere('deployment.id = :deploymentId')
      .setParameters({ deploymentId: parseInt(messageDto.deploymentId, 10), projectId: project.id }).getOne();
    if (!deployment) {
      throw new NotFoundException(`Deployment not found with id  ${messageDto.deploymentId}`);
    }

    const dataFile = await this.dataFilesRepository.createQueryBuilder('dataFile').where('dataFile.filepath = :filepath')
      .andWhere('dataFile.deploymentId = :deploymentId').setParameters({
        deploymentId: deployment.id,
        filepath: messageDto.dataFile,
      }).getOne();

    if (!dataFile) {
      throw new NotFoundException(`Data file not found with filepath ${messageDto.dataFile} and deployment ${deployment.id}`);
    }

    dataFile.thumbnailUrl = messageDto.thumbnail;

    await this.dataFilesRepository.save(dataFile);

    return dataFile;

  }

  public async createDataFile(messageDto: MessageDto) {
    logger.debug('Creating Data file', messageDto);
    let localPath = null;
    logger.debug('Checking content type');
    const mediaType = await this.mediaTypesRepository.findOne({ where: { mime: messageDto.contentType } });
    if (!mediaType) {
      this.storageService.deleteWIFile(messageDto.wiProject, messageDto.dataFile).then(
        () => {
          logger.debug('Removed correctly');
        },
        (err) => {
          logger.error('Error removing file', messageDto);
        },
      );
      throw new BadRequestException('Content type not supported');
    }
    try {
      const project = await this.projectsRepository.findOne({ where: { slug: messageDto.wiProject } });
      if (!project) {
        throw new NotFoundException('Project not found');
      }

      const deployment = await this.deploymentsRepository.createQueryBuilder('deployment')
        .where('deployment.projectId = :projectId').andWhere('deployment.id = :deploymentId')
        .setParameters({ deploymentId: parseInt(messageDto.deploymentId, 10), projectId: project.id }).getOne();
      if (!deployment) {
        throw new NotFoundException('Deployment not found with id ', messageDto.deploymentId);
      }

      localPath = await this.storageService.downloadFile(messageDto.wiProject, messageDto.dataFile);

      const exifs = await this.obtainExifTags(localPath);

      const dataFile = new DataFiles();
      dataFile.deploymentId = parseInt(messageDto.deploymentId, 10);
      dataFile.filename = messageDto.originalName;
      dataFile.filepath = messageDto.dataFile;
      dataFile.filesize = messageDto.size;
      dataFile.exifDataFilePivots = exifs;
      dataFile.mediaType = mediaType;
      dataFile.clientId = messageDto.clientId;
      dataFile.participant = await this.participantsRepository.findOne(messageDto.userId);
      await this.dataFilesRepository.save(dataFile);

      return dataFile;
    } catch (err) {
      logger.error('Error', err);
      throw err;
    } finally {
      try {
        if (localPath) {
          logger.debug('Removing file', localPath);
          await fs.unlink(localPath);
        }
      } catch (err) {
        logger.error('Error removing file', err);
      }
    }

  }

}
