import { IsString, IsNumberString, IsOptional, IsArray } from 'class-validator';
import { isObject } from 'util';

export class MessageDto {

  @IsString()
  bucket: string;

  @IsString()
  dataFile: string;

  @IsString()
  wiProject: string;

  @IsString()
  @IsNumberString()
  deploymentId: string;

  @IsString()
  contentType: string;

  @IsString()
  @IsNumberString()
  userId: string;

  @IsString()
  originalName: string;

  @IsString()
  @IsNumberString()
  size: string;

  @IsOptional()
  @IsString()
  thumbnail: string;

  @IsOptional()
  @IsString()
  clientId: string;

  @IsOptional()
  identification: {
    label: string,
    score: number,
  };

  @IsOptional()
  model: {
    name: string,
    version: string,
  };

  constructor(partial: Partial<MessageDto>) {
    Object.assign(this, partial);
  }
}
