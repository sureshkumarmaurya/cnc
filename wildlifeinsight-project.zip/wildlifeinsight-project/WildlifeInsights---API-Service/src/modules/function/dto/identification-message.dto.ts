import { IsString, IsNumberString, IsOptional, IsArray } from 'class-validator';
import { isObject } from 'util';

export class IdentificationMessageDto {

  @IsString()
  bucket: string;

  @IsString()
  dataFile: string;

  @IsString()
  wiProject: string;

  @IsString()
  @IsNumberString()
  deploymentId: string;

  identification: {
    label: string,
    score: number,
  };

  model: {
    name: string,
    version: string,
  };

  constructor(partial: Partial<IdentificationMessageDto>) {
    Object.assign(this, partial);
  }
}
