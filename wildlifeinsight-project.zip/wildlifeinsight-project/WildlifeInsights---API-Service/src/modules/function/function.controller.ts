import { Get, Controller, Req, Post, Body, Patch, Param, Delete, ParseIntPipe, BadRequestException } from '@nestjs/common';
import { ApiUseTags, ApiBearerAuth, ApiOperation, ApiResponse, ApiImplicitQuery, ApiImplicitParam } from '@nestjs/swagger';
import { MessageDto } from './dto/message.dto';
import { FunctionService } from './function.service';
import { validate } from 'class-validator';
import { IdentificationMessageDto } from './dto/identification-message.dto';

const logger = require('logger');

export const baitTypesRelations = [];

@Controller('/function')
@ApiUseTags('Function')
@ApiBearerAuth()
export class FunctionController {
  constructor(private functionService: FunctionService) { }

  private async validateMessage(message: MessageDto) {
    const errors = await validate(message);
    if (errors.length > 0) {
      const formatedErrors = errors.map((error) => {
        const messageKeys = Object.keys(error.constraints);
        return {
          status: 400,
          title: error.property,
          detail: error.constraints[messageKeys[0]],
        };
      });
      throw new BadRequestException({ errors: formatedErrors });
    }
  }

  private async validateIdentificationMessage(message: IdentificationMessageDto) {
    const errors = await validate(message);
    if (errors.length > 0) {
      const formatedErrors = errors.map((error) => {
        const messageKeys = Object.keys(error.constraints);
        return {
          status: 400,
          title: error.property,
          detail: error.constraints[messageKeys[0]],
        };
      });
      throw new BadRequestException({ errors: formatedErrors });
    }
  }

  @Post('/data-file-created')
  async dataFileCreated(@Req() request) {
    const message = Buffer.from(request.body.message.data, 'base64').toString('ascii');
    logger.info('data-file-created body', message);
    const messageDto = new MessageDto(JSON.parse(message).data);
    await this.validateMessage(messageDto);
    try {
      await this.functionService.createDataFile(messageDto);
    } catch (err) {
      logger.error('Error in data file created ok', err);
    }

    return 'ok';
  }

  @Post('/data-file-removed')
  async dataFileRemoved(@Req() request) {
    logger.info('data-file-removed body', request.body);
    return 'ok';
  }

  @Post('/identification-ok')
  async identificationOk(@Req() request) {
    const message = Buffer.from(request.body.message.data, 'base64').toString('ascii');
    logger.info('data-file-created body', message);
    const messageDto = new IdentificationMessageDto(JSON.parse(message).data);
    await this.validateIdentificationMessage(messageDto);
    try {
      await this.functionService.addIdentification(messageDto);
    } catch (err) {
      logger.error('Error in identification ok', err);
    }

    return 'ok';
  }
  @Post('/thumbnail-ok')
  async thumbnailOk(@Req() request) {
    const message = Buffer.from(request.body.message.data, 'base64').toString('ascii');

    logger.info('Thumbnail-ok with message', message);
    const messageDto = new MessageDto(JSON.parse(message).data);
    try {
      await this.functionService.setThumbnail(messageDto);
    } catch (err) {
      logger.error('Error in thumbnail ok', err);
    }
    return 'ok';
  }

}
