import { Inject, BadRequestException } from '@nestjs/common';
import { Repository } from 'typeorm';
import { CreateParticipantTypeDto } from './dto/create-participant-type.dto';
import { UpdateParticipantTypeDto } from './dto/update-participant-type.dto';
import { GenericService } from 'utils/generic.service';
import { ParticipantTypes } from 'modules/database/entities/participant-types.entity';

export class ParticipantTypeService extends GenericService<ParticipantTypes, CreateParticipantTypeDto, UpdateParticipantTypeDto>{

  constructor(
    @Inject('ParticipantTypesRepositoryToken') private readonly participantTypesRepository: Repository<ParticipantTypes>,
  ) {
    super(participantTypesRepository, 'participantType');
  }

  async setDataCreate(create: CreateParticipantTypeDto) {
    const model = new ParticipantTypes();
    model.typeName = create.typeName;
    model.remarks = create.remarks;
    model.function = create.function;
    return model;
  }

  async validateBeforeCreate(create: CreateParticipantTypeDto) {
    const count = await this.participantTypesRepository.count({ where: { typeName: create.typeName } });
    if (count > 0) {
      throw new BadRequestException(`TypeName: ${create.typeName} is not unique`);
    }
  }

  async validateBeforeUpdate(id: number, create: UpdateParticipantTypeDto) {
    const count = await this.participantTypesRepository.count({ where: { typeName: create.typeName } });
    if (count > 0) {
      throw new BadRequestException(`TypeName: ${create.typeName} is not unique`);
    }
  }

  async setDataUpdate(model: ParticipantTypes, update: UpdateParticipantTypeDto) {
    if (update.typeName !== undefined) {
      model.typeName = update.typeName;
    }
    if (update.remarks !== undefined) {
      model.remarks = update.remarks;
    }
    if (update.function !== undefined) {
      model.function = update.function;
    }
    return model;
  }
}
