import { ParticipantTypeResolver } from './participant-type.resolver';
import { ParticipantTypeController, participantTypesRelations } from './participant-type.controller';
import { ParticipantTypeService } from './participant-type.service';
import { Module, RequestMethod, MiddlewareConsumer } from '@nestjs/common';
import { PaginationMiddleware } from 'middlewares/pagination.middleware';
import { DatabaseModule } from 'modules/database/database.module';

@Module({
  imports: [DatabaseModule],
  controllers: [ParticipantTypeController],
  providers: [ParticipantTypeService, ParticipantTypeResolver],
})
export class ParticipantTypeModule {
  public configure(consumer: MiddlewareConsumer) {
    consumer
      .apply(PaginationMiddleware)
      .with({ includes: [], allowIncludes: participantTypesRelations })
      .forRoutes({ path: '/api/v1/participant-type*', method: RequestMethod.GET });
  }
}
