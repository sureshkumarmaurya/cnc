import { ApiModelProperty } from '@nestjs/swagger';
import { ParticipantTypesDto } from '../../../../database/dto/participant-types.dto';
import { MetaDto } from '../../../../database/dto/meta.dto';

export class ParticipantTypesPaginatedDto {

  @ApiModelProperty({ type: ParticipantTypesDto, isArray: true })
  readonly data: ParticipantTypesDto[];

  @ApiModelProperty()
  readonly meta: MetaDto;

  constructor(data, totalItems: number, pageSize: number, page: number) {
    this.data = data;
    this.meta = new MetaDto(Math.ceil(totalItems / pageSize), totalItems, pageSize, page);
  }
}
