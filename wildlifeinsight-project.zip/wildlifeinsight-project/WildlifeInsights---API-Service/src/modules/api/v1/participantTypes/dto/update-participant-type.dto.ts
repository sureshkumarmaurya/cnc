import { ApiModelProperty } from '@nestjs/swagger';
import { IsString, IsInt, IsEmail, IsIn, IsNumber, IsBoolean, IsArray, IsOptional, IsIP, MaxLength, IsUrl } from 'class-validator';

export class UpdateParticipantTypeDto {

  @IsString()
  @MaxLength(255)
  @IsOptional()
  typeName: string | null;

  @IsString()
  @IsOptional()
  remarks: string | null;

  @IsString()
  @MaxLength(255)
  @IsOptional()
  function: string | null;
}
