import { UpdateParticipantTypeDto } from './dto/update-participant-type.dto';
import { CreateParticipantTypeDto } from './dto/create-participant-type.dto';
import { Get, Controller, Req, Post, Body, Patch, Param, Delete, ParseIntPipe } from '@nestjs/common';
import { ParticipantTypeService } from './participant-type.service';
import { ApiUseTags, ApiBearerAuth, ApiOperation, ApiResponse, ApiImplicitQuery, ApiImplicitParam } from '@nestjs/swagger';
import { ParticipantTypesPaginatedDto } from './dto/participant-types.dto';
import { Pagination } from 'decorators/pagination.decorator';
import { ValidationPipe } from 'pipes/validation.pipe';
import { ParticipantTypesDto } from '../../../database/dto/participant-types.dto';
import { PaginationModel } from 'utils/pagination.model';

const logger = require('logger');

export const participantTypesRelations = [];

@Controller('/api/v1/participant-type')
@ApiUseTags('ParticipantTypes')
@ApiBearerAuth()
export class ParticipantTypeController {
  constructor(private readonly participantTypeService: ParticipantTypeService) { }

  @Get()
  @ApiOperation({
    title: 'Get ParticipantTypes', description: `
    Get all participant types:
  `, operationId: 'GetAllParticipantTypes',
  })
  @ApiResponse({ status: 200, description: 'ParticipantTypes have been successfully returned', isArray: false, type: ParticipantTypesPaginatedDto })
  @ApiResponse({ status: 403, description: 'Not authorized.' })
  @ApiResponse({ status: 401, description: 'Not authenticated.' })
  @ApiImplicitQuery({
    name: 'includes', description: `
  Allows include the ParticipantTypes's relations. Available ${participantTypesRelations}
  `, type: String, required: false,
  })
  @ApiImplicitQuery({ name: 'fields', description: 'ParticipantTypes\'s fields to select', type: String, required: false })
  @ApiImplicitQuery({ name: 'page[size]', description: 'Page size. Default 10', type: String, required: false })
  @ApiImplicitQuery({ name: 'page[number]', description: 'Page number', type: String, required: false })
  @ApiImplicitQuery({ name: 'sort', description: 'Sort results', type: String, required: false })

  async findAll(@Pagination() pagination: PaginationModel) {
    logger.info('Getting all participant types');
    const data = await this.participantTypeService.findAll(pagination);
    return new ParticipantTypesPaginatedDto(data[0], data[1], pagination.pageSize, pagination.pageNumber);
  }

  @Get('/:id')
  @ApiOperation({
    title: 'Get participant type by id', description: `
    Get participant type by id
  `, operationId: 'GetParticipantTypeById',
  })
  @ApiImplicitQuery({
    name: 'includes', description: `
  Allows include the ParticipantTypes's relations. Available ${participantTypesRelations}
  `, type: String, required: false,
  })
  @ApiImplicitParam({ name: 'id', description: 'Id of the participant type' })
  @ApiResponse({ status: 200, description: 'ParticipantType has been successfully returned', isArray: false, type: ParticipantTypesDto })
  @ApiResponse({ status: 404, description: 'ParticipantType does not exist or you don\'t have permission' })
  @ApiResponse({ status: 401, description: 'Not authenticated.' })
  async getById(@Param('id', new ParseIntPipe()) id: number, @Pagination() pagination: PaginationModel) {
    logger.info('Get participant type by id ', id);
    return await this.participantTypeService.getById(id, pagination);
  }

  @Post()
  @ApiOperation({
    title: 'Create a participant type', description: `
    Create new participant type
  `, operationId: 'CreateParticipantType',
  })
  @ApiResponse({ status: 200, description: 'ParticipantType has been successfully created', isArray: false, type: ParticipantTypesDto })
  @ApiResponse({ status: 400, description: 'Body contains errors' })
  @ApiResponse({ status: 401, description: 'Not authenticated.' })
  async create(@Body(new ValidationPipe()) createParticipantTypeDto: CreateParticipantTypeDto) {
    logger.info('Creating participant type');
    return await this.participantTypeService.create(createParticipantTypeDto);
  }

  @Patch('/:id')
  @ApiOperation({
    title: 'Update participant type', description: `
    Update participant type
  `, operationId: 'UpdateParticipantType',
  })
  @ApiImplicitParam({ name: 'id', description: 'Id of the participant type' })
  @ApiResponse({ status: 200, description: 'ParticipantType has been successfully updated', isArray: false, type: ParticipantTypesDto })
  @ApiResponse({ status: 404, description: 'ParticipantType does not exist or you don\'t have permission' })
  @ApiResponse({ status: 401, description: 'Not authenticated.' })

  async update(@Param('id', new ParseIntPipe()) id: number, @Body(new ValidationPipe()) updateParticipantTypeDto: UpdateParticipantTypeDto) {
    logger.info('Updating participant type');
    // TODO: Add security
    return await this.participantTypeService.update(id, updateParticipantTypeDto);
  }

  @Delete('/:id')
  @ApiOperation({
    title: 'Delete participant type', description: `
    Delete participant type
  `, operationId: 'DeleteParticipantType',
  })
  @ApiImplicitParam({ name: 'id', description: 'Id of the participant type' })
  @ApiResponse({ status: 200, description: 'ParticipantType has been successfully deleted', isArray: false, type: ParticipantTypesDto })
  @ApiResponse({ status: 404, description: 'ParticipantType does not exist or you don\'t have permission' })
  @ApiResponse({ status: 401, description: 'Not authenticated.' })
  async remove(@Param('id', new ParseIntPipe()) id: number) {
    logger.info('Deleting participant type');
    return await this.participantTypeService.remove(id);
  }
}
