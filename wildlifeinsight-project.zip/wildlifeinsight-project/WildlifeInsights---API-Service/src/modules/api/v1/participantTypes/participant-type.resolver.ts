import { CreateParticipantTypeDto } from './dto/create-participant-type.dto';
import { ParticipantTypeService } from './participant-type.service';
import { Resolver, Query, ResolveProperty, Mutation, Args } from '@nestjs/graphql';
import { UpdateParticipantTypeDto } from './dto/update-participant-type.dto';
import { UseInterceptors, UseGuards } from '@nestjs/common';
import { GraphqlAuthGuard } from 'guards/graphql-passport.guard';
import { GraphqlUserWithPermissions } from 'decorators/graphql-user.decorator';
import { ValidationGraphqlInterceptor } from 'interceptors/validation-graphql.interceptor';
import { PaginationGraphqlInterceptor } from 'interceptors/pagination-graphql.interceptor';
import { User } from 'decorators/user.decorator';
import { ParticipantTypesPaginatedDto } from './dto/participant-types.dto';

const logger = require('logger');

@Resolver('ParticipantType')
export class ParticipantTypeResolver {
  constructor(private readonly initiativeService: ParticipantTypeService) {}

  @Query()
  @UseGuards(GraphqlAuthGuard)
  @UseInterceptors(PaginationGraphqlInterceptor)
  async getParticipantTypes(@GraphqlUserWithPermissions() authenticatedUser, @Args() args) {
    const data = await this.initiativeService.findAll(args.pagination, { authenticatedUser, params: args });
    return new ParticipantTypesPaginatedDto(data[0], data[1], args.pagination.pageSize, args.pagination.pageNumber);
  }

  @Query()
  @UseGuards(GraphqlAuthGuard)
  async getParticipantType(@GraphqlUserWithPermissions() authenticatedUser, @Args() args) {
    const { id } = args;
    return await this.initiativeService.getById(id, {}, { authenticatedUser, params: args });
  }

  @Mutation()
  @UseGuards(GraphqlAuthGuard)
  @UseInterceptors(new ValidationGraphqlInterceptor(CreateParticipantTypeDto))
  async createParticipantType(@GraphqlUserWithPermissions() authenticatedUser, @Args() args) {
    const { body } = args;
    return this.initiativeService.create(body, { authenticatedUser, params: args });
  }

  @Mutation()
  @UseGuards(GraphqlAuthGuard)
  @UseInterceptors(new ValidationGraphqlInterceptor(UpdateParticipantTypeDto))
  async updateParticipantType(@GraphqlUserWithPermissions() authenticatedUser, @Args() args) {
    const { id, body } = args;
    return this.initiativeService.update(id, body, { authenticatedUser, params: args });
  }

  @Mutation()
  @UseGuards(GraphqlAuthGuard)
  async deleteParticipantType(@GraphqlUserWithPermissions() authenticatedUser, @Args() args) {
    const { id } = args;
    return this.initiativeService.remove(id, { authenticatedUser, params: args });
  }
}
