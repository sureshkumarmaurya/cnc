import { ApiModelProperty } from '@nestjs/swagger';
import { IsString, IsInt, IsNumber, IsOptional, MaxLength, IsISO8601, ValidateIf } from 'class-validator';

export class UpdateDeviceDto {

  @IsString()
  @MaxLength(255)
  @IsOptional()
  @ApiModelProperty({ required: true })
  name: string;

  @ValidateIf(o => !(o.purchaseDate instanceof Date))
  @IsISO8601()
  @IsOptional()
  @ApiModelProperty({ required: false })
  purchaseDate: Date;

  @IsString()
  @IsOptional()
  @MaxLength(255)
  @ApiModelProperty({ required: false })
  make: string | null;

  @IsString()
  @IsOptional()
  @MaxLength(255)
  @ApiModelProperty({ required: false })
  model: string | null;

  @IsString()
  @IsOptional()
  @MaxLength(255)
  @ApiModelProperty({ required: false })
  modelNumber: string | null;

  @IsString()
  @IsOptional()
  @MaxLength(255)
  @ApiModelProperty({ required: false })
  serialNumber: string | null;

  @IsInt()
  @IsOptional()
  @ApiModelProperty({ required: false })
  purchaseYear: number | null;

  @IsNumber()
  @IsOptional()
  @ApiModelProperty({ required: false })
  purchasePrice: number;

  @IsString()
  @IsOptional()
  @MaxLength(255)
  @ApiModelProperty({ required: false })
  productUrl: string | null;

  @IsString()
  @IsOptional()
  @ApiModelProperty({ required: false })
  remarks: string | null;
}
