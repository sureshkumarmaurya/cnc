import { DeviceController, devicesRelations } from './device.controller';
import { DeviceService } from './device.service';
import { Module, RequestMethod, MiddlewareConsumer } from '@nestjs/common';
import { PaginationMiddleware } from 'middlewares/pagination.middleware';
import { DeviceResolver } from './device.resolver';
import { DatabaseModule } from 'modules/database/database.module';
import { SensorModule } from './sensors/sensor.module';

@Module({
  imports: [DatabaseModule, SensorModule],
  controllers: [DeviceController],
  providers: [DeviceService, DeviceResolver],
})
export class DeviceModule {
  public configure(consumer: MiddlewareConsumer) {
    consumer
      .apply(PaginationMiddleware)
      .with({ includes: [], allowIncludes: devicesRelations })
      .forRoutes({ path: '/api/v1/organization/:organizationId/device*', method: RequestMethod.GET });
  }
}
