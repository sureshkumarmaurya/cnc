import { UpdateSensorDto } from './dto/update-sensor.dto';
import { CreateSensorDto } from './dto/create-sensor.dto';
import { Sensors } from 'modules/database/entities/sensors.entity';
import { Repository, SelectQueryBuilder } from 'typeorm';
import { Injectable, Inject, NotFoundException, BadRequestException, UnauthorizedException } from '@nestjs/common';
import { GenericService } from 'utils/generic.service';
import { InfoDto } from 'dto/info.dto';
import { Organizations } from 'modules/database/entities/organizations.entity';
import { Devices } from 'modules/database/entities/devices.entity';

const logger = require('logger');

@Injectable()
export class SensorService extends GenericService<Sensors, CreateSensorDto, UpdateSensorDto>  {

  constructor(
    @Inject('SensorsRepositoryToken') private readonly sensorsRepository: Repository<Sensors>,
    @Inject('DevicesRepositoryToken') private readonly devicesRepository: Repository<Devices>,
  ) {
    super(sensorsRepository, 'sensor');
  }

  setFilters(query: SelectQueryBuilder<Sensors>, filters: any, info: InfoDto) {
    query.andWhere('sensor.deviceId = :deviceId');
    if (info.pagination.includes && info.pagination.includes.indexOf('device') >= 0) {
      query.innerJoinAndSelect('sensor.device', 'device');
      info.pagination.includes.splice(info.pagination.includes.indexOf('device'), 1);
    } else {
      query.innerJoin('sensor.device', 'device');
    }
    query.andWhere('device.organizationId = :organizationId').setParameters({
      deviceId: info.params.deviceId,
      organizationId: info.params.organizationId,
    });
    return query;
  }

  setFiltersGetById(query: SelectQueryBuilder<Sensors>, info: InfoDto) {
    query.andWhere('sensor.deviceId = :deviceId');
    if (info.pagination.includes && info.pagination.includes.indexOf('device') >= 0) {
      query.innerJoinAndSelect('sensor.device', 'device');
      info.pagination.includes.splice(info.pagination.includes.indexOf('device'), 1);
    } else {
      query.innerJoin('sensor.device', 'device');
    }
    query.andWhere('device.organizationId = :organizationId').setParameters({
      deviceId: info.params.deviceId,
      organizationId: info.params.organizationId,
    });
    return query;
  }

  setFiltersDelete(query: SelectQueryBuilder<Sensors>, info: InfoDto) {
    query.where('sensor.deviceId = :deviceId')
    .innerJoin('sensor.device', 'device')
    .andWhere('device.organizationId = :organizationId').setParameters({
      deviceId: info.params.deviceId,
      organizationId: info.params.organizationId,
    });
    return query;
  }

  setFiltersUpdate(query: SelectQueryBuilder<Sensors>, info: InfoDto) {
    query.where('sensor.deviceId = :deviceId')
    .innerJoin('sensor.device', 'device')
    .andWhere('device.organizationId = :organizationId').setParameters({
      deviceId: info.params.deviceId,
      organizationId: info.params.organizationId,
    });
    return query;
  }

  async getDeviceById(id: number): Promise<Devices> {
    return this.devicesRepository.findOne(id);
  }

  async setDataCreate(create: CreateSensorDto, info: InfoDto) {
    const device = await this.devicesRepository.findOne(info.params.deviceId);

    const model = new Sensors();
    model.name = create.name;
    model.gain = create.gain;
    model.triggerSpeed = create.triggerSpeed;
    model.active = create.active;
    model.remarks = create.remarks;
    model.device = device;

    return model;

  }

  async setDataUpdate(model: Sensors, update: UpdateSensorDto, info: InfoDto) {

    if (update.name !== undefined) {
      model.name = update.name;
    }
    if (update.remarks !== undefined) {
      model.remarks = update.remarks;
    }
    if (update.gain !== undefined) {
      model.gain = update.gain;
    }
    if (update.active !== undefined) {
      model.active = update.active;
    }
    if (update.triggerSpeed !== undefined) {
      model.triggerSpeed = update.triggerSpeed;
    }

    return model;
  }

}
