import { CreateSensorDto } from './dto/create-sensor.dto';
import { SensorService } from './sensor.service';
import { Resolver, Query, ResolveProperty, Mutation } from '@nestjs/graphql';
import { UpdateSensorDto } from './dto/update-sensor.dto';
import { UseInterceptors, UseGuards } from '@nestjs/common';
import { ValidationGraphqlInterceptor } from 'interceptors/validation-graphql.interceptor';
import { PaginationGraphqlInterceptor } from 'interceptors/pagination-graphql.interceptor';
import { PermissionsGraphQlGuard } from 'guards/permissions-graphql.guard';
import { Sensors } from 'modules/database/entities/sensors.entity';
import { PaginationModel } from 'utils/pagination.model';

const logger = require('logger');

@Resolver('Sensor')
@UseGuards(PermissionsGraphQlGuard)
export class SensorResolver {
  constructor(private readonly sensorService: SensorService) {}

  @Query()
  @UseInterceptors(PaginationGraphqlInterceptor)
  async getSensors(req, args: { pagination: PaginationModel }, context, info) {
    const authenticatedUser = req.user;
    const data = await this.sensorService.findAll(args.pagination, { authenticatedUser, params: args });
    return data[0];
  }

  @Query()
  async getSensor(req, args, context, info) {
    const { id } = args;
    const authenticatedUser = req.user;
    return await this.sensorService.getById(id, {}, { authenticatedUser, params: args });
  }

  @ResolveProperty()
  async device(sensor: Sensors, args, context, info) {
    return this.sensorService.getDeviceById(sensor.deviceId);
  }

  @Mutation()
  @UseInterceptors(new ValidationGraphqlInterceptor(CreateSensorDto))
  async createSensor(req, args: {body: CreateSensorDto}, context, info) {
    const authenticatedUser = req.user;
    const { body } = args;
    return this.sensorService.create(body, { authenticatedUser, params: args });
  }

  @Mutation()
  @UseInterceptors(new ValidationGraphqlInterceptor(UpdateSensorDto))
  async updateSensor(req, args: {id: number, body: UpdateSensorDto}, context, info) {
    const authenticatedUser = req.user;
    const { id, body } = args;
    return this.sensorService.update(id, body, { authenticatedUser, params: args });
  }

  @Mutation()
  async deleteSensor(req, args, context, info) {
    const { id } = args;
    const authenticatedUser = req.user;
    return this.sensorService.remove(id, { authenticatedUser, params: args });
  }
}
