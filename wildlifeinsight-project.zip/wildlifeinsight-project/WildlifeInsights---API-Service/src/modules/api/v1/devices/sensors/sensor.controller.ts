import { Permissions } from 'decorators/permissions.decorator';
import { UpdateSensorDto } from './dto/update-sensor.dto';
import { CreateSensorDto } from './dto/create-sensor.dto';
import { Get, Controller, Req, Post, Body, Patch, Param, Delete, ParseIntPipe, UseGuards } from '@nestjs/common';
import { SensorService } from './sensor.service';
import { ApiUseTags, ApiBearerAuth, ApiOperation, ApiResponse, ApiImplicitQuery, ApiImplicitParam } from '@nestjs/swagger';
import { SensorsPaginatedDto } from './dto/sensors.dto';
import { Pagination } from 'decorators/pagination.decorator';
import { ValidationPipe } from 'pipes/validation.pipe';
import { SensorsDto } from 'modules/database/dto/sensors.dto';
import { PermissionsGuard } from 'guards/permissions.guard';
import { User } from 'decorators/user.decorator';
import { AuthenticatedUserDto } from 'dto/authenticated-user.dto';
import { PERMISSIONS } from 'utils/permissions.enum';
import { PaginationModel } from 'utils/pagination.model';

const logger = require('logger');

export const sensorsRelations = ['device'];

@Controller('/api/v1/organization/:organizationId/device/:deviceId/sensor')
@ApiUseTags('Sensors')
@ApiBearerAuth()
@UseGuards(PermissionsGuard)
export class SensorController {
  constructor(private readonly sensorService: SensorService) { }

  @Get()
  @ApiOperation({
    title: 'Get Sensors by organization', description: `
    Get all sensors:
  `, operationId: 'GetAllSensorsByOrganization',
  })
  @ApiResponse({ status: 200, description: 'Sensors have been successfully returned', isArray: false, type: SensorsPaginatedDto })
  @ApiResponse({ status: 403, description: 'Not authorized.' })
  @ApiResponse({ status: 401, description: 'Not authenticated.' })
  @ApiImplicitQuery({
    name: 'includes', description: `
  Allows include the Sensors's relations. Available ${sensorsRelations}
  `, type: String, required: false,
  })
  @ApiImplicitParam({ name: 'organizationId', description: 'Organization the device belongs to', type: Number, required: true })
  @ApiImplicitParam({ name: 'deviceId', description: 'Device the sensor belongs to', type: Number, required: true })
  @ApiImplicitQuery({ name: 'fields', description: 'Sensors\'s fields to select', type: String, required: false })
  @ApiImplicitQuery({ name: 'page[size]', description: 'Page size. Default 10', type: String, required: false })
  @ApiImplicitQuery({ name: 'page[number]', description: 'Page number', type: String, required: false })
  @ApiImplicitQuery({ name: 'sort', description: 'Sort results', type: String, required: false })
  @Permissions(PERMISSIONS.SENSOR_GET_ALL)
  async findAll(@Pagination() pagination: PaginationModel, @Param() params, @User() authenticatedUser: AuthenticatedUserDto) {
    logger.info('Getting all');
    const data = await this.sensorService.findAll(pagination, { authenticatedUser, params });
    return new SensorsPaginatedDto(data[0], data[1], pagination.pageSize, pagination.pageNumber);
  }

  @Get('/:id')
  @ApiOperation({
    title: 'Get sensor by id', description: `
    Get sensor by id
  `, operationId: 'GetSensorById',
  })
  @ApiImplicitQuery({
    name: 'includes', description: `
  Allows include the Sensors's relations. Available ${sensorsRelations}
  `, type: String, required: false,
  })
  @ApiImplicitParam({ name: 'id', description: 'Id of the sensor' })
  @ApiImplicitParam({ name: 'organizationId', description: 'Organization the device belongs to', type: Number, required: true })
  @ApiImplicitParam({ name: 'deviceId', description: 'Device the sensor belongs to', type: Number, required: true })
  @ApiResponse({ status: 200, description: 'Sensor has been successfully returned', isArray: false, type: SensorsDto })
  @ApiResponse({ status: 404, description: 'Sensor does not exist or you don\'t have permission' })
  @ApiResponse({ status: 401, description: 'Not authenticated.' })
  @Permissions(PERMISSIONS.SENSOR_GET_ONE)
  async getById(@Param('id', new ParseIntPipe()) id: number, @Pagination() pagination: PaginationModel, @User() authenticatedUser: AuthenticatedUserDto, @Param() params) {
    logger.info('Get by id ', id);
    return await this.sensorService.getById(id, pagination, { authenticatedUser, params });
  }

  @Post()
  @Permissions('permission')
  @ApiOperation({
    title: 'Create sensor', description: `
    Create new sensor
  `, operationId: 'CreateSensor',
  })
  @ApiImplicitParam({ name: 'organizationId', description: 'Organization the device belongs to', type: Number, required: true })
  @ApiImplicitParam({ name: 'deviceId', description: 'Device the sensor belongs to', type: Number, required: true })
  @ApiResponse({ status: 200, description: 'Sensor has been successfully created', isArray: false, type: SensorsDto })
  @ApiResponse({ status: 400, description: 'Body contains errors' })
  @ApiResponse({ status: 401, description: 'Not authenticated.' })
  @Permissions(PERMISSIONS.SENSOR_CREATE)
  async create(@Body(new ValidationPipe()) createSensorDto: CreateSensorDto, @User() authenticatedUser: AuthenticatedUserDto, @Param() params) {
    logger.info('Creating sensor');
    return await this.sensorService.create(createSensorDto, { authenticatedUser, params });
  }

  @Patch('/:id')
  @ApiOperation({
    title: 'Update sensor', description: `
    Update sensor
  `, operationId: 'UpdateSensor',
  })
  @ApiImplicitParam({ name: 'organizationId', description: 'Organization the device belongs to', type: Number, required: true })
  @ApiImplicitParam({ name: 'deviceId', description: 'Device the sensor belongs to', type: Number, required: true })
  @ApiImplicitParam({ name: 'id', description: 'Id of the sensor' })
  @ApiResponse({ status: 200, description: 'Sensor has been successfully updated', isArray: false, type: SensorsDto })
  @ApiResponse({ status: 404, description: 'Sensor does not exist or you don\'t have permission' })
  @ApiResponse({ status: 401, description: 'Not authenticated.' })
  @Permissions(PERMISSIONS.SENSOR_UPDATE)
  async update(@Param('id', new ParseIntPipe()) id: number, @Body(new ValidationPipe()) updateSensorDto: UpdateSensorDto, @User() authenticatedUser: AuthenticatedUserDto, @Param() params) {
    logger.info('Updating company');
    // TODO: Add security
    return await this.sensorService.update(id, updateSensorDto, { authenticatedUser, params });
  }

  @Delete('/:id')
  @ApiOperation({
    title: 'Delete sensor', description: `
    Delete sensor
  `, operationId: 'DeleteSensor',
  })
  @ApiImplicitParam({ name: 'organizationId', description: 'Organization the device belongs to', type: Number, required: true })
  @ApiImplicitParam({ name: 'deviceId', description: 'Device the sensor belongs to', type: Number, required: true })
  @ApiImplicitParam({ name: 'id', description: 'Id of the sensor' })
  @ApiResponse({ status: 200, description: 'Sensor has been successfully deleted', isArray: false, type: SensorsDto })
  @ApiResponse({ status: 404, description: 'Sensor does not exist or you don\'t have permission' })
  @ApiResponse({ status: 401, description: 'Not authenticated.' })
  @Permissions(PERMISSIONS.SENSOR_DELETE)
  async remove(@Param('id', new ParseIntPipe()) id: number, @User() authenticatedUser: AuthenticatedUserDto, @Param() params) {
    logger.info('Deleting sensor');
    return await this.sensorService.remove(id, { authenticatedUser, params });
  }
}
