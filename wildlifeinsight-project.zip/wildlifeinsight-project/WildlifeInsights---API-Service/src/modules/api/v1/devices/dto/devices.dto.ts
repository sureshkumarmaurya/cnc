import { ApiModelProperty } from '@nestjs/swagger';
import { DevicesDto } from 'modules/database/dto/devices.dto';
import { MetaDto } from 'modules/database/dto/meta.dto';

export class DevicesPaginatedDto {

  @ApiModelProperty({ type: DevicesDto, isArray: true })
  readonly data: DevicesDto[];

  @ApiModelProperty()
  readonly meta: MetaDto;

  constructor(data, totalItems: number, pageSize: number, page: number) {
    this.data = data;
    this.meta = new MetaDto(Math.ceil(totalItems / pageSize), totalItems, pageSize, page);
  }
}
