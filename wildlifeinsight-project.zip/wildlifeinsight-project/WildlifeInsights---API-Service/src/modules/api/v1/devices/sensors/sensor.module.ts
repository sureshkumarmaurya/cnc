import { SensorController, sensorsRelations } from './sensor.controller';
import { SensorService } from './sensor.service';
import { Module, RequestMethod, MiddlewareConsumer } from '@nestjs/common';
import { PaginationMiddleware } from 'middlewares/pagination.middleware';
import { SensorResolver } from './sensor.resolver';
import { DatabaseModule } from 'modules/database/database.module';

@Module({
  imports: [DatabaseModule],
  controllers: [SensorController],
  providers: [SensorService, SensorResolver],
})
export class SensorModule {
  public configure(consumer: MiddlewareConsumer) {
    consumer
      .apply(PaginationMiddleware)
      .with({ includes: [], allowIncludes: sensorsRelations })
      .forRoutes({ path: '/api/v1/organization/:organizationId/device/:deviceId/sensor*', method: RequestMethod.GET });
  }
}
