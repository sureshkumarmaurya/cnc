import { Permissions } from 'decorators/permissions.decorator';
import { UpdateDeviceDto } from './dto/update-device.dto';
import { CreateDeviceDto } from './dto/create-device.dto';
import { Get, Controller, Req, Post, Body, Patch, Param, Delete, ParseIntPipe, UseGuards } from '@nestjs/common';
import { DeviceService } from './device.service';
import { ApiUseTags, ApiBearerAuth, ApiOperation, ApiResponse, ApiImplicitQuery, ApiImplicitParam } from '@nestjs/swagger';
import { DevicesPaginatedDto } from './dto/devices.dto';
import { Pagination } from 'decorators/pagination.decorator';
import { ValidationPipe } from 'pipes/validation.pipe';
import { DevicesDto } from 'modules/database/dto/devices.dto';
import { PermissionsGuard } from 'guards/permissions.guard';
import { User } from 'decorators/user.decorator';
import { AuthenticatedUserDto } from 'dto/authenticated-user.dto';
import { PERMISSIONS } from 'utils/permissions.enum';
import { PaginationModel } from 'utils/pagination.model';

const logger = require('logger');

export const devicesRelations = ['organization', 'sensors'];

@Controller('/api/v1/organization/:organizationId/device')
@ApiUseTags('Devices')
@ApiBearerAuth()
@UseGuards(PermissionsGuard)
export class DeviceController {
  constructor(private readonly deviceService: DeviceService) { }

  @Get()
  @ApiOperation({
    title: 'Get Devices by organization', description: `
    Get all devices
  `, operationId: 'GetAllDevicesByOrganization',
  })
  @ApiResponse({ status: 200, description: 'Devices have been successfully returned', isArray: false, type: DevicesPaginatedDto })
  @ApiResponse({ status: 403, description: 'Not authorized.' })
  @ApiResponse({ status: 401, description: 'Not authenticated.' })
  @ApiImplicitParam({ name: 'organizationId', description: 'Organization the device belongs to', type: Number, required: true })
  @ApiImplicitQuery({
    name: 'includes', description: `
  Allows include the Devices's relations. Available ${devicesRelations}
  `, type: String, required: false,
  })
  @ApiImplicitQuery({ name: 'fields', description: 'Devices\'s fields to select', type: String, required: false })
  @ApiImplicitQuery({ name: 'page[size]', description: 'Page size. Default 10', type: String, required: false })
  @ApiImplicitQuery({ name: 'page[number]', description: 'Page number', type: String, required: false })
  @ApiImplicitQuery({ name: 'sort', description: 'Sort results', type: String, required: false })
  @Permissions(PERMISSIONS.DEVICE_GET_ALL)
  async findAll(@Pagination() pagination: PaginationModel, @Param() params, @User() authenticatedUser: AuthenticatedUserDto) {
    logger.info('Getting all devices by organization');
    const data = await this.deviceService.findAll(pagination, { authenticatedUser, params });
    return new DevicesPaginatedDto(data[0], data[1], pagination.pageSize, pagination.pageNumber);
  }

  @Get('/:id')
  @ApiOperation({
    title: 'Get device by id', description: `
    Get device by id
  `, operationId: 'GetDeviceById',
  })
  @ApiImplicitQuery({
    name: 'includes', description: `
  Allows include the Devices's relations. Available ${devicesRelations}
  `, type: String, required: false,
  })
  @ApiImplicitParam({ name: 'organizationId', description: 'Organization the device belongs to', type: Number, required: true })
  @ApiImplicitParam({ name: 'id', description: 'Id of the device' })
  @ApiResponse({ status: 200, description: 'Device has been successfully returned', isArray: false, type: DevicesDto })
  @ApiResponse({ status: 404, description: 'Device does not exist or you don\'t have permission' })
  @ApiResponse({ status: 401, description: 'Not authenticated.' })
  @Permissions(PERMISSIONS.DEVICE_GET_ONE)
  async getById(@Param('id', new ParseIntPipe()) id: number, @User() authenticatedUser: AuthenticatedUserDto, @Param() params, @Pagination() pagination: PaginationModel) {
    logger.info('Get device by id ', id);
    return await this.deviceService.getById(id, pagination, { authenticatedUser, params });
  }

  @Post()
  // @Permissions('permission')
  @ApiOperation({
    title: 'Create device', description: `
    Create new device
  `, operationId: 'CreateDevice',
  })
  @ApiImplicitParam({ name: 'organizationId', description: 'Organization the device belongs to', type: Number, required: true })
  @ApiResponse({ status: 200, description: 'Device has been successfully created', isArray: false, type: DevicesDto })
  @ApiResponse({ status: 400, description: 'Body contains errors' })
  @ApiResponse({ status: 401, description: 'Not authenticated.' })
  @Permissions(PERMISSIONS.DEVICE_CREATE)
  async create(@Body(new ValidationPipe()) createDeviceDto: CreateDeviceDto, @User() authenticatedUser: AuthenticatedUserDto, @Param() params) {
    logger.info('Creating device');
    return await this.deviceService.create(createDeviceDto, { authenticatedUser, params });
  }

  @Patch('/:id')
  @ApiOperation({
    title: 'Update device', description: `
    Update device
  `, operationId: 'UpdateDevice',
  })
  @ApiImplicitParam({ name: 'id', description: 'Id of the device' })
  @ApiImplicitParam({ name: 'organizationId', description: 'Organization the device belongs to', type: Number, required: true })
  @ApiResponse({ status: 200, description: 'Device has been successfully updated', isArray: false, type: DevicesDto })
  @ApiResponse({ status: 404, description: 'Device does not exist or you don\'t have permission' })
  @ApiResponse({ status: 401, description: 'Not authenticated.' })
  @Permissions(PERMISSIONS.DEVICE_UPDATE)
  async update(@Param('id', new ParseIntPipe()) id: number, @Body(new ValidationPipe()) updateDeviceDto: UpdateDeviceDto, @User() authenticatedUser: AuthenticatedUserDto, @Param() params) {
    logger.info('Updating device');
    // TODO: Add security
    return await this.deviceService.update(id, updateDeviceDto, { authenticatedUser, params });
  }

  @Delete('/:id')
  @ApiOperation({
    title: 'Delete device', description: `
    Delete device
  `, operationId: 'DeleteDevice',
  })
  @ApiImplicitParam({ name: 'id', description: 'Id of the device' })
  @ApiImplicitParam({ name: 'organizationId', description: 'Organization the device belongs to', type: Number, required: true })
  @ApiResponse({ status: 200, description: 'Device has been successfully deleted', isArray: false, type: DevicesDto })
  @ApiResponse({ status: 404, description: 'Device does not exist or you don\'t have permission' })
  @ApiResponse({ status: 401, description: 'Not authenticated.' })
  @Permissions(PERMISSIONS.DEVICE_DELETE)
  async remove(@Param('id', new ParseIntPipe()) id: number, @User() authenticatedUser: AuthenticatedUserDto, @Param() params) {
    logger.info('Deleting device');
    return await this.deviceService.remove(id, { authenticatedUser, params });
  }
}
