import { ApiModelProperty } from '@nestjs/swagger';
import { SensorsDto } from 'modules/database/dto/sensors.dto';
import { MetaDto } from 'modules/database/dto/meta.dto';

export class SensorsPaginatedDto {

  @ApiModelProperty({ type: SensorsDto, isArray: true })
  readonly data: SensorsDto[];

  @ApiModelProperty()
  readonly meta: MetaDto;

  constructor(data, totalItems: number, pageSize: number, page: number) {
    this.data = data;
    this.meta = new MetaDto(Math.ceil(totalItems / pageSize), totalItems, pageSize, page);
  }
}
