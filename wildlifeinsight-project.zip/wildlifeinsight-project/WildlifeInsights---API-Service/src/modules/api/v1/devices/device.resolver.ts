import { CreateDeviceDto } from './dto/create-device.dto';
import { DeviceService } from './device.service';
import { Resolver, Query, ResolveProperty, Mutation, Args, Parent } from '@nestjs/graphql';
import { UpdateDeviceDto } from './dto/update-device.dto';
import { UseInterceptors, UseGuards } from '@nestjs/common';
import { ValidationGraphqlInterceptor } from 'interceptors/validation-graphql.interceptor';
import { PaginationGraphqlInterceptor } from 'interceptors/pagination-graphql.interceptor';
import { Permissions } from 'decorators/permissions.decorator';
import { GraphqlUserWithPermissions } from 'decorators/graphql-user.decorator';
import { PermissionsGraphQlGuard } from 'guards/permissions-graphql.guard';
import { GraphqlAuthGuard } from 'guards/graphql-passport.guard';
import { Devices } from 'modules/database/entities/devices.entity';
import { User } from 'decorators/user.decorator';
import { DevicesPaginatedDto } from './dto/devices.dto';
import { PERMISSIONS } from 'utils/permissions.enum';

@Resolver('Device')
@UseGuards(PermissionsGraphQlGuard)
export class DeviceResolver {
  constructor(private readonly deviceService: DeviceService) {}

  @Query()
  @UseGuards(GraphqlAuthGuard)
  @UseInterceptors(PaginationGraphqlInterceptor)
  async getDevices(@GraphqlUserWithPermissions(PERMISSIONS.ORGANIZATION_GET_ONE) authenticatedUser, @Args() args) {
    const data = await this.deviceService.findAll(args.pagination, { authenticatedUser, params: args });
    return new DevicesPaginatedDto(data[0], data[1], args.pagination.pageSize, args.pagination.pageNumber);
  }

  @Query()
  @UseGuards(GraphqlAuthGuard)
  async getDevice(@GraphqlUserWithPermissions(PERMISSIONS.ORGANIZATION_GET_ONE) authenticatedUser, @Args() args) {
    const { id } = args;
    return await this.deviceService.getById(id, {}, { authenticatedUser, params: args });
  }

  @ResolveProperty()
  async organization(@Parent() device: Devices) {
    return this.deviceService.getOrganizationById(device.organizationId);
  }

  @ResolveProperty()
  async sensors(@Parent() device: Devices) {
    return this.deviceService.getSensorsOfDevice(device.id);
  }

  @Mutation()
  @UseGuards(GraphqlAuthGuard)
  @UseInterceptors(new ValidationGraphqlInterceptor(CreateDeviceDto))
  async createDevice(@GraphqlUserWithPermissions(PERMISSIONS.ORGANIZATION_UPDATE) authenticatedUser, @Args() args) {
    const { body } = args;
    return this.deviceService.create(body, { authenticatedUser, params: args });
  }

  @Mutation()
  @UseGuards(GraphqlAuthGuard)
  @UseInterceptors(new ValidationGraphqlInterceptor(UpdateDeviceDto))
  async updateDevice(@GraphqlUserWithPermissions(PERMISSIONS.ORGANIZATION_UPDATE) authenticatedUser, @Args() args) {
    const { id, body } = args;
    return this.deviceService.update(id, body, { authenticatedUser, params: args });
  }

  @Mutation()
  @UseGuards(GraphqlAuthGuard)
  async deleteDevice(@GraphqlUserWithPermissions(PERMISSIONS.ORGANIZATION_UPDATE) authenticatedUser, @Args() args) {
    const { id } = args;
    return this.deviceService.remove(id, { authenticatedUser, params: args });
  }
}
