import { UpdateDeviceDto } from './dto/update-device.dto';
import { CreateDeviceDto } from './dto/create-device.dto';
import { Devices } from 'modules/database/entities/devices.entity';
import { Repository, SelectQueryBuilder } from 'typeorm';
import { Injectable, Inject, NotFoundException, BadRequestException, UnauthorizedException } from '@nestjs/common';
import { GenericService } from 'utils/generic.service';
import { InfoDto } from 'dto/info.dto';
import { Organizations } from 'modules/database/entities/organizations.entity';
import { Sensors } from 'modules/database/entities/sensors.entity';

const logger = require('logger');

@Injectable()
export class DeviceService extends GenericService<Devices, CreateDeviceDto, UpdateDeviceDto>  {

  constructor(
    @Inject('DevicesRepositoryToken') private readonly devicesRepository: Repository<Devices>,
    @Inject('SensorsRepositoryToken') private readonly sensorsRepository: Repository<Sensors>,
    @Inject('OrganizationsRepositoryToken') private readonly organizationsRepository: Repository<Organizations>,
  ) {
    super(devicesRepository, 'device');
  }

  setFilters(query: SelectQueryBuilder<Devices>, filters: any, info: InfoDto) {
    query.where('device.organizationId = :organizationId').setParameter('organizationId', info.params.organizationId);
    return query;
  }

  setFiltersGetById(query: SelectQueryBuilder<Devices>, info: InfoDto) {
    query.andWhere('device.organizationId = :organizationId').setParameter('organizationId', info.params.organizationId);
    return query;
  }

  setFiltersDelete(query: SelectQueryBuilder<Devices>, info: InfoDto) {
    query.andWhere('device.organizationId = :organizationId').setParameter('organizationId', info.params.organizationId);
    return query;
  }

  setFiltersUpdate(query: SelectQueryBuilder<Devices>, info: InfoDto) {
    query.andWhere('device.organizationId = :organizationId').setParameter('organizationId', info.params.organizationId);
    return query;
  }

  async getOrganizationById(id: number): Promise<Organizations> {
    return this.organizationsRepository.findOne(id);
  }

  async getSensorsOfDevice(id: number): Promise<Sensors[]> {
    return this.sensorsRepository.find({ where: { deviceId: id } });
  }

  async setDataCreate(create: CreateDeviceDto, info: InfoDto) {
    const organization = await this.organizationsRepository.findOne(info.params.organizationId);

    const model = new Devices();
    model.name = create.name;
    model.purchaseDate = create.purchaseDate;
    model.make = create.make;
    model.model = create.model;
    model.modelNumber = create.modelNumber;
    model.serialNumber = create.serialNumber;
    model.purchaseYear = create.purchaseYear;
    model.purchasePrice = create.purchasePrice;
    model.productUrl = create.productUrl;
    model.remarks = create.remarks;
    model.organization = organization;

    return model;

  }

  async setDataUpdate(model: Devices, update: UpdateDeviceDto, info: InfoDto) {

    if (update.name !== undefined) {
      model.name = update.name;
    }
    if (update.remarks !== undefined) {
      model.remarks = update.remarks;
    }
    if (update.purchaseDate !== undefined) {
      model.purchaseDate = update.purchaseDate;
    }
    if (update.make !== undefined) {
      model.make = update.make;
    }
    if (update.model !== undefined) {
      model.model = update.model;
    }
    if (update.modelNumber !== undefined) {
      model.modelNumber = update.modelNumber;
    }
    if (update.serialNumber !== undefined) {
      model.serialNumber = update.serialNumber;
    }
    if (update.purchaseYear !== undefined) {
      model.purchaseYear = update.purchaseYear;
    }
    if (update.purchasePrice !== undefined) {
      model.purchasePrice = update.purchasePrice;
    }
    if (update.productUrl !== undefined) {
      model.productUrl = update.productUrl;
    }

    return model;
  }

}
