import { ApiModelProperty } from '@nestjs/swagger';
import { IsString, IsNumber, IsOptional, MaxLength, IsBoolean } from 'class-validator';

export class UpdateSensorDto {

  @IsString()
  @IsOptional()
  @MaxLength(255)
  @ApiModelProperty({ required: false })
  name: string;

  @IsOptional()
  @IsNumber()
  @ApiModelProperty({ required: false })
  triggerSpeed: number | null;

  @IsOptional()
  @IsNumber()
  @ApiModelProperty({ required: false })
  gain: number | null;

  @IsOptional()
  @IsBoolean()
  @ApiModelProperty({ required: false })
  active: boolean = true;

  @IsString()
  @IsOptional()
  @ApiModelProperty({ required: false })
  remarks: string | null;

}
