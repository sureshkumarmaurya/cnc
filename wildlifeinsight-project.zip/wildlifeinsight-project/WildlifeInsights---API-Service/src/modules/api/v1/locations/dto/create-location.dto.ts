import { ApiModelProperty } from '@nestjs/swagger';
import { IsString, IsInt, IsNumber, IsOptional, MaxLength, Validate, IsDefined } from 'class-validator';
import { FeaturesDto } from 'modules/database/dto/features.dto';
import { DecimalChecker } from "../../../../../decorators/validation/decimal-validator";

export class CreateLocationDto {

  @IsOptional()
  @IsNumber()
  @ApiModelProperty({
    description: '(Latitude field has been deprecated.)',
    required: false
  })
  latitude: number | null;

  @IsOptional()
  @IsNumber()
  @ApiModelProperty({
    description: '(Longitude field has been deprecated.)',
    required: false
  })
  longitude: number | null;


  @IsDefined()
  @Validate(DecimalChecker, {
    message: "Latitude must be string and also contain at least four and maximum eight decimal digits"
  })
  @ApiModelProperty({
    description: '(Minimum 4 decimal and maximum 8 decimal.)',
    required: true
  })
  latitudeStr: string;

  @IsDefined()
  @ApiModelProperty({
    description: '(Minimum 4 decimal and maximum 8 decimal.)',
    required: true
  })
  @Validate(DecimalChecker, {
    message: "Longitude must be string and also contain at least four and maximum eight decimal digits"
  })
  longitudeStr: string;

  @IsString()
  @MaxLength(255)
  @IsDefined()
  @ApiModelProperty({ required: true })
  placename: string;

  @IsOptional()
  @IsString()
  @MaxLength(255)
  @ApiModelProperty({ required: false })
  propertyType: string | null;

  @IsOptional()
  @IsString()
  @MaxLength(255)
  @ApiModelProperty({ required: false })
  habitat: string | null;

  @IsOptional()
  @IsString()
  @ApiModelProperty({ required: false })
  remarks: string | null;

  @IsOptional()
  @IsString()
  @MaxLength(255)
  @ApiModelProperty({ required: false })
  plotTreatment: string | null;

  @IsOptional()
  @IsString()
  @ApiModelProperty({ required: false })
  plotTreatmentDescription: string | null;

  @IsString()
  @MaxLength(255)
  @ApiModelProperty({ required: true })
  geodeticDatum: string;

  @IsOptional()
  @IsString()
  @MaxLength(255)
  @ApiModelProperty({ required: false })
  fieldNumber: string;

  @IsOptional()
  @IsString()
  @MaxLength(255)
  @ApiModelProperty({ required: false })
  country: string;

  @IsOptional()
  @IsString()
  @MaxLength(255)
  @ApiModelProperty({ required: false })
  firstOrderDivision: string;

  @IsOptional()
  @IsString()
  @MaxLength(255)
  @ApiModelProperty({ required: false })
  secondOrderDivision: string;

  @IsOptional()
  @IsString()
  @MaxLength(255)
  @ApiModelProperty({ required: false })
  landcoverType: string;

  @IsOptional()
  @IsString()
  @MaxLength(255)
  @ApiModelProperty({ required: false })
  igbpClimateClassification: string;

  @IsOptional()
  @IsInt()
  @ApiModelProperty({ required: false })
  elevationGtopo30: number;

  @IsOptional()
  @ApiModelProperty({ required: false })
  features: FeaturesDto[];
}
