import { ApiModelProperty } from '@nestjs/swagger';
import { LocationsDto } from 'modules/database/dto/locations.dto';
import { MetaDto } from 'modules/database/dto/meta.dto';
import { getLatLong } from '../../../../../utils/lat-long';

export class LocationsPaginatedDto {

  @ApiModelProperty({ type: LocationsDto, isArray: true })
  readonly data: LocationsDto[];

  @ApiModelProperty()
  readonly meta: MetaDto;

  constructor(data, totalItems: number, pageSize: number, page: number) {

    this.data = data.map((location) => {
      return {
        ...location,
        latitudeStr: getLatLong(location.latitude),
        longitudeStr: getLatLong(location.longitude)
      }
    })

    this.meta = new MetaDto(Math.ceil(totalItems / pageSize), totalItems, pageSize, page);
  }
}
