import { LocationController, locationsRelations } from './location.controller';
import { LocationService } from './location.service';
import { Module, RequestMethod, MiddlewareConsumer } from '@nestjs/common';
import { PaginationMiddleware } from 'middlewares/pagination.middleware';
import { LocationResolver } from './location.resolver';
import { DatabaseModule } from 'modules/database/database.module';
import { LocationGeneralController } from './location-general.controller';

@Module({
  imports: [DatabaseModule],
  controllers: [LocationController, LocationGeneralController],
  providers: [LocationService, LocationResolver],
})
export class LocationModule {
  public configure(consumer: MiddlewareConsumer) {
    consumer
      .apply(PaginationMiddleware)
      .with({ includes: [], allowIncludes: locationsRelations })
      .forRoutes(
        { path: '/api/v1/project/:projectId/location', method: RequestMethod.GET },
        { path: '/api/v1/organization/:organizationId/location', method: RequestMethod.GET },
        { path: '/api/v1/location', method: RequestMethod.GET },
        { path: '/api/v1/project/:projectId/location/:locationId', method: RequestMethod.GET },
      );
  }
}
