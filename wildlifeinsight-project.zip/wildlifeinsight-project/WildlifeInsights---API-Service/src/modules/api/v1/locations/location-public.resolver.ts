import { LocationService } from './location.service';
import { Resolver, Query, Args } from '@nestjs/graphql';
import { UseInterceptors, HttpException, HttpStatus } from '@nestjs/common';
import { InitiativeService } from '../initiatives/initiative.service';
import { PaginationGraphqlInterceptor } from 'interceptors/pagination-graphql.interceptor';
import { LocationsPaginatedDto } from './dto/locations.dto';

const logger = require('logger');

@Resolver('LocationPublic')
export class LocationPublicResolver {
  constructor(
    private readonly locationService: LocationService,
    private readonly initiativeService: InitiativeService,
  ) { }

  @Query()
  @UseInterceptors(PaginationGraphqlInterceptor)
  async getLocationsPublic(@Args() args) {

    let data = null;
    const { initiativeId, organizationId, projectId, pagination, filters } = args;
    const initiativeData = await this.initiativeService.getById(initiativeId, pagination, { params: args });

    if (!initiativeData.isLocationPublic) {
      throw new HttpException({ status: HttpStatus.FORBIDDEN, error: 'forbidden' }, 403);
    }

    if (organizationId) {
      data = await this.locationService.findAllByOrganization(organizationId, pagination, { params: args }, filters);
    } else if (initiativeId) {
      data = await this.locationService.findAllByProject(projectId, initiativeId, pagination, { params: args }, filters);
    }

    if (!(data && data.length)) {
      data = await this.locationService.findAllWithoutOrganization(pagination, { params: args }, filters);
    }

    return new LocationsPaginatedDto(data[0], data[1], pagination.pageSize, pagination.pageNumber);
  }

}
