import { Get, Controller, Param, Query, ParseIntPipe } from '@nestjs/common';
import { LocationService } from './location.service';
import { ApiUseTags, ApiBearerAuth, ApiOperation, ApiResponse, ApiImplicitQuery, ApiImplicitParam } from '@nestjs/swagger';
import { LocationsPaginatedDto } from './dto/locations.dto';
import { Pagination } from 'decorators/pagination.decorator';
import { User } from 'decorators/user.decorator';
import { AuthenticatedUserDto } from 'dto/authenticated-user.dto';
import { PaginationModel } from 'utils/pagination.model';

const logger = require('logger');

export const locationsRelations = ['features', 'device'];

@Controller('/api/v1')
@ApiUseTags('Locations')
@ApiBearerAuth()
export class LocationGeneralController {
  constructor(private readonly locationService: LocationService) { }

  @Get('/organization/:organizationId/location')
  @ApiOperation({
    title: 'Get Locations of organization', description: `
    Get all locations by organization
  `, operationId: 'GetAllLocationsByOrganization',
  })
  @ApiResponse({ status: 200, description: 'Locations have been successfully returned', isArray: false, type: LocationsPaginatedDto })
  @ApiResponse({ status: 403, description: 'Not authorized.' })
  @ApiResponse({ status: 401, description: 'Not authenticated.' })
  @ApiImplicitQuery({
    name: 'includes', description: `
  Allows include the Locations's relations. Available ${locationsRelations}
  `, type: String, required: false,
  })
  @ApiImplicitQuery({ name: 'fields', description: 'Locations\'s fields to select', type: String, required: false })
  @ApiImplicitQuery({ name: 'page[size]', description: 'Page size. Default 10', type: String, required: false })
  @ApiImplicitQuery({ name: 'page[number]', description: 'Page number', type: String, required: false })
  @ApiImplicitQuery({ name: 'sort', description: 'Sort results', type: String, required: false })
  @ApiImplicitQuery({ name: 'name', description: 'Filter by name', type: String, required: false })
  @ApiImplicitParam({ name: 'organizationId', description: 'Organization the location belongs to', type: Number, required: true })
  async findAllByOrganiztion(@Param('organizationId', new ParseIntPipe()) organizationId: number, @Query() filters, @Pagination() pagination: PaginationModel, @Param() params, @User() authenticatedUser: AuthenticatedUserDto) {
    logger.info('Getting all locations by organization');
    const data = await this.locationService.findAllByOrganization(organizationId, pagination, { authenticatedUser, params }, filters);
    return new LocationsPaginatedDto(data[0], data[1], pagination.pageSize, pagination.pageNumber);
  }

  @Get('/location')
  @ApiOperation({
    title: 'Get Locations ', description: `
    Get all locations
  `, operationId: 'GetAllLocations',
  })
  @ApiResponse({ status: 200, description: 'Locations have been successfully returned', isArray: false, type: LocationsPaginatedDto })
  @ApiResponse({ status: 403, description: 'Not authorized.' })
  @ApiResponse({ status: 401, description: 'Not authenticated.' })
  @ApiImplicitQuery({
    name: 'includes', description: `
  Allows include the Locations's relations. Available ${locationsRelations}
  `, type: String, required: false,
  })
  @ApiImplicitQuery({ name: 'fields', description: 'Locations\'s fields to select', type: String, required: false })
  @ApiImplicitQuery({ name: 'page[size]', description: 'Page size. Default 10', type: String, required: false })
  @ApiImplicitQuery({ name: 'page[number]', description: 'Page number', type: String, required: false })
  @ApiImplicitQuery({ name: 'sort', description: 'Sort results', type: String, required: false })
  @ApiImplicitQuery({ name: 'name', description: 'Filter by name', type: String, required: false })
  async findAll(@Query() filters, @Pagination() pagination: PaginationModel, @Param() params, @User() authenticatedUser: AuthenticatedUserDto) {
    logger.info('Getting all locations');
    const data = await this.locationService.findAllWithoutOrganization(pagination, { authenticatedUser, params }, filters);
    return new LocationsPaginatedDto(data[0], data[1], pagination.pageSize, pagination.pageNumber);
  }

}
