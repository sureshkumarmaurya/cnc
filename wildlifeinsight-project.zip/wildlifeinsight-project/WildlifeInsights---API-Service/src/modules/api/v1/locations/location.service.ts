import { UpdateLocationDto } from './dto/update-location.dto';
import { CreateLocationDto } from './dto/create-location.dto';
import { Locations } from 'modules/database/entities/locations.entity';
import { Repository, SelectQueryBuilder, Not } from 'typeorm';
import { Injectable, Inject, NotFoundException, BadRequestException, UnauthorizedException } from '@nestjs/common';
import { GenericService } from 'utils/generic.service';
import { InfoDto } from 'dto/info.dto';
import { Projects } from 'modules/database/entities/projects.entity';
import { PermissionsUtils } from 'utils/permissions.utils';
import { ProjectsDto } from 'modules/database/dto/projects.dto';
import { PERMISSIONS } from 'utils/permissions.enum';
import { Features } from 'modules/database/entities/features.entity';
import { PaginationModel } from 'utils/pagination.model';
import { getLatLong } from '../../../../utils/lat-long';

const logger = require('logger');

@Injectable()
export class LocationService extends GenericService<Locations, CreateLocationDto, UpdateLocationDto>  {

  constructor(
    @Inject('LocationsRepositoryToken') private readonly locationsRepository: Repository<Locations>,
    @Inject('ProjectsRepositoryToken') private readonly projectsRepository: Repository<Projects>,
    @Inject('FeaturesRepositoryToken') private readonly featuresRepository: Repository<Features>,
  ) {
    super(locationsRepository, 'location');
  }

  setFilters(query: SelectQueryBuilder<Locations>, filters: any, info: InfoDto) {
    if (info.params.projectId) {
      query.where('location.projectId = :projectId').setParameter('projectId', info.params.projectId);
    }
    if (info.others && info.others.projectIds) {
      query.andWhere('location.projectId in (:...projectIds)').setParameter('projectIds', info.others.projectIds);
    }
    if (filters && filters.name) {
      query.andWhere('lower(location.placename) like :name').setParameter('name', `%${filters.name.toLowerCase()}%`);
    }
    return query;
  }

  setFiltersGetById(query: SelectQueryBuilder<Locations>, info: InfoDto) {
    query.andWhere('location.projectId = :projectId').setParameter('projectId', info.params.projectId);
    return query;
  }

  setFiltersDelete(query: SelectQueryBuilder<Locations>, info: InfoDto) {
    query.andWhere('location.projectId = :projectId').setParameter('projectId', info.params.projectId);
    return query;
  }

  setFiltersUpdate(query: SelectQueryBuilder<Locations>, info: InfoDto) {
    query.andWhere('location.projectId = :projectId').setParameter('projectId', info.params.projectId);
    return query;
  }

  assignProjectIdsToInfoWithPermissions(type: string, permission: any, info: any, id?: number) {
    let projectIds;

    if (!type) {
      projectIds = PermissionsUtils.getProjectsInAllOrganizationsWithPermission(info.authenticatedUser, permission);
    } else if (type === 'organization') {
      projectIds = PermissionsUtils.getProjectsInOrganizationWithPermission(info.authenticatedUser, permission, id);
    } else if (type === 'initiative') {
      projectIds = PermissionsUtils.getProjectsInInitiativeWithPermission(info.authenticatedUser, permission, id);
    }

    if (!projectIds || projectIds.length === 0) {
      return false;
    }

    info.others = { ...info.others, projectIds: projectIds.map((p: ProjectsDto) => p.id) };
    return info;
  }

  async getProjectById(id: number): Promise<Projects> {
    return this.projectsRepository.findOne(id);
  }

  async getFeaturesOfLocation(parentLocation: Locations): Promise<Features[]> {
    return this.featuresRepository.find({ locations: parentLocation });
  }

  async findAllWithInitiative(id: number) {
    return this.projectsRepository.createQueryBuilder()
      .where('initiative_id = :id', { id })
      .getMany();
  }

  async findAllByOrganization(organizationId: number, pagination: PaginationModel, info?: InfoDto, filters: any = null): Promise<[Locations[], number]> {
    let infoData = { ...info };
    if (infoData && infoData.authenticatedUser && infoData.authenticatedUser.user) {
      infoData = this.assignProjectIdsToInfoWithPermissions('organization', PERMISSIONS.LOCATION_GET_ALL, infoData, organizationId);
      if (!infoData) {
        return [[], 0];
      }
    }
    return this.findAll(pagination, infoData, filters);
  }

  async findAllByProject(projectId: number, initiativeId: number, pagination: PaginationModel, info?: InfoDto, filters: any = null): Promise<[Locations[], number]> {
    let infoData = { ...info };
    if (initiativeId) {
      if (infoData && infoData.authenticatedUser && infoData.authenticatedUser.user) {
        infoData = this.assignProjectIdsToInfoWithPermissions('initiative', PERMISSIONS.LOCATION_GET_ALL, infoData, initiativeId);
        if (!infoData) {
          return [[], 0];
        }
      } else {
        const projects = await this.findAllWithInitiative(initiativeId);
        if (!projects || projects.length === 0) {
          return [[], 0];
        }
        infoData.others = { ...infoData.others, projectIds: projects.map(p => p.id) };
      }
    }

    return this.findAll(pagination, infoData, filters);
  }

  async findAllWithoutOrganization(pagination: PaginationModel, info?: InfoDto, filters: any = null): Promise<[Locations[], number]> {
    let infoData = { ...info };
    if (infoData && infoData.authenticatedUser && infoData.authenticatedUser.user) {
      infoData = this.assignProjectIdsToInfoWithPermissions(null, PERMISSIONS.LOCATION_GET_ALL, infoData);
      if (!infoData) {
        return [[], 0];
      }
    }
    return this.findAll(pagination, infoData, filters);
  }

  async setDataCreate(create: CreateLocationDto, info: InfoDto) {
    const project = await this.projectsRepository.findOne(info.params.projectId);

    const model = new Locations();
    model.placename = create.placename;
    model.latitude = Number(create.latitudeStr);
    model.longitude = Number(create.longitudeStr);
    model.propertyType = create.propertyType;
    model.habitat = create.habitat;
    model.plotTreatment = create.plotTreatment;
    model.plotTreatmentDescription = create.plotTreatmentDescription;
    model.geodeticDatum = create.geodeticDatum;
    model.fieldNumber = create.fieldNumber;
    model.country = create.country;
    model.firstOrderDivision = create.firstOrderDivision;
    model.secondOrderDivision = create.secondOrderDivision;
    model.landcoverType = create.landcoverType;
    model.igbpClimateClassification = create.igbpClimateClassification;
    model.elevationGtopo30 = create.elevationGtopo30;
    model.remarks = create.remarks;
    model.project = project;

    return model;

  }

  async actionAfterCreate(data: Locations, create: CreateLocationDto) {
    // Create features associated with the location just created
    await Promise.all(create.features.map(async (feature) => {
      this.createOrUpdateFeature(feature.featureName, feature.description, data.id);
    }));
  }

  async setDataUpdate(model: Locations, update: UpdateLocationDto, info: InfoDto) {

    if (update.remarks !== undefined) {
      model.remarks = update.remarks;
    }
    if (update.latitudeStr !== undefined) {
      model.latitude = Number(update.latitudeStr);
    }
    if (update.longitudeStr !== undefined) {
      model.longitude = Number(update.longitudeStr);
    }
    if (update.placename !== undefined) {
      model.placename = update.placename;
    }
    if (update.propertyType !== undefined) {
      model.propertyType = update.propertyType;
    }
    if (update.habitat !== undefined) {
      model.habitat = update.habitat;
    }
    if (update.plotTreatment !== undefined) {
      model.plotTreatment = update.plotTreatment;
    }
    if (update.plotTreatmentDescription !== undefined) {
      model.plotTreatmentDescription = update.plotTreatmentDescription;
    }
    if (update.geodeticDatum !== undefined) {
      model.geodeticDatum = update.geodeticDatum;
    }
    if (update.fieldNumber !== undefined) {
      model.fieldNumber = update.fieldNumber;
    }
    if (update.country !== undefined) {
      model.country = update.country;
    }
    if (update.firstOrderDivision !== undefined) {
      model.firstOrderDivision = update.firstOrderDivision;
    }
    if (update.secondOrderDivision !== undefined) {
      model.secondOrderDivision = update.secondOrderDivision;
    }
    if (update.landcoverType !== undefined) {
      model.landcoverType = update.landcoverType;
    }
    if (update.igbpClimateClassification !== undefined) {
      model.igbpClimateClassification = update.igbpClimateClassification;
    }
    if (update.elevationGtopo30 !== undefined) {
      model.elevationGtopo30 = update.elevationGtopo30;
    }

    return model;
  }

  async actionAfterUpdate(data: Locations, update: UpdateLocationDto) {
    // create or update features provided in the update DTO, store their ids
    const activeFeatures = await Promise.all(update.features.map(async (feature) => {
      return await this.createOrUpdateFeature(feature.featureName, feature.description, data.id).then(feature => feature.id);
    }));

    // get ids of all features currently defined (this will be the ones created
    // or updated above, plus any other ones already defined), store their ids
    const allFeatures = await this.featuresRepository
      .find({ locations: data })
      .then(features => features.map(location => location.id));

    // compute the difference between the two sets: this is the list of ids
    // of all (if any) features that are not required anymore
    const inactiveFeatures = allFeatures.filter(feature => activeFeatures.indexOf(feature) === -1);
    // finally, delete inactive features
    this.featuresRepository.delete(inactiveFeatures);
  }

  /**
   * Create or update features associated with a given location
   */
  async createOrUpdateFeature(featureName: string, description: string, locationId: number) {
    try {
      const existFeature = await this.featuresRepository.findOne({ featureName });
      if (existFeature) { await this.featuresRepository.delete(existFeature.id); }
      const location = await this.locationsRepository.findOne(locationId);
      return await this.featuresRepository.save({ featureName, description, locations: location });
    } catch (err) {
      logger.error(`Error while creating or updating feature: ${err}`);
    }
  }


  async getById(id: number, pagination: PaginationModel, info?: InfoDto): Promise<Locations> {
    logger.debug('Getting by id');
    let query = this.repository.createQueryBuilder(this.alias);
    info.pagination = pagination;
    query = this.setFiltersGetById(query, info);
    query.andWhere(`${this.alias}.id = :id`).setParameter('id', id);

    const model = await query.getOne();
    if (!model) {
      throw new NotFoundException(`${this.alias} not found`);
    }

    model.latitudeStr = getLatLong(model.latitude);
    model.longitudeStr = getLatLong(model.longitude);
    return model;
  }



  async checkUniquePlaceNameAndProjectName(id: number, placename: string): Promise<number> {
    return this.locationsRepository.count({ where: { projectId: id, placename: placename } });
  }


  async checkOnUpdate(projectId: number, placename: string, locationId: number): Promise<number> {
    return this.locationsRepository.count({ where: { projectId: projectId, placename: placename, id: Not(locationId) } });
  }


  async create(createModel: CreateLocationDto, info?: InfoDto): Promise<Locations> {
    logger.debug(`Creating ${this.alias}`);


    var countPlaceNameForProject = await this.checkUniquePlaceNameAndProjectName(info.params.projectId, createModel.placename);

    if (countPlaceNameForProject > 0) {
      throw new BadRequestException(`Place name already exists for this project`);
    }

    await this.validateBeforeCreate(createModel, info);
    const model = await this.setDataCreate(createModel, info);

    const location = await this.locationsRepository.save(model);
    if (!location) {
      throw new NotFoundException(`Location not created`);
    }

    if (this.actionAfterCreate) this.actionAfterCreate(location, createModel);

    location['latitudeStr'] = getLatLong(location.latitude);
    location['longitudeStr'] = getLatLong(location.longitude);
    return location;
  }

  async update(id: number, updateModel: UpdateLocationDto, info?: InfoDto): Promise<Locations> {
    logger.debug(`Updating ${this.alias}`);
    var countPlaceNameForProject = await this.checkOnUpdate(info.params.projectId, updateModel.placename, id);
    if (countPlaceNameForProject > 0) {
      throw new BadRequestException(`Place name already exists for this project`);
    }

    await this.validateBeforeUpdate(id, updateModel, info);
    let query = this.repository.createQueryBuilder(this.alias);
    query = this.setFiltersUpdate(query, info);
    query.andWhere(`${this.alias}.id = :id`).setParameter('id', id);
    let model = await query.getOne();
    if (!model) {
      throw new NotFoundException(`${this.alias} not found`);
    }

    model = await this.setDataUpdate(model, updateModel, info);

    model['latitudeStr'] = getLatLong(model.latitude);
    model['longitudeStr'] = getLatLong(model.longitude);


    return new Promise((resolve, reject) => {
      this.repository.save(model)
        .then((result) => {
          if (this.actionAfterUpdate) this.actionAfterUpdate(result, updateModel);
          resolve(result);
        })
        .catch(e => reject(e));
    });
  }

}
