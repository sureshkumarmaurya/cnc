import { Permissions } from 'decorators/permissions.decorator';
import { UpdateLocationDto } from './dto/update-location.dto';
import { CreateLocationDto } from './dto/create-location.dto';
import { Get, Controller, Req, Post, Body, Patch, Param, Delete, ParseIntPipe, UseGuards, Query } from '@nestjs/common';
import { LocationService } from './location.service';
import { ApiUseTags, ApiBearerAuth, ApiOperation, ApiResponse, ApiImplicitQuery, ApiImplicitParam } from '@nestjs/swagger';
import { LocationsPaginatedDto } from './dto/locations.dto';
import { Pagination } from 'decorators/pagination.decorator';
import { ValidationPipe } from 'pipes/validation.pipe';
import { LocationsDto } from 'modules/database/dto/locations.dto';
import { PermissionsGuard } from 'guards/permissions.guard';
import { User } from 'decorators/user.decorator';
import { AuthenticatedUserDto } from 'dto/authenticated-user.dto';
import { PERMISSIONS } from 'utils/permissions.enum';
import { PaginationModel } from 'utils/pagination.model';

const logger = require('logger');

export const locationsRelations = ['features', 'project'];

@Controller('/api/v1/project/:projectId/location')
@ApiUseTags('Locations')
@ApiBearerAuth()
@UseGuards(PermissionsGuard)
export class LocationController {
  constructor(private readonly locationService: LocationService) { }

  @Get()
  @ApiOperation({
    title: 'Get Locations by project', description: `
    Get all locations by project
  `, operationId: 'GetAllLocationsByProject',
  })
  @ApiResponse({ status: 200, description: 'Locations have been successfully returned', isArray: false, type: LocationsPaginatedDto })
  @ApiResponse({ status: 403, description: 'Not authorized.' })
  @ApiResponse({ status: 401, description: 'Not authenticated.' })
  @ApiImplicitParam({ name: 'projectId', description: 'Project the location belongs to', type: Number, required: true })
  @ApiImplicitQuery({
    name: 'includes', description: `
  Allows include the Locations's relations. Available ${locationsRelations}
  `, type: String, required: false,
  })
  @ApiImplicitQuery({ name: 'fields', description: 'Locations\'s fields to select', type: String, required: false })
  @ApiImplicitQuery({ name: 'page[size]', description: 'Page size. Default 10', type: String, required: false })
  @ApiImplicitQuery({ name: 'page[number]', description: 'Page number', type: String, required: false })
  @ApiImplicitQuery({ name: 'sort', description: 'Sort results', type: String, required: false })
  @ApiImplicitQuery({ name: 'name', description: 'Filter by name', type: String, required: false })
  @Permissions(PERMISSIONS.LOCATION_GET_ALL)
  async findAll(@Query() filters, @Pagination() pagination: PaginationModel, @Param() params, @User() authenticatedUser: AuthenticatedUserDto) {
    logger.info('Getting all locations by project');
    const data = await this.locationService.findAll(pagination, { authenticatedUser, params }, filters);
    return new LocationsPaginatedDto(data[0], data[1], pagination.pageSize, pagination.pageNumber);
  }

  @Get('/:id')
  @ApiOperation({
    title: 'Get location by id', description: `
    Get location by id
  `, operationId: 'GetLocationById',
  })
  @ApiImplicitQuery({
    name: 'includes', description: `
  Allows include the Locations's relations. Available ${locationsRelations}
  `, type: String, required: false,
  })
  @ApiImplicitParam({ name: 'projectId', description: 'Project the location belongs to', type: Number, required: true })
  @ApiImplicitParam({ name: 'id', description: 'Id of the location' })
  @ApiResponse({ status: 200, description: 'Location has been successfully returned', isArray: false, type: LocationsDto })
  @ApiResponse({ status: 404, description: 'Location does not exist or you don\'t have permission' })
  @ApiResponse({ status: 401, description: 'Not authenticated.' })
  @Permissions(PERMISSIONS.LOCATION_GET_ONE)
  async getById(@Param('id', new ParseIntPipe()) id: number, @User() authenticatedUser: AuthenticatedUserDto, @Param() params, @Pagination() pagination: PaginationModel) {
    logger.info('Get location by id ', id);
    return await this.locationService.getById(id, pagination, { authenticatedUser, params });
  }

  @Post()
  @ApiOperation({
    title: 'Create location', description: `
    Create new location
  `, operationId: 'CreateLocation',
  })
  @ApiImplicitParam({ name: 'projectId', description: 'Project the location belongs to', type: Number, required: true })
  @ApiResponse({ status: 200, description: 'Location has been successfully created', isArray: false, type: LocationsDto })
  @ApiResponse({ status: 400, description: 'Body contains errors' })
  @ApiResponse({ status: 401, description: 'Not authenticated.' })
  @Permissions(PERMISSIONS.LOCATION_CREATE)
  async create(@Body(new ValidationPipe()) createLocationDto: CreateLocationDto, @User() authenticatedUser: AuthenticatedUserDto, @Param() params) {
    logger.info('Creating location');
    return await this.locationService.create(createLocationDto, { authenticatedUser, params });
  }

  @Patch('/:id')
  @ApiOperation({
    title: 'Update location', description: `
    Update location
  `, operationId: 'UpdateLocation',
  })
  @ApiImplicitParam({ name: 'projectId', description: 'Project the location belongs to', type: Number, required: true })
  @ApiImplicitParam({ name: 'id', description: 'Id of the location' })
  @ApiResponse({ status: 200, description: 'Location has been successfully updated', isArray: false, type: LocationsDto })
  @ApiResponse({ status: 404, description: 'Location does not exist or you don\'t have permission' })
  @ApiResponse({ status: 401, description: 'Not authenticated.' })
  @Permissions(PERMISSIONS.LOCATION_UPDATE)
  async update(@Param('id', new ParseIntPipe()) id: number, @Body(new ValidationPipe()) updateLocationDto: UpdateLocationDto, @User() authenticatedUser: AuthenticatedUserDto, @Param() params) {
    logger.info('Updating location');
    // TODO: Add security
    return await this.locationService.update(id, updateLocationDto, { authenticatedUser, params });
  }

  @Delete('/:id')
  @ApiOperation({
    title: 'Delete location', description: `
    Delete location
  `, operationId: 'DeleteLocation',
  })
  @ApiImplicitParam({ name: 'projectId', description: 'Project the location belongs to', type: Number, required: true })
  @ApiImplicitParam({ name: 'id', description: 'Id of the location' })
  @ApiResponse({ status: 200, description: 'Location has been successfully deleted', isArray: false, type: LocationsDto })
  @ApiResponse({ status: 404, description: 'Location does not exist or you don\'t have permission' })
  @ApiResponse({ status: 401, description: 'Not authenticated.' })
  @Permissions(PERMISSIONS.LOCATION_DELETE)
  async remove(@Param('id', new ParseIntPipe()) id: number, @User() authenticatedUser: AuthenticatedUserDto, @Param() params) {
    logger.info('Deleting location');
    return await this.locationService.remove(id, { authenticatedUser, params });
  }
}
