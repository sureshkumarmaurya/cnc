import { CreateLocationDto } from './dto/create-location.dto';
import { LocationService } from './location.service';
import { Resolver, Query, ResolveProperty, Mutation, Args, Parent } from '@nestjs/graphql';
import { UpdateLocationDto } from './dto/update-location.dto';
import { UseInterceptors, UseGuards } from '@nestjs/common';
import { GraphqlAuthGuard } from 'guards/graphql-passport.guard';
import { GraphqlUserWithPermissions } from 'decorators/graphql-user.decorator';
import { ValidationGraphqlInterceptor } from 'interceptors/validation-graphql.interceptor';
import { PaginationGraphqlInterceptor } from 'interceptors/pagination-graphql.interceptor';
import { Permissions } from 'decorators/permissions.decorator';
import { Locations } from 'modules/database/entities/locations.entity';
import { PERMISSIONS } from 'utils/permissions.enum';
import { User } from 'decorators/user.decorator';
import { LocationsPaginatedDto } from './dto/locations.dto';
import { Features } from 'modules/database/entities/features.entity';

const logger = require('logger');

@Resolver('Location')
export class LocationResolver {
  constructor(private readonly locationService: LocationService) {}

  @Query()
  @UseInterceptors(PaginationGraphqlInterceptor)
  async getLocations(@GraphqlUserWithPermissions() authenticatedUser, @Args() args) {
    let data;

    if (args.projectId || args.initiativeId) {
      data = await this.locationService.findAllByProject(args.projectId, args.initiativeId, args.pagination, { authenticatedUser, params: args }, args.filters);
    }

    if (args.organizationId) {
      data = await this.locationService.findAllByOrganization(args.organizationId, args.pagination, { authenticatedUser, params: args }, args.filters);
    }

    if (!data) {
      data = await this.locationService.findAllWithoutOrganization(args.pagination, { authenticatedUser, params: args }, args.filters);
    }

    return new LocationsPaginatedDto(data[0], data[1], args.pagination.pageSize, args.pagination.pageNumber);
  }

  @Query()
  @UseGuards(GraphqlAuthGuard)
  @Permissions(PERMISSIONS.LOCATION_GET_ONE)
  async getLocation(@GraphqlUserWithPermissions(PERMISSIONS.LOCATION_GET_ONE) authenticatedUser, @Args() args) {
    const { id } = args;
    return await this.locationService.getById(id, {}, { authenticatedUser, params: args });
  }

  @ResolveProperty()
  async project(@Parent() location: Locations) {
    return this.locationService.getProjectById(location.projectId);
  }

  @ResolveProperty()
  async features(@Parent() location: Locations) {
    return this.locationService.getFeaturesOfLocation(location);
  }

  @Mutation()
  @UseGuards(GraphqlAuthGuard)
  @UseInterceptors(new ValidationGraphqlInterceptor(CreateLocationDto))
  @Permissions(PERMISSIONS.LOCATION_CREATE)
  async createLocation(@GraphqlUserWithPermissions(PERMISSIONS.LOCATION_CREATE) authenticatedUser, @Args() args) {
    const { body } = args;
    return this.locationService.create(body, { authenticatedUser, params: args });
  }

  @Mutation()
  @UseGuards(GraphqlAuthGuard)
  @Permissions(PERMISSIONS.LOCATION_UPDATE)
  @UseInterceptors(new ValidationGraphqlInterceptor(UpdateLocationDto))
  async updateLocation(@GraphqlUserWithPermissions(PERMISSIONS.LOCATION_UPDATE) authenticatedUser, @Args() args) {
    const { id, body } = args;
    return this.locationService.update(id, body, { authenticatedUser, params: args });
  }

  @Mutation()
  @UseGuards(GraphqlAuthGuard)
  @Permissions(PERMISSIONS.LOCATION_DELETE)
  async deleteLocation(@GraphqlUserWithPermissions(PERMISSIONS.LOCATION_DELETE) authenticatedUser, @Args() args) {
    const { id } = args;
    return this.locationService.remove(id, { authenticatedUser, params: args });
  }
}
