import { LocationService } from './location.service';
import { InitiativeService } from '../initiatives/initiative.service';
import { Module } from '@nestjs/common';
import { LocationPublicResolver } from './location-public.resolver';
import { DatabaseModule } from 'modules/database/database.module';

@Module({
  imports: [DatabaseModule],
  controllers: [],
  providers: [LocationService, InitiativeService, LocationPublicResolver],
})
export class LocationPublicModule {

}
