import { ApiModelProperty } from '@nestjs/swagger';

export class AnalyticsDto {

  @ApiModelProperty({ type: Number, isArray: false })
  numDeployments: number;

  @ApiModelProperty({ type: Number, isArray: false })
  numDevices: number;

  @ApiModelProperty({ type: Number, isArray: false })
  numIdentifications?: number;

  @ApiModelProperty({ type: Number, isArray: false })
  numSpecies?: number;

  @ApiModelProperty({ type: Number, isArray: false })
  numImages: number;

  @ApiModelProperty({ type: Number, isArray: false })
  uniqueLocations: number;

  @ApiModelProperty({ type: Number, isArray: false })
  blankImagesCount?: number;

  @ApiModelProperty({ type: Number, isArray: false })
  unknownImagesCount?: number;

  @ApiModelProperty({ type: Number, isArray: false })
  samplingDaysCount: number;

  @ApiModelProperty({ type: Number, isArray: false })
  usersWithRolesOnProject: number;

  @ApiModelProperty({ type: Number, isArray: false })
  numUsers: number;

  @ApiModelProperty({ type: Number, isArray: false })
  humanImagesCount?: number;

  @ApiModelProperty({ type: Number, isArray: false })
  wildlifeImagesCount?: number;

  @ApiModelProperty({ type: Number, isArray: false })
  averageNumberOfImagesPerDeployment?: number;

  @ApiModelProperty({ type: Number, isArray: false })
  numCountries?: number;

  @ApiModelProperty({ type: Object, isArray: true })
  imagesPerSpecies?: object[];

  @ApiModelProperty({ type: Object, isArray: true })
  imagesPerLocation?: object[];
}
