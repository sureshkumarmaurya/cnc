import { AnalyticsController } from './analytics.controller';
import { AnalyticsService } from './analytics.service';
import { Module } from '@nestjs/common';
import { AnalyticsPublicResolver } from './analytics-public.resolver';
import { DatabaseModule } from 'modules/database/database.module';

@Module({
  imports: [DatabaseModule],
  controllers: [AnalyticsController],
  providers: [AnalyticsService, AnalyticsPublicResolver],
})

export class AnalyticsPublicModule { }
