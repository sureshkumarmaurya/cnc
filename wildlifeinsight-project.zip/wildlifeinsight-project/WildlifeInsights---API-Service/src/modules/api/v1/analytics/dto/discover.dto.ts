import { ApiModelProperty } from '@nestjs/swagger';

export class DiscoverDto {

  @ApiModelProperty({ type: Number, isArray: false })
  projectId: number;

  @ApiModelProperty({ type: String, isArray: false })
  projectName: string;

  @ApiModelProperty({ type: String, isArray: false })
  slug: string;

  @ApiModelProperty({ type: URL, isArray: false })
  thumbnailUrl?: string;

  @ApiModelProperty({ type: Number, isArray: false })
  initiativeId?: number;

  @ApiModelProperty({ type: String, isArray: false })
  initiativeName?: string;

  @ApiModelProperty({ type: String, isArray: false })
  organizationName: string;

  @ApiModelProperty({ type: Number, isArray: false })
  lng: number;

  @ApiModelProperty({ type: Number, isArray: false })
  lat: number;
}

export class DiscoverInitiativesDto {
  @ApiModelProperty({ type: Number, isArray: false })
  id: number;

  @ApiModelProperty({ type: String, isArray: false })
  name: string;
}

export class DiscoverGeoRegionsDto {
  @ApiModelProperty({ type: Number, isArray: false })
  id: number;

  @ApiModelProperty({ type: String, isArray: false })
  name: string;
}

export class DiscoverProjectsDto {
  @ApiModelProperty({ type: Number, isArray: false })
  id: number;

  @ApiModelProperty({ type: String, isArray: false })
  name: string;
}

export class DiscoverFiltersDto {
  @ApiModelProperty({ type: DiscoverProjectsDto, isArray: true })
  projects: object[];

  @ApiModelProperty({ type: DiscoverInitiativesDto, isArray: true })
  initiatives: object[];

  @ApiModelProperty({ type: String, isArray: true })
  countries: string[];

  @ApiModelProperty({ type: DiscoverGeoRegionsDto, isArray: true })
  geoRegions: object[];

  @ApiModelProperty({ type: Number, isArray: true })
  timespan: object;

  @ApiModelProperty({ type: Boolean, isArray: true })
  endangered: boolean[];
}
