import { Permissions } from 'decorators/permissions.decorator';
import { Get, Controller, Req, Post, Body, Patch, Param, Query, Delete, ParseIntPipe, UseGuards } from '@nestjs/common';
import { ApiUseTags, ApiBearerAuth, ApiOperation, ApiResponse, ApiImplicitQuery, ApiImplicitParam } from '@nestjs/swagger';
import { Pagination } from 'decorators/pagination.decorator';
import { ValidationPipe } from 'pipes/validation.pipe';
import { PermissionsGuard } from 'guards/permissions.guard';
import { User } from 'decorators/user.decorator';
import { AuthenticatedUserDto } from 'dto/authenticated-user.dto';
import { AnalyticsService } from './analytics.service';
import { AnalyticsDto } from './dto/analytics.dto';
import { ParseIntRequiredPipe } from 'pipes/parse-int-required.pipe';

const logger = require('logger');

@Controller('/api/v1')
@ApiUseTags('Analytics')
@ApiBearerAuth()
@UseGuards(PermissionsGuard)
export class AnalyticsController {
  constructor(private readonly analyticsService: AnalyticsService) { }

  @Get('/analytics')
  @ApiOperation({
    title: 'Get Analytics', description: `
    Get all analytics
  `, operationId: 'GetAllAnalytics',
  })
  @ApiResponse({ status: 200, description: 'Analytics have been successfully returned', isArray: false, type: AnalyticsDto })
  @ApiResponse({ status: 403, description: 'Not authorized.' })
  @ApiResponse({ status: 401, description: 'Not authenticated.' })
  async findAll(@User() authenticatedUser: AuthenticatedUserDto) {
    logger.info('Getting all');
    const data = await this.analyticsService.findAllByProject(null, null, null, { authenticatedUser });
  }

  @Get('/organization/:organizationId/analytics')
  @ApiOperation({
    title: 'Get Analytics', description: `
    Get all analytics by organization
  `, operationId: 'GetAllAnalyticsByOrganization',
  })
  @ApiImplicitParam({ name: 'organizationId', description: 'Organization the analytics belongs to', type: Number, required: true })
  @ApiResponse({ status: 200, description: 'Analytics have been successfully returned', isArray: false, type: AnalyticsDto })
  @ApiResponse({ status: 403, description: 'Not authorized.' })
  @ApiResponse({ status: 401, description: 'Not authenticated.' })
  async findAllByOrganization(@Param('organizationId', new ParseIntRequiredPipe(true)) organizationId, @User() authenticatedUser: AuthenticatedUserDto) {
    logger.info('Getting all');
    return  await this.analyticsService.findAllByProject(null, null, organizationId, { authenticatedUser });
  }

  @Get('/project/:projectId/analytics')
  @ApiOperation({
    title: 'Get Analytics', description: `
    Get all analytics by project
  `, operationId: 'GetAllAnalyticsByProject',
  })
  @ApiImplicitParam({ name: 'projectId', description: 'Project the deployment belongs to', type: Number, required: true })
  @ApiResponse({ status: 200, description: 'Analytics have been successfully returned', isArray: false, type: AnalyticsDto })
  @ApiResponse({ status: 403, description: 'Not authorized.' })
  @ApiResponse({ status: 401, description: 'Not authenticated.' })
  async findAllByProject(@Param('projectId', new ParseIntRequiredPipe(true)) projectId, @User() authenticatedUser: AuthenticatedUserDto) {
    logger.info('Getting all');
    return await this.analyticsService.findAllByProject(projectId, null, null, { authenticatedUser });
  }

  @Get('/project/discover')
  @ApiOperation({
    title: 'Get data for Discover section', description: `
    Get data for Discover section
  `, operationId: 'GetDiscoverData',
  })
  @ApiImplicitQuery({ name: 'endangeredSpecies', description: 'Whether to filter for endangered species', type: Boolean, required: false })
  @ApiImplicitQuery({ name: 'country', description: 'Country for filter', type: String, required: false })
  @ApiImplicitQuery({ name: 'year', description: 'Year for filter', type: Number, required: false })
  @ApiImplicitQuery({ name: 'initiativeId', description: 'Initiative for filter', type: Number, required: false })
  @ApiImplicitQuery({ name: 'xmin', description: 'Min value for the bounding box x coordinate', type: Number, required: false })
  @ApiImplicitQuery({ name: 'ymin', description: 'Min value for the bounding box y coordinate', type: Number, required: false })
  @ApiImplicitQuery({ name: 'xmax', description: 'Max value for the bounding box y coordinate', type: Number, required: false })
  @ApiImplicitQuery({ name: 'ymax', description: 'Max value for the bounding box y coordinate', type: Number, required: false })
  @ApiImplicitQuery({ name: 'projectNameSubstring', description: 'Full or partial name of project(s) to filter for', type: String, required: false })
  @ApiResponse({ status: 200, description: 'Discover data has been successfully returned', isArray: false, type: AnalyticsDto })
  @ApiResponse({ status: 403, description: 'Not authorized.' })
  @ApiResponse({ status: 401, description: 'Not authenticated.' })
  async getDiscoverData(@Query() filters) {
    logger.info('Getting discover data');
    return await this.analyticsService.getDiscoverData(filters);
  }
}
