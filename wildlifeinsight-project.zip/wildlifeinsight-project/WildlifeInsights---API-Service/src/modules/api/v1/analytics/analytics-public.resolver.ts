
import { Resolver, Query, Args } from '@nestjs/graphql';
import { AnalyticsService } from './analytics.service';

const logger = require('logger');

@Resolver('AnalyticsPublic')
export class AnalyticsPublicResolver {
  constructor(private readonly analyticsService: AnalyticsService) { }

  @Query()
  async getAnalyticsPublic(@Args() args) {
    logger.debug('Getting analytics');
    return await this.analyticsService.findAllByProject(args.projectId, null, null);
  }

  @Query()
  async getDiscoverData(@Args() args) {
    logger.debug(`getDiscoverData via GraphQL - args: ${JSON.stringify(args)}`);
    const result = await this.analyticsService.getDiscoverData(args.filters);
    return result;
  }

  @Query()
  async getDiscoverFilters() {
    return await this.analyticsService.getDiscoverFilters();
  }

  @Query()
  async getProjectHighlightedPhotos(@Args() args) {
    const result = await this.analyticsService.getHighlightedPhotos(args.projectId);
    return result;
  }
}
