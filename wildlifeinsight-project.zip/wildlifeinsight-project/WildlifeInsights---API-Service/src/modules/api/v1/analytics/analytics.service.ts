import { Repository,  Brackets } from 'typeorm';
import { Injectable, Inject, BadRequestException } from '@nestjs/common';
import { InfoDto } from 'dto/info.dto';
import { Projects, ProjectHighlightedPhotos } from 'modules/database/entities/projects.entity';
import { Deployments } from 'modules/database/entities/deployments.entity';
import { Initiatives } from 'modules/database/entities/initiatives.entity';
import { Organizations } from 'modules/database/entities/organizations.entity';
import { PermissionsUtils } from 'utils/permissions.utils';
import { AnalyticsDto } from './dto/analytics.dto';
import { DiscoverFiltersDto } from './dto/discover.dto';
import { PERMISSIONS } from 'utils/permissions.enum';
import { ProjectsDto } from 'modules/database/dto/projects.dto';
import { Devices } from 'modules/database/entities/devices.entity';
import { OrganizationsDto } from 'modules/database/dto/organizations.dto';
import { IdentifiedObjects } from 'modules/database/entities/identified-objects.entity';
import { DiscoverFilters } from 'modules/database/entities/discover-filters.entity';
import { DiscoverObservations } from 'modules/database/entities/discover-observations.entity';
import { GeoRegions } from 'modules/database/entities/geo-regions.entity';
import { DiscoverProjects } from 'modules/database/entities/discover-projects.entity';
import { ProjectsOperationalAnalytics } from 'modules/database/entities/projects-operational-analytics.entity';
import { DataCache } from 'modules/database/entities/data-cache.entity';
import { MD5 } from 'crypto-js';
import { ProjectService } from '../projects/project.service';
import { EntityType } from 'utils/entities.utils';

// Metadata for document returned by getDiscoverData()
// Remember to keep this in sync with docs/README_discover-feature.md
export const discoverResponseMetadata = {
  doctype: 'wi_discover',
  version: 2,
};

const logger = require('logger');
const config = require('config');

@Injectable()
export class AnalyticsService  {

  constructor(
    @Inject('ProjectsRepositoryToken') private readonly projectsRepository: Repository<Projects>,
    @Inject('ProjectHighlightedPhotosRepositoryToken') private readonly projectHighlightedPhotosRepository: Repository<ProjectHighlightedPhotos>,
    @Inject('DeploymentsRepositoryToken') private readonly deploymentsRepository: Repository<Deployments>,
    @Inject('DevicesRepositoryToken') private readonly devicesRepository: Repository<Devices>,
    @Inject('InitiativesRepositoryToken') private readonly initiativesRepository: Repository<Initiatives>,
    @Inject('IdentifiedObjectsRepositoryToken') private readonly identifiedObjectsRepository: Repository<IdentifiedObjects>,
    @Inject('OrganizationsRepositoryToken') private readonly organizationsRepository: Repository<Organizations>,
    @Inject('DiscoverFiltersToken') private readonly discoverFiltersRepository: Repository<DiscoverFilters>,
    @Inject('DiscoverObservationsToken') private readonly discoverObservationsRepository: Repository<DiscoverObservations>,
    @Inject('DiscoverProjectsToken') private readonly discoverProjectsRepository: Repository<DiscoverProjects>,
    @Inject('GeoRegionsRepositoryToken') private readonly geoRegionsRepository: Repository<GeoRegions>,
    @Inject('ProjectsOperationalAnalyticsRepositoryToken') private readonly projectsOperationalAnalyticsRepository: Repository<ProjectsOperationalAnalytics>,
    @Inject('DataCacheRepositoryToken') private readonly dataCacheRepository: Repository<DataCache>,
  ) {}

  /**
   * Count devices across given organizations
   */
  private async countDevices(organizations) {
    logger.debug('Count devices of organizations', organizations);
    if (!organizations || organizations.length === 0) {
      return 0;
    }
    const count = await this.devicesRepository.createQueryBuilder('d')
    .where('d.organizationId in (:...organizations)').setParameter('organizations', organizations).getCount();
    return count;
  }

  /**
   * Count deployments across given projects
   */
  private async countDeployments(projects) {
    logger.debug('Count deployments of project', projects);
    if (!projects || projects.length === 0) {
      return 0;
    }
    const count = await this.deploymentsRepository.createQueryBuilder('d')
    .where('d.projectId in (:...projects)').setParameter('projects', projects).getCount();
    return count;
  }

  /**
   * Count identifications across given projects
   */
  private async countIdentifications(projects) {
    logger.debug('Count identifications of project', projects);
    if (!projects || projects.length === 0) {
      return 0;
    }
    const count = await this.identifiedObjectsRepository.createQueryBuilder('idObj')
    .innerJoin('idObj.identification', 'idOut')
    .innerJoin('idOut.dataFile', 'dataFile')
    .innerJoin('dataFile.deployment', 'deployment')
    .where('deployment.projectId in (:...projects)').setParameter('projects', projects).getCount();
    return count;
  }

  /**
   * Count unique species across given projects
   */
  private async countSpecies(projects) {
    logger.debug('Count species of project', projects);
    if (!projects || projects.length === 0) {
      return 0;
    }
    const count = await this.identifiedObjectsRepository.createQueryBuilder('idObj')
      .select('COUNT(DISTINCT(taxonomies_uuid))', 'species')
      .innerJoin('idObj.identification', 'idOut')
      .innerJoin('idOut.dataFile', 'dataFile')
      .innerJoin('dataFile.deployment', 'deployment')
      .where('deployment.projectId in (:...projects)').setParameter('projects', projects).getRawOne();
    return count.species;
  }

  /**
   * To compute analytics given one or more of a projectId, initiativeId and
   * organizationId, we select:
   * * the project with the supplied projectId (if applicable)
   * * all the projects of the initiative with the supplied initiativeId (if
   *   applicable)
   * * all the projects of the organization with the supplied organizationId (if
   *   applicable)
   *
   * (and merge the singleton list of project with the list of projects of
   * the given initiative and of the given organization)
   *
   * * the parent organization(s) of the project with supplied projectId and of
   *   the initiative with supplied initiativeId
   *
   * Otherwise, if none of projectId, initiativeId and organizationId is
   * provided, we select *all* projects and *all* organizations
   */
  async allAnalyticsByProjectInitiativeOrOrganization(projectId: Number, initiativeId: Number, organizationId: Number) {
    const result = new AnalyticsDto();

    const project: Projects = await this.projectsRepository
      .createQueryBuilder('p')
      .where('id = :id')
      .setParameter('id', projectId)
      .getOne();

    let projectIds: Number[] | null;
    let initiativeProjectIds: Number[] | null;
    let organizationProjectIds: Number[] | null;
    let initiative: Initiatives | null;
    let organizationIds: Number[] | null;
    const allProjectIds: Number[] = [];

    if (projectId) {
      projectIds = [projectId];
    }

    if (initiativeId) {
      const initiativeProjects = await this.projectsRepository.createQueryBuilder('p')
        .where('p.initiativeId = :initiativeId').setParameter('initiativeId', initiativeId).getMany();
      logger.debug(`projects: ${initiativeProjects}`);
      initiativeProjectIds = initiativeProjects.map(p => p.id);
      initiative = await this.initiativesRepository
        .createQueryBuilder('i')
        .where('id = :initiativeId')
        .setParameter('initiativeId', initiativeId)
        .getOne();
    }

    if (organizationId) {
      const organizationProjects = await this.projectsRepository.createQueryBuilder('p')
        .where('p.organizationId = :organizationId').setParameter('organizationId', organizationId).getMany();
      organizationProjectIds = organizationProjects.map(p => p.id);
    }

    [projectIds, initiativeProjectIds, organizationProjectIds].forEach((entityProjectIds) => {
      if (Array.isArray(entityProjectIds)) {
        logger.debug(`entityProjectIds: ${entityProjectIds}`);
        entityProjectIds.forEach((id) => {
          allProjectIds.push(id);
        });
      }
    });

    logger.debug(`allProjectIds: ${allProjectIds}`);

    const organizations = await this.organizationsRepository.createQueryBuilder('o')
      .where('o.id IN (:...organizationIds)')
      .setParameter(
        'organizationIds',
        [project ? project.organizationId : null,
          initiative ? initiative.ownerOrganizationId : null,
          organizationId])
      .getMany();
    organizationIds = organizations.map(o => o.id);
    logger.debug(`organizationIds: ${JSON.stringify(organizationIds)}`);

    result.numDeployments = await this.countDeployments(allProjectIds);
    result.numDevices = await this.countDevices(organizationIds);
    result.numIdentifications = await this.countIdentifications(allProjectIds);
    result.numSpecies = await this.countSpecies(allProjectIds);

    return result;
  }

  /**
   * Compute metrics for a given project or set of projects within a given
   * initiative or organization, or for all projects across the WI platform.
   *
   * Metrics are calculated across the projects the user has read access to.
   */
  async findAllByProject(projectId: number | null, initiativeId: number | null, organizationId: number | null, info?: InfoDto): Promise<AnalyticsDto> {
    // Poor man's dependent typing to reject calls where more than one of the
    // <entityType>Id parameters are not-null
    const countNulls = (i : number) => i == null ? 0 : 1;
    if ((countNulls(projectId) + countNulls(initiativeId) + countNulls(organizationId)) > 1) {
      throw new BadRequestException('Function can only take at most one of projectId, initiativeId or organizationId parameters.');
    }

    const result = new AnalyticsDto();

    let entityType : EntityType;
    let entityId : number;
    let projectIds : number[] = [];

    if (projectId) {
      entityType = 'project';
      entityId = projectId;
    } else if (initiativeId) {
      entityType = 'initiative';
      entityId = initiativeId;
    } else if (organizationId) {
      entityType = 'organization';
      entityId = organizationId;
    }

    if (info && info.authenticatedUser) {
      // get list of projects visible to the user within the given entity
      projectIds = await ProjectService.getProjectsAccessibleToUserWithinEntity(info.authenticatedUser, entityType, entityId);
    } else if (projectId) {
      projectIds.push(projectId);
    }

    /**
     * `projectCount` is always the number of projects the user has access to,
     * of those requested.
     *
     * `initiativeCount` is always 1 if analytics have been requested for an
     * initiative, otherwise we calculate this further down.
     *
     * Likewise for `organizationCount`.
     */
    const entityCounts = {
      projectCount: projectIds.length,
      initiativeCount: initiativeId ? 1 : null,
      organizationCount: organizationId ? 1 : null,
    };

    if (organizationId) {
      entityCounts.organizationCount = 1;
      entityCounts.initiativeCount = await this.initiativesRepository.createQueryBuilder('i')
        .where('i.ownerOrganizationId = :organizationId', { organizationId }).getCount();
      entityCounts.projectCount = projectIds.length;
    }

    /**
     * If calculating operational statistics for the whole platform, `projects`
     * is a list of all the project a user has access to, and therefore we
     * select the count of distinct `initiative_id` and `organizations_id` from
     * the list of projects, to compute how many initiatives and organizations
     * these projects are members of.
     */
    if (!(projectId || initiativeId || organizationId)) {
      entityCounts.initiativeCount = await this.projectsRepository.createQueryBuilder('p')
        .select('COUNT(DISTINCT(initiative_id))', 'count').getRawOne().then(result => result.count);
      entityCounts.organizationCount = await this.projectsRepository.createQueryBuilder('p')
        .select('COUNT(DISTINCT(organizations_id))', 'count').getRawOne().then(result => result.count);
    }

    if (projectIds.length > 0) {
      const data = await this.projectsOperationalAnalyticsRepository.createQueryBuilder('poa')
      .where('poa.projectId in (:...projects)').setParameter('projects', projectIds).getMany();

      data.forEach((poa) => {
        Object.keys(poa).forEach((key) => {
          if (Number.isInteger(parseInt(poa[key], 10))) {
            if (!result[key]) { result[key] = 0; }
            const value = parseInt(poa[key], 10);
            if (value) { result[key] = result[key] + value; }
          }
        });
      });

      result.imagesPerSpecies = this.computeImagesPerGroup('imagesPerSpecies', 'taxonomies_uuid', data);
      // Actually calculate total number of wildlife images from the sum of counts of images of each species
      /*
      result.wildlifeImagesCount =
        Array.isArray(result.imagesPerSpecies) &&
        result.imagesPerSpecies
          .reduce((prev, current) => { return prev + current['image_count']; }, 0);
      */
      result.numSpecies = Array.isArray(result.imagesPerSpecies) ?
        result.imagesPerSpecies.length : 0;

      result.imagesPerLocation = this.computeImagesPerGroup('imagesPerLocation', 'locations_id', data);

      /**
       * Compute list of unique countries
       * data.map() generates an array whose members are the list of countries of each project
       * The [].concat.apply() thingy flattens the array
       * Putting this into a Set removes duplicates
       * And finally the ... spread operator turns the Set back into an array
       * We then get the length of the array to get the number of unique items (countries, in this case)
       */
      result.numCountries = [...new Set([].concat.apply([], data.map(poa => poa.countries)))].length;
    }

    // add entityCounts to result
    Object.keys(entityCounts).forEach((key) => {
      result[key] = entityCounts[key];
    });

    return result;
  }

  /**
   * Calculate sum for each item for the projects list
   */
  computeImagesPerGroup(fieldName: 'imagesPerSpecies' | 'imagesPerLocation', idField: 'taxonomies_uuid' | 'locations_id', data: any): any {
    let list = [];
    data.forEach((item) => { if (item[fieldName]) { list = [...list, ...item[fieldName]]; } });
    return list.reduce((prev, current) => {
      const updated = [...prev];
      const index = updated.findIndex(item => item[idField] === current[idField]);
      if (index !== -1) {
        updated[index].image_count += parseInt(current.image_count, 10);
      } else {
        updated.push(current);
      }
      return updated;
    },                 [])
    // sort by number of images, descending
    .sort((a, b) => b.image_count - a.image_count);
  }

  /**
   * Compute list of possible values for each of the public Discover interface
   * filters.
   *
   * Note that the lists of values only depend on the source data and *do not*
   * react to a user's current selections of filters.
   *
   * For example, if new images are uploaded to the WI platform and these carry
   * a later date than any other image, the `timespan` filter will list the
   * latest date of any of the photos as latest available date for the filter
   * itself.
   */
  async getDiscoverFilters(): Promise<DiscoverFiltersDto> {
    const result : DiscoverFilters = await this.discoverFiltersRepository.createQueryBuilder('d').getOne();

    // Initiatives id + name are returned by the underlying view as a single
    // string such as "12345 Name of the initiative"
    // Here we split this into separate variables for id and name, and push
    // an array if unpacked initiative data as the `initiatives` member of the
    // result object.
    const initiatives = result.initiatives && result.initiatives.length > 0 ?
      result.initiatives[0]
        .filter(initiative => initiative)
        .map((initiative) => {
          const [, id, name] = /^(\d+)\s(.*)$/g.exec(initiative);
          return { id, name };
        }) :
        [];

    // As above for projects
    const projects =  result.projects && result.projects.length > 0 ?
    result.projects[0]
      .filter(project => project)
      .map((project) => {
        const [, id, name] = /^(\d+)\s(.*)$/g.exec(project);
        return { id, name };
      }) :
      [];

    // As above for geo_regions
    const geoRegions = result.geoRegions && result.geoRegions.length > 0 ?
      result.geoRegions[0]
        .filter(initiative => initiative)
        .map((initiative) => {
          const [, id, name] = /^(\d+)\s(.*)$/g.exec(initiative);
          return { id, name };
        }) :
        [];

    return {
      projects,
      initiatives,
      geoRegions,
      countries: result.countries.filter(country => country),
      timespan: { start: result.timespan[0], end: result.timespan[1] },
      endangered: result.endangered.filter(status => status !== null),
    };
  }

  /**
   * Compute data for discover interface
   */

  async getDiscoverData(filters: DiscoverFilters): Promise<object> {
    const key: string = MD5(JSON.stringify(filters)).toString();
    const dataCacheExpirationInHours = config.get('dataCacheExpirationInHours');
    const cachedData = await this.getCachedData(key);

    if (cachedData) {
      const recordTimestamp = new Date(cachedData.lastChanged);
      const current = new Date();
      const diff = (current.getTime() - recordTimestamp.getTime()) / 3600000;
      if (dataCacheExpirationInHours > diff) { return cachedData.data; }
    }

    const data = await this.computeDiscoverData(filters);
    await this.updateOrAddDiscoverFiltersToCache(key, data);
    return data;
  }

  async getCachedData(key: string): Promise<DataCache> {
    return await this.dataCacheRepository.findOne({ where: { key } });
  }

  async updateOrAddDiscoverFiltersToCache(key: string, data: any): Promise<any> {
    const count = await this.dataCacheRepository.count({ key });
    return (count === 0) ?
      await this.dataCacheRepository.insert({
        key,
        data,
        lastChanged: new Date(),
      }) :
      await this.dataCacheRepository.update({ key }, { data });
  }

  async computeDiscoverData(filters): Promise<object> {
    const queries = {
      organizationsCount: this.discoverObservationsRepository.createQueryBuilder('d'),
      initiativesCount: this.discoverObservationsRepository.createQueryBuilder('d'),
      participantsCount: this.discoverObservationsRepository.createQueryBuilder('d'),
      countriesCount: this.discoverObservationsRepository.createQueryBuilder('d'),
      speciesCount: this.discoverObservationsRepository.createQueryBuilder('d'),
      wildlifeImagesCount: this.discoverObservationsRepository.createQueryBuilder('d'),
      humanImagesCount: this.discoverObservationsRepository.createQueryBuilder('d'),
      dataFilesCount: this.discoverObservationsRepository.createQueryBuilder('d'),
      devicesCount: this.discoverObservationsRepository.createQueryBuilder('d'),
      deploymentsCount: this.discoverObservationsRepository.createQueryBuilder('d'),
      locationsCount: this.discoverObservationsRepository.createQueryBuilder('d'),
      observations: this.discoverObservationsRepository.createQueryBuilder('d')
        .addSelect('id'),
      identifications: this.discoverObservationsRepository.createQueryBuilder('d')
        .addSelect('id'),
    };

    logger.debug(filters);

    if (filters && filters.projects) {
      logger.debug(`Adding filter: projects = ${filters.projects}`);
      Object.entries(queries).forEach((query) => {
        query[1].andWhere('d.project_id IN (:...projects)').setParameter('projects', filters.projects);
      });
    }

    if (filters && filters.projectNameSubstring) {
      logger.debug(`Adding filter: projectNameSubstring = ${filters.projectNameSubstring}`);
      Object.entries(queries).forEach((query) => {
        query[1].andWhere('d.projectName ILIKE :projectName').setParameter('projectName', `%${filters.projectNameSubstring.toLowerCase()}%`);
      });
    }

    if (filters && filters.endangeredSpecies) {
      logger.debug(`Adding filter: endangeredSpecies = ${filters.endangeredSpecies}`);
      Object.entries(queries).forEach((query) => {
        query[1].andWhere('d.endangeredSpecies = :endangeredSpecies').setParameter('endangeredSpecies', filters.endangeredSpecies);
      });
    }

    if (filters && filters.taxonomies) {
      logger.debug(`Adding filter: taxonomies = ${filters.taxonomies}`);
      Object.entries(queries).forEach((query) => {
        query[1].andWhere('d.taxonomyId IN (:...taxonomies)').setParameter('taxonomies', filters.taxonomies);
      });
    }

    if (filters && filters.countries) {
      logger.debug(`Adding filter: countries = ${filters.countries}`);
      Object.entries(queries).forEach((query) => {
        query[1].andWhere('d.country IN (:...countries)').setParameter('countries', filters.countries);
      });
    }

    if (filters && filters.timespan) {
      logger.debug(`Adding filter: timespan = ${JSON.stringify(filters.timespan)}`);
      Object.entries(queries).forEach((query) => {
        query[1].andWhere(new Brackets(
          (qb) => {
            qb
              .where('d.date >= :start', { start: filters.timespan.start })
              .andWhere('d.date <= :end', { end: filters.timespan.end });
          }));
      });
    }

    if (filters && filters.initiatives) {
      logger.debug(`Adding filter: initiatives = ${filters.initiatives}`);
      Object.entries(queries).forEach((query) => {
        query[1].andWhere('d.initiativeId IN (:...initiatives)').setParameter('initiatives', filters.initiatives);
      });
    }

    if (filters && filters.geoRegions) {
      logger.debug(`Adding filter: geoRegions ${JSON.stringify(filters.geoRegions)}`);

      const geoRegions: GeoRegions[] = await this.geoRegionsRepository.findByIds(filters.geoRegions);

      Object.entries(queries).forEach((query) => {
        query[1].andWhere(new Brackets(
          (qb) => {
            qb.where('ST_Contains((SELECT region::geometry FROM geo_regions WHERE id = :geoRegionId ), ST_Transform(ST_SetSRID(d.project_location, 4326), 4326))', { geoRegionId: geoRegions[0].id });
            geoRegions.slice(1).forEach((geoRegion) => {
              qb.orWhere('ST_Contains((SELECT region::geometry FROM geo_regions WHERE id = :geoRegionId ), ST_Transform(ST_SetSRID(d.project_location, 4326), 4326))', { geoRegionId: geoRegion.id });
            });
          },
        ));
      });
    }

    if (filters && ((filters.xmin && filters.ymin && filters.xmax && filters.ymax) || filters.boundingBox)) {
      // If this function is being invoked via the GraphQL resolver, which
      // accepts a 'BoundingBox' data structure for the coordinates of the
      // bounding box, unpack the coordinates into xmin/ymin/xmax/ymax
      if (filters.boundingBox) {
        filters.xmin = filters.boundingBox.sw.lng;
        filters.ymin = filters.boundingBox.sw.lat;
        filters.xmax = filters.boundingBox.ne.lng;
        filters.ymax = filters.boundingBox.ne.lat;
      }

      logger.debug(`Adding filter: bounding box [[${filters.ymin}, ${filters.xmin}], [${filters.ymax}, ${filters.xmax}]]`);

      // Construct bounding box from requested coordinates using 4326 SRID (WGS84)
      // and check for projects which fall within it.
      Object.entries(queries).forEach((query) => {
        query[1].andWhere('ST_Contains(ST_MakeEnvelope(:xmin, :ymin, :xmax, :ymax), d.project_location)')
          .setParameter('xmin', filters.xmin)
          .setParameter('ymin', filters.ymin)
          .setParameter('xmax', filters.xmax)
          .setParameter('ymax', filters.ymax);
      });
    }

    const observationsByProject = await queries.observations.andWhere('d.status <> \'blank\'').select('distinct(project_id), count(id)').groupBy('project_id').getRawMany();
    const observationCount = observationsByProject.length ?
      observationsByProject.map(item => item.count).reduce((a, b) => { return parseInt(a, 10) + parseInt(b, 10); }, 0) :
      0;
    const identificationsByProject = await queries.identifications.andWhere('d.status <> \'blank\' and d.verified is true').select('distinct(project_id), count(id)').groupBy('project_id').getRawMany();
    const identificationsCount = identificationsByProject.length ?
      identificationsByProject.map(item => item.count).reduce((a, b) => { return parseInt(a, 10) + parseInt(b, 10); }, 0) :
      0;
    const projects : number[] = observationsByProject.map(item => item.project_id);

    const projectCount : number = projects.length;

    const projectList : DiscoverProjects[] = projectCount ?
      await this.discoverProjectsRepository.createQueryBuilder('d').where('d.projectId IN (:...projects)', { projects }).getMany() :
      [];

    // To compute total sampling days, sum project sampling days if we have
    // more than one project given all the filters applied; otherwise set count
    // to zero
    let samplingDaysRaw;
    if (projects.length) {
      samplingDaysRaw = await this.discoverProjectsRepository
        .createQueryBuilder('d')
        .select('sum(d.samplingDays)')
        .where('d.projectId IN (:...projects)', { projects }).getRawOne();
    } else {
      samplingDaysRaw = { count: 0 };
    }
    const samplingDaysCount = samplingDaysRaw.count;

    const organizationsCount : number = await queries.organizationsCount.select('COUNT(DISTINCT organization_id)').getRawOne().then(res => res.count);
    const initiativesCount : number = await queries.initiativesCount.select('COUNT(DISTINCT initiative_id)').getRawOne().then(res => res.count);

    const wildlifeImagesCount : number = await queries.wildlifeImagesCount.andWhere('d.isWildlife IS TRUE').select('COUNT(*)').getRawOne().then(res => res.count);
    const humanImagesCount : number = await queries.humanImagesCount.andWhere('d.isHuman IS TRUE').select('COUNT(*)').getRawOne().then(res => res.count);
    const countriesCount : number = await queries.countriesCount.select('COUNT(DISTINCT country)').getRawOne().then(res => res.count);
    const participantsCount : number =  await queries.participantsCount.select('COUNT(DISTINCT participant_id)').getRawOne().then(res => res.count);
    const speciesCount : number =  await queries.speciesCount.select('COUNT(DISTINCT taxonomy_uuid)').getRawOne().then(res => res.count);
    const locationsCount : number = await queries.locationsCount.select('COUNT(DISTINCT location_id)').getRawOne().then(res => res.count);
    const devicesCount : number = await queries.devicesCount.select('COUNT(DISTINCT device_id)').getRawOne().then(res => res.count);
    const dataFilesCount : number = await queries.dataFilesCount.select('COUNT(DISTINCT id)').getRawOne().then(res => res.count);
    const deploymentsCount : number = await queries.deploymentsCount.select('COUNT(DISTINCT deployment_id)').getRawOne().then(res => res.count);

    const extent = projectCount ?
      await this.discoverProjectsRepository.createQueryBuilder('d')
        .select(
          `ST_XMin(ST_Extent(d.project_location)) AS xmin,
          ST_YMin(ST_Extent(d.project_location)) AS ymin,
          ST_XMax(ST_Extent(d.project_location)) AS xmax,
          ST_YMax(ST_Extent(d.project_location)) AS ymax`)
        .where('d.projectId IN (:...projects)', { projects })
        .getRawOne() :
      { xmin: null, ymin: null, xmax: null, ymax: null };

    /**
     * Add some padding and arbitrary decimal precision to the extent.
     * This helps specifically when the resultset contains one project only
     * (in which case xmin==xmax and ymin==xmax).
     */
    extent.xmin = extent.xmin ? (Number.parseFloat(extent.xmin) - 0.05).toFixed(5) : null;
    extent.ymin = extent.ymin ? (Number.parseFloat(extent.ymin) - 0.05).toFixed(5) : null;
    extent.xmax = extent.xmax ? (Number.parseFloat(extent.xmax) + 0.05).toFixed(5) : null;
    extent.ymax = extent.ymax ? (Number.parseFloat(extent.ymax) + 0.05).toFixed(5) : null;

    return {
      metadata: discoverResponseMetadata,
      data: {
        counts: {
          observations: observationCount,
          identifications: identificationsCount,
          organizations: organizationsCount,
          initiatives: initiativesCount,
          projects: projectCount,
          participants: participantsCount,
          species: speciesCount,
          locations: locationsCount,
          devices: devicesCount,
          dataFiles: dataFilesCount,
          deployments: deploymentsCount,
          humanImages: humanImagesCount,
          wildlifeImages: wildlifeImagesCount,
          countries: countriesCount,
          samplingDays: samplingDaysCount,
        },
        extent: {
          sw: {
            lng: extent.xmin,
            lat: extent.ymin,
          },
          ne: {
            lng: extent.xmax,
            lat: extent.ymax,
          },
        },
        projects: projectList.map((i) => {
          return {
            id: i.projectId,
            name: i.projectName,
            slug: i.slug,
            country: i.country,
            photo: i.thumbnailUrl,
            organization: i.organizationName,
            location: { lat: i.lat, lng: i.lng },
          };
        }),
      },
    };
  }

  /**
   * Get thumbnail URLs of highlighted photos for a given project
   */
  async getHighlightedPhotos(projectId: number) {
    const highlightedPhotos = await this
      .projectHighlightedPhotosRepository
      .createQueryBuilder('d')
      .where('d.project_id = :project_id').setParameter('project_id', projectId)
      .getRawMany();
    return {
      highlightedPhotos: highlightedPhotos.map((i) => {
        return {
          thumbnailUrl: i.d_thumbnail_url,
        };
      }),
    };
  }
}
