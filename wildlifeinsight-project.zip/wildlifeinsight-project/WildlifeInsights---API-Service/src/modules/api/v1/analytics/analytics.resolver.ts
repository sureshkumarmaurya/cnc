import { AnalyticsService } from './analytics.service';
import { Resolver, Query, ResolveProperty, Mutation, Args, Parent } from '@nestjs/graphql';
import { UseInterceptors, UseGuards, ParseIntPipe } from '@nestjs/common';
import { GraphqlUserWithPermissions } from 'decorators/graphql-user.decorator';
import { GraphqlAuthGuard } from 'guards/graphql-passport.guard';
import { User } from 'decorators/user.decorator';

const logger = require('logger');

@Resolver('Analytics')
export class AnalyticsResolver {
  constructor(private readonly analyticsService: AnalyticsService) {}

  @Query()
  @UseGuards(GraphqlAuthGuard)
  async getAnalytics(@GraphqlUserWithPermissions() authenticatedUser, @Args() args) {
    logger.debug('Getting analytics');

    /**
     * Technical debt: as we have no easy way to express via GraphQL inputs that
     * this query should be called either with *one only of* organizationId,
     * initiativeId or projectId (to request data, respectively, for all the
     * projects of an organization, for all the projects of an initiative, or
     * for a single project) *or* with *none* of these three parameters, here we
     * enforce via a quick hack, that:
     * * if projectId is provided, both organizationId and initiativeId are
     *   ignored
     * * if initiativeId is provided (and projectId is *not provided*, which
     *   would trigger the previous rule), organizationId is ignored
     */
    if (args.projectId) {
      args.initiativeId = null;
      args.organizationId = null;
    } else if (args.initiativeId) {
      args.organizationId = null;
    }

    return await this.analyticsService.findAllByProject(args.projectId, args.initiativeId, args.organizationId, { authenticatedUser });
  }
}
