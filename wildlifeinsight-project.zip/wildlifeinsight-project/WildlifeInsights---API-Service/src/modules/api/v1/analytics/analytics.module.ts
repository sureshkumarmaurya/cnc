import { AnalyticsController } from './analytics.controller';
import { AnalyticsService } from './analytics.service';
import { Module, RequestMethod, MiddlewareConsumer } from '@nestjs/common';
import { AnalyticsResolver } from './analytics.resolver';
import { DatabaseModule } from 'modules/database/database.module';

@Module({
  imports: [DatabaseModule],
  controllers: [AnalyticsController],
  providers: [AnalyticsService, AnalyticsResolver],
})
export class AnalyticsModule {
  public configure(consumer: MiddlewareConsumer) {}
}
