import { TaxonomyController } from './taxonomy.controller';
import { TaxonomyService } from './taxonomy.service';
import { Module } from '@nestjs/common';
import { TaxonomyPublicResolver } from './taxonomy-public.resolver';
import { DatabaseModule } from 'modules/database/database.module';

@Module({
  imports: [DatabaseModule],
  controllers: [TaxonomyController],
  providers: [TaxonomyService, TaxonomyPublicResolver],
})
export class TaxonomyPublicModule {}
