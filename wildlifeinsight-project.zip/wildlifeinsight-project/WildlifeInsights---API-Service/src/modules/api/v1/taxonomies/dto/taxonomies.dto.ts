import { ApiModelProperty } from '@nestjs/swagger';
import { TaxonomiesDto } from 'modules/database/dto/taxonomies.dto';
import { MetaDto } from 'modules/database/dto/meta.dto';

export class TaxonomiesPaginatedDto {

  @ApiModelProperty({ type: TaxonomiesDto, isArray: true })
  readonly data: TaxonomiesDto[];

  @ApiModelProperty()
  readonly meta: MetaDto;

  constructor(data, totalItems: number, pageSize: number, page: number) {
    this.data = data;
    this.meta = new MetaDto(Math.ceil(totalItems / pageSize), totalItems, pageSize, page);
  }
}
