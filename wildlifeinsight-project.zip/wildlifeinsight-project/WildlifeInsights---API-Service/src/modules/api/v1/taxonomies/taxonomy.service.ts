import { Taxonomies } from 'modules/database/entities/taxonomies.entity';
import { Repository, SelectQueryBuilder, In } from 'typeorm';
import { Injectable, Inject } from '@nestjs/common';
import { GenericService } from 'utils/generic.service';
import { InfoDto } from 'dto/info.dto';
import { IucnRedListCategories } from 'modules/database/entities/iucn-red-list-categories.entity';
import { CommonNames } from 'modules/database/entities/common-names.entity';
import { Projects } from 'modules/database/entities/projects.entity';
import { ProjectsOperationalAnalytics } from 'modules/database/entities/projects-operational-analytics.entity';
import { EntityType } from 'utils/entities.utils';
import { ProjectService } from '../projects/project.service';
import { PaginationModel } from 'utils/pagination.model';

const logger = require('logger');

@Injectable()
export class TaxonomyService extends GenericService<Taxonomies, any, any>  {

  constructor(
    @Inject('TaxonomiesRepositoryToken') private readonly taxonomiesRepository: Repository<Taxonomies>,
    @Inject('IucnRedListCategoriesRepositoryToken') private readonly iucnRedListCategoriesRepository: Repository<IucnRedListCategories>,
    @Inject('CommonNamesRepositoryToken') private readonly commonNamesRepository: Repository<CommonNames>,
    @Inject('ProjectsRepositoryToken') private readonly projectsRepository: Repository<Projects>,
    @Inject('ProjectsOperationalAnalyticsRepositoryToken') private readonly projectsOperationalAnalyticsRepository: Repository<ProjectsOperationalAnalytics>,
  ) {
    super(taxonomiesRepository, 'taxonomy');
  }

  setFilters(query: SelectQueryBuilder<Taxonomies>, filters: any, info: InfoDto) {
    const { search: filterSearch, taxonLevel, searchNamesBy, lang, taxonomyUUIDs } = filters;
    /**
     * API clients can explicitly request via query parameters (for both REST
     * and GraphQL) whether to search by common name, by scientific name, or
     * both.
     *
     * This is done via a single parameter (`searchNamesBy`) with possible
     * values `['scientificName', 'commonName', 'scientificAndCommonName']`,
     * defaulting to the user's value of the `participants.use_common_names` db
     * field (and if this is not set, or if the query is from a
     * non-authenticated REST endpoint and therefore there is no
     * `authenticatedUser` data available, to `scientificAndCommonName`), *if*
     * the parameter is not explicitly provided in the query.
     *
     * See https://www.pivotaltracker.com/story/show/168379548 for context.
     */
    const useCommonNames: boolean = (info.authenticatedUser && info.authenticatedUser.user && info.authenticatedUser.user.useCommonNames);
    const commonNameField = (!lang || lang === 'EN') ? 'commonNameEnglish' : 'commonName';

    /**
     * Allow to search taxonomies by common name in a specific language based on
     * the `lang` parameter; the parameter is not required, defaulting to
     * English if not provided in the query.
     *
     * Possible values for this parameter: `['EN', 'ES', 'FR']`.
     *
     * Common names in languages other than English are stored in the
     * `common_names` DB table, `commonName` column.
     *
     * The `commonNameField` variable is set depending on the `lang` parameter,
     * and can be: `['commonNameEnglish','commonName']`
     */

    let searchFields: string[] = (!searchNamesBy && useCommonNames)
      ? [commonNameField]
      : ['scientificName', commonNameField]; // default value

    if (searchNamesBy === 'scientificName') { searchFields = [searchNamesBy]; }
    else if (searchNamesBy === 'commonName') { searchFields = [commonNameField]; }

    if (taxonLevel) {
      query.where('taxonomy.taxonLevel = :taxonLevel', { taxonLevel });
    }

    if (taxonLevel && filterSearch) {
      const search = `%${filterSearch.toLowerCase()}%`;

      query
        .andWhere(`lower(taxonomy.${taxonLevel}) like :search`, { search });
    } else if (filterSearch) {
      const search = `%${filterSearch.toLowerCase()}%`;

      query
        .orWhere('lower(taxonomy.family) like :search')
        .orWhere('lower(taxonomy.genus) like :search')
        .orWhere('lower(taxonomy.species) like :search');

      searchFields.forEach((field) => {
        if (field === 'commonName' && lang) {
          query
            .innerJoin('taxonomy.commonNames', 'commonNames')
            .where('lower(commonNames.commonName) like :search')
            .andWhere('commonNames.language = :language')
            .setParameter('search', search)
            .setParameter('language', lang);
        } else { query.orWhere(`lower(taxonomy.${field}) like :search`); }
      });

      query.setParameter('search', search);
    }

    if (taxonomyUUIDs && taxonomyUUIDs.length > 0) {
      query.andWhere('taxonomy.uniqueIdentifier IN (:...taxonomyUUIDs)')
      .setParameter('taxonomyUUIDs', taxonomyUUIDs);
    }

    return query;
  }

  async getIucnCategoryById(id: number): Promise<IucnRedListCategories> {
    return this.iucnRedListCategoriesRepository.findOne(id);
  }

  async getCommonNamesByTaxonomyId(id: string): Promise<CommonNames[]> {
    return this.commonNamesRepository.find({ where: { taxonomyId: id } });
  }

  async setDataCreate(create: any, info: InfoDto) {
    return null;
  }

  async setDataUpdate(model: Taxonomies, update: any, info: InfoDto) {
    return model;
  }

  async getTaxonomyByUUID(uuid: string) {
    return await this.taxonomiesRepository.findOne({ uniqueIdentifier: uuid });
  }

  /**
   * Return projects ids related to entity requested
   * @param entityType `project` | `organization` | `initiative`
   * @param entityId
   */
  async getEntityRelatedProjects(entityType: EntityType, entityId: number): Promise<any[]> {
    let projectIds = [];
    if (entityType === 'project') {
      projectIds = [entityId];
    } else if (entityType === 'initiative') {
      const projects = await this.projectsRepository.find({ initiativeId: entityId });
      projectIds = projects.map(item => item.id);
    } else if (entityType === 'organization') {
      const projects = await this.projectsRepository.find({ organizationId: entityId });
      projectIds = projects.map(item => item.id);
    }
    return projectIds;
  }

  /**
   * Find taxonomies related to projects by operational analytics (images_per_species field)
   * @param projectIds
   */
  async getProjectsTaxonomiesUUIDs(projectIds: number[]): Promise<any[]> {
    const taxonomiesUUIDs = [];
    const analytics = await this.projectsOperationalAnalyticsRepository.find({ where: { projectId: In(projectIds) } });
    analytics.forEach((item) => {
      if (item.imagesPerSpecies) {
        Object.keys(item.imagesPerSpecies).forEach((key) => {
          if (item.imagesPerSpecies[key].taxonomies_uuid && !taxonomiesUUIDs.includes(item.imagesPerSpecies[key].taxonomies_uuid)) {
            taxonomiesUUIDs.push(item.imagesPerSpecies[key].taxonomies_uuid);
          }
        });
      }
    });
    return taxonomiesUUIDs;
  }

  async getTaxonomiesForEntity(entityType: EntityType, entityId: number, pagination: PaginationModel, info?: InfoDto, filters: any = {}) {
    try {
      const projectIds = await ProjectService.getProjectsAccessibleToUserWithinEntity(info.authenticatedUser, entityType, entityId);
      if (!projectIds || projectIds.length === 0) { return []; }

      const projectsTaxonomiesUUIDs = await this.getProjectsTaxonomiesUUIDs(projectIds);
      if (!projectsTaxonomiesUUIDs || projectsTaxonomiesUUIDs.length === 0) { return []; }

      filters.taxonomyUUIDs = projectsTaxonomiesUUIDs;
      return await this.findAll(pagination, info, filters);
    } catch (err) {
      logger.error('Get taxonomies for entity error: ', err);
    }
  }

}
