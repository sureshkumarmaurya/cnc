import { TaxonomyController, taxonomiesRelations } from './taxonomy.controller';
import { TaxonomyService } from './taxonomy.service';
import { Module, RequestMethod, MiddlewareConsumer } from '@nestjs/common';
import { PaginationMiddleware } from 'middlewares/pagination.middleware';
import { TaxonomyResolver } from './taxonomy.resolver';
import { DatabaseModule } from 'modules/database/database.module';

@Module({
  imports: [DatabaseModule],
  controllers: [TaxonomyController],
  providers: [TaxonomyService, TaxonomyResolver],
})
export class TaxonomyModule {
  public configure(consumer: MiddlewareConsumer) {
    consumer
      .apply(PaginationMiddleware)
      .with({ includes: [], allowIncludes: taxonomiesRelations })
      .forRoutes(
        { path: '/api/v1/taxonomy', method: RequestMethod.GET },
        { path: '/api/v1/taxonomy/:taxonomyId', method: RequestMethod.GET },
      );
  }
}
