import { TaxonomyService } from './taxonomy.service';
import { Resolver, Query, ResolveProperty, Args, Parent } from '@nestjs/graphql';
import { ValidationError } from 'apollo-server-express';
import { UseInterceptors } from '@nestjs/common';
import { PaginationGraphqlInterceptor } from 'interceptors/pagination-graphql.interceptor';
import { Taxonomies } from 'modules/database/entities/taxonomies.entity';
import { TaxonomiesPaginatedDto } from './dto/taxonomies.dto';

@Resolver('TaxonomyPublic')
export class TaxonomyPublicResolver {
  constructor(private readonly taxonomyService: TaxonomyService) {}

  @Query()
  @UseInterceptors(PaginationGraphqlInterceptor)
  async getTaxonomiesPublic(@Args() args) {
    const data = await this.taxonomyService.findAll(args.pagination, { params: args }, args.filters);
    return new TaxonomiesPaginatedDto(data[0], data[1], args.pagination.pageSize, args.pagination.pageNumber);
  }

  @Query()
  async getTaxonomyPublic(@Args() args) {
    const { id, uuid } = args;
    if (!id && !uuid) { throw new ValidationError('Invalid request error. At least one field [id, uuid] must be specified'); }

    const result = (uuid) ?
      await this.taxonomyService.getTaxonomyByUUID(uuid) :
      await this.taxonomyService.getById(id, {}, { params: args });

    return result;
  }

  @ResolveProperty()
  async iucnCategory(@Parent() taxonomy: Taxonomies) {
    if (!taxonomy.iucnCategoryId) {
      return null;
    }
    return this.taxonomyService.getIucnCategoryById(taxonomy.iucnCategoryId);
  }

  @ResolveProperty()
  async commonNames(@Parent() taxonomy: Taxonomies) {
    return this.taxonomyService.getCommonNamesByTaxonomyId(taxonomy.uniqueIdentifier);
  }

}
