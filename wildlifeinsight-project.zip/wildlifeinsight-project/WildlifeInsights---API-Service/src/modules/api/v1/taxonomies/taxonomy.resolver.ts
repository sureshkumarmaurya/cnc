import { TaxonomyService } from './taxonomy.service';
import { Resolver, Query, ResolveProperty, Args, Parent } from '@nestjs/graphql';
import { ValidationError } from 'apollo-server-express';
import { UseInterceptors, UseGuards } from '@nestjs/common';
import { GraphqlAuthGuard } from 'guards/graphql-passport.guard';
import { GraphqlUserWithPermissions } from 'decorators/graphql-user.decorator';
import { PaginationGraphqlInterceptor } from 'interceptors/pagination-graphql.interceptor';
import { Taxonomies } from 'modules/database/entities/taxonomies.entity';
import { User } from 'decorators/user.decorator';
import { TaxonomiesPaginatedDto } from './dto/taxonomies.dto';

@Resolver('Taxonomy')
export class TaxonomyResolver {
  constructor(private readonly taxonomyService: TaxonomyService) {}

  @Query()
  @UseGuards(GraphqlAuthGuard)
  @UseInterceptors(PaginationGraphqlInterceptor)
  async getTaxonomies(@GraphqlUserWithPermissions() authenticatedUser, @Args() args) {
    const data = await this.taxonomyService.findAll(args.pagination, { authenticatedUser, params: args }, args.filters);
    return new TaxonomiesPaginatedDto(data[0], data[1], args.pagination.pageSize, args.pagination.pageNumber);
  }

  @Query()
  @UseGuards(GraphqlAuthGuard)
  async getTaxonomy(@GraphqlUserWithPermissions() authenticatedUser, @Args() args) {
    const { id, uuid } = args;
    if (!id && !uuid) { throw new ValidationError('Invalid request error. At least one field [id, uuid] must be specified'); }

    const result = (uuid) ?
      await this.taxonomyService.getTaxonomyByUUID(uuid) :
      await this.taxonomyService.getById(id, {}, { authenticatedUser, params: args });

    return result;
  }

  @ResolveProperty()
  async iucnCategory(@Parent() taxonomy: Taxonomies) {
    if (!taxonomy.iucnCategoryId) {
      return null;
    }
    return this.taxonomyService.getIucnCategoryById(taxonomy.iucnCategoryId);
  }

  @ResolveProperty()
  async commonNames(@Parent() taxonomy: Taxonomies) {
    return this.taxonomyService.getCommonNamesByTaxonomyId(taxonomy.uniqueIdentifier);
  }

  @Query()
  @UseGuards(GraphqlAuthGuard)
  @UseInterceptors(PaginationGraphqlInterceptor)
  async getTaxonomiesForEntity(@GraphqlUserWithPermissions() authenticatedUser, @Args() args) {
    const data = await this.taxonomyService.getTaxonomiesForEntity(args.entityType, args.entityId, args.pagination, { authenticatedUser, params: args }, args.filters);
    return new TaxonomiesPaginatedDto(data[0], data[1], args.pagination.pageSize, args.pagination.pageNumber);
  }

}
