import { Get, Controller, Req, Post, Body, Patch, Param, Delete, ParseIntPipe, UseGuards, Query } from '@nestjs/common';
import { TaxonomyService } from './taxonomy.service';
import { ApiUseTags, ApiBearerAuth, ApiOperation, ApiResponse, ApiImplicitQuery, ApiImplicitParam } from '@nestjs/swagger';
import { TaxonomiesPaginatedDto } from './dto/taxonomies.dto';
import { Pagination } from 'decorators/pagination.decorator';
import { TaxonomiesDto } from 'modules/database/dto/taxonomies.dto';
import { PermissionsGuard } from 'guards/permissions.guard';
import { User } from 'decorators/user.decorator';
import { AuthenticatedUserDto } from 'dto/authenticated-user.dto';
import { PaginationModel } from 'utils/pagination.model';

const logger = require('logger');

export const taxonomiesRelations = ['iucnCategory', 'commonNames'];

@Controller('/api/v1/taxonomy')
@ApiUseTags('Taxonomies')
@ApiBearerAuth()
@UseGuards(PermissionsGuard)
export class TaxonomyController {
  constructor(private readonly taxonomyService: TaxonomyService) { }

  @Get()
  @ApiOperation({
    title: 'Get Taxonomies', description: `
    Get all taxonomies:
  `, operationId: 'GetAllTaxonomies',
  })
  @ApiResponse({ status: 200, description: 'Taxonomies have been successfully returned', isArray: false, type: TaxonomiesPaginatedDto })
  @ApiResponse({ status: 403, description: 'Not authorized.' })
  @ApiResponse({ status: 401, description: 'Not authenticated.' })
  @ApiImplicitQuery({
    name: 'includes', description: `
  Allows include the Taxonomies's relations. Available ${taxonomiesRelations}
  `, type: String, required: false,
  })
  @ApiImplicitQuery({ name: 'fields', description: 'Taxonomies\'s fields to select', type: String, required: false })
  @ApiImplicitQuery({ name: 'page[size]', description: 'Page size. Default 10', type: String, required: false })
  @ApiImplicitQuery({ name: 'page[number]', description: 'Page number', type: String, required: false })
  @ApiImplicitQuery({ name: 'sort', description: 'Sort results', type: String, required: false })
  @ApiImplicitQuery({ name: 'search', description: 'Search taxonomies by text', type: String, required: false })
  @ApiImplicitQuery({ name: 'taxonLevel', description: 'Filter taxonomies by taxon level', type: String, required: false })
  @ApiImplicitQuery({ name: 'searchNamesBy', description: 'Field for search by name', enum: ['scientificName', 'commonName', 'scientificAndCommonName'], required: false })
  @ApiImplicitQuery({ name: 'lang', description: 'Search taxonomies by common name in a specific language', enum: ['EN', 'ES', 'FR'], required: false })
  async findAll(@Pagination() pagination: PaginationModel, @Param() params, @User() authenticatedUser: AuthenticatedUserDto, @Query() filters) {
    logger.info('Getting all');
    const data = await this.taxonomyService.findAll(pagination, { authenticatedUser, params }, filters);
    return new TaxonomiesPaginatedDto(data[0], data[1], pagination.pageSize, pagination.pageNumber);
  }

  @Get('/:id')
  @ApiOperation({
    title: 'Get taxonomy by id', description: `
    Get taxonomy by id
  `, operationId: 'GetTaxonomyById',
  })
  @ApiImplicitQuery({
    name: 'includes', description: `
  Allows include the Taxonomies's relations. Available ${taxonomiesRelations}
  `, type: String, required: false,
  })
  @ApiImplicitParam({ name: 'id', description: 'Id of the taxonomy' })
  @ApiResponse({ status: 200, description: 'Taxonomy has been successfully returned', isArray: false, type: TaxonomiesDto })
  @ApiResponse({ status: 404, description: 'Taxonomy does not exist or you don\'t have permission' })
  @ApiResponse({ status: 401, description: 'Not authenticated.' })
  async getById(@Param('id', new ParseIntPipe()) id: number, @User() authenticatedUser: AuthenticatedUserDto, @Param() params, @Pagination() pagination: PaginationModel) {
    logger.info('Get by id ', id);
    return await this.taxonomyService.getById(id, pagination, { authenticatedUser, params });
  }
}
