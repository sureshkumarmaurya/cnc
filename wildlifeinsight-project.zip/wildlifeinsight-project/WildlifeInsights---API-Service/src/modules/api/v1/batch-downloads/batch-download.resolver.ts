import { BatchDownloadService } from './batch-download.service';
import { Resolver, Mutation, Args } from '@nestjs/graphql';
import { UseGuards } from '@nestjs/common';
import { GraphqlUserWithPermissions } from 'decorators/graphql-user.decorator';
import { GraphqlAuthGuard } from 'guards/graphql-passport.guard';
import { EBatchDownloadStatus } from 'modules/database/dto/batch-downloads.dto';

const logger = require('logger');

@Resolver('BatchDownload')
export class BatchDownloadResolver {
  constructor(private readonly batchDownloadService: BatchDownloadService) {}

  @Mutation()
  @UseGuards(GraphqlAuthGuard)
  async requestDownloadBundle(@GraphqlUserWithPermissions() authenticatedUser, @Args() args) {
    logger.debug('Processing request for download of project or initiative data');
    const job = await this.batchDownloadService.create(args, { authenticatedUser, params: args });
    if (job && job.status === EBatchDownloadStatus.Finished) {
      this.batchDownloadService.sendBundleReadyEmail(job.id, job.uuid, { authenticatedUser, params: args });
    }
    return await this.batchDownloadService.getJobDataForMutation(job);
  }
}
