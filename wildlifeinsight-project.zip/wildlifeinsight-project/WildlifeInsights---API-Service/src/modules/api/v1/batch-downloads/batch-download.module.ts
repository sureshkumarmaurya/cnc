import { Module, RequestMethod, MiddlewareConsumer } from '@nestjs/common';
import { DatabaseModule } from 'modules/database/database.module';
import { BatchDownloadController } from './batch-download.controller';
import { BatchDownloadService } from './batch-download.service';
import { PaginationMiddleware } from 'middlewares/pagination.middleware';
import { BatchDownloadResolver } from './batch-download.resolver';
import { GoogleModule } from 'modules/google/google.module';
import { PublicDownloadRequestService } from './public-download-request.service';

@Module({
  imports: [DatabaseModule, GoogleModule],
  controllers: [BatchDownloadController],
  providers: [BatchDownloadService, PublicDownloadRequestService, BatchDownloadResolver],
})
export class BatchDownloadModule {
  public configure(consumer: MiddlewareConsumer) {
    consumer
      .apply(PaginationMiddleware)
      .with({ includes: [] })
      .forRoutes(
        { path: '/api/v1/:target/:targetId/batch-download/:id', method: RequestMethod.GET },
      );
  }
}
