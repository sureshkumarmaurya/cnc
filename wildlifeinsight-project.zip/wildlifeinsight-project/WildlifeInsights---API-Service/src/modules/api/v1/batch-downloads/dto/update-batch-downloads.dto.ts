import { ApiModelProperty } from '@nestjs/swagger';
import { IsString } from 'class-validator';
import { EBatchDownloadStatus } from '../../../../database/dto/batch-downloads.dto';

export class UpdateBatchDownloadDto {
  @ApiModelProperty({ required: false, type: String, maxLength: 255 })
  @IsString()
  status: EBatchDownloadStatus;
}
