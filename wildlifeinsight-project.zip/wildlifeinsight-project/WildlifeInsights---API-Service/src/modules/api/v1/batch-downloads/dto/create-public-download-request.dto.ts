import { ApiModelProperty } from '@nestjs/swagger';
import { IsString, MaxLength, IsEmail, IsNotEmpty } from 'class-validator';

export class CreatePublicDownloadRequestDto {
  @IsString()
  @IsNotEmpty()
  @MaxLength(255)
  @ApiModelProperty({ required: true })
  name: string;

  @IsString()
  @IsNotEmpty()
  @MaxLength(255)
  @ApiModelProperty({ required: true })
  organization: string;

  @IsEmail()
  @IsNotEmpty()
  @ApiModelProperty({ required: true })
  email: string;
}
