import { Module, MiddlewareConsumer } from '@nestjs/common';
import { DatabaseModule } from 'modules/database/database.module';
import { BatchDownloadPublicResolver } from './batch-download-public.resolver';
import { PublicDownloadRequestService } from './public-download-request.service';
import { BatchDownloadService } from './batch-download.service';

@Module({
  imports: [DatabaseModule],
  providers: [PublicDownloadRequestService, BatchDownloadService, BatchDownloadPublicResolver],
})
export class BatchDownloadPublicModule {
  public configure(consumer: MiddlewareConsumer) {}
}
