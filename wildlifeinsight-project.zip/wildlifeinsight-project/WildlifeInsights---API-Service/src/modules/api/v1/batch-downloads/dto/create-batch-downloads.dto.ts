import { ApiModelProperty } from '@nestjs/swagger';
import { EntityType } from '../batch-download.service';

export class CreateBatchDownloadDto {
  @ApiModelProperty({ required: true, type: String })
  entityType: EntityType;

  @ApiModelProperty({ required: true, type: Number })
  entityId: number;

  @ApiModelProperty({ required: false, type: Boolean })
  forceGenerationOfBundle: boolean;
}
