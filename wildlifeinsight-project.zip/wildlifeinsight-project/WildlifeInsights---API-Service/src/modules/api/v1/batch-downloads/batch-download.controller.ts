import { Post, Get, Patch, Param, Body, ParseIntPipe, UseGuards, Controller, Delete } from '@nestjs/common';
import { ApiUseTags, ApiBearerAuth, ApiOperation, ApiResponse, ApiImplicitParam } from '@nestjs/swagger';
import { BatchDownloadService } from './batch-download.service';
import { BatchDownloadsDto, EBatchDownloadStatus } from 'modules/database/dto/batch-downloads.dto';
import { CreateBatchDownloadDto } from './dto/create-batch-downloads.dto';
import { UpdateBatchDownloadDto } from './dto/update-batch-downloads.dto';
import { ValidationPipe } from 'pipes/validation.pipe';
import { User } from 'decorators/user.decorator';
import { AuthenticatedUserDto } from 'dto/authenticated-user.dto';
import { Pagination } from 'decorators/pagination.decorator';
import { PermissionsGuard } from 'guards/permissions.guard';
import { StorageService } from '../../../google/storage.service';
import { PERMISSIONS } from 'utils/permissions.enum';
import { Permissions } from 'decorators/permissions.decorator';
import { PaginationModel } from 'utils/pagination.model';

const logger = require('logger');

@Controller('/api/v1/batch-downloads')
@ApiUseTags('BatchDownloads')
@ApiBearerAuth()
@UseGuards(PermissionsGuard)
export class BatchDownloadController {
  constructor(
    private readonly batchDownloadService: BatchDownloadService,
    private readonly googleCloudStorageService: StorageService,
  ) {}

  @Post('/manage/revoke-gcp-roles')
  @ApiOperation({
    title: 'Revoke all GCP storage role bindings related to batch downloads',
    description: 'Revoke all GCP storage role bindings related to batch download',
    operationId: 'revokeAllBatchDownloadsGCPRoles',
  })
  @UseGuards(PermissionsGuard)
  @ApiResponse({ status: 200, description: 'GCP storage role bindings for batch downloads have been revoked' })
  @ApiResponse({ status: 400, description: 'Body contains errors' })
  @ApiResponse({ status: 401, description: 'Not authenticated.' })
  @Permissions(PERMISSIONS.PERFORM_API_ADMIN_OPERATIONS)
  async revokeGCPRoleBindingsForBatchDownloads(@Body(new ValidationPipe()) @User() authenticatedUser: AuthenticatedUserDto) {
    logger.info('Revoking all GCP storage role bindings related to batch download');

    return await this.googleCloudStorageService.revokeGCPRoleBindingsForBatchDownloads();
  }

  @Post('/manage/grant-gcp-roles')
  @ApiOperation({
    title: 'Grant all applicable GCP storage role bindings related to batch downloads',
    description: 'Grant all applicable GCP storage role bindings related to batch downloads',
    operationId: 'grantAllBatchDownloadsGCPRoles',
  })
  @UseGuards(PermissionsGuard)
  @ApiResponse({ status: 200, description: 'GCP storage role bindings for batch downloads have been granted' })
  @ApiResponse({ status: 400, description: 'Body contains errors' })
  @ApiResponse({ status: 401, description: 'Not authenticated.' })
  @Permissions(PERMISSIONS.PERFORM_API_ADMIN_OPERATIONS)
  async grantGCPRoleBindingsForBatchDownloads(@Body(new ValidationPipe()) @User() authenticatedUser: AuthenticatedUserDto) {
    logger.info('Granting all applicable GCP storage role bindings related to batch downloads');

    return await this.googleCloudStorageService.grantGCPRoleBindingsForBatchDownloads();
  }

  /**
   * Creates a new batch-download record
   * @param createBatchDownloadDto
   * @param authenticatedUser
   * @param params
   */
  @Post('/:entityType/:entityId')
  @ApiOperation({ title: 'Create batch download', description: 'Create new batch-download', operationId: 'CreateBatchDownload' })
  @ApiImplicitParam({ name: 'entityType', description: 'entity type for the batch-download' })
  @ApiImplicitParam({ name: 'entityId', description: 'entity id for the batch-download' })
  @ApiResponse({ status: 200, description: 'Batch download has been successfully created', isArray: false, type: BatchDownloadsDto })
  @ApiResponse({ status: 400, description: 'Body contains errors' })
  @ApiResponse({ status: 401, description: 'Not authenticated.' })
  async create(@Body(new ValidationPipe()) createBatchDownloadDto: CreateBatchDownloadDto, @User() authenticatedUser: AuthenticatedUserDto, @Param() params) {
    logger.info('Create BatchDownload');
    return await this.batchDownloadService.create(createBatchDownloadDto, { authenticatedUser, params });
  }

  @Get('/:id')
  @ApiOperation({ title: 'Get by ID batch download', description: 'Get one batch-download by ID', operationId: 'GetByIdBatchDownload' })
  @ApiImplicitParam({ name: 'id', description: 'Id of the batch-download' })
  @ApiImplicitParam({ name: 'entityType', description: 'entity type for the batch-download' })
  @ApiImplicitParam({ name: 'entityId', description: 'entity id for the batch-download' })
  @ApiResponse({ status: 200, description: 'Batch download has been successfully returned', isArray: false, type: BatchDownloadsDto })
  @ApiResponse({ status: 404, description: 'Batch download does not exist or you don\'t have permission' })
  @ApiResponse({ status: 401, description: 'Not authenticated.' })
  async getById(@Param('id', new ParseIntPipe()) id: number, @User() authenticatedUser: AuthenticatedUserDto, @Param() params, @Pagination() pagination: PaginationModel) {
    logger.info('Get BatchDownload by ID', id);
    return await this.batchDownloadService.getById(id, pagination, { authenticatedUser, params });
  }

  @Patch('/:id')
  @ApiOperation({ title: 'Update batch download', description: 'Update batch-download by ID', operationId: 'UpdateBatchDownload' })
  @ApiImplicitParam({ name: 'id', description: 'Id of the batch-download' })
  @ApiResponse({ status: 200, description: 'Batch download has been successfully updated', isArray: false, type: BatchDownloadsDto })
  @ApiResponse({ status: 404, description: 'Batch download does not exist or you don\'t have permission' })
  @ApiResponse({ status: 401, description: 'Not authenticated.' })
  async update(@Param('id', new ParseIntPipe()) id: number, @Body(new ValidationPipe()) updateBatchDownloadDto: UpdateBatchDownloadDto, @User() authenticatedUser: AuthenticatedUserDto, @Param() params) {
    logger.info('Updating BatchDownload by ID');
    const { uuid } = await this.batchDownloadService.getById(id, {});
    if (updateBatchDownloadDto.status === EBatchDownloadStatus.Finished) {
      await this.batchDownloadService.sendBundleReadyEmail(id, uuid, { authenticatedUser, params });
    }
    return await this.batchDownloadService.update(id, updateBatchDownloadDto, { authenticatedUser, params });
  }

  @Delete('/:id')
  @ApiOperation({ title: 'Delete batch download job', description: 'Delete batch-download job by ID', operationId: 'DeleteBatchDownload' })
  @ApiImplicitParam({ name: 'id', description: 'Id of the batch-download' })
  @ApiResponse({ status: 200, description: 'Batch download has been successfully deleted', isArray: false, type: BatchDownloadsDto })
  @ApiResponse({ status: 404, description: 'Batch download does not exist or you don\'t have permission' })
  @ApiResponse({ status: 401, description: 'Not authenticated.' })
  async remove(@Param('id', new ParseIntPipe()) id: number, @User() authenticatedUser: AuthenticatedUserDto, @Param() params) {
    logger.info('Deleting BatchDownload by ID');
    return await this.batchDownloadService.remove(id, { authenticatedUser, params });
  }

  /**
   * Creates a new download bundle that includes the whole set of data of
   * the platform.
   * @param createBatchDownloadDto
   * @param authenticatedUser
   * @param params
   */
  @Post('/all-platform-data')
  @ApiOperation({ title: 'Create discover batch download', description: 'Create new discover batch-download', operationId: 'CreatePublicBatchDownload' })
  @UseGuards(PermissionsGuard)
  @ApiResponse({ status: 200, description: 'Discover batch download has been successfully created', isArray: false, type: BatchDownloadsDto })
  @ApiResponse({ status: 400, description: 'Body contains errors' })
  @ApiResponse({ status: 401, description: 'Not authenticated.' })
  @Permissions(PERMISSIONS.PERFORM_API_ADMIN_OPERATIONS)
  async createGlobalDownloadBundle(@Body(new ValidationPipe()) createBatchDownloadDto: CreateBatchDownloadDto, @User() authenticatedUser: AuthenticatedUserDto, @Param() params) {
    logger.info('Creating download bundle for all platform data');
    // This is a public download - set this information as a parameter
    params.isPublic = true;
    return await this.batchDownloadService.create(createBatchDownloadDto, { authenticatedUser, params });
  }

}
