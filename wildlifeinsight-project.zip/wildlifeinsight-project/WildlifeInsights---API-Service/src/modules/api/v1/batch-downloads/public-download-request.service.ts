import { Injectable, Inject, BadRequestException } from '@nestjs/common';
import { CreatePublicDownloadRequestDto } from './dto/create-public-download-request.dto';
import { PublicDownloadRequest } from 'modules/database/entities/public-download-requests.entity';
import { Repository } from 'typeorm';
import { BatchDownloads } from 'modules/database/entities/batch-downloads.entity';

const logger = require('logger');

@Injectable()
export class PublicDownloadRequestService {

  constructor(
    @Inject('PublicDownloadRequestRepositoryToken') private readonly publicDownloadRequestRepository: Repository<PublicDownloadRequest>,
  ) {}

  async create(userData: CreatePublicDownloadRequestDto, batchDownloadJob: BatchDownloads): Promise<PublicDownloadRequest> {
    try {
      const requestUserData        = new PublicDownloadRequest();
      requestUserData.name         = userData.name;
      requestUserData.organization = userData.organization;
      requestUserData.email        = userData.email;
      requestUserData.batchDownloadJobId = batchDownloadJob.id;

      logger.debug('Saving discover downloads user data');
      const batchDownloadPublic = await this.publicDownloadRequestRepository.save(requestUserData);

      return batchDownloadPublic;
    } catch (err) {
      throw new BadRequestException(err);
    }
  }

}
