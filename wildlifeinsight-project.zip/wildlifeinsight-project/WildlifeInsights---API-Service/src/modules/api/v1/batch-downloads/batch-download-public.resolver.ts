import { PublicDownloadRequestService } from './public-download-request.service';
import { BatchDownloadService } from '../batch-downloads/batch-download.service';
import { Resolver, Mutation, Args } from '@nestjs/graphql';
import { UseInterceptors } from '@nestjs/common';
import { ValidationGraphqlInterceptor } from 'interceptors/validation-graphql.interceptor';
import { CreatePublicDownloadRequestDto } from './dto/create-public-download-request.dto';

const logger = require('logger');

@Resolver('BatchDownloadPublic')
export class BatchDownloadPublicResolver {
  constructor(
    private readonly batchDownloadService: BatchDownloadService,
  ) {}

  @Mutation()
  @UseInterceptors(new ValidationGraphqlInterceptor(CreatePublicDownloadRequestDto))
  async requestDownloadBundlePublic(@Args() args) {
    logger.debug('Processing request for download of project or initiative data');
    // This is a public download - set this information as a parameter
    args.isPublic = true;
    const { body } = args;
    // Generate bundle (this may be a NOOP if a "fresh" matching bundle exists
    // already); in any case, we get back the details of the batch download job
    const job = await this.batchDownloadService.create(body, { params: args }, body);
    return await this.batchDownloadService.getJobDataForMutation(job);
  }
}
