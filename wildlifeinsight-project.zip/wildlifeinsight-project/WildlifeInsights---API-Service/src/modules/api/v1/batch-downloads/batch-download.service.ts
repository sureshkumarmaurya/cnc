import { Injectable, Inject, BadRequestException, NotFoundException, InternalServerErrorException, UnauthorizedException } from '@nestjs/common';
import { UpdateBatchDownloadDto } from './dto/update-batch-downloads.dto';
import { CreateBatchDownloadDto } from './dto/create-batch-downloads.dto';
import { BatchDownloads } from 'modules/database/entities/batch-downloads.entity';
import { Repository, SelectQueryBuilder } from 'typeorm';
import { GenericService } from 'utils/generic.service';
import { InfoDto } from 'dto/info.dto';
import { EBatchDownloadStatus } from 'modules/database/dto/batch-downloads.dto';
import { Organizations } from 'modules/database/entities/organizations.entity';
import { Initiatives } from 'modules/database/entities/initiatives.entity';
import { Projects } from 'modules/database/entities/projects.entity';
import { Participants } from 'modules/database/entities/participants.entity';
import { MailService } from 'utils/mail.utils';
import { PermissionsUtils } from 'utils/permissions.utils';
import { PERMISSIONS } from 'utils/permissions.enum';
import * as moment from 'moment';
import { AuthenticatedUserDto } from 'dto/authenticated-user.dto';
import { ProjectExporter } from 'utils/project.exporter.utils';
import { BatchDownloadsDeployments } from 'modules/database/entities/batch-downloads-deployments.entity';
import { BatchDownloadsCameras } from 'modules/database/entities/batch-downloads-cameras.entity';
import { BatchDownloadsImages } from 'modules/database/entities/batch-downloads-images.entity';
import { BatchDownloadsProjects } from 'modules/database/entities/batch-downloads-projects.entity';
import { ROLES } from 'utils/roles.enum';
import { PublicDownloadRequestService } from './public-download-request.service';
import { CreatePublicDownloadRequestDto } from './dto/create-public-download-request.dto';
import { exec } from 'ts-process-promises';
import { PaginationModel } from 'utils/pagination.model';

const config = require('config');
const logger = require('logger');

interface BatchDownloadData {
  entityType: EntityType;
  entityId: number;
  entityField: string;
  participantId: number;
  isPublic: boolean;
}

export enum EntityType {
  Global = 'global',
  Organization = 'organization',
  Initiative = 'initiative',
  Project = 'project',
}

export enum URLComponents {
  URL = 'url',
  BasePath = 'path',
  Slug = 'slug',
}

@Injectable()
export class BatchDownloadService extends GenericService<BatchDownloads, CreateBatchDownloadDto, UpdateBatchDownloadDto>  {
  existingDownloadBundle: BatchDownloads;
  isPublic: boolean;

  constructor(
    @Inject('BatchDownloadsRepositoryToken') private readonly batchDownloadsRepository: Repository<BatchDownloads>,
    @Inject('OrganizationsRepositoryToken') private readonly organizationsRepository: Repository<Organizations>,
    @Inject('InitiativesRepositoryToken') private readonly initiativesRepository: Repository<Initiatives>,
    @Inject('ProjectsRepositoryToken') private readonly projectsRepository: Repository<Projects>,
    @Inject('BatchDownloadsProjectsRepositoryToken') private readonly batchDownloadsProjectsRepository: Repository<BatchDownloadsProjects>,
    @Inject('BatchDownloadsDeploymentsRepositoryToken') private readonly batchDownloadsDeploymentsRepository: Repository<BatchDownloadsDeployments>,
    @Inject('BatchDownloadsCamerasRepositoryToken') private readonly batchDownloadsCamerasRepository: Repository<BatchDownloadsCameras>,
    @Inject('BatchDownloadsImagesRepositoryToken') private readonly batchDownloadsImagesRepository: Repository<BatchDownloadsImages>,
    @Inject('ParticipantsRepositoryToken') private readonly participantsRepository: Repository<Participants>,

    private readonly publicDownloadRequestService: PublicDownloadRequestService,
  ) {
    super(batchDownloadsRepository, 'batch-download');
    this.isPublic = false;
  }

  setFilters(query: SelectQueryBuilder<BatchDownloads>, filters: any, info: InfoDto) {
    return query;
  }

  setFiltersGetById(query: SelectQueryBuilder<BatchDownloads>, info: InfoDto) {
    return query;
  }

  setFiltersDelete(query: SelectQueryBuilder<BatchDownloads>, info: InfoDto) {
    return query;
  }

  setFiltersUpdate(query: SelectQueryBuilder<BatchDownloads>, info: InfoDto) {
    return query;
  }

  /**
   * Validate and parse request data for batch download.
   */
  parseBatchDownloadData(info: InfoDto): BatchDownloadData {
    const { authenticatedUser, params } = info;
    const { entityType } = params;

    return {
      entityType,
      entityId: (params.entityId) ? parseInt(params.entityId, 10) : null,
      entityField: (entityType !== EntityType.Global) ? `${entityType}Id` : null,
      participantId: authenticatedUser && authenticatedUser.user ? authenticatedUser.user.id : null,
      isPublic: params.isPublic,
    };
  }

  async validateBeforeCreate(createModel: CreateBatchDownloadDto, info: InfoDto) {
    const batchDownloadData: BatchDownloadData = this.parseBatchDownloadData(info);
    // Check for an existing batch download job with same parameters and within
    // the validity timeframe (in days) specified as config
    const qb = this.batchDownloadsRepository.createQueryBuilder('bdj');

    if (info.params.isPublic) {
      qb.where('bdj.is_public IS TRUE');
      qb.andWhere(`bdj.id = ${qb.subQuery().select('MAX(bd.id)').from(BatchDownloads, 'bd').where('bd.is_public IS TRUE').getQuery()}`);
    } else {
      qb.where('bdj.participantId = :participantId').setParameter('participantId', batchDownloadData.participantId);
      qb.andWhere(`bdj.${batchDownloadData.entityField} = :entityId`).setParameter('entityId', batchDownloadData.entityId);
    }

    // We can't just do "... < interval ':days days'" below as the variable
    // cannot be within a quoted string. So we resort to a nice trick thanks to
    // casting (via https://stackoverflow.com/a/7797994/550077)
    qb.andWhere(
      "age(now(), bdj.requested_timestamp) < '1 day'::interval * :days",
      { days: config.get('batchDownloads.keepDownloadBundlesAvailableForDays') },
    );
    const existing = await qb.getOne();
    this.existingDownloadBundle = existing;
  }

  async setDataCreate(create: CreateBatchDownloadDto, info: InfoDto) {
    const model = new BatchDownloads();
    const batchDownloadData = this.parseBatchDownloadData(info);

    if (info.params && info.params.isPublic) {
      model.isPublic = true;
    } else {
      logger.debug(`Creating new batch download job definition: entityType: ${batchDownloadData.entityType}, entityId: ${batchDownloadData.entityId}, supplied data: ${JSON.stringify(info.params)}`);

      model[batchDownloadData.entityField] = batchDownloadData.entityId;
      model.participantId = batchDownloadData.participantId;
    }

    return model;
  }

  async setDataUpdate(model: BatchDownloads, update: UpdateBatchDownloadDto, info: InfoDto) {
    const updatedObject = { ...model, ...update };
    return updatedObject;
  }

  async create(createModel: CreateBatchDownloadDto, info?: InfoDto, publicDownloadRequest?: CreatePublicDownloadRequestDto): Promise<BatchDownloads> | undefined {
    logger.debug(`Creating ${this.alias}`);
    const batchDownloadData = this.parseBatchDownloadData(info);

    // first check for an existing job with same parameters and still valid
    await this.validateBeforeCreate(createModel, info);

    // if this is found, noop and return its data
    if (this.existingDownloadBundle && !createModel.forceGenerationOfBundle) {
      const model = new BatchDownloads;
      logger.debug(`Matching download bundle was already created and is still available:
      entityType: ${batchDownloadData.entityType}, entityId: ${batchDownloadData.entityId}, matching supplied data: ${JSON.stringify(info.params)}.`);
      model.uuid = this.existingDownloadBundle.uuid;
      model.isPublic = this.existingDownloadBundle.isPublic;
      model.participantId = this.existingDownloadBundle.participantId;
      model[batchDownloadData.entityField] = this.existingDownloadBundle[batchDownloadData.entityField];
      model.requestedTimestamp = this.existingDownloadBundle.requestedTimestamp;
      model.status = this.existingDownloadBundle.status;
      model.projectsInDownloadBundle = this.existingDownloadBundle.projectsInDownloadBundle;
      model.id = this.existingDownloadBundle.id;

      logger.debug(`Existing batch download job found: refer to URI for download: ${JSON.stringify(model)}`);

      if (model.isPublic && publicDownloadRequest) {
        logger.debug(`Public download request: ${JSON.stringify(publicDownloadRequest)}`);
        // Record that someone has requested to download a global data bundle
        this.publicDownloadRequestService.create(publicDownloadRequest as CreatePublicDownloadRequestDto, model);
      }

      return model;
    }

    // otherwise, create a new job from the supplied metadata
    const model = await this.setDataCreate(createModel, info);

    this.isPublic = model.isPublic;

    let batchDownloadJob: BatchDownloads;
    let resultBatchDownloadJob: BatchDownloads;

    try {
      if (info.params && info.params.isPublic) {
        model.projectsInDownloadBundle = await this.getListOfProjectsForDiscoverDownload();
      } else {
        model.projectsInDownloadBundle = await this.getListOfProjectsForDownload(batchDownloadData, info.authenticatedUser);
      }

      logger.debug('Saving job metadata');
      /**
       * Save new job data, and retrieve it. AFAIU retrieving it via a separate
       * query (vs just assigning the result of save()) is needed when some
       * fields are generated by PostgreSQL.
       */
      batchDownloadJob = await this.batchDownloadsRepository.save(model).then(async (bdr) => {
        const qb = this.batchDownloadsRepository.createQueryBuilder('bdj');
        if (!this.isPublic) {
          qb.innerJoinAndSelect('bdj.participant', 'participant');
        }
        qb.where('bdj.id = :batchDownloadId');
        qb.setParameter('batchDownloadId', bdr.id);

        return await qb.getOne();
      });

      const projectExporter = await new ProjectExporter(
        this.projectsRepository,
        this.batchDownloadsProjectsRepository,
        this.batchDownloadsDeploymentsRepository,
        this.batchDownloadsCamerasRepository,
        this.batchDownloadsImagesRepository);

      logger.debug(`Preparing metadata export bundle for projects with id: ${model.projectsInDownloadBundle}`);

      if (info.params && info.params.isPublic) {

        if (publicDownloadRequest) {
          logger.debug(`Public download request: ${JSON.stringify(publicDownloadRequest)}`);
          // Record that someone has requested to download a global data bundle
          this.publicDownloadRequestService.create(publicDownloadRequest as CreatePublicDownloadRequestDto, resultBatchDownloadJob);
        }

        exec(`ts-node -r tsconfig-paths/register src/scripts/batch-downloads/export-download-bundle.ts --job_id ${batchDownloadJob.id}`);
        return batchDownloadJob;
      }

      resultBatchDownloadJob = await projectExporter.export(batchDownloadJob);
    } catch (err) {
      throw new BadRequestException(err);
    }

    this.isPublic = false;
    return resultBatchDownloadJob;
  }

  /**
   * Remove a batch download job by id
   * TODO: delete associated blobs on cloud storage buckets
   */
  async remove(id: number, info?: InfoDto): Promise<BatchDownloads> | null {
    const batchDownloadJob = await this.getById(id, {});

    let model;

    // Deleting a batch download job is allowed to the user who requested it
    // or to users with generalRole API_OPERATIONS_ADMIN
    if (info && info.authenticatedUser && info.authenticatedUser.user) {
      if (
          (batchDownloadJob.participantId === info.authenticatedUser.user.id) ||
          (info.authenticatedUser.generalRole && info.authenticatedUser.generalRole.slug === ROLES.API_OPERATIONS_ADMIN)
        ) {
        model = await super.remove(id, info);
      } else {
        throw new UnauthorizedException('Cannot delete batch download jobs which don\'t belong to the current user');
      }
    }

    return model;
  }

  /**
   * Compute list of projects for which data should be exported
   * If entityType is project, it's just the project itself.
   * If entityType is initiative or organization, it's the list of projects the
   * user has access to, within the given initiative or organization.
   *
   * BUG: getProjectsInInitiativeWithPermission is always returning the empty set
   */
  async getListOfProjectsForDownload(batchDownloadData: BatchDownloadData, authenticatedUser: AuthenticatedUserDto) {
    if (batchDownloadData.entityType === EntityType.Project) {
      return [batchDownloadData.entityId];
    }

    if (batchDownloadData.entityType === EntityType.Initiative) {
      return PermissionsUtils
        .getProjectsInInitiativeWithPermission(authenticatedUser, PERMISSIONS.DEPLOYMENT_GET_ALL, batchDownloadData.entityId)
        .map(project => project.id);
    }

    if (batchDownloadData.entityType === EntityType.Organization) {
      return PermissionsUtils
        .getProjectsInOrganizationWithPermission(authenticatedUser, PERMISSIONS.DEPLOYMENT_GET_ALL, batchDownloadData.entityId)
        .map(project => project.id);
    }
  }

  // Get a list of public project id's
  async getListOfProjectsForDiscoverDownload() {
    const projectIds = await this.batchDownloadsProjectsRepository.createQueryBuilder()
      .select('project_internal_id')
      .getRawMany();

    // tslint:disable-next-line
    return projectIds.map(({ project_internal_id }) => project_internal_id);
  }

  /**
   * Generate a user-friendly base filename which is used both for the folder
   * name within a download bundle (without extension) and for the bundle zip
   * file itself (with .zip extension)
   *
   * * for global downloads, uuid + "all-platform-data"
   * * for all other downloads, uuid + entityType + entityTypeValue
   */
  static getBundleBaseFilenameFromMetadata(uuid: string, entityType: EntityType, entityTypeValue: number | null) : string {
    const prefix = 'wildlife-insights';

    if (entityType === EntityType.Global) {
      return `${prefix}_${uuid}_all-platform-data`;
    }
    return `${prefix}_${uuid}_${entityType}-${entityTypeValue}_data`;
  }

  static getBatchDownloadUrl(uuid: string, component: URLComponents = URLComponents.URL, isPublic: boolean, entityType: EntityType, entityTypeValue?: number | null): string {
    const baseUrl = `https://${config.get('batchDownloads.bucketName')}.storage.googleapis.com`;
    const environment = config.get('appEnvironment');
    const version = config.get('batchDownloads.featureVersion');
    const basePath = `/${environment}/${version}/${uuid}`;

    const slug: string = `${this.getBundleBaseFilenameFromMetadata(uuid, entityType, entityTypeValue)}.zip`;

    const url: string = `${baseUrl}${basePath}/${slug}`;

    if (component === URLComponents.URL) {
      return url;
    }
    if (component === URLComponents.BasePath) {
      return basePath;
    }
    if (component === URLComponents.Slug) {
      return slug;
    }
  }

  getExpirationDate(requestedTimestamp) {
    return moment(requestedTimestamp).add(config.get('batchDownloads.keepDownloadBundlesAvailableForDays'), 'days').format();
  }

  static getEntityType(data: BatchDownloads) {
    if (!data.projectId && !data.initiativeId && !data.organizationId) { return EntityType.Global; }
    if (data.projectId) { return EntityType.Project; }
    if (data.initiativeId) { return EntityType.Initiative; }
    if (data.organizationId) { return EntityType.Organization; }
    throw new Error('Invalid entity type');
  }

  static getEntityTypeValue(data: BatchDownloads) {
    if (data.projectId) { return data.projectId; }
    if (data.initiativeId) { return data.initiativeId; }
    if (data.organizationId) { return data.organizationId; }
    throw new Error('Invalid entity type');
  }

  async getEntityData(entityType: string, data) {
    const idField = `${entityType}Id`;
    const entityId = data[idField];

    let repository;

    if (entityType === 'organization') {
      repository = this.organizationsRepository;
    }
    if (entityType === 'initiative') {
      repository = this.initiativesRepository;
    }
    if (entityType === 'project') {
      repository = this.projectsRepository;
    }

    return await repository.findOne(entityId);
  }

  /**
   * Given a batch download job, create data structure to be returned by the API
   */
  async getJobDataForMutation(batchDownloadsJob: BatchDownloads) {
    const entityType = BatchDownloadService.getEntityType(batchDownloadsJob);
    const entityTypeValue = (entityType === EntityType.Global) ? null : BatchDownloadService.getEntityTypeValue(batchDownloadsJob);
    const downloadUrl = BatchDownloadService.getBatchDownloadUrl(batchDownloadsJob.uuid, URLComponents.URL, this.isPublic, entityType, entityTypeValue);
    const availableUntil = this.getExpirationDate(batchDownloadsJob.requestedTimestamp);

    return {
      downloadUrl,
      availableUntil,
      availableNow: batchDownloadsJob.status === EBatchDownloadStatus.Finished,
    };
  }

  async sendBundleReadyEmail(id: number, uuid: string, info?: InfoDto) {
    try {
      const pagination: PaginationModel = {};
      const mailService = new MailService();
      const batchDownloadsData = await this.getById(id, pagination, info);
      const entityType = BatchDownloadService.getEntityType(batchDownloadsData);
      const entityTypeValue = BatchDownloadService.getEntityTypeValue(batchDownloadsData);
      const bundleUrl = BatchDownloadService.getBatchDownloadUrl(uuid, URLComponents.URL, this.isPublic, entityType, entityTypeValue);
      const expirationDate = this.getExpirationDate(batchDownloadsData.requestedTimestamp);
      const { name: entityName } = await this.getEntityData(entityType, batchDownloadsData);
      const { email } = await this.participantsRepository.findOne(batchDownloadsData.participantId);
      const messageData = {
        bundleUrl, entityName, entity: entityType, expirationDate: moment(expirationDate).format('MM/DD/YYYY'),
      };
      await mailService.sendTransactionalEmail(messageData, [{ address: email }], 'data-download');
    } catch (err) {
      logger.error(`Send bundle-ready email error. Batch downloads id: ${id}`, err);
      return false;
    }
  }

  // Get last url of discover public downloads file bundle
  async getLastPublicDownloadUrl() {
    const lastPublicDownload = await this.batchDownloadsRepository.findOne({
      where: {
        isPublic: true,
        status: EBatchDownloadStatus.Finished,
      },
      order: { requestedTimestamp: 'DESC' },
    });
    const { uuid } = lastPublicDownload;
    const url = BatchDownloadService.getBatchDownloadUrl(uuid, URLComponents.URL, lastPublicDownload.isPublic, EntityType.Global);

    return url;
  }
}
