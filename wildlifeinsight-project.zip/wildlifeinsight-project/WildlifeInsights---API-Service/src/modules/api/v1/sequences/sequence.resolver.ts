import { SequenceService } from './sequence.service';
import { Resolver, Query, ResolveProperty, Mutation, Args, Parent } from '@nestjs/graphql';
import { UpdateSequenceDto } from './dto/update-sequence.dto';
import { UseInterceptors, UseGuards } from '@nestjs/common';
import { ValidationGraphqlInterceptor } from 'interceptors/validation-graphql.interceptor';
import { PaginationGraphqlInterceptor } from 'interceptors/pagination-graphql.interceptor';
import { Permissions } from 'decorators/permissions.decorator';
import { GraphqlUserWithPermissions } from 'decorators/graphql-user.decorator';
import { GraphqlAuthGuard } from 'guards/graphql-passport.guard';
import { Sequences } from 'modules/database/entities/sequences.entity';
import { PERMISSIONS } from 'utils/permissions.enum';
import { SequencesPaginatedDto } from './dto/sequences.dto';

const logger = require('logger');

@Resolver('Sequence')
export class SequenceResolver {
  constructor(private readonly sequenceService: SequenceService) {}

  @Query()
  @UseGuards(GraphqlAuthGuard)
  @UseInterceptors(PaginationGraphqlInterceptor)
  @Permissions(PERMISSIONS.SEQUENCE_GET_ALL)
  async getSequences(@GraphqlUserWithPermissions(PERMISSIONS.SEQUENCE_GET_ALL) authenticatedUser, @Args() args) {
    const data = await this.sequenceService.findAll(args.pagination, { authenticatedUser, params: args });
    return new SequencesPaginatedDto(data[0], data[1], args.pagination.pageSize, args.pagination.pageNumber);
  }

  @Query()
  @UseGuards(GraphqlAuthGuard)
  @Permissions(PERMISSIONS.SEQUENCE_GET_ONE)
  async getSequence(@GraphqlUserWithPermissions(PERMISSIONS.SEQUENCE_GET_ONE) authenticatedUser, @Args() args) {
    const { id } = args;
    return await this.sequenceService.getById(id, {}, { authenticatedUser, params: args });
  }

  @ResolveProperty()
  async deployment(@Parent() sequence: Sequences) {
    return this.sequenceService.getDeploymentById(sequence.deploymentId);
  }

  @Mutation()
  @UseGuards(GraphqlAuthGuard)
  @Permissions(PERMISSIONS.SEQUENCE_UPDATE)
  @UseInterceptors(new ValidationGraphqlInterceptor(UpdateSequenceDto))
  async createSequence(@GraphqlUserWithPermissions(PERMISSIONS.SEQUENCE_UPDATE) authenticatedUser, @Args() args) {
    const { id, body } = args;
    return this.sequenceService.create(body, { authenticatedUser, params: args });
  }

  @Mutation()
  @UseGuards(GraphqlAuthGuard)
  @Permissions(PERMISSIONS.SEQUENCE_UPDATE)
  @UseInterceptors(new ValidationGraphqlInterceptor(UpdateSequenceDto))
  async updateSequence(@GraphqlUserWithPermissions(PERMISSIONS.SEQUENCE_UPDATE) authenticatedUser, @Args() args) {
    const { id, body } = args;
    return this.sequenceService.update(id, body, { authenticatedUser, params: args });
  }

  @Mutation()
  @UseGuards(GraphqlAuthGuard)
  @Permissions(PERMISSIONS.SEQUENCE_DELETE)
  async deleteSequence(@GraphqlUserWithPermissions(PERMISSIONS.SEQUENCE_DELETE) authenticatedUser, @Args() args) {
    const { id } = args;
    return this.sequenceService.remove(id, { authenticatedUser, params: args });
  }
}
