import { IsString, IsInt, IsNumber, IsOptional, MaxLength, IsISO8601 } from 'class-validator';
import { ApiModelProperty } from '@nestjs/swagger';

export class UpdateSequenceDto {

  @IsString()
  @MaxLength(255)
  @IsOptional()
  @ApiModelProperty({ required: false, type: String, maxLength: 255 })
  name: string;

  @IsString()
  @MaxLength(255)
  @IsOptional()
  @ApiModelProperty({ required: false, type: String, maxLength: 255 })
  controlField: string;

  @IsInt()
  @IsOptional()
  @ApiModelProperty({ required: false, type: Number })
  rule: number;

  @IsString()
  @IsOptional()
  @ApiModelProperty({ required: false, type: String, maxLength: 255 })
  remarks: string;

  @IsString()
  @MaxLength(255)
  @IsOptional()
  @ApiModelProperty({ required: false, type: String, maxLength: 255 })
  sequenceIdentifier: string;

}
