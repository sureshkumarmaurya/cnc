import { Permissions } from 'decorators/permissions.decorator';
import { UpdateSequenceDto } from './dto/update-sequence.dto';
import { CreateSequenceDto } from './dto/create-sequence.dto';
import { Get, Controller, Req, Post, Body, Patch, Param, Delete, ParseIntPipe, UseGuards } from '@nestjs/common';
import { SequenceService } from './sequence.service';
import { ApiUseTags, ApiBearerAuth, ApiOperation, ApiResponse, ApiImplicitQuery, ApiImplicitParam } from '@nestjs/swagger';
import { SequencesPaginatedDto } from './dto/sequences.dto';
import { Pagination } from 'decorators/pagination.decorator';
import { ValidationPipe } from 'pipes/validation.pipe';
import { SequencesDto } from 'modules/database/dto/sequences.dto';
import { PermissionsGuard } from 'guards/permissions.guard';
import { User } from 'decorators/user.decorator';
import { AuthenticatedUserDto } from 'dto/authenticated-user.dto';
import { PERMISSIONS } from 'utils/permissions.enum';
import { PaginationModel } from 'utils/pagination.model';

const logger = require('logger');

export const sequencesRelations = ['deployment'];

@Controller('/api/v1/project/:projectId/deployment/:deploymentId/sequence')
@ApiUseTags('Sequences')
@ApiBearerAuth()
@UseGuards(PermissionsGuard)
export class SequenceController {
  constructor(private readonly sequenceService: SequenceService) { }

  @Get('')
  @ApiOperation({
    title: 'Get Sequences by deployment', description: `
    Get all sequences
  `, operationId: 'GetAllSequencesByDeployment',
  })
  @ApiImplicitParam({ name: 'projectId', description: 'Project the deployment belongs to', type: Number, required: true })
  @ApiImplicitParam({ name: 'deploymentId', description: 'Deployment the sequence belongs to', type: Number, required: true })
  @ApiResponse({ status: 200, description: 'Sequences have been successfully returned', isArray: false, type: SequencesPaginatedDto })
  @ApiResponse({ status: 403, description: 'Not authorized.' })
  @ApiResponse({ status: 401, description: 'Not authenticated.' })
  @ApiImplicitQuery({
    name: 'includes', description: `
  Allows include the Sequences's relations. Available ${sequencesRelations}
  `, type: String, required: false,
  })
  @ApiImplicitParam({ name: 'deploymentId', description: 'Id of the deployment', required: true, type: Number })
  @ApiImplicitQuery({ name: 'fields', description: 'Sequences\'s fields to select', type: String, required: false })
  @ApiImplicitQuery({ name: 'page[size]', description: 'Page size. Default 10', type: String, required: false })
  @ApiImplicitQuery({ name: 'page[number]', description: 'Page number', type: String, required: false })
  @ApiImplicitQuery({ name: 'sort', description: 'Sort results', type: String, required: false })
  @Permissions(PERMISSIONS.SEQUENCE_GET_ALL)
  async findAll(@Pagination() pagination: PaginationModel, @Param() params, @User() authenticatedUser: AuthenticatedUserDto) {
    logger.info('Getting all sequences by deployment');
    const data = await this.sequenceService.findAll(pagination, { authenticatedUser, params });
    return new SequencesPaginatedDto(data[0], data[1], pagination.pageSize, pagination.pageNumber);
  }

  @Get('/:id')
  @ApiOperation({
    title: 'Get sequence by id', description: `
    Get sequence by id
  `, operationId: 'GetSequenceById',
  })
  @ApiImplicitQuery({
    name: 'includes', description: `
  Allows include the Sequences's relations. Available ${sequencesRelations}
  `, type: String, required: false,
  })
  @ApiImplicitParam({ name: 'id', description: 'Id of the sequence' })
  @ApiResponse({ status: 200, description: 'Sequence has been successfully returned', isArray: false, type: SequencesDto })
  @ApiResponse({ status: 404, description: 'Sequence does not exist or you don\'t have permission' })
  @ApiResponse({ status: 401, description: 'Not authenticated.' })
  async getById(@Param('id', new ParseIntPipe()) id: number, @User() authenticatedUser: AuthenticatedUserDto, @Param() params, @Pagination() pagination: PaginationModel) {
    logger.info('Get sequence by id ', id);
    return await this.sequenceService.getById(id, pagination, { authenticatedUser, params });
  }

  @Post()
  @ApiOperation({
    title: 'Create sequence', description: `
    Create new sequence
  `, operationId: 'CreateSequence',
  })
  @ApiImplicitParam({ name: 'projectId', description: 'Project the deployment belongs to', type: Number, required: true })
  @ApiImplicitParam({ name: 'deploymentId', description: 'Deployment the sequence belongs to', type: Number, required: true })
  @ApiResponse({ status: 200, description: 'Sequence has been successfully created', isArray: false, type: SequencesDto })
  @ApiResponse({ status: 400, description: 'Body contains errors' })
  @ApiResponse({ status: 401, description: 'Not authenticated.' })
  @Permissions(PERMISSIONS.SEQUENCE_CREATE)
  async create(@Body(new ValidationPipe()) createSequenceDto: CreateSequenceDto, @User() authenticatedUser: AuthenticatedUserDto, @Param() params) {
    logger.info('Creating sequence');
    return await this.sequenceService.create(createSequenceDto, { authenticatedUser, params });
  }

  @Patch('/:id')
  @ApiOperation({
    title: 'Update sequence', description: `
    Update sequence
  `, operationId: 'UpdateSequence',
  })
  @ApiImplicitParam({ name: 'id', description: 'Id of the sequence' })
  @ApiImplicitParam({ name: 'projectId', description: 'Project the deployment belongs to', type: Number, required: true })
  @ApiImplicitParam({ name: 'deploymentId', description: 'Deployment the sequence belongs to', type: Number, required: true })
  @ApiResponse({ status: 200, description: 'Sequence has been successfully updated', isArray: false, type: SequencesDto })
  @ApiResponse({ status: 404, description: 'Sequence does not exist or you don\'t have permission' })
  @ApiResponse({ status: 401, description: 'Not authenticated.' })
  @Permissions(PERMISSIONS.SEQUENCE_UPDATE)
  async update(@Param('id', new ParseIntPipe()) id: number, @Body(new ValidationPipe()) updateSequenceDto: UpdateSequenceDto, @User() authenticatedUser: AuthenticatedUserDto, @Param() params) {
    logger.info('Updating sequence');
    return await this.sequenceService.update(id, updateSequenceDto, { authenticatedUser, params });
  }

  @Delete('/:id')
  @ApiOperation({
    title: 'Delete sequence', description: `
    Delete sequence
  `, operationId: 'DeleteSequence',
  })
  @ApiImplicitParam({ name: 'id', description: 'Id of the sequence' })
  @ApiImplicitParam({ name: 'projectId', description: 'Project the deployment belongs to', type: Number, required: true })
  @ApiImplicitParam({ name: 'deploymentId', description: 'Deployment the sequence belongs to', type: Number, required: true })
  @ApiResponse({ status: 200, description: 'Sequence has been successfully deleted', isArray: false, type: SequencesDto })
  @ApiResponse({ status: 404, description: 'Sequence does not exist or you don\'t have permission' })
  @ApiResponse({ status: 401, description: 'Not authenticated.' })
  @Permissions(PERMISSIONS.SEQUENCE_DELETE)
  async remove(@Param('id', new ParseIntPipe()) id: number, @User() authenticatedUser: AuthenticatedUserDto, @Param() params) {
    logger.info('Deleting sequence');
    return await this.sequenceService.remove(id, { authenticatedUser, params });
  }
}
