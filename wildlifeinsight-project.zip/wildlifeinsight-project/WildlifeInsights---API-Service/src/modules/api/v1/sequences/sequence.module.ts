import { SequenceController, sequencesRelations } from './sequence.controller';
import { SequenceService } from './sequence.service';
import { Module, RequestMethod, MiddlewareConsumer } from '@nestjs/common';
import { PaginationMiddleware } from 'middlewares/pagination.middleware';
import { SequenceResolver } from './sequence.resolver';
import { DatabaseModule } from 'modules/database/database.module';

@Module({
  imports: [DatabaseModule],
  controllers: [SequenceController],
  providers: [SequenceService, SequenceResolver],
})
export class SequenceModule {
  public configure(consumer: MiddlewareConsumer) {
    consumer
      .apply(PaginationMiddleware)
      .with({ includes: [], allowIncludes: sequencesRelations })
      .forRoutes(
        { path: '/api/v1/project/:projectId/deployment/:deploymentId/sequence', method: RequestMethod.GET },
        { path: '/api/v1/project/:projectId/deployment/:deploymentId/sequence/:id', method: RequestMethod.GET },
      );
  }
}
