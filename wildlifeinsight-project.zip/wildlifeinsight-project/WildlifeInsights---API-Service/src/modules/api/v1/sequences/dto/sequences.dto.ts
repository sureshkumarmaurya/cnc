import { ApiModelProperty } from '@nestjs/swagger';
import { SequencesDto } from 'modules/database/dto/sequences.dto';
import { MetaDto } from 'modules/database/dto/meta.dto';

export class SequencesPaginatedDto {

  @ApiModelProperty({ type: SequencesDto, isArray: true })
  readonly data: SequencesDto[];

  @ApiModelProperty()
  readonly meta: MetaDto;

  constructor(data, totalItems: number, pageSize: number, page: number) {
    this.data = data;
    this.meta = new MetaDto(Math.ceil(totalItems / pageSize), totalItems, pageSize, page);
  }
}
