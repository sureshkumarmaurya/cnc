import { UpdateSequenceDto } from './dto/update-sequence.dto';
import { CreateSequenceDto } from './dto/create-sequence.dto';
import { Sequences } from 'modules/database/entities/sequences.entity';
import { Repository, SelectQueryBuilder } from 'typeorm';
import { Injectable, Inject, NotFoundException, BadRequestException, UnauthorizedException } from '@nestjs/common';
import { GenericService } from 'utils/generic.service';
import { InfoDto } from 'dto/info.dto';
import { Projects } from 'modules/database/entities/projects.entity';
import { Deployments } from 'modules/database/entities/deployments.entity';

@Injectable()
export class SequenceService extends GenericService<Sequences, CreateSequenceDto, UpdateSequenceDto>  {

  constructor(
    @Inject('SequencesRepositoryToken') private readonly sequencesRepository: Repository<Sequences>,
    @Inject('ProjectsRepositoryToken') private readonly projectsRepository: Repository<Projects>,
    @Inject('DeploymentsRepositoryToken') private readonly deploymentsRepository: Repository<Deployments>,
  ) {
    super(sequencesRepository, 'sequence');
  }

  setFilters(query: SelectQueryBuilder<Sequences>, filters: any, info: InfoDto) {

    if (info.pagination.includes && info.pagination.includes.indexOf('deployment') >= 0) {
      query.innerJoinAndSelect('sequence.deployment', 'deployment');
      info.pagination.includes.splice(info.pagination.includes.indexOf('deployment'), 1);
    } else {
      query.innerJoin('sequence.deployment', 'deployment');
    }
    if (info.params.projectId) {
      query.where('deployment.projectId = :projectId').setParameter('projectId', info.params.projectId);
    }
    if (info.params.deploymentId) {
      query.andWhere('deployment.id = :deploymentId').setParameter('deploymentId', info.params.deploymentId);
    }

    if (info.others && info.others.projectIds) {
      query.where('deployment.projectId in (:...projectIds)').setParameter('projectIds', info.others.projectIds);
    }

    return query;
  }

  setFiltersGetById(query: SelectQueryBuilder<Sequences>, info: InfoDto) {
    if (info.pagination.includes && info.pagination.includes.indexOf('deployment') >= 0) {
      query.innerJoinAndSelect('sequence.deployment', 'deployment');
      info.pagination.includes.splice(info.pagination.includes.indexOf('deployment'), 1);
    } else {
      query.innerJoin('sequence.deployment', 'deployment');
    }
    query.where('deployment.projectId = :projectId').setParameter('projectId', info.params.projectId);
    return query;
  }

  setFiltersDelete(query: SelectQueryBuilder<Sequences>, info: InfoDto) {
    query.innerJoin('sequence.deployment', 'deployment');
    query.where('deployment.projectId = :projectId').setParameter('projectId', info.params.projectId);
    return query;
  }

  setFiltersUpdate(query: SelectQueryBuilder<Sequences>, info: InfoDto) {
    query.innerJoin('sequence.deployment', 'deployment');
    query.where('deployment.projectId = :projectId').setParameter('projectId', info.params.projectId);
    return query;
  }

  async getDeploymentById(id: number): Promise<Deployments> {
    return this.deploymentsRepository.findOne(id);
  }

  async validateBeforeCreate(createModel: CreateSequenceDto, info: InfoDto): Promise<void> {

    const deployment = await this.deploymentsRepository.findOne({ where: { id: info.params.deploymentId, projectId: info.params.projectId } });
    if (!deployment) {
      throw new NotFoundException('Deployment not found');
    }
  }

  async setDataCreate(create: CreateSequenceDto, info: InfoDto) {
    const model = new Sequences();
    model.name = create.name;
    model.controlField = create.controlField;
    model.rule = create.rule;
    model.remarks = create.remarks;
    model.sequenceIdentifier = create.sequenceIdentifier;
    model.deployment = await this.deploymentsRepository.findOne({ where: { id: info.params.deploymentId, projectId: info.params.projectId } });
    return model;

  }

  async setDataUpdate(model: Sequences, update: UpdateSequenceDto, info: InfoDto) {

    if (update.name !== undefined) {
      model.name = update.name;
    }
    if (update.controlField !== undefined) {
      model.controlField = update.controlField;
    }
    if (update.rule !== undefined) {
      model.rule = update.rule;
    }
    if (update.remarks !== undefined) {
      model.remarks = update.remarks;
    }
    if (update.sequenceIdentifier !== undefined) {
      model.sequenceIdentifier = update.sequenceIdentifier;
    }
    return model;
  }

}
