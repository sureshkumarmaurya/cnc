import { Repository, SelectQueryBuilder, In } from 'typeorm';
import { Injectable, Inject, NotFoundException, BadRequestException, UnauthorizedException } from '@nestjs/common';
import { GenericService } from 'utils/generic.service';
import { InfoDto } from 'dto/info.dto';

import { Participants } from 'modules/database/entities/participants.entity';
import { OrganizationParticipantPivot } from 'modules/database/entities/organization-participant-pivot.entity';
import { InitiativeParticipantPivot } from 'modules/database/entities/initiative-participant-pivot.entity';
import { ParticipantTypeProjectPivot } from 'modules/database/entities/participant-type-project-pivot.entity';
import { SequenceIdentificationOutputs } from 'modules/database/entities/sequence-identification-outputs.entity';
import { IdentificationOutputs } from 'modules/database/entities/identification-outputs.entity';
import { Deployments } from 'modules/database/entities/deployments.entity';
import { DataFiles } from 'modules/database/entities/data-files.entity';
import { RoleChanges } from 'modules/database/entities/role-changes.entity';

import { AuthenticatedUserDto } from 'dto/authenticated-user.dto';
const _ = require('lodash');

const logger = require('logger');

@Injectable()
export class ParticipantService extends GenericService<Participants, void, void>  {

  constructor(
    @Inject('ParticipantsRepositoryToken') private readonly participantsRepository: Repository<Participants>,
    @Inject('OrganizationParticipantPivotRepositoryToken') private readonly organizationParticipantPivotRepository: Repository<OrganizationParticipantPivot>,
    @Inject('InitiativeParticipantPivotRepositoryToken') private readonly initiativeParticipantPivotRepository: Repository<InitiativeParticipantPivot>,
    @Inject('ParticipantTypeProjectPivotRepositoryToken') private readonly participantTypeProjectPivotRepository: Repository<ParticipantTypeProjectPivot>,
    @Inject('SequenceIdentificationOutputsRepositoryToken') private readonly sequenceIdentificationOutputsRepository: Repository<SequenceIdentificationOutputs>,
    @Inject('IdentificationOutputsRepositoryToken') private readonly identificationOutputsRepository: Repository<IdentificationOutputs>,
    @Inject('DeploymentsRepositoryToken') private readonly deploymentsRepository: Repository<Deployments>,
    @Inject('DataFilesRepositoryToken') private readonly dataFilesRepository: Repository<DataFiles>,
    @Inject('RoleChangesRepositoryToken') private readonly roleChangesRepository: Repository<RoleChanges>,
  ) {
    super(participantsRepository, 'participant');
  }

  setFilters(query: SelectQueryBuilder<Participants>, filters: any, info: InfoDto) {

    if (filters && filters.whitelisted !== undefined) {
      query.andWhere('participant.whitelisted = :whitelisted').setParameter('whitelisted', filters.whitelisted);
    }

    if (filters && filters.firstName) {
      query.andWhere('participant.firstName = :firstName').setParameter('firstName', filters.firstName);
    }

    if (filters && filters.lastName) {
      query.andWhere('participant.lastName = :lastName').setParameter('lastName', filters.lastName);
    }

    if (filters && filters.email) {
      query.andWhere('participant.email = :email').setParameter('email', filters.email);
    }

    if (filters && filters.id) {
      query.andWhere('participant.id = :id').setParameter('id', filters.id);
    }

    return query;
  }

  // The following method is defined here because it is abstract in the base
  // class, but we don't currently use it for any practical purpose.
  async setDataCreate(create: any, info: InfoDto) {
    const model = new Participants();
    return model;
  }

  // The following method is defined here because it is abstract in the base
  // class, but we don't currently use it for any practical purpose.
  async setDataUpdate(model: Participants, update: any, info: InfoDto) {
    return model;
  }

  /**
   * Attempt to delete a list of participants, given their ids.
   */
  async deleteParticipants(participantsIds: number[], authenticatedUser: AuthenticatedUserDto) {
    const deletingPromises = participantsIds.map(id => this.deleteParticipantWithPivots(id, authenticatedUser.user.id));
    return await Promise.all(deletingPromises);
  }

  /**
   * Attempt to delete a participant, alongside relevant pivots which are safe
   * to delete, i.e. do not lead to any conservation data being removed: these
   * are roles of the user on an organization, initiative or project.
   *
   * For other entities which are linked to the user being deleted, for example
   * `data_files` or `identification_outputs`, the new owner will be set to the
   * user performing the deletion operation. This is so that the entities are
   * not orphaned (which may not even be allowed, depending on data integrity
   * constraints).
   *
   * Deletion of users, as a capability restricted to platform administrators
   * with a specific role, is nevertheless meant to be used sparingly and mainly
   * in the context of allowing the deletion of users who signed up for the
   * platform but won't be whitelisted, so that these accounts won't keep
   * appearing in the list of accounts that need to be vetted and whitelisted,
   * so *in practice* there should be very few cases in which we "transfer"
   * entities such as data files to a new owner - for most of user deletions,
   * these users won't have any data associated to them, besides the initial
   * project and organization that are created when a user has validated their
   * email address.
   */
  async deleteParticipantWithPivots(participantId: number, currentUserId: number) {
    return new Promise(async (resolve, reject) => {
      try {
        const organizationRolesByOrganization = await this.organizationParticipantPivotRepository
          .find({ where: { participantId } })
          .then(pivots => _.groupBy(pivots, 'organizationId'))
          .catch(err => logger.error(err));
        const initiativeRolesByInitiative = await this.initiativeParticipantPivotRepository
          .find({ where: { participantId } })
          .then(pivots => _.groupBy(pivots, 'initiativeId'))
          .catch(err => logger.error(err));
        const projectRolesByProject = await this.participantTypeProjectPivotRepository
          .find({ where: { participantId } })
          .then(pivots => _.groupBy(pivots, 'projectId'))
          .catch(err => logger.error(err));

        /**
         * If the user being deleted is the only one who currently has a role on
         * an organization, we add the user who is *requesting the deletion* to
         * the organization, with the same role of the user being deleted, so
         * that the organization is not orphaned.
         *
         * In practice, for the core use case of the 'deleteParticipants'
         * mutation, namely deleting users who have never been whitelisted and
         * therefore have never used the platform, the organization and project
         * that they are members of (the ones created when a user confirms their
         * email address) should actually be deleted (rather than kept making
         * sure that they aren't orphaned, as we are doing here).
         *
         * However, this would require an entire new set of heuristics. For
         * example, the user may have been whitelisted at some point, and then
         * their access may have been revoked again for some reason, so we can't
         * rely on their non-whitelisted status as a signal that we can delete
         * "empty" organizations and projects associated only to them.
         */
        await Promise.all(Object.keys(organizationRolesByOrganization).map(async (organization) => {
          if (organizationRolesByOrganization[organization].length === 1) {
            await this.organizationParticipantPivotRepository.insert({
              ...organizationRolesByOrganization[organization][0],
              participantId: currentUserId,
            });
          }
        }));

        // As above, for initiatives
        await Promise.all(Object.keys(initiativeRolesByInitiative).map(async (initiative) => {
          if (initiativeRolesByInitiative[initiative].length === 1) {
            await this.initiativeParticipantPivotRepository.insert({
              ...initiativeRolesByInitiative[initiative][0],
              participantId: currentUserId,
            });
          }
        }));

        // As above, for projects
        await Promise.all(Object.keys(projectRolesByProject).map(async (project) => {
          if (projectRolesByProject[project].length === 1) {
            await this.participantTypeProjectPivotRepository.insert({
              ...projectRolesByProject[project][0],
              startDate: new Date(),
              participantId: currentUserId,
            });
          }
        }));

        /**
         * For entities *other than organizations, initiatives or projects*
         * which are associated to a user, we replace the id of the user being
         * deleted with the id of the user who is performing the deletion.
         */
        await this.sequenceIdentificationOutputsRepository.update({ participantId }, { participantId: currentUserId });
        await this.identificationOutputsRepository.update({ participantId }, { participantId: currentUserId });
        await this.deploymentsRepository.update({ participantSetSensorId: participantId }, { participantSetSensorId: currentUserId });
        await this.deploymentsRepository.update({ participantRemoveSensorId: participantId }, { participantRemoveSensorId: currentUserId });
        await this.dataFilesRepository.update({ participantId }, { participantId: currentUserId });
        await this.roleChangesRepository.update({ invitationInitiatorId: participantId }, { invitationInitiatorId: currentUserId });
        await this.roleChangesRepository.update({ participantId }, { participantId: currentUserId });

        /**
         * And finally, we actually delete the user. This will trigger any
         * `CASCADE`s set at the database level (for example, deleting the user
         * from all the organization/initiative/project-participant pivot
         * tables)
         */
        await this.participantsRepository.delete({ id: participantId });

        resolve({
          participantId,
          deleted: true,
        });
      } catch (err) {
        resolve({
          participantId,
          deleted: false,
        });
      }
    });
  }
}
