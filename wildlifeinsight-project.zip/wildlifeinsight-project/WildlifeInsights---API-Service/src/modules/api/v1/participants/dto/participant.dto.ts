import { ApiModelProperty } from '@nestjs/swagger';
import { ParticipantsDto } from 'modules/database/dto/participants.dto';
import { MetaDto } from 'modules/database/dto/meta.dto';

export class ParticipantPaginatedDto {

  @ApiModelProperty({ type: ParticipantsDto, isArray: true })
  readonly data: ParticipantsDto[];

  @ApiModelProperty()
  readonly meta: MetaDto;

  constructor(data, totalItems: number, pageSize: number, page: number) {
    this.data = data;
    this.meta = new MetaDto(Math.ceil(totalItems / pageSize), totalItems, pageSize, page);
  }
}
