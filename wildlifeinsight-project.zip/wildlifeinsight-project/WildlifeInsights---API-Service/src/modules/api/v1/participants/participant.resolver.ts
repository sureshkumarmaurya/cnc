import { Resolver, Query, Args, Mutation } from '@nestjs/graphql';
import { GraphqlUserWithPermissions } from 'decorators/graphql-user.decorator';
import { PaginationGraphqlInterceptor } from 'interceptors/pagination-graphql.interceptor';
import { UseInterceptors, UseGuards } from '@nestjs/common';
import { ParticipantService } from './participant.service';
import { ParticipantPaginatedDto } from './dto/participant.dto';
import { GraphqlAuthGuard } from 'guards/graphql-passport.guard';
import { PERMISSIONS } from 'utils/permissions.enum';
import { Permissions } from 'decorators/permissions.decorator';
@Resolver('Participant')
export class ParticipantResolver {
  constructor(private readonly participantService: ParticipantService) {}

  @Query()
  async getParticipantData(@GraphqlUserWithPermissions() authenticatedUser) {
    const { user, projectRole: projectRoles, organizationRole: organizationRoles, initiativeRole: initiativeRoles, generalRole: defaultRole } = authenticatedUser;
    return {
      projectRoles,
      organizationRoles,
      initiativeRoles,
      user: {
        ...user,
        defaultRole,
      },
    };
  }

  @Query()
  @UseInterceptors(PaginationGraphqlInterceptor)
  @UseGuards(GraphqlAuthGuard)
  async getParticipants(@GraphqlUserWithPermissions(PERMISSIONS.PARTICIPANT_ACTIVATE_ACCOUNT) authenticatedUser, @Args() args) {
    const data = await this.participantService.findAll(args.pagination, { authenticatedUser, params: args }, args.filters);
    return new ParticipantPaginatedDto(data[0], data[1], args.pagination.pageSize, args.pagination.pageNumber);
  }

  @Mutation()
  @UseGuards(GraphqlAuthGuard)
  @Permissions(PERMISSIONS.MANAGE_PARTICIPANTS)
  async deleteParticipants(@GraphqlUserWithPermissions(PERMISSIONS.MANAGE_PARTICIPANTS) authenticatedUser, @Args() args) {
    const { participantsIds } = args;
    return this.participantService.deleteParticipants(participantsIds, authenticatedUser);
  }
}
