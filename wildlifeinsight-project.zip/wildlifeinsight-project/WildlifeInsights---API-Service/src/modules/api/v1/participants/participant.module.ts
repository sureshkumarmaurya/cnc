import { Module } from '@nestjs/common';
import { ParticipantResolver } from './participant.resolver';
import { DatabaseModule } from 'modules/database/database.module';
import { ParticipantService } from './participant.service';

@Module({
  imports: [DatabaseModule],
  providers: [ParticipantResolver, ParticipantService],
})
export class ParticipantModule {
}
