import { Permissions } from 'decorators/permissions.decorator';
import { Get, Controller, Req, Post, Body, Patch, Param, Delete, ParseIntPipe, UseGuards } from '@nestjs/common';
import { SubprojectService } from './subproject.service';
import { ApiUseTags, ApiBearerAuth, ApiOperation, ApiResponse, ApiImplicitQuery, ApiImplicitParam } from '@nestjs/swagger';
import { SubprojectsPaginatedDto } from './dto/subprojects.dto';
import { Pagination } from 'decorators/pagination.decorator';
import { ValidationPipe } from 'pipes/validation.pipe';
import { SubprojectsDto } from 'modules/database/dto/subprojects.dto';
import { PermissionsGuard } from 'guards/permissions.guard';
import { User } from 'decorators/user.decorator';
import { AuthenticatedUserDto } from 'dto/authenticated-user.dto';
import { PERMISSIONS } from 'utils/permissions.enum';
import { CreateSubprojectDto } from './dto/create-subproject.dto';
import { UpdateSubprojectDto } from './dto/update-subproject.dto';
import { PaginationModel } from 'utils/pagination.model';
const logger = require('logger');
export const subprojectRelations = ['project', 'deployments'];

@Controller('/api/v1/project/:projectId/subproject')
@ApiUseTags('Subprojects')
@ApiBearerAuth()
@UseGuards(PermissionsGuard)
export class SubprojectController {
  constructor(private readonly subprojectService: SubprojectService) { }

  @Get('')
  @ApiOperation({
    title: 'Get subprojects by project', description: `
    Get all subprojects by project:
  `, operationId: 'GetAll',
  })
  @ApiImplicitParam({ name: 'projectId', description: 'Project the deployment belongs to', type: Number, required: true })
  @ApiResponse({ status: 200, description: 'Subprojects have been successfully returned', isArray: false, type: SubprojectsPaginatedDto })
  @ApiResponse({ status: 403, description: 'Not authorized.' })
  @ApiResponse({ status: 401, description: 'Not authenticated.' })
  @ApiImplicitQuery({ name: 'includes', description: `Allows the inclusion of the subprojects relations. Available ${subprojectRelations}`, type: String, required: false })
  @ApiImplicitQuery({ name: 'fields', description: 'Subprojects\' fields to select', type: String, required: false })
  @ApiImplicitQuery({ name: 'page[size]', description: 'Page size. Default 10', type: String, required: false })
  @ApiImplicitQuery({ name: 'page[number]', description: 'Page number', type: String, required: false })
  @ApiImplicitQuery({ name: 'sort', description: 'Sort results', type: String, required: false })
  @Permissions(PERMISSIONS.PROJECT_GET_ALL)
  async findAll(@Pagination() pagination: PaginationModel, @Param() params, @User() authenticatedUser: AuthenticatedUserDto) {
    logger.info('Getting all subprojects');
    const data = await this.subprojectService.findAll(pagination, { authenticatedUser, params });
    return new SubprojectsPaginatedDto(data[0], data[1], pagination.pageSize, pagination.pageNumber);
  }

  @Get('/:id')
  @ApiOperation({
    title: 'Get subproject by id', description: `
    Get subproject by id
  `, operationId: 'GetSubprojectById',
  })
  @ApiImplicitQuery({
    name: 'includes', description: `
  Allows the inclusion of the subproject relations. Available ${subprojectRelations}
  `, type: String, required: false,
  })
  @ApiImplicitParam({ name: 'id', description: 'Id of the subproject' })
  @ApiResponse({ status: 200, description: 'Subproject has been successfully returned', isArray: false, type: SubprojectsDto })
  @ApiResponse({ status: 404, description: 'Sequence does not exist or you don\'t have permission' })
  @ApiResponse({ status: 401, description: 'Not authenticated.' })
  @Permissions(PERMISSIONS.PROJECT_GET_ONE)
  async getById(@Param('id', new ParseIntPipe()) id: number, @User() authenticatedUser: AuthenticatedUserDto, @Param() params, @Pagination() pagination: PaginationModel) {
    logger.info('Get by id ', id);
    return await this.subprojectService.getById(id, pagination, { authenticatedUser, params });
  }

  @Post()
  @ApiOperation({
    title: 'Create subproject', description: `
    Create new subproject
  `, operationId: 'CreateSubproject',
  })
  @ApiImplicitParam({ name: 'projectId', description: 'Project the subproject belongs to', type: Number, required: true })
  @ApiResponse({ status: 200, description: 'Subproject has been successfully created', isArray: false, type: SubprojectsDto })
  @ApiResponse({ status: 400, description: 'Body contains errors' })
  @ApiResponse({ status: 401, description: 'Not authenticated.' })
  @Permissions(PERMISSIONS.DEPLOYMENT_CREATE)
  async create(@Body(new ValidationPipe()) createSubprojectDto: CreateSubprojectDto, @User() authenticatedUser: AuthenticatedUserDto, @Param() params) {
    logger.info('Creating subproject');
    return await this.subprojectService.create(createSubprojectDto, { authenticatedUser, params });
  }

  @Patch('/:id')
  @ApiOperation({
    title: 'Update subproject', description: `
    Update sequence
  `, operationId: 'UpdateSubproject',
  })
  @ApiImplicitParam({ name: 'id', description: 'Id of the sequence' })
  @ApiImplicitParam({ name: 'projectId', description: 'Project the deployment belongs to', type: Number, required: true })
  @ApiResponse({ status: 200, description: 'Subproject has been successfully updated', isArray: false, type: SubprojectsDto })
  @ApiResponse({ status: 404, description: 'Subproject does not exist or you don\'t have permission to edit it' })
  @ApiResponse({ status: 401, description: 'Not authenticated.' })
  @Permissions(PERMISSIONS.DEPLOYMENT_UPDATE)
  async update(@Param('id', new ParseIntPipe()) id: number, @Body(new ValidationPipe()) updateSubprojectDto: UpdateSubprojectDto, @User() authenticatedUser: AuthenticatedUserDto, @Param() params) {
    logger.info('Updating subproject');
    return await this.subprojectService.update(id, updateSubprojectDto, { authenticatedUser, params });
  }

  @Delete('/:id')
  @ApiOperation({
    title: 'Delete subproject', description: `
    Delete subproject
  `, operationId: 'DeleteSubproject',
  })
  @ApiImplicitParam({ name: 'id', description: 'Id of the subproject' })
  @ApiImplicitParam({ name: 'projectId', description: 'Project the subproject belongs to', type: Number, required: true })
  @ApiResponse({ status: 200, description: 'Subproject has been successfully deleted', isArray: false, type: SubprojectsDto })
  @ApiResponse({ status: 404, description: 'Subproject does not exist or you don\'t have permission' })
  @ApiResponse({ status: 401, description: 'Not authenticated.' })
  @Permissions(PERMISSIONS.DEPLOYMENT_DELETE)
  async remove(@Param('id', new ParseIntPipe()) id: number, @User() authenticatedUser: AuthenticatedUserDto, @Param() params) {
    logger.info('Deleting subproject');
    return await this.subprojectService.remove(id, { authenticatedUser, params });
  }
}
