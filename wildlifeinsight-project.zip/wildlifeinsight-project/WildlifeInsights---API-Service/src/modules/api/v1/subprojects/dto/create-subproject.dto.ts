import { ApiModelProperty } from '@nestjs/swagger';
import { IsString, MaxLength, IsOptional, IsInt, ValidateNested } from 'class-validator';

export class CreateSubprojectDto {
  @IsString()
  @MaxLength(255)
  @ApiModelProperty({ required: true, type: String, maxLength: 255 })
  name: string;

  @IsString()
  @IsOptional()
  @ApiModelProperty({ required: false, type: String })
  design: string;

  @ValidateNested()
  @IsOptional()
  @ApiModelProperty({ required: false })
  metadata: object;

}
