import { IsString, IsInt, IsNumber, IsOptional, MaxLength, IsISO8601, ValidateNested } from 'class-validator';
import { ApiModelProperty } from '@nestjs/swagger';

export class UpdateSubprojectDto {

  @IsString()
  @MaxLength(255)
  @IsOptional()
  @ApiModelProperty({ required: false, type: String, maxLength: 255 })
  name: string;

  @IsString()
  @IsOptional()
  @ApiModelProperty({ required: false, type: String })
  design: string;

  @ValidateNested()
  @IsOptional()
  @ApiModelProperty({ required: false })
  metadata: object;

}
