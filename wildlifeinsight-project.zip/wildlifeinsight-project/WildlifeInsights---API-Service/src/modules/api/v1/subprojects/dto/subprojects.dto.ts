import { ApiModelProperty } from '@nestjs/swagger';
import { SubprojectsDto } from 'modules/database/dto/subprojects.dto';
import { MetaDto } from 'modules/database/dto/meta.dto';

export class SubprojectsPaginatedDto {

  @ApiModelProperty({ type: SubprojectsDto, isArray: true })
  readonly data: SubprojectsDto[];

  @ApiModelProperty()
  readonly meta: MetaDto;

  constructor(data, totalItems: number, pageSize: number, page: number) {
    this.data = data;
    this.meta = new MetaDto(Math.ceil(totalItems / pageSize), totalItems, pageSize, page);
  }
}
