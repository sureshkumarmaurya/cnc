import { UpdateSubprojectDto } from './dto/update-subproject.dto';
import { CreateSubprojectDto } from './dto/create-subproject.dto';
import { Repository, SelectQueryBuilder } from 'typeorm';
import { Injectable, Inject, NotFoundException, BadRequestException, UnauthorizedException } from '@nestjs/common';
import { GenericService } from 'utils/generic.service';
import { InfoDto } from 'dto/info.dto';
import { Projects } from 'modules/database/entities/projects.entity';
import { Deployments } from 'modules/database/entities/deployments.entity';
import { Subprojects } from 'modules/database/entities/subprojects.entity';

@Injectable()
export class SubprojectService extends GenericService<Subprojects, CreateSubprojectDto, UpdateSubprojectDto>  {
  constructor(
    @Inject('SubprojectsRepositoryToken') private readonly subprojectsRepository: Repository<Subprojects>,
    @Inject('ProjectsRepositoryToken') private readonly projectsRepository: Repository<Projects>,
    @Inject('DeploymentsRepositoryToken') private readonly deploymentsRepository: Repository<Deployments>,
  ) {
    super(subprojectsRepository, 'subproject');
  }

  setFilters(query: SelectQueryBuilder<Subprojects>, filters: any, info: InfoDto) {
    if (info && info.params && info.params.projectId) {
      query.where('subproject.projectId = :projectId').setParameter('projectId', info.params.projectId);
    }
    return query;
  }

  async validateBeforeCreate(createModel: CreateSubprojectDto, info: InfoDto): Promise<void> {
  }

  async setDataCreate(create: CreateSubprojectDto, info: InfoDto) {
    const model = new Subprojects();
    model.name = create.name;
    model.design = create.design;
    model.metadata = create.metadata;
    model.project = await this.projectsRepository.findOne({ where: { id: info.params.projectId } });
    return model;
  }

  async setDataUpdate(model: Subprojects, update: UpdateSubprojectDto, info: InfoDto) {

    if (update.name !== undefined) {
      model.name = update.name;
    }
    if (update.design !== undefined) {
      model.design = update.design;
    }
    if (update.metadata !== undefined) {
      model.metadata = update.metadata;
    }
    return model;
  }

}
