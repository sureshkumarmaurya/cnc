import { SubprojectController, subprojectRelations } from './subproject.controller';
import { SubprojectService } from './subproject.service';
import { Module, RequestMethod, MiddlewareConsumer } from '@nestjs/common';
import { PaginationMiddleware } from 'middlewares/pagination.middleware';
import { DatabaseModule } from 'modules/database/database.module';

@Module({
  imports: [DatabaseModule],
  controllers: [SubprojectController],
  providers: [SubprojectService],
})

export class SubprojectModule {
  public configure(consumer: MiddlewareConsumer) {
    consumer
      .apply(PaginationMiddleware)
      .with({ includes: [], allowIncludes: subprojectRelations })
      .forRoutes(
        { path: '/api/v1/project/:projectId/subproject', method: RequestMethod.GET },
        { path: '/api/v1/project/:projectId/subproject/:id', method: RequestMethod.GET },
      );
  }
}
