import { Get, Controller, Param, Query } from '@nestjs/common';
import { ApiUseTags, ApiOperation, ApiResponse } from '@nestjs/swagger';

export const taxonomiesRelations = ['iucnCategory', 'commonNames'];

@Controller('/api/v1/health')
@ApiUseTags('APIHealth')
export class HealthController {
  @Get()
  @ApiOperation({
    title: 'Health check', description: 'Simple API health check: will return 200 if API is available.', operationId: 'APIHealthCheck',
  })
  @ApiResponse({ status: 200, description: 'API is ready' })
  async healthCheck() {
    return { ok: true };
  }
}
