import { HealthController } from './health.controller';
import { Module, RequestMethod, MiddlewareConsumer } from '@nestjs/common';
import { DatabaseModule } from 'modules/database/database.module';

@Module({
  imports: [DatabaseModule],
  controllers: [HealthController],
})
export class HealthModule {
  public configure(consumer: MiddlewareConsumer) {
    consumer
      .apply()
      .with()
      .forRoutes(
        { path: '/api/v1/health', method: RequestMethod.GET },
      );
  }
}
