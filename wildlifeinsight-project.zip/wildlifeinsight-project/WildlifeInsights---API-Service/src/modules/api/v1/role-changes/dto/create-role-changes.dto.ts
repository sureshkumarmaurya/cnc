import { ApiModelProperty } from '@nestjs/swagger';
import { IsString, IsInt, IsEmail } from 'class-validator';

type RoleChangeType = 'create' | 'update' | 'delete';

export class CreateRoleChangesDto {

  @IsEmail()
  email: string;

  @IsInt()
  organizationId: number | null;

  @IsInt()
  initiativeId: number | null;

  @IsInt()
  projectId: number | null;

  @IsInt()
  invitationInitiatorId: number | null;

  @IsString()
  role: string;

  changeType: RoleChangeType;

  @IsString()
  activationToken: string;

  @IsString()
  status: string;

  changeTimestamp: Date;
}
