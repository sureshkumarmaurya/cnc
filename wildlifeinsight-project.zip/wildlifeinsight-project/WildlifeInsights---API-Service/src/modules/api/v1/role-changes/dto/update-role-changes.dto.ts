import { ApiModelProperty } from '@nestjs/swagger';
import { IsString, IsInt } from 'class-validator';

export class UpdateRoleChangesDto {

  @IsInt()
  participantId: number;

  @IsString()
  status: string;

  changeTimestamp: Date;
}
