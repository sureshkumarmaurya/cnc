import { RoleChangesController } from './role-changes.controller';
import { Module } from '@nestjs/common';
import { RoleChangesService } from './role-changes.service';
import { DatabaseModule } from 'modules/database/database.module';

@Module({
  imports: [DatabaseModule],
  controllers: [RoleChangesController],
  providers: [RoleChangesService],
})

export class RoleChangesModule {

}
