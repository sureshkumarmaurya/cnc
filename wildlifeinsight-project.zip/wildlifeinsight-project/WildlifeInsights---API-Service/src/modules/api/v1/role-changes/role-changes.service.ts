import { Inject, BadRequestException, Injectable } from '@nestjs/common';
import { Repository } from 'typeorm';
import { CreateRoleChangesDto } from './dto/create-role-changes.dto';
import { UpdateRoleChangesDto } from './dto/update-role-changes.dto';
import { GenericService } from 'utils/generic.service';
import { RoleChanges } from 'modules/database/entities/role-changes.entity';
import { Participants } from 'modules/database/entities/participants.entity';
import { OrganizationParticipantPivot } from 'modules/database/entities/organization-participant-pivot.entity';
import { InitiativeParticipantPivot } from 'modules/database/entities/initiative-participant-pivot.entity';
import { ParticipantTypeProjectPivot } from 'modules/database/entities/participant-type-project-pivot.entity';
import { Organizations } from 'modules/database/entities/organizations.entity';
import { Initiatives } from 'modules/database/entities/initiatives.entity';
import { Projects } from 'modules/database/entities/projects.entity';
import { Roles } from 'modules/database/entities/roles.entity';
import { ParticipantTypes } from 'modules/database/entities/participant-types.entity';
import { UsersACLCache } from 'modules/database/entities/users-acl-cache.entity';
import { ROLES } from 'utils/roles.enum';
import { MailService } from 'utils/mail.utils';

const config = require('config');
const logger = require('logger');

type MailType = 'create' | 'change' | 'revoke';

@Injectable()
export class RoleChangesService extends GenericService<RoleChanges, CreateRoleChangesDto, UpdateRoleChangesDto>{

  constructor(
    @Inject('RoleChangesRepositoryToken') private readonly roleChangesRepository: Repository<RoleChanges>,
    @Inject('RolesRepositoryToken') private readonly rolesRepository: Repository<Roles>,
    @Inject('ParticipantsRepositoryToken') private readonly participantsRepository: Repository<Participants>,
    @Inject('OrganizationParticipantPivotRepositoryToken') private readonly organizationParticipantPivotRepository: Repository<OrganizationParticipantPivot>,
    @Inject('InitiativeParticipantPivotRepositoryToken') private readonly initiativeParticipantPivotRepository: Repository<InitiativeParticipantPivot>,
    @Inject('ParticipantTypeProjectPivotRepositoryToken') private readonly participantTypeProjectPivotRepository: Repository<ParticipantTypeProjectPivot>,
    @Inject('OrganizationsRepositoryToken') private readonly organizationsRepository: Repository<Organizations>,
    @Inject('InitiativesRepositoryToken') private readonly initiativesRepository: Repository<Initiatives>,
    @Inject('ProjectsRepositoryToken') private readonly projectsRepository: Repository<Projects>,
    @Inject('ParticipantTypesRepositoryToken') private readonly participantTypesRepository: Repository<ParticipantTypes>,
    @Inject('UsersACLCacheRepositoryToken') private readonly usersACLCacheRepository: Repository<UsersACLCache>,
  ) {
    super(roleChangesRepository, 'RoleChanges');
  }

  async setDataCreate(create: CreateRoleChangesDto) {
    const model = new RoleChanges();

    const participantId = await this.getParticipantId(create.email);
    const roleId = await this.getRoleId(create.role);

    if (roleId) { model.roleId = roleId; }

    if (participantId) {
      model.participantId = participantId;
    } else {
      model.email = create.email;
    }

    model.organizationId = create.organizationId;
    model.initiativeId = create.initiativeId;
    model.projectId = create.projectId;
    model.changeType = create.changeType;
    model.activationToken = create.activationToken;
    model.status = create.status;
    model.changeTimestamp = new Date();
    model.invitationInitiatorId = create.invitationInitiatorId;

    return model;
  }

  async validateBeforeCreate(create: CreateRoleChangesDto) {}

  async validateBeforeUpdate(id: number, update: UpdateRoleChangesDto) {}

  async setDataUpdate(model: RoleChanges, update: UpdateRoleChangesDto) {
    if (update.status) { model.status = update.status; }
    if (update.participantId) { model.participantId = update.participantId; }

    model.changeTimestamp = new Date();
    return model;
  }

  /**
   * actionAfterCreate
   * @description After create hook for RoleChanges service.
   * In this step, we can get role_changes records with and without active user.
   * If user doen't exist - just send invitation e-mail
   * If this user exist - create participant record flow (manageParticipantPivot func)
  */

  async actionAfterCreate(data) {
    if (data.participantId) {
      await this.manageParticipantPivot(data, true);
    } else {
      await this.sendMail(data, 'create');
    }
  }

  /**
   * actionAfterUpdate
   * @description After update hook for RoleChanges service.
   * If this user exists but role_changes.status still new.
   * (in case, when user will create an account after invitation)
   * create participant record flow (manageParticipantPivot func).
  */
  async actionAfterUpdate(data) {
    const recordTimestamp = new Date(data.changeTimestamp);
    const current = new Date();
    const diff = Math.ceil((current.getTime() - recordTimestamp.getTime()) / 3600000);
    const roleChangeRequestExpirationInHours = config.get('roleChangeRequestExpirationInHours');

    if (
      data.participantId &&
      data.status === 'new' &&
      (roleChangeRequestExpirationInHours > diff)
    ) { await this.manageParticipantPivot(data, false); }
  }

  async getRoleId(role) {
    try {
      const { id } = await this.rolesRepository.findOne({ where: { slug: ROLES[role] } });
      return id;
    } catch (err) {
      logger.error(`Get role id error. Role: ${role}`, err);
      return false;
    }
  }

  async getRoleString (roleId) {
    const { slug } = await this.rolesRepository.findOne(roleId);
    return slug.split('_')[1];
  }

  async getParticipantId(email) {
    try {
      const { id } = await this.participantsRepository.findOne({ where: { email } });
      return id;
    } catch (err) {
      logger.error(`Get participant error. Email: ${email}`, err);
      return false;
    }
  }

  async getParticipantData(id) {
    return await this.participantsRepository.findOne(id);
  }

  /**
   * manageParticipantPivot
   * @description Participant Pivot flow (only for exist users).
   * - Detect entity type. (organization, initiative, project)
   * - Manage entity_participant_pivot record. (create, update, delete)
   * - Send info mail. (create, change, revoke)
   * - Deactivate role_changes record. (status="old")
  */

  async manageParticipantPivot(data, mail: boolean) {

    const entityType = this.getEntityType(data);
    const idField = `${entityType}Id`;

    const {
      id,
      [idField]: entityId,
      roleId,
      participantId,
      changeType,
    } = data;

    let model;
    let repository;

    if (entityType === 'organization') {
      model = new OrganizationParticipantPivot();
      repository = this.organizationParticipantPivotRepository;
    }
    if (entityType === 'initiative') {
      model = new InitiativeParticipantPivot();
      repository = this.initiativeParticipantPivotRepository;
    }
    if (entityType === 'project') {
      model = new ParticipantTypeProjectPivot();
      repository = this.participantTypeProjectPivotRepository;
      model.participantTypeId = await this.getPrincipalInvestigatorTypeId();
    }

    model[idField] = entityId;
    model.participantId = participantId;
    model.roleId = roleId;

    const entityPivot = await repository.findOne({ where: { participantId, [idField]: entityId } });

    try {
      switch (changeType) {
        case 'create':
          /**
           * If the change being requested is to create a new role on an entity
           * for a user who already has a role on it, we do nothing, *except* in
           * the case described below.
           *
           * If the change being requested is:
           * * to *create* a new role (vs changing or revoking a role)
           * * on a *project* or *initiative* (not on an organization)
           * * for a user who already has an *implicit* role on the project or initiative
           *
           * then we need to:
           * * delete the existing implicit role, and
           * * let the creation of the new explicit role proceed
           */
          if ((entityType === 'project' || entityType === 'initiative') && entityPivot && entityPivot.isImplicit) {
            await repository.remove(entityPivot);
          } else if (entityPivot) {
            break;
          }
          await repository.save(model);
          if (mail) { await this.sendMail(data, 'create'); }
          break;
        case 'update':
          const mailData = { ...data, oldRoleId: entityPivot.roleId };
          await repository.remove(entityPivot);
          await repository.save(model);
          if (mail) { await this.sendMail(mailData, 'change'); }
          break;
        case 'delete':
          await repository.remove(entityPivot);
          await this.sendMail(data, 'revoke');
          break;
      }

      await this.deactivateRoleChangesItem(id);
    } catch (error) {
      logger.error('Role change request failed', error);
    }

    // clear ACL cache for this user, as their roles and permissions may have changed
    logger.info(`Clearing ACL cache for user ${participantId}`);
    await this.usersACLCacheRepository.delete({ userId: participantId });
  }

  /**
   * sendMail
   * @description Send mail for participants about entity membership changes
  */
  async sendMail(data, type: MailType) {

    const { invitationInitiatorId, activationToken } = data;
    const mailService = new MailService();
    let messageData = {};
    const apiUrl = config.get('auth.apiServiceUrl');
    const entity = this.getEntityType(data);

    let participantEmail;
    try {
      participantEmail = (data.email) ? data.email :  await this.getParticipantData(data.participantId);
    } catch (err) {
      logger.error('Send mail error. Get participant data: ', err);
    }

    if (type === 'revoke') {
      try {
        const { name: entityName } = await this.getEntityData(data);
        messageData = { entity, entityName };
        await mailService.sendTransactionalEmail(messageData, [{ address: participantEmail }], 'wi-revoke-access');
      } catch (err) {
        logger.error('Send mail error: ', err);
        return;
      }
    }

    if (type === 'create') {
      try {
        const { name: entityName } = await this.getEntityData(data);
        const { firstName, lastName, email: initiatorEmail } = await this.getParticipantData(invitationInitiatorId);
        const name = (firstName && lastName) ? `${firstName} ${lastName}` : 'A user';
        const role = await this.getRoleString(data.roleId);
        const apiLink = `${apiUrl}/api/v1/invitation?token=${encodeURIComponent(activationToken)}`;

        const roleChangeRequestExpirationInHours = config.get('roleChangeRequestExpirationInHours');
        messageData = { name, initiatorEmail, role, entity, entityName, apiLink, expiration: `${roleChangeRequestExpirationInHours}h` };
        const template = (data.participantId) ? 'invitation' : 'wi-non-user-invitation';
        await mailService.sendTransactionalEmail(messageData, [{ address: participantEmail }], template);

      } catch (err) {
        logger.error('Send mail error: ', err);
      }
    }

    if (type === 'change') {
      try {
        const { name: entityName, id: entityId } = await this.getEntityData(data);
        const { firstName, lastName, email: initiatorEmail } = await this.getParticipantData(invitationInitiatorId);
        const name = (firstName && lastName) ? `${firstName} ${lastName}` : 'A user';

        const newRole = await this.getRoleString(data.roleId);
        const oldRole = await this.getRoleString(data.oldRoleId);
        const entityUrl = `${apiUrl}/manage/${entity}/${entityId}`;

        messageData = { name, initiatorEmail, oldRole, newRole, entity, entityName, entityUrl };
        await mailService.sendTransactionalEmail(messageData, [{ address: participantEmail }], 'wi-role-change');
      } catch (err) {
        logger.error('Send mail error: ', err);
      }
    }
  }

  async deactivateRoleChangesItem(id) {
    const updateRoleChangesDto = new UpdateRoleChangesDto();
    updateRoleChangesDto.status = 'old';

    try {
      await this.update(id, updateRoleChangesDto);
    } catch (err) {
      logger.error('Error deactivate role_changes record', err);
    }

  }

  async getEntityData(data) {
    const entityType = this.getEntityType(data);
    const idField = `${entityType}Id`;
    const entityId = data[idField];

    let repository;

    if (entityType === 'organization') {
      repository = this.organizationsRepository;
    }
    if (entityType === 'initiative') {
      repository = this.initiativesRepository;
    }
    if (entityType === 'project') {
      repository = this.projectsRepository;
    }

    return await repository.findOne(entityId);
  }

  async getPrincipalInvestigatorTypeId () {
    try {
      const { id } = await this.participantTypesRepository.findOne({ where: { name: 'PRINCIPAL INVESTIGATOR' } });
      return id;
    } catch (err) {
      logger.error('Get principal investigator type id error', err);
      return false;
    }
  }

  getEntityType(data) {
    const entities = ['organization', 'project', 'initiative'];
    return entities.find(item => data[`${item}Id`]);
  }
}
