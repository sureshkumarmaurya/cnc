import { Controller, Get, Body, ValidationPipe, Query, Res } from '@nestjs/common';
import { ApiOperation, ApiImplicitQuery, ApiUseTags } from '@nestjs/swagger';
import { CryptoUtils } from 'utils/crypto.utils';
import { RoleChangesService } from './role-changes.service';

const config = require('config');
const logger = require('logger');

@Controller('/api/v1')
@ApiUseTags('RoleChanges')
export class RoleChangesController {
  constructor(private readonly roleChangesService: RoleChangesService) { }

  @Get('/invitation')
  @ApiOperation({
    title: 'Invitation proxy',
    description: 'Check invitation token and redirect user to join page if they don\'t have an account',
    operationId: 'Invitation',
  })
  @ApiImplicitQuery({ name: 'token', description: 'Link token for user detection', type: String, required: true })
  async redirect(@Query() filters, @Res() res) {
    const { token } = filters;
    const email = CryptoUtils.decrypt(token);

    const dashboardUrl = config.get('dashboardUrl');

    try {
      await this.roleChangesService.getParticipantId(email);
      return res.redirect(dashboardUrl);
    } catch (e) {
      return res.redirect(`${dashboardUrl}/join`); // user doesn't have an account
    }
  }

}
