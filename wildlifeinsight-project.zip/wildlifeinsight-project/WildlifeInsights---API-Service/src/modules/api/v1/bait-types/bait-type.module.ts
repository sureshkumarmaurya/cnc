import { DatabaseModule } from 'modules/database/database.module';
import { BaitTypeController, baitTypesRelations } from './bait-type.controller';
import { BaitTypeService } from './bait-type.service';
import { Module, RequestMethod, MiddlewareConsumer } from '@nestjs/common';
import { PaginationMiddleware } from 'middlewares/pagination.middleware';
import { BaitTypeResolver } from './bait-type.resolver';

@Module({
  imports: [DatabaseModule],
  controllers: [BaitTypeController],
  providers: [BaitTypeService, BaitTypeResolver],
})
export class BaitTypeModule {
  public configure(consumer: MiddlewareConsumer) {
    consumer
      .apply(PaginationMiddleware)
      .with({ includes: [], allowIncludes: baitTypesRelations })
      .forRoutes({ path: '/api/v1/bait-type*', method: RequestMethod.GET });
  }
}
