import { IsString, IsOptional, MaxLength } from 'class-validator';

export class CreateBaitTypeDto {

  @IsString()
  @MaxLength(255)
  typeName: string;

  @IsString()
  @MaxLength(255)
  schedule: string;

  @IsString()
  @MaxLength(255)
  scheme: string;

  @IsString()
  @IsOptional()
  description: string | null;
}
