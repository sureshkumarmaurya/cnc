import { IsString, IsInt, IsEmail, IsIn, IsNumber, IsBoolean, IsArray, IsOptional, IsIP, MaxLength, IsUrl } from 'class-validator';

export class UpdateBaitTypeDto {

  @IsString()
  @MaxLength(255)
  @IsOptional()
  typeName: string;

  @IsString()
  @MaxLength(255)
  @IsOptional()
  schedule: string;

  @IsString()
  @MaxLength(255)
  @IsOptional()
  scheme: string;

  @IsString()
  @IsOptional()
  description: string | null;
}
