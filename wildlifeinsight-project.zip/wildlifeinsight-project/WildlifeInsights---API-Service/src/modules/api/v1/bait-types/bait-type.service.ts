import { Inject, BadRequestException, Injectable } from '@nestjs/common';
import { Repository } from 'typeorm';
import { BaitTypes } from '../../../database/entities/bait-types.entity';
import { CreateBaitTypeDto } from './dto/create-bait-type.dto';
import { UpdateBaitTypeDto } from './dto/update-bait-type.dto';
import { GenericService } from 'utils/generic.service';

@Injectable()
export class BaitTypeService extends GenericService<BaitTypes, CreateBaitTypeDto, UpdateBaitTypeDto>{

  constructor(
    @Inject('BaitTypesRepositoryToken') private readonly baitTypeRepository: Repository<BaitTypes>,
  ) {
    super(baitTypeRepository, 'baittype');
  }

  async setDataCreate(create: CreateBaitTypeDto) {

    const model = new BaitTypes();
    model.schedule = create.schedule;
    model.scheme = create.scheme;
    model.typeName = create.typeName;
    model.description = create.description;
    return model;

  }

  async validateBeforeCreate(create: CreateBaitTypeDto) {
    const count = await this.baitTypeRepository.count({ where: { typeName: create.typeName } });
    if (count > 0) {
      throw new BadRequestException(`Type Name: ${create.typeName} is not unique`);
    }
  }

  async validateBeforeUpdate(id: number, create: UpdateBaitTypeDto) {
    const count = await this.baitTypeRepository.count({ where: { typeName: create.typeName } });
    if (count > 0) {
      throw new BadRequestException(`Type Name: ${create.typeName} is not unique`);
    }
  }

  async setDataUpdate(model: BaitTypes, update: UpdateBaitTypeDto) {
    if (update.description !== undefined) {
      model.description = update.description;
    }
    if (update.schedule !== undefined) {
      model.schedule = update.schedule;
    }
    if (update.scheme !== undefined) {
      model.scheme = update.scheme;
    }
    if (update.typeName !== undefined) {
      model.typeName = update.typeName;
    }
    return model;
  }
}
