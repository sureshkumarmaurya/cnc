import { CreateBaitTypeDto } from './dto/create-bait-type.dto';
import { BaitTypeService } from './bait-type.service';
import { Resolver, Query, ResolveProperty, Mutation, Subscription, Context, GqlExecutionContext, Args } from '@nestjs/graphql';
import { UpdateBaitTypeDto } from './dto/update-bait-type.dto';
import { UseInterceptors, UseGuards, createParamDecorator } from '@nestjs/common';
import { GraphqlAuthGuard } from 'guards/graphql-passport.guard';
import { ValidationGraphqlInterceptor } from 'interceptors/validation-graphql.interceptor';
import { PaginationGraphqlInterceptor } from 'interceptors/pagination-graphql.interceptor';
import { User } from 'decorators/user.decorator';
import { BaitTypesPaginatedDto } from './dto/bait-types.dto';
import { GraphqlUserWithPermissions } from 'decorators/graphql-user.decorator';
import { PERMISSIONS } from 'utils/permissions.enum';
import { Permissions } from 'decorators/permissions.decorator';

const logger = require('logger');

@Resolver('BaitType')
export class BaitTypeResolver {
  constructor(private readonly baitTypeService: BaitTypeService) {}

  @Query()
  @UseGuards(GraphqlAuthGuard)
  @UseInterceptors(PaginationGraphqlInterceptor)
  async getBaitTypes(@User() authenticatedUser, @Args() args) {
    logger.debug('user', authenticatedUser);
    const data = await this.baitTypeService.findAll(args.pagination,  { authenticatedUser, params: args });
    return new BaitTypesPaginatedDto(data[0], data[1], args.pagination.pageSize, args.pagination.pageNumber);
  }

  @Query()
  @UseGuards(GraphqlAuthGuard)
  async getBaitType(@Args() args, @User() authenticatedUser) {
    logger.debug('Get bait type', args);
    const { id } = args;
    const data = await this.baitTypeService.getById(id, {},  { authenticatedUser, params: args });
    logger.debug('Data', data);
    return data;
  }

  @Mutation()
  @UseGuards(GraphqlAuthGuard)
  @UseInterceptors(new ValidationGraphqlInterceptor(CreateBaitTypeDto))
  async createBaitType(@Args() args, @GraphqlUserWithPermissions(PERMISSIONS.PERFORM_API_ADMIN_OPERATIONS) authenticatedUser) {
    const { body } = args;
    return this.baitTypeService.create(body, { authenticatedUser, params: args });
  }

  @Mutation()
  @UseGuards(GraphqlAuthGuard)
  @UseInterceptors(new ValidationGraphqlInterceptor(UpdateBaitTypeDto))
  async updateBaitType(@Args() args, @GraphqlUserWithPermissions(PERMISSIONS.PERFORM_API_ADMIN_OPERATIONS) authenticatedUser) {
    const { id, body } = args;
    return this.baitTypeService.update(id, body, { authenticatedUser, params: args });
  }

  @Mutation()
  @UseGuards(GraphqlAuthGuard)
  async deleteBaitType(@Args() args, @GraphqlUserWithPermissions(PERMISSIONS.PERFORM_API_ADMIN_OPERATIONS) authenticatedUser) {
    const { id } = args;
    return this.baitTypeService.remove(id, { authenticatedUser, params: args });
  }

}
