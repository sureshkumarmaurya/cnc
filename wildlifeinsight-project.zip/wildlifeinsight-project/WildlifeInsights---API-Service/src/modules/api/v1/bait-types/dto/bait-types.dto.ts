import { ApiModelProperty } from '@nestjs/swagger';
import { BaitTypesDto } from 'modules/database/dto/bait-types.dto';
import { MetaDto } from 'modules/database/dto/meta.dto';

export class BaitTypesPaginatedDto {

  @ApiModelProperty({ type: BaitTypesDto, isArray: true })
  readonly data: BaitTypesDto[];

  @ApiModelProperty()
  readonly meta: MetaDto;

  constructor(data, totalItems: number, pageSize: number, page: number) {
    this.data = data;
    this.meta = new MetaDto(Math.ceil(totalItems / pageSize), totalItems, pageSize, page);
  }
}
