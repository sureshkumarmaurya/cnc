import { UpdateBaitTypeDto } from './dto/update-bait-type.dto';
import { CreateBaitTypeDto } from './dto/create-bait-type.dto';
import { Get, Controller, Req, Post, Body, Patch, Param, Delete, ParseIntPipe, UseGuards } from '@nestjs/common';
import { BaitTypeService } from './bait-type.service';
import { ApiUseTags, ApiBearerAuth, ApiOperation, ApiResponse, ApiImplicitQuery, ApiImplicitParam } from '@nestjs/swagger';
import { BaitTypesPaginatedDto } from './dto/bait-types.dto';
import { Pagination } from 'decorators/pagination.decorator';
import { ValidationPipe } from 'pipes/validation.pipe';
import { BaitTypesDto } from 'modules/database/dto/bait-types.dto';
import { User } from 'decorators/user.decorator';
import { AuthenticatedUserDto } from 'dto/authenticated-user.dto';
import { PaginationModel } from 'utils/pagination.model';
import { PermissionsGuard } from 'guards/permissions.guard';
import { PERMISSIONS } from 'utils/permissions.enum';
import { Permissions } from 'decorators/permissions.decorator';

const logger = require('logger');

export const baitTypesRelations = [];

@Controller('/api/v1/bait-type')
@ApiUseTags('BaitTypes')
@ApiBearerAuth()
@UseGuards(PermissionsGuard)
export class BaitTypeController {
  constructor(private readonly baitTypeService: BaitTypeService) { }

  @Get()
  @ApiOperation({
    title: 'Get BaitTypes', description: `
    Get all bait types
  `, operationId: 'GetAllBaitTypes',
  })
  @ApiResponse({ status: 200, description: 'BaitTypes have been successfully returned', isArray: false, type: BaitTypesPaginatedDto })
  @ApiResponse({ status: 403, description: 'Not authorized.' })
  @ApiResponse({ status: 401, description: 'Not authenticated.' })
  @ApiImplicitQuery({
    name: 'includes', description: `
  Allows include the BaitTypes's relations. Available ${baitTypesRelations}
  `, type: String, required: false,
  })
  @ApiImplicitQuery({ name: 'fields', description: 'BaitTypes\'s fields to select', type: String, required: false })
  @ApiImplicitQuery({ name: 'page[size]', description: 'Page size. Default 10', type: String, required: false })
  @ApiImplicitQuery({ name: 'page[number]', description: 'Page number', type: String, required: false })
  @ApiImplicitQuery({ name: 'sort', description: 'Sort results', type: String, required: false })

  async findAll(@Pagination() pagination: PaginationModel, @Param() params, @User() authenticatedUser: AuthenticatedUserDto) {
    logger.info('Getting all bait types');
    const data = await this.baitTypeService.findAll(pagination, { authenticatedUser, params });
    return new BaitTypesPaginatedDto(data[0], data[1], pagination.pageSize, pagination.pageNumber);
  }

  @Get('/:id')
  @ApiOperation({
    title: 'Get bait type by id', description: `
    Get bait type by id
  `, operationId: 'GetBaitTypeById',
  })
  @ApiImplicitParam({ name: 'id', description: 'Id of the organization' })
  @ApiImplicitQuery({
    name: 'includes', description: `
  Allows include the BaitTypes's relations. Available ${baitTypesRelations}
  `, type: String, required: false,
  })
  @ApiResponse({ status: 200, description: 'BaitType has been successfully returned', isArray: false, type: BaitTypesDto })
  @ApiResponse({ status: 404, description: 'BaitType does not exist or you don\'t have permission' })
  @ApiResponse({ status: 401, description: 'Not authenticated.' })
  async getById(@Param('id', new ParseIntPipe()) id: number, @User() authenticatedUser: AuthenticatedUserDto, @Param() params, @Pagination() pagination: PaginationModel) {
    logger.info('Get by id ', id);
    return await this.baitTypeService.getById(id, pagination, { authenticatedUser, params });
  }

  @Post()
  @ApiOperation({
    title: 'Create bait type', description: `
    Create new bait type
  `, operationId: 'CreateBaitType',
  })
  @ApiResponse({ status: 200, description: 'BaitType has been successfully created', isArray: false, type: BaitTypesDto })
  @ApiResponse({ status: 400, description: 'Body contains errors' })
  @ApiResponse({ status: 401, description: 'Not authenticated.' })
  @Permissions(PERMISSIONS.PERFORM_API_ADMIN_OPERATIONS)
  async create(@Body(new ValidationPipe()) createBaitTypeDto: CreateBaitTypeDto, @User() authenticatedUser: AuthenticatedUserDto, @Param() params) {
    logger.info('Creating bait type');
    return await this.baitTypeService.create(createBaitTypeDto, { authenticatedUser, params });
  }

  @Patch('/:id')
  @ApiOperation({
    title: 'Update bait type', description: `
    Update bait type
  `, operationId: 'UpdateBaitType',
  })
  @ApiImplicitParam({ name: 'id', description: 'Id of the bait type' })
  @ApiResponse({ status: 200, description: 'BaitType has been successfully updated', isArray: false, type: BaitTypesDto })
  @ApiResponse({ status: 404, description: 'BaitType does not exist or you don\'t have permission' })
  @ApiResponse({ status: 401, description: 'Not authenticated.' })
  @Permissions(PERMISSIONS.PERFORM_API_ADMIN_OPERATIONS)
  async update(@Param('id', new ParseIntPipe()) id: number, @Body(new ValidationPipe()) updateBaitTypeDto: UpdateBaitTypeDto, @User() authenticatedUser: AuthenticatedUserDto, @Param() params) {
    logger.info('Updating bait type');
    // TODO: Add security
    return await this.baitTypeService.update(id, updateBaitTypeDto, { authenticatedUser, params });
  }

  @Delete('/:id')
  @ApiOperation({
    title: 'Delete bait type', description: `
    Delete bait type
  `, operationId: 'DeleteBaitType',
  })
  @ApiImplicitParam({ name: 'id', description: 'Id of the bait type' })
  @ApiResponse({ status: 200, description: 'BaitType has been successfully deleted', isArray: false, type: BaitTypesDto })
  @ApiResponse({ status: 404, description: 'BaitType does not exist or you don\'t have permission' })
  @ApiResponse({ status: 401, description: 'Not authenticated.' })
  @Permissions(PERMISSIONS.PERFORM_API_ADMIN_OPERATIONS)
  async remove(@Param('id', new ParseIntPipe()) id: number, @User() authenticatedUser: AuthenticatedUserDto, @Param() params) {
    logger.info('Deleting bait type');
    return await this.baitTypeService.remove(id, { authenticatedUser, params });
  }
}
