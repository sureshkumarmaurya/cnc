import { IsOptional, ValidateNested } from 'class-validator';
import { ApiModelProperty } from '@nestjs/swagger';

export class UpdateDataFileDto {
  highlighted: boolean;

  @ValidateNested()
  @IsOptional()
  @ApiModelProperty({ required: false })
  metadata: object;
}
