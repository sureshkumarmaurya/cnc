export class CreateDataFileDto {

  deploymentId: number;

  dataFileId: string;

  originalLocationUrl: string;

  localPath: string;

  fileName: string;

  size: string;

  mimetype: string;

  sequenceId: number;

  position: number;

  timestamp: Date;

  noCV: boolean;
}
