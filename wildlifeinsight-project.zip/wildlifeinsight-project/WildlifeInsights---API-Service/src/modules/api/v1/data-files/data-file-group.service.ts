import { Injectable } from '@nestjs/common';
import { DataFiles } from 'modules/database/entities/data-files.entity';
import { IDataFileGroup, IDataFileIndexed } from './data-file-group.interface';

@Injectable()
export class DataFileGroupService {
  private _limit: { min: number, max: number };

  constructor() {
    this._limit = {
      min: 0,
      max: 120,
    };
  }

  private filterTimeStep(timeStep) {

    if (timeStep < this._limit.min) {
      return this._limit.min;
    }

    if (timeStep > this._limit.max) {
      return this._limit.max;
    }

    return timeStep;
  }

  private getTimeDiff(prevDataFile, nextDataFile) {
    const previousDate = prevDataFile.timestamp || prevDataFile.createdAt;
    const nextDate = nextDataFile.timestamp || nextDataFile.createdAt;
    return (previousDate.getTime() - nextDate.getTime()) / 1000;
  }

  private setInitialSortIndex([...inputArray]) {
    return inputArray.map((item, index) => {
      item.indexInitial = index;
      return item;
    });
  }

  private prepareDataFileList([...inputArray]: DataFiles[]) {
    return this
      .setInitialSortIndex(inputArray)
      .sort((a, b) => { return a.timestamp - b.timestamp; });
  }

  private groupDataFileList([...inputArray]: IDataFileIndexed[], timeStep: number): IDataFileGroup[] {

    const output: IDataFileGroup[] = [];
    const dataFileListLength: number = inputArray.length;
    let groupIndex: number = 0;

    if (timeStep === 0) {
      return inputArray.map((singleDataFile) => {
        const item = { name: groupIndex, data: [singleDataFile] };
        groupIndex++;
        return item;
      });
    }

    output[groupIndex] = { name: groupIndex, data: [inputArray[groupIndex]] };

    for (let index: number = 0; index < dataFileListLength; index++) {
      const currentDataFile: IDataFileIndexed = inputArray[index];
      const nextDataFile: IDataFileIndexed = inputArray[index + 1];

      if (nextDataFile) {
        if (this.getTimeDiff(nextDataFile, currentDataFile) > timeStep) {
          groupIndex++;
          output[groupIndex] = { name: groupIndex, data: [] };
        }
        output[groupIndex].data.push(nextDataFile);
      }
    }

    return output;
  }

  public groupByTimeStep(timeStep: number = 0, dataFileList: DataFiles[]): IDataFileGroup[] {
    const dataFileListLength: number = dataFileList.length;
    let mappedList: IDataFileIndexed[] = [];

    if (!dataFileListLength) {
      return [];
    }

    const timeStampFiltered = this.filterTimeStep(timeStep);

    mappedList = this.prepareDataFileList(dataFileList);

    return this
      .groupDataFileList(mappedList, timeStampFiltered)
      .map((item) => {
        item.data.sort((prev: IDataFileIndexed, next: IDataFileIndexed) => { return prev.indexInitial - next.indexInitial; });
        return item;
      })
      .sort((prev: IDataFileGroup, next: IDataFileGroup) => {
        return prev.data[0].indexInitial - next.data[0].indexInitial;
      });

  }
}
