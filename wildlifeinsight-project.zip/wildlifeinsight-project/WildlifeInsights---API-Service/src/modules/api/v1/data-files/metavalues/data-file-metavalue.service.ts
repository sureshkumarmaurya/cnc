import { UpdateDataFileMetavalueDto } from './dto/update-data-file-metavalue.dto';
import { CreateDataFileMetavalueDto } from './dto/create-data-file-metavalue.dto';
import { DataFileMetavalues } from 'modules/database/entities/data-file-metavalues.entity';
import { Repository, SelectQueryBuilder } from 'typeorm';
import { Injectable, Inject, NotFoundException, BadRequestException, UnauthorizedException } from '@nestjs/common';
import { GenericService } from 'utils/generic.service';
import { InfoDto } from 'dto/info.dto';
import { Organizations } from 'modules/database/entities/organizations.entity';
import { Devices } from 'modules/database/entities/devices.entity';
import { DataFileMetakeys } from 'modules/database/entities/data-file-metakeys.entity';

const logger = require('logger');

@Injectable()
export class DataFileMetavalueService extends GenericService<DataFileMetavalues, CreateDataFileMetavalueDto, UpdateDataFileMetavalueDto>  {

  constructor(
    @Inject('DataFileMetavaluesRepositoryToken') private readonly dataFileMetavaluesRepository: Repository<DataFileMetavalues>,
    @Inject('DataFileMetakeysRepositoryToken') private readonly dataFileMetakeysRepository: Repository<DataFileMetakeys>,
  ) {
    super(dataFileMetavaluesRepository, 'dataFileMetavalue');
  }

  setFilters(query: SelectQueryBuilder<DataFileMetavalues>, filters: any, info: InfoDto) {
    query.innerJoin('dataFileMetavalue.dataFile', 'dataFile')
    .innerJoin('dataFile.deployment', 'deployment')
    .andWhere('dataFile.id = :dataFileId')
    .andWhere('deployment.id = :deploymentId')
    .andWhere('deployment.projectId = :projectId')
    .setParameters({
      deploymentId: info.params.deploymentId,
      dataFileId: info.params.dataFileId,
      projectId: info.params.projectId,
    });

    return query;
  }

  setFiltersGetById(query: SelectQueryBuilder<DataFileMetavalues>, info: InfoDto) {
    query.innerJoin('dataFileMetavalue.dataFile', 'dataFile')
    .innerJoin('dataFile.deployment', 'deployment')
    .andWhere('dataFile.id = :dataFileId')
    .andWhere('deployment.id = :deploymentId')
    .andWhere('deployment.projectId = :projectId')
    .setParameters({
      deploymentId: info.params.deploymentId,
      dataFileId: info.params.dataFileId,
      projectId: info.params.projectId,
    });
    return query;
  }

  setFiltersDelete(query: SelectQueryBuilder<DataFileMetavalues>, info: InfoDto) {
    query.innerJoin('dataFileMetavalue.dataFile', 'dataFile')
    .innerJoin('dataFile.deployment', 'deployment')
    .andWhere('dataFile.id = :dataFileId')
    .andWhere('deployment.id = :deploymentId')
    .andWhere('deployment.projectId = :projectId')
    .setParameters({
      deploymentId: info.params.deploymentId,
      dataFileId: info.params.dataFileId,
      projectId: info.params.projectId,
    });
    return query;
  }

  setFiltersUpdate(query: SelectQueryBuilder<DataFileMetavalues>, info: InfoDto) {
    query.innerJoin('dataFileMetavalue.dataFile', 'dataFile')
    .innerJoin('dataFile.deployment', 'deployment')
    .andWhere('dataFile.id = :dataFileId')
    .andWhere('deployment.id = :deploymentId')
    .andWhere('deployment.projectId = :projectId')
    .setParameters({
      deploymentId: info.params.deploymentId,
      dataFileId: info.params.dataFileId,
      projectId: info.params.projectId,
    });
    return query;
  }

  async getDataFileMetakeyById(id: number): Promise<DataFileMetakeys> {
    return this.dataFileMetakeysRepository.findOne(id);
  }

  async validateBeforeCreate(createModel: CreateDataFileMetavalueDto, info: InfoDto): Promise<void> {
    logger.debug('Validating datafilemetakey');

    const count = await this.dataFileMetakeysRepository.createQueryBuilder('dataFileMetakey')
    .innerJoin('dataFileMetakey.mediaTypes', 'mediaType')
    .innerJoin('mediaType.dataFiles', 'dataFile')
    .where('dataFile.id = :dataFileId')
    .andWhere('dataFileMetakey.id = :dataFileMetakeyId')
    .setParameters({
      dataFileId: info.params.dataFileId,
      dataFileMetakeyId: createModel.keyId,
    }).getCount();
    if (count === 0) {
      throw new NotFoundException('Data file metakey not found');
    }
  }

  async setDataCreate(create: CreateDataFileMetavalueDto, info: InfoDto) {

    const model = new DataFileMetavalues();
    model.dataFileId = info.params.dataFileId;
    model.keyId = create.keyId;
    model.value = create.value;
    model.remarks = create.remarks;

    return model;

  }

  async setDataUpdate(model: DataFileMetavalues, update: UpdateDataFileMetavalueDto, info: InfoDto) {

    if (update.value !== undefined) {
      model.value = update.value;
    }
    if (update.remarks !== undefined) {
      model.remarks = update.remarks;
    }

    return model;
  }

}
