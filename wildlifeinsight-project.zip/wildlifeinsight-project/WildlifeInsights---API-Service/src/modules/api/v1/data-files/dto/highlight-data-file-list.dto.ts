export class HighlightDataFileListDto {
  highlighted: boolean;
  dataFileIdList: number[];
}
