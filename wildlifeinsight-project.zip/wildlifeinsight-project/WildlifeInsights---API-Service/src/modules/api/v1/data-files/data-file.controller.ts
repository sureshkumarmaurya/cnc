import { Permissions } from 'decorators/permissions.decorator';
import { UpdateDataFileDto } from './dto/update-data-file.dto';
import { CreateDataFileDto } from './dto/create-data-file.dto';
import { HighlightDataFileListDto } from './dto/highlight-data-file-list.dto';
import { Get, Controller, Req, Post, Body, Patch, Param, Delete, ParseIntPipe, UseGuards, UseInterceptors, FileInterceptor, UploadedFile, Query, BadRequestException } from '@nestjs/common';
import { DataFileService } from './data-file.service';
import { ApiUseTags, ApiBearerAuth, ApiOperation, ApiResponse, ApiImplicitQuery, ApiImplicitParam, ApiImplicitBody } from '@nestjs/swagger';
import { DataFilesPaginatedDto } from './dto/data-files.dto';
import { Pagination } from 'decorators/pagination.decorator';
import { ValidationPipe } from 'pipes/validation.pipe';
import { DataFilesDto } from 'modules/database/dto/data-files.dto';
import { PermissionsGuard } from 'guards/permissions.guard';
import { User } from 'decorators/user.decorator';
import { AuthenticatedUserDto } from 'dto/authenticated-user.dto';
import { PERMISSIONS } from 'utils/permissions.enum';
import * as multer from 'multer';
import * as uuid from 'uuid/v4';
import { UploadUrlDto } from './dto/upload-url.dto';
import { ParseDateRequiredPipe } from 'pipes/parse-date-required.pipe';
import { ParseIntRequiredPipe } from 'pipes/parse-int-required.pipe';
import { ParseBoolPipe } from 'pipes/parse-bool.pipe';
import { DataFileInterceptor } from 'interceptors/data-file.interceptor';
import { PaginationModel } from 'utils/pagination.model';

const logger = require('logger');

export const dataFilesRelations = ['deployment', 'participant', 'exifDataFilePivots', 'exifDataFilePivots.exifTag', 'mediaTypes', 'dataFileMetavalues', 'dataFileMetavalues.key', 'identificationOutputs'];

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, '/tmp');
  },
  filename: (req, file, cb) => {
    const parts = file.originalname.split('.');

    cb(null, `${uuid()}.${parts[parts.length - 1]}`);
  },
});

@Controller('/api/v1/project/:projectId')
@ApiUseTags('DataFiles')
@ApiBearerAuth()
@UseGuards(PermissionsGuard)
export class DataFileController {
  constructor(private readonly dataFileService: DataFileService) { }

  @Get('/deployment/:deploymentId/data-file')
  @ApiOperation({
    title: 'Get DataFiles by deployment', description: `
    Get all dataFiles by deployment
  `, operationId: 'GetAllDataFilesByDeployment',
  })
  @ApiImplicitParam({ name: 'projectId', description: 'Project the deployment belongs to', type: Number, required: true })
  @ApiImplicitParam({ name: 'deploymentId', description: 'Deployment the data file belongs to', type: Number, required: true })
  @ApiResponse({ status: 200, description: 'DataFiles have been successfully returned', isArray: false, type: DataFilesPaginatedDto })
  @ApiResponse({ status: 403, description: 'Not authorized.' })
  @ApiResponse({ status: 401, description: 'Not authenticated.' })
  @ApiImplicitQuery({
    name: 'includes', description: `
  Allows include the DataFiles's relations. Available ${dataFilesRelations}
  `, type: String, required: false,
  })
  @ApiImplicitParam({ name: 'deploymentId', description: 'Id of the deployment', required: true, type: Number })
  @ApiImplicitQuery({ name: 'fields', description: 'DataFiles\'s fields to select', type: String, required: false })
  @ApiImplicitQuery({ name: 'page[size]', description: 'Page size. Default 10', type: String, required: false })
  @ApiImplicitQuery({ name: 'page[number]', description: 'Page number', type: String, required: false })
  @ApiImplicitQuery({ name: 'sort', description: 'Sort results', type: String, required: false })
  @Permissions(PERMISSIONS.DATA_FILE_GET_ALL)
  async findAll(@Pagination() pagination: PaginationModel, @Param() params, @User() authenticatedUser: AuthenticatedUserDto) {
    logger.info('Getting all data files by deployment');
    const data = await this.dataFileService.findAll(pagination, { authenticatedUser, params });
    return new DataFilesPaginatedDto(data[0], data[1], pagination.pageSize, pagination.pageNumber);
  }

  @Get('/data-file')
  @ApiOperation({
    title: 'Get DataFiles by project', description: `
    Get all dataFiles by project
  `, operationId: 'GetAllDataFilesByProject',
  })
  @ApiImplicitParam({ name: 'projectId', description: 'Project the deployment belongs to', type: Number, required: true })
  @ApiResponse({ status: 200, description: 'DataFiles have been successfully returned', isArray: false, type: DataFilesPaginatedDto })
  @ApiResponse({ status: 403, description: 'Not authorized.' })
  @ApiResponse({ status: 401, description: 'Not authenticated.' })
  @ApiImplicitQuery({
    name: 'includes', description: `
  Allows include the DataFiles's relations. Available ${dataFilesRelations}
  `, type: String, required: false,
  })
  @ApiImplicitQuery({ name: 'fields', description: 'DataFiles\'s fields to select', type: String, required: false })
  @ApiImplicitQuery({ name: 'page[size]', description: 'Page size. Default 10', type: String, required: false })
  @ApiImplicitQuery({ name: 'page[number]', description: 'Page number', type: String, required: false })
  @ApiImplicitQuery({ name: 'sort', description: 'Sort results', type: String, required: false })
  @ApiImplicitQuery({ name: 'deploymentIds', description: 'Deployments for filter', type: String, required: false, collectionFormat: 'csv' })
  @ApiImplicitQuery({ name: 'taxonomyIds', description: 'Taxonomies for filter', type: String, required: false, collectionFormat: 'csv' })
  @ApiImplicitQuery({ name: 'dataFileIds', description: 'Ids of data files for filter', type: String, required: false, collectionFormat: 'csv' })
  @ApiImplicitQuery({ name: 'blank', description: 'blank for filter', type: Boolean, required: false })
  @ApiImplicitQuery({ name: 'highlighted', description: 'highlighted for filter', type: Boolean, required: false })
  @Permissions(PERMISSIONS.DATA_FILE_GET_ALL)
  async findAllByProject(@Pagination() pagination: PaginationModel, @Param() params, @User() authenticatedUser: AuthenticatedUserDto, @Query() filters) {
    logger.info('Getting all data files by project');
    if (filters.deploymentIds) {
      filters.deploymentIds = filters.deploymentIds.split(',');
    }
    if (filters.taxonomyIds) {
      filters.taxonomyIds = filters.taxonomyIds.split(',');
    }
    if (filters.dataFileIds) {
      filters.dataFileIds = filters.dataFileIds.split(',');
    }
    const data = await this.dataFileService.findAll(pagination, { authenticatedUser, params }, filters);
    return new DataFilesPaginatedDto(data[0], data[1], pagination.pageSize, pagination.pageNumber);
  }

  @Get('/data-file-for-identification')
  @ApiOperation({
    title: 'Get All DataFiles by project where the user has permission to identify animals', description: `
    Get all dataFiles by project where the user has permission to identify animals
  `, operationId: 'GetAllDataFilesByProjectForIdentification',
  })
  @ApiResponse({ status: 200, description: 'DataFiles have been successfully returned', isArray: false, type: DataFilesPaginatedDto })
  @ApiResponse({ status: 403, description: 'Not authorized.' })
  @ApiResponse({ status: 401, description: 'Not authenticated.' })
  @ApiImplicitQuery({
    name: 'includes', description: `
  Allows include the DataFiles's relations. Available ${dataFilesRelations}
  `, type: String, required: false,
  })
  @ApiImplicitParam({ name: 'projectId', description: 'Project the deployment belongs to', type: Number, required: true })
  @ApiImplicitQuery({ name: 'fields', description: 'DataFiles\'s fields to select', type: String, required: false })
  @ApiImplicitQuery({ name: 'page[size]', description: 'Page size. Default 10', type: String, required: false })
  @ApiImplicitQuery({ name: 'page[number]', description: 'Page number', type: String, required: false })
  @ApiImplicitQuery({ name: 'sort', description: 'Sort results', type: String, required: false })
  @ApiImplicitQuery({ name: 'deploymentIds', description: 'Deployments for filter', type: String, required: false, collectionFormat: 'csv' })
  @ApiImplicitQuery({ name: 'taxonomyIds', description: 'Taxonomies for filter', type: String, required: false, collectionFormat: 'csv' })
  @ApiImplicitQuery({ name: 'dataFileIds', description: 'Ids of data files for filter', type: String, required: false, collectionFormat: 'csv' })
  @ApiImplicitQuery({ name: 'blank', description: 'blank for filter', type: Boolean, required: false })
  @ApiImplicitQuery({ name: 'highlighted', description: 'highlighted for filter', type: Boolean, required: false })
  async findAllInProjectByIdentificationPermision(@Param('projectId', new ParseIntPipe()) projectId: number, @Pagination() pagination: PaginationModel, @Param() params, @User() authenticatedUser: AuthenticatedUserDto, @Query() filters) {
    logger.info('Getting all');
    if (filters.deploymentIds) {
      filters.deploymentIds = filters.deploymentIds.split(',');
    }
    if (filters.taxonomyIds) {
      filters.taxonomyIds = filters.taxonomyIds.split(',');
    }
    if (filters.dataFileIds) {
      filters.dataFileIds = filters.dataFileIds.split(',');
    }
    const data = await this.dataFileService.findAllInProjectByIdentificationPermission(projectId, pagination, { authenticatedUser, params }, filters);
    return new DataFilesPaginatedDto(data[0], data[1], pagination.pageSize, pagination.pageNumber);
  }

  @Get('/deployment/:deploymentId/data-file/:id/download-url')
  @ApiOperation({
    title: 'Get download url of one dataFile by id', description: `
    Get download url of the dataFile
  `, operationId: 'GetDownloadUrlById',
  })
  @ApiImplicitParam({ name: 'projectId', description: 'Project the deployment belongs to', type: Number, required: true })
  @ApiImplicitParam({ name: 'deploymentId', description: 'Id of the deployment', required: true, type: Number })
  @ApiImplicitParam({ name: 'id', description: 'Id of the dataFile', required: true, type: Number })
  @ApiResponse({ status: 200, description: 'URL has been successfully returned', isArray: false, type: DataFilesDto })
  @ApiResponse({ status: 404, description: 'DataFile does not exist or you don\'t have permission' })
  @ApiResponse({ status: 401, description: 'Not authenticated.' })
  @ApiResponse({ status: 403, description: 'You don\'t have permissions' })
  @Permissions(PERMISSIONS.DATA_FILE_DOWNLOAD)
  async getDownloadUrl(@Param('id', new ParseIntPipe()) id: number, @User() authenticatedUser: AuthenticatedUserDto, @Param() params) {
    logger.info('Get download URL by id ', id);
    const url = await this.dataFileService.generateDownloadUrl(id, { authenticatedUser, params });
    return {
      url,
    };
  }

  @Get('/deployment/:deploymentId/data-file/:id')
  @ApiOperation({
    title: 'Get dataFile by id', description: `
    Get dataFile by id
  `, operationId: 'GetDataFileById',
  })
  @ApiImplicitQuery({
    name: 'includes', description: `
  Allows include the DataFiles's relations. Available ${dataFilesRelations}
  `, type: String, required: false,
  })
  @ApiImplicitParam({ name: 'id', description: 'Id of the dataFile' })
  @ApiImplicitParam({ name: 'projectId', description: 'Project the deployment belongs to', type: Number, required: true })
  @ApiImplicitParam({ name: 'deploymentId', description: 'Deployment the data file belongs to', type: Number, required: true })
  @ApiResponse({ status: 200, description: 'DataFile has been successfully returned', isArray: false, type: DataFilesDto })
  @ApiResponse({ status: 404, description: 'DataFile does not exist or you don\'t have permission' })
  @ApiResponse({ status: 401, description: 'Not authenticated.' })
  @Permissions(PERMISSIONS.DATA_FILE_GET_ONE)
  async getById(@Param('id', new ParseIntPipe()) id: number, @User() authenticatedUser: AuthenticatedUserDto, @Param() params, @Pagination() pagination: PaginationModel) {
    logger.info('Get data file by id ', id);
    const data = await this.dataFileService.getById(id, pagination, { authenticatedUser, params });
    return data;
  }

  @Get('/deployment/:deploymentId/data-file/by-clientId/:clientId')
  @ApiOperation({
    title: 'Get dataFile by clientId', description: `
    Get dataFile by clientId
  `, operationId: 'GetDataFileByClientId',
  })
  @ApiImplicitQuery({
    name: 'includes', description: `
  Allows include the DataFiles's relations. Available ${dataFilesRelations}
  `, type: String, required: false,
  })
  @ApiImplicitParam({ name: 'clientId', description: 'clientId', type: String, required: true })
  @ApiImplicitParam({ name: 'projectId', description: 'Project the deployment belongs to', type: Number, required: true })
  @ApiImplicitParam({ name: 'deploymentId', description: 'Deployment the data file belongs to', type: Number, required: true })
  @ApiResponse({ status: 200, description: 'DataFiles have been successfully returned', isArray: false, type: DataFilesDto })
  @ApiResponse({ status: 403, description: 'Not authorized.' })
  @ApiResponse({ status: 401, description: 'Not authenticated.' })
  @Permissions(PERMISSIONS.DATA_FILE_GET_ONE)
  async getByClientId(@User() authenticatedUser: AuthenticatedUserDto, @Param() params, @Pagination() pagination: PaginationModel) {
    logger.info('Get data file by clientId ', params.clientId);
    logger.info(pagination);
    const data = await this.dataFileService.getByClientId(params.clientId, pagination, { authenticatedUser, params });
    return data;
  }

  @Post('/deployment/:deploymentId/data-file/upload-url')
  @ApiOperation({
    title: 'Create data file and get upload URL for image', description: `
    Create data file without attaching an actual image file, and get the upload URL where the image file could be later uploaded
  `, operationId: 'CreateDataFileAndGetDownloadUrl',
  })
  @ApiImplicitParam({ name: 'projectId', description: 'Project the deployment belongs to', type: Number, required: true })
  @ApiImplicitParam({ name: 'deploymentId', description: 'Id of the deployment', required: true, type: Number })
  @ApiImplicitParam({ name: 'id', description: 'Id of the dataFile', required: true, type: Number })
  @ApiResponse({ status: 200, description: 'URL has been successfully returned', isArray: false, type: DataFilesDto })
  @ApiResponse({ status: 404, description: 'DataFile does not exist or you don\'t have permission' })
  @ApiResponse({ status: 401, description: 'Not authenticated.' })
  @ApiResponse({ status: 403, description: 'You don\'t have permissions' })
  @Permissions(PERMISSIONS.DATA_FILE_DOWNLOAD)
  async getUploadUrl(@User() authenticatedUser: AuthenticatedUserDto, @Param() params, @Body(new ValidationPipe()) uploadUrlDto: UploadUrlDto) {
    logger.info('Get upload url');
    const url = await this.dataFileService.generateUploadUrl(uploadUrlDto.fileName, uploadUrlDto.contentType, uploadUrlDto.clientId, { authenticatedUser, params });
    return {
      url,
    };
  }

  @Post('/deployment/:deploymentId/data-file')
  @ApiOperation({
    title: 'Create dataFile', description: `
    Create new dataFile
  `, operationId: 'CreateDataFile',
  })
  @ApiImplicitParam({ name: 'projectId', description: 'Project the deployment belongs to', type: Number, required: true })
  @ApiImplicitParam({ name: 'deploymentId', description: 'Deployment the data file belongs to', type: Number, required: true })
  @ApiImplicitBody({ name: 'sequenceId', description: 'Sequence the data file belongs to', type: Number, required: false })
  @ApiImplicitBody({ name: 'position', description: 'Position in the sequence', type: Number, required: false })
  @ApiImplicitBody({ name: 'timestamp', description: 'Date of the data-file was took (ISO string)', type: String, required: true })
  @ApiImplicitBody({ name: 'noCV', description: 'Set to `true` if you don\'t want to execute CV on the image.', type: String, required: false })
  @ApiResponse({ status: 200, description: 'DataFile has been successfully created', isArray: false, type: DataFilesDto })
  @ApiResponse({ status: 400, description: 'Body contains errors' })
  @ApiResponse({ status: 401, description: 'Not authenticated.' })
  @Permissions(PERMISSIONS.DATA_FILE_CREATE)
  @UseInterceptors(FileInterceptor('file', { storage }), DataFileInterceptor)
  async create(
    @UploadedFile() file,
    @Body('sequenceId', new ParseIntRequiredPipe(false)) sequenceId,
    @Body('position', new ParseIntRequiredPipe(false)) position,
    @Body('timestamp', new ParseDateRequiredPipe(true)) timestamp,
    @Body('noCV', new ParseBoolPipe(false)) noCV: boolean,
    @Param('deploymentId', new ParseIntPipe()) deploymentId: number,
    @User() authenticatedUser: AuthenticatedUserDto,
    @Param() params,
  ) {
    logger.debug(file);
    logger.info('Creating dataFile');
    logger.debug('timestamp:', timestamp);
    logger.debug('noCV:', noCV);
    if (!file || !file.path) {
      throw new BadRequestException('File is required');
    }
    const createDataFileDto = new CreateDataFileDto();
    createDataFileDto.localPath = file.path;
    createDataFileDto.fileName = file.originalname;
    createDataFileDto.size = file.size;
    createDataFileDto.mimetype = file.mimetype;
    createDataFileDto.deploymentId = deploymentId;
    createDataFileDto.sequenceId = sequenceId;
    createDataFileDto.position = position;
    createDataFileDto.timestamp = timestamp;
    return await this.dataFileService.create(createDataFileDto, { authenticatedUser, params }, noCV);
  }

  @Post('/deployment/:deploymentId/sequence/:sequenceId/data-file')
  @ApiOperation({
    title: 'Create dataFile', description: `
    Create new dataFile
  `, operationId: 'CreateDataFileWithSequence',
  })
  @ApiImplicitParam({ name: 'projectId', description: 'Project the deployment belongs to', type: Number, required: true })
  @ApiImplicitParam({ name: 'deploymentId', description: 'Deployment the data file belongs to', type: Number, required: true })
  @ApiImplicitBody({ name: 'sequenceId', description: 'Sequence the data file belongs to', type: Number, required: false })
  @ApiImplicitBody({ name: 'position', description: 'Position in the sequence', type: Number, required: false })
  @ApiImplicitBody({ name: 'timestamp', description: 'Date of the data-file was took (ISO string)', type: String, required: true })
  @ApiImplicitBody({ name: 'noCV', description: 'if you don\'t want execut CV in the image.', type: String, required: false })
  @ApiResponse({ status: 200, description: 'DataFile has been successfully created', isArray: false, type: DataFilesDto })
  @ApiResponse({ status: 400, description: 'Body contains errors' })
  @ApiResponse({ status: 401, description: 'Not authenticated.' })
  @Permissions(PERMISSIONS.DATA_FILE_CREATE)
  @UseInterceptors(FileInterceptor('file', { storage }))
  async createWithSequence(
    @UploadedFile() file,
    @Body('position', new ParseIntRequiredPipe(false)) position,
    @Body('timestamp', new ParseDateRequiredPipe(true)) timestamp,
    @Body('noCV', new ParseBoolPipe(false)) noCV: boolean,
    @Param('deploymentId', new ParseIntRequiredPipe()) deploymentId: number,
    @Param('sequenceId', new ParseIntRequiredPipe()) sequenceId: number,
    @User() authenticatedUser: AuthenticatedUserDto,
    @Param() params,
  ) {
    logger.debug(file);
    logger.info('Creating dataFile');
    logger.info(`noCV: ${noCV}`);
    if (!file || !file.path) {
      throw new BadRequestException('File is required');
    }
    const createDataFileDto = new CreateDataFileDto();
    createDataFileDto.localPath = file.path;
    createDataFileDto.fileName = file.originalname;
    createDataFileDto.size = file.size;
    createDataFileDto.mimetype = file.mimetype;
    createDataFileDto.deploymentId = deploymentId;
    createDataFileDto.sequenceId = sequenceId;
    createDataFileDto.position = position;
    createDataFileDto.timestamp = timestamp;
    return await this.dataFileService.create(createDataFileDto, { authenticatedUser, params }, noCV);
  }

  /**
   * Highlights bulk files
   * @param highlightDataFileListDto
   * @param authenticatedUser
   * @param params
   */
  @Patch('/deployment/:deploymentId/data-file/highlight-bulk')
  @ApiOperation({ title: 'Highlight dataFile', description: 'Highlight dataFile', operationId: 'Highlight' })
  @ApiImplicitParam({ name: 'projectId', description: 'Project the deployment belongs to', type: Number, required: true })
  @ApiImplicitParam({ name: 'deploymentId', description: 'Deployment the data file belongs to', type: Number, required: true })
  @ApiResponse({ status: 200, description: 'DataFiles has been successfully updated', isArray: false, type: DataFilesDto })
  @ApiResponse({ status: 401, description: 'Not authenticated.' })
  @Permissions(PERMISSIONS.DATA_FILE_UPDATE)
  async highlight(@Body() highlightDataFileListDto: HighlightDataFileListDto, @User() authenticatedUser: AuthenticatedUserDto, @Param() params) {
    logger.info('Highlight data file');
    return await this.dataFileService.highlight(highlightDataFileListDto.dataFileIdList, highlightDataFileListDto.highlighted, { authenticatedUser, params });
  }

  @Patch('/deployment/:deploymentId/data-file/:id')
  @ApiOperation({
    title: 'Update dataFile', description: `
    Update dataFile
  `, operationId: 'UpdateDataFile',
  })
  @ApiImplicitParam({ name: 'id', description: 'Id of the dataFile' })
  @ApiImplicitParam({ name: 'projectId', description: 'Project the deployment belongs to', type: Number, required: true })
  @ApiImplicitParam({ name: 'deploymentId', description: 'Deployment the data file belongs to', type: Number, required: true })
  @ApiResponse({ status: 200, description: 'DataFile has been successfully updated', isArray: false, type: DataFilesDto })
  @ApiResponse({ status: 404, description: 'DataFile does not exist or you don\'t have permission' })
  @ApiResponse({ status: 401, description: 'Not authenticated.' })
  @Permissions(PERMISSIONS.DATA_FILE_UPDATE)
  async update(@Param('id', new ParseIntPipe()) id: number, @Body(new ValidationPipe()) updateDataFileDto: UpdateDataFileDto, @User() authenticatedUser: AuthenticatedUserDto, @Param() params) {
    logger.info('Updating data file');
    // TODO: Add security
    return await this.dataFileService.update(id, updateDataFileDto, { authenticatedUser, params });
  }

  @Delete('/deployment/:deploymentId/data-file-bulk/')
  @ApiOperation({ title: 'Delete dataFile list', description: 'Delete dataFile list', operationId: 'DeleteBulk' })
  @ApiImplicitParam({ name: 'projectId', description: 'Project the deployment belongs to', type: Number, required: true })
  @ApiImplicitParam({ name: 'deploymentId', description: 'Deployment the data file belongs to', type: Number, required: true })
  @ApiImplicitBody({ name: 'idList', description: 'ids of the data files', type: Array, required: false })
  @ApiResponse({ status: 200, description: 'DataFile has been successfully deleted', isArray: false, type: DataFilesDto })
  @ApiResponse({ status: 404, description: 'DataFile does not exist or you don\'t have permission' })
  @ApiResponse({ status: 401, description: 'Not authenticated.' })
  @Permissions(PERMISSIONS.DATA_FILE_DELETE)
  async removeMany(@Body('idList', new ValidationPipe()) idList: number[], @User() authenticatedUser: AuthenticatedUserDto, @Param() params) {
    logger.info('Deleting dataFile list');
    const result = await this.dataFileService.removeMany(idList, { authenticatedUser, params });
    return { count: result.length };
  }

  @Delete('/deployment/:deploymentId/data-file/:id')
  @ApiOperation({ title: 'Delete dataFile', description: 'Delete dataFile', operationId: 'DeleteDataFile' })
  @ApiImplicitParam({ name: 'id', description: 'Id of the dataFile' })
  @ApiImplicitParam({ name: 'projectId', description: 'Project the deployment belongs to', type: Number, required: true })
  @ApiImplicitParam({ name: 'deploymentId', description: 'Deployment the data file belongs to', type: Number, required: true })
  @ApiResponse({ status: 200, description: 'DataFile has been successfully deleted', isArray: false, type: DataFilesDto })
  @ApiResponse({ status: 404, description: 'DataFile does not exist or you don\'t have permission' })
  @ApiResponse({ status: 401, description: 'Not authenticated.' })
  @Permissions(PERMISSIONS.DATA_FILE_DELETE)
  async remove(@Param('id', new ParseIntPipe()) id: number, @User() authenticatedUser: AuthenticatedUserDto, @Param() params) {
    logger.info('Deleting dataFile');
    return await this.dataFileService.remove(id, { authenticatedUser, params });
  }
}
