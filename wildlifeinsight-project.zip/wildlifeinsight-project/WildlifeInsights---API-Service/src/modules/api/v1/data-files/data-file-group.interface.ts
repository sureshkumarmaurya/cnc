import { DataFiles } from 'modules/database/entities/data-files.entity';

export interface IDataFileIndexed extends DataFiles {
  indexInitial: number;
}

export interface IDataFileGroup {
  name: number;
  data: IDataFileIndexed[];
}
