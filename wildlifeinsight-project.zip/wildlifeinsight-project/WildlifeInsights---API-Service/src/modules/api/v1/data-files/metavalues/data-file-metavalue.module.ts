import { DataFileMetavalueController, dataFileMetavaluesRelations } from './data-file-metavalue.controller';
import { DataFileMetavalueService } from './data-file-metavalue.service';
import { Module, RequestMethod, MiddlewareConsumer } from '@nestjs/common';
import { PaginationMiddleware } from 'middlewares/pagination.middleware';
import { DataFileMetavalueResolver } from './data-file-metavalue.resolver';
import { DatabaseModule } from 'modules/database/database.module';

@Module({
  imports: [DatabaseModule],
  controllers: [DataFileMetavalueController],
  providers: [DataFileMetavalueService, DataFileMetavalueResolver],
})
export class DataFileMetavalueModule {
  public configure(consumer: MiddlewareConsumer) {
    consumer
      .apply(PaginationMiddleware)
      .with({ includes: [], allowIncludes: dataFileMetavaluesRelations })
      .forRoutes({ path: '/api/v1/project/:projectId/deployment/:deploymentId/data-file/:dataFileId/data-file-metavalue*', method: RequestMethod.GET });
  }
}
