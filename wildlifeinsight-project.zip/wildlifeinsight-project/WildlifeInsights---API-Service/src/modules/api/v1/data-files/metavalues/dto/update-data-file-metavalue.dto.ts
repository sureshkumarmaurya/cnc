import { ApiModelProperty } from '@nestjs/swagger';
import { IsString, IsNumber, IsOptional, MaxLength, IsBoolean } from 'class-validator';

export class UpdateDataFileMetavalueDto {

  @IsString()
  @MaxLength(255)
  @ApiModelProperty({ required: true })
  value: string;

  @IsNumber()
  @ApiModelProperty({ required: true })
  keyId: number;

  @IsString()
  @IsOptional()
  @ApiModelProperty({ required: false })
  remarks: string ;

}
