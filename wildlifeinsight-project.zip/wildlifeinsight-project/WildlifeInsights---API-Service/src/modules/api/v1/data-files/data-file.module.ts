
import { Module, RequestMethod, MiddlewareConsumer } from '@nestjs/common';
import { PaginationMiddleware } from 'middlewares/pagination.middleware';

/**
 * Controllers
 */
import { DataFileController, dataFilesRelations } from './data-file.controller';
import { DataFileGeneralController } from './data-file-general.controller';

/**
 * Resolvers
 */
import { DataFileResolver } from './data-file.resolver';
import { ExifResolver } from './exif.resolver';

/**
 * Services
 */
import { DataFileService } from './data-file.service';
import { DataFileGroupService } from './data-file-group.service';
import { ImageManagementService } from '../../../../services/ImageManagement.service';

/**
 * Modules
 */
import { DatabaseModule } from 'modules/database/database.module';
import { GoogleModule } from 'modules/google/google.module';

@Module({
  imports: [DatabaseModule, GoogleModule],
  controllers: [DataFileController, DataFileGeneralController],
  providers: [DataFileService, DataFileResolver, ExifResolver, ImageManagementService, DataFileGroupService],
  exports: [DataFileService],
})
export class DataFileModule {
  public configure(consumer: MiddlewareConsumer) {
    consumer
      .apply(PaginationMiddleware)
      .with({ includes: [], allowIncludes: dataFilesRelations })
      .forRoutes(
        { path: '/api/v1/project/:projectId/data-file', method: RequestMethod.GET },
        { path: '/api/v1/project/:projectId/data-file-for-identification', method: RequestMethod.GET },
        { path: '/api/v1/project/:projectId/deployment/:deploymentId/data-file', method: RequestMethod.GET },
        { path: '/api/v1/project/:projectId/data-file/:id', method: RequestMethod.GET },
        { path: '/api/v1/project/:projectId/deployment/:deploymentId/data-file/by-clientId/:clientId', method: RequestMethod.GET },
        { path: '/api/v1/project/:projectId/deployment/:deploymentId/data-file/:id', method: RequestMethod.GET },
        { path: '/api/v1/data-file', method: RequestMethod.GET },
        { path: '/api/v1/data-file-for-identification', method: RequestMethod.GET },
        { path: '/api/v1/organization/:organizationId/data-file', method: RequestMethod.GET },
        { path: '/api/v1/organization/:organizationId/data-file-for-identification', method: RequestMethod.GET },
      );
  }
}
