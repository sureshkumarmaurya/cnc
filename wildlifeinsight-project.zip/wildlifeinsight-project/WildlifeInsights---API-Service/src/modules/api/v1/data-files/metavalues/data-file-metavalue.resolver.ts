import { CreateDataFileMetavalueDto } from './dto/create-data-file-metavalue.dto';
import { DataFileMetavalueService } from './data-file-metavalue.service';
import { Resolver, Query, ResolveProperty, Mutation } from '@nestjs/graphql';
import { UpdateDataFileMetavalueDto } from './dto/update-data-file-metavalue.dto';
import { UseInterceptors, UseGuards } from '@nestjs/common';
import { ValidationGraphqlInterceptor } from 'interceptors/validation-graphql.interceptor';
import { PaginationGraphqlInterceptor } from 'interceptors/pagination-graphql.interceptor';
import { PermissionsGraphQlGuard } from 'guards/permissions-graphql.guard';
import { DataFileMetavalues } from 'modules/database/entities/data-file-metavalues.entity';
import { PaginationModel } from 'utils/pagination.model';

const logger = require('logger');

@Resolver('DataFileMetavalue')
@UseGuards(PermissionsGraphQlGuard)
export class DataFileMetavalueResolver {
  constructor(private readonly dataFileMetavalueService: DataFileMetavalueService) {}

  @Query()
  @UseInterceptors(PaginationGraphqlInterceptor)
  async getDataFileMetavalues(req, args: { pagination: PaginationModel }, context, info) {
    const authenticatedUser = req.user;
    const data = await this.dataFileMetavalueService.findAll(args.pagination, { authenticatedUser, params: args });
    return data[0];
  }

  @Query()
  async getDataFileMetavalue(req, args, context, info) {
    const { id } = args;
    const authenticatedUser = req.user;
    return await this.dataFileMetavalueService.getById(id, {}, { authenticatedUser, params: args });
  }

  @ResolveProperty()
  async key(dataFileMetavalue: DataFileMetavalues, args, context, info) {
    return this.dataFileMetavalueService.getDataFileMetakeyById(dataFileMetavalue.keyId);
  }

  @Mutation()
  @UseInterceptors(new ValidationGraphqlInterceptor(CreateDataFileMetavalueDto))
  async createDataFileMetavalue(req, args: {body: CreateDataFileMetavalueDto}, context, info) {
    const authenticatedUser = req.user;
    const { body } = args;
    return this.dataFileMetavalueService.create(body, { authenticatedUser, params: args });
  }

  @Mutation()
  @UseInterceptors(new ValidationGraphqlInterceptor(UpdateDataFileMetavalueDto))
  async updateDataFileMetavalue(req, args: {id: number, body: UpdateDataFileMetavalueDto}, context, info) {
    const authenticatedUser = req.user;
    const { id, body } = args;
    return this.dataFileMetavalueService.update(id, body, { authenticatedUser, params: args });
  }

  @Mutation()
  async deleteDataFileMetavalue(req, args, context, info) {
    const { id } = args;
    const authenticatedUser = req.user;
    return this.dataFileMetavalueService.remove(id, { authenticatedUser, params: args });
  }
}
