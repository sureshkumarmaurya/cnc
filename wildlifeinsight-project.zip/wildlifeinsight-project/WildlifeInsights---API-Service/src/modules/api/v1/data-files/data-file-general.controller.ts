import { DataFileService } from './data-file.service';
import { ApiBearerAuth, ApiUseTags, ApiOperation, ApiResponse, ApiImplicitQuery, ApiImplicitParam } from '@nestjs/swagger';
import { Controller, UseGuards, Param, Get, ParseIntPipe, Query } from '@nestjs/common';
import { PermissionsGuard } from 'guards/permissions.guard';
import { dataFilesRelations } from './data-file.controller';
import { Pagination } from 'decorators/pagination.decorator';
import { User } from 'decorators/user.decorator';
import { AuthenticatedUserDto } from 'dto/authenticated-user.dto';
import { DataFilesPaginatedDto } from './dto/data-files.dto';
import { PaginationModel } from 'utils/pagination.model';

const logger = require('logger');

@Controller('/api/v1')
@ApiUseTags('DataFiles')
@ApiBearerAuth()
@UseGuards(PermissionsGuard)
export class DataFileGeneralController {
  constructor(private readonly dataFileService: DataFileService) { }

  @Get('/data-file-for-identification')
  @ApiOperation({
    title: 'Get All DataFiles where the user has permission to identify animals', description: `
    Get all dataFiles where the user has permission to identify animals
  `, operationId: 'GetAllDataFilesForIdentification',
  })
  @ApiResponse({ status: 200, description: 'DataFiles have been successfully returned', isArray: false, type: DataFilesPaginatedDto })
  @ApiResponse({ status: 403, description: 'Not authorized.' })
  @ApiResponse({ status: 401, description: 'Not authenticated.' })
  @ApiImplicitQuery({
    name: 'includes', description: `
  Allows include the DataFiles's relations. Available ${dataFilesRelations}
  `, type: String, required: false,
  })
  @ApiImplicitQuery({ name: 'fields', description: 'DataFiles\'s fields to select', type: String, required: false })
  @ApiImplicitQuery({ name: 'page[size]', description: 'Page size. Default 10', type: String, required: false })
  @ApiImplicitQuery({ name: 'page[number]', description: 'Page number', type: String, required: false })
  @ApiImplicitQuery({ name: 'sort', description: 'Sort results', type: String, required: false })
  @ApiImplicitQuery({ name: 'deploymentIds', description: 'Deployments for filter', type: String, required: false, collectionFormat: 'csv' })
  @ApiImplicitQuery({ name: 'taxonomyIds', description: 'Taxonomies for filter', type: String, required: false, collectionFormat: 'csv' })
  @ApiImplicitQuery({ name: 'dataFileIds', description: 'Ids of data files for filter', type: String, required: false, collectionFormat: 'csv' })
  @ApiImplicitQuery({ name: 'blank', description: 'blank for filter', type: Boolean, required: false })
  async findAllWithoutOrganizationByIdentificationPermision(@Pagination() pagination: PaginationModel, @Param() params, @User() authenticatedUser: AuthenticatedUserDto, @Query() filters) {
    logger.info('Getting all data files for identification');
    if (filters.deploymentIds) {
      filters.deploymentIds = filters.deploymentIds.split(',');
    }
    if (filters.taxonomyIds) {
      filters.taxonomyIds = filters.taxonomyIds.split(',');
    }
    if (filters.dataFileIds) {
      filters.dataFileIds = filters.dataFileIds.split(',');
    }
    const data = await this.dataFileService.findAllWithoutOrganizationByIdentificationPermission(pagination, { authenticatedUser, params }, filters);
    return new DataFilesPaginatedDto(data[0], data[1], pagination.pageSize, pagination.pageNumber);
  }

  @Get('/data-file')
  @ApiOperation({
    title: 'Get All DataFiles', description: `
    Get all dataFiles
  `, operationId: 'GetAllDataFiles',
  })
  @ApiResponse({ status: 200, description: 'DataFiles have been successfully returned', isArray: false, type: DataFilesPaginatedDto })
  @ApiResponse({ status: 403, description: 'Not authorized.' })
  @ApiResponse({ status: 401, description: 'Not authenticated.' })
  @ApiImplicitQuery({
    name: 'includes', description: `
  Allows include the DataFiles's relations. Available ${dataFilesRelations}
  `, type: String, required: false,
  })
  @ApiImplicitQuery({ name: 'fields', description: 'DataFiles\'s fields to select', type: String, required: false })
  @ApiImplicitQuery({ name: 'page[size]', description: 'Page size. Default 10', type: String, required: false })
  @ApiImplicitQuery({ name: 'page[number]', description: 'Page number', type: String, required: false })
  @ApiImplicitQuery({ name: 'sort', description: 'Sort results', type: String, required: false })
  @ApiImplicitQuery({ name: 'deploymentIds', description: 'Deployments for filter', type: String, required: false, collectionFormat: 'csv' })
  @ApiImplicitQuery({ name: 'taxonomyIds', description: 'Taxonomies for filter', type: String, required: false, collectionFormat: 'csv' })
  @ApiImplicitQuery({ name: 'dataFileIds', description: 'Ids of data files for filter', type: String, required: false, collectionFormat: 'csv' })
  @ApiImplicitQuery({ name: 'blank', description: 'blank for filter', type: Boolean, required: false })
  async findAllWithoutOrganization(@Pagination() pagination: PaginationModel, @Param() params, @User() authenticatedUser: AuthenticatedUserDto, @Query() filters) {
    logger.info('Getting all data files');
    if (filters.deploymentIds) {
      filters.deploymentIds = filters.deploymentIds.split(',');
    }
    if (filters.taxonomyIds) {
      filters.taxonomyIds = filters.taxonomyIds.split(',');
    }
    if (filters.dataFileIds) {
      filters.dataFileIds = filters.dataFileIds.split(',');
    }
    const data = await this.dataFileService.findAllWithoutOrganization(pagination, { authenticatedUser, params }, filters);
    return new DataFilesPaginatedDto(data[0], data[1], pagination.pageSize, pagination.pageNumber);
  }

  @Get('/organization/:organizationId/data-file-for-identification')
  @ApiOperation({
    title: 'Get All DataFiles of one organization where the user has permission of identify images', description: `
    Get all dataFiles:
  `, operationId: 'GetAllDataFilesByOrganizationForIdentification',
  })
  @ApiResponse({ status: 200, description: 'DataFiles have been successfully returned', isArray: false, type: DataFilesPaginatedDto })
  @ApiResponse({ status: 403, description: 'Not authorized.' })
  @ApiResponse({ status: 401, description: 'Not authenticated.' })
  @ApiImplicitQuery({
    name: 'includes', description: `
  Allows include the DataFiles's relations. Available ${dataFilesRelations}
  `, type: String, required: false,
  })
  @ApiImplicitParam({ name: 'organizationId', description: 'Id of the organization', required: true, type: Number })
  @ApiImplicitQuery({ name: 'fields', description: 'DataFiles\'s fields to select', type: String, required: false })
  @ApiImplicitQuery({ name: 'page[size]', description: 'Page size. Default 10', type: String, required: false })
  @ApiImplicitQuery({ name: 'page[number]', description: 'Page number', type: String, required: false })
  @ApiImplicitQuery({ name: 'sort', description: 'Sort results', type: String, required: false })
  @ApiImplicitQuery({ name: 'deploymentIds', description: 'Deployments for filter', type: String, required: false, collectionFormat: 'csv' })
  @ApiImplicitQuery({ name: 'taxonomyIds', description: 'Taxonomies for filter', type: String, required: false, collectionFormat: 'csv' })
  @ApiImplicitQuery({ name: 'dataFileIds', description: 'Ids of data files for filter', type: String, required: false, collectionFormat: 'csv' })
  @ApiImplicitQuery({ name: 'blank', description: 'blank for filter', type: Boolean, required: false })
  async findAllInOrganizationByIdentificationPermision(
    @Param('organizationId',
           new ParseIntPipe()) organizationId: number,
    @Pagination() pagination: PaginationModel,
    @Param() params,
    @User() authenticatedUser: AuthenticatedUserDto,
    @Query() filters) {
    logger.info('Getting all data files by project for identification');
    if (filters.deploymentIds) {
      filters.deploymentIds = filters.deploymentIds.split(',');
    }
    if (filters.taxonomyIds) {
      filters.taxonomyIds = filters.taxonomyIds.split(',');
    }
    if (filters.dataFileIds) {
      filters.dataFileIds = filters.dataFileIds.split(',');
    }
    const data = await this.dataFileService.findAllInOrganizationByIdentificationPermission(organizationId, pagination, { authenticatedUser, params }, filters);
    return new DataFilesPaginatedDto(data[0], data[1], pagination.pageSize, pagination.pageNumber);
  }

  @Get('/organization/:organizationId/data-file')
  @ApiOperation({
    title: 'Get All DataFiles of one organization ', description: `
    Get all dataFiles:
  `, operationId: 'GetAllDataFilesByOrganization',
  })
  @ApiResponse({ status: 200, description: 'DataFiles have been successfully returned', isArray: false, type: DataFilesPaginatedDto })
  @ApiResponse({ status: 403, description: 'Not authorized.' })
  @ApiResponse({ status: 401, description: 'Not authenticated.' })
  @ApiImplicitQuery({
    name: 'includes', description: `
  Allows include the DataFiles's relations. Available ${dataFilesRelations}
  `, type: String, required: false,
  })
  @ApiImplicitParam({ name: 'organizationId', description: 'Id of the organization', required: true, type: Number })
  @ApiImplicitQuery({ name: 'fields', description: 'DataFiles\'s fields to select', type: String, required: false })
  @ApiImplicitQuery({ name: 'page[size]', description: 'Page size. Default 10', type: String, required: false })
  @ApiImplicitQuery({ name: 'page[number]', description: 'Page number', type: String, required: false })
  @ApiImplicitQuery({ name: 'sort', description: 'Sort results', type: String, required: false })
  @ApiImplicitQuery({ name: 'deploymentIds', description: 'Deployments for filter', type: String, required: false, collectionFormat: 'csv' })
  @ApiImplicitQuery({ name: 'taxonomyIds', description: 'Taxonomies for filter', type: String, required: false, collectionFormat: 'csv' })
  @ApiImplicitQuery({ name: 'dataFileIds', description: 'Ids of data files for filter', type: String, required: false, collectionFormat: 'csv' })
  @ApiImplicitQuery({ name: 'blank', description: 'blank for filter', type: Boolean, required: false })
  async findAllInOrganization(@Param('organizationId', new ParseIntPipe()) organizationId: number, @Pagination() pagination: PaginationModel, @Param() params, @User() authenticatedUser: AuthenticatedUserDto, @Query() filters) {
    logger.info('Getting all data files by organization');
    if (filters.deploymentIds) {
      filters.deploymentIds = filters.deploymentIds.split(',');
    }
    if (filters.taxonomyIds) {
      filters.taxonomyIds = filters.taxonomyIds.split(',');
    }
    if (filters.dataFileIds) {
      filters.dataFileIds = filters.dataFileIds.split(',');
    }
    const data = await this.dataFileService.findAllInOrganization(organizationId, pagination, { authenticatedUser, params }, filters);
    return new DataFilesPaginatedDto(data[0], data[1], pagination.pageSize, pagination.pageNumber);
  }
}
