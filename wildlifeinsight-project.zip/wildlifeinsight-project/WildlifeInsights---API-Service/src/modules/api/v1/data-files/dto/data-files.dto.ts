import { ApiModelProperty } from '@nestjs/swagger';
import { DataFilesDto } from 'modules/database/dto/data-files.dto';
import { MetaDto } from 'modules/database/dto/meta.dto';

export class DataFilesPaginatedDto {

  @ApiModelProperty({ type: DataFilesDto, isArray: true })
  readonly data: DataFilesDto[];

  @ApiModelProperty()
  readonly meta: MetaDto;

  constructor(data, totalItems: number, pageSize: number, page: number) {
    this.data = data;
    this.meta = new MetaDto(Math.ceil(totalItems / pageSize), totalItems, pageSize, page);
  }
}
