import { Repository, SelectQueryBuilder, DeepPartial, Brackets } from 'typeorm';
import { Injectable, Inject, NotFoundException, BadRequestException } from '@nestjs/common';
import { IDataFileGroup } from './data-file-group.interface';
/**
 * DTOs
 */
import { UpdateDataFileDto } from './dto/update-data-file.dto';
import { CreateDataFileDto } from './dto/create-data-file.dto';
import { InfoDto } from 'dto/info.dto';
import { ProjectsDto } from 'modules/database/dto/projects.dto';

/**
 * Database
 */
import { DataFiles } from 'modules/database/entities/data-files.entity';
import { Projects } from 'modules/database/entities/projects.entity';
import { Deployments } from 'modules/database/entities/deployments.entity';
import { MediaTypes } from 'modules/database/entities/media-types.entity';
import { ExifDataFilePivot } from 'modules/database/entities/exif-data-file-pivot.entity';
import { ExifTags } from 'modules/database/entities/exif-tags.entity';
import { DataFileSequencePivot } from '../../../database/entities/data-file-sequence-pivot.entity';
import { DataFileMetakeys } from '../../../database/entities/data-file-metakeys.entity';
import { Sequences } from 'modules/database/entities/sequences.entity';
import { Participants } from 'modules/database/entities/participants.entity';
import { IdentificationOutputs } from 'modules/database/entities/identification-outputs.entity';
import { IdentificationMethods } from 'modules/database/entities/identification-methods.entity';
import { IdentificationMethodTaxonomyPivot } from 'modules/database/entities/identification-method-taxonomy-pivot.entity';
import { IdentifiedObjects } from 'modules/database/entities/identified-objects.entity';
import { LatestIdentificationOutputs } from 'modules/database/entities/latest-identification-outputs.entity';
import { Taxonomies } from 'modules/database/entities/taxonomies.entity';
import { Locations } from 'modules/database/entities/locations.entity';
import { DataFileMetavalues } from 'modules/database/entities/data-file-metavalues.entity';
import { AuthenticatedUserDto } from 'dto/authenticated-user.dto';

/**
 * Services
 */
import { StorageService } from 'modules/google/storage.service';
import { GenericService } from 'utils/generic.service';
import { ImageManagementService } from 'services/ImageManagement.service';
import { DataFileGroupService } from './data-file-group.service';

/**
 * Utils
 */
import { ExifUtils } from 'utils/exif.utils';
import { CVUtils } from 'utils/cv.utils';
import { PermissionsUtils } from 'utils/permissions.utils';
import { PERMISSIONS } from 'utils/permissions.enum';
import { PaginationUtil } from 'utils/pagination.util';
import { UrlUtil } from 'utils/url.util';
import { ROLES } from 'utils/roles.enum';
import { PaginationModel } from 'utils/pagination.model';

const logger = require('logger');
const fs = require('fs').promises;

@Injectable()
export class DataFileService extends GenericService<DataFiles, CreateDataFileDto, UpdateDataFileDto>  {

  constructor(
    @Inject('DataFilesRepositoryToken') private readonly dataFilesRepository: Repository<DataFiles>,
    @Inject('DataFileMetakeysRepositoryToken') private readonly dataFileMetakeysRepository: Repository<DataFileMetakeys>,
    @Inject('DataFileMetavaluesRepositoryToken') private readonly dataFileMetavaluesRepository: Repository<DataFileMetavalues>,
    @Inject('ProjectsRepositoryToken') private readonly projectsRepository: Repository<Projects>,
    @Inject('DeploymentsRepositoryToken') private readonly deploymentsRepository: Repository<Deployments>,
    @Inject('MediaTypesRepositoryToken') private readonly mediaTypesRepository: Repository<MediaTypes>,
    @Inject('ExifTagsRepositoryToken') private readonly exifTagsRepository: Repository<ExifTags>,
    @Inject('SequencesRepositoryToken') private readonly sequencesRepository: Repository<Sequences>,
    @Inject('ParticipantsRepositoryToken') private readonly participantsRepository: Repository<Participants>,
    @Inject('IdentificationOutputsRepositoryToken') private readonly identificationOutputsRepository: Repository<IdentificationOutputs>,
    @Inject('LatestIdentificationOutputsRepositoryToken') private readonly latestIdentificationOutputsRepository: Repository<LatestIdentificationOutputs>,
    @Inject('ExifDataFilePivotRepositoryToken') private readonly exifDataFilePivotRepository: Repository<ExifDataFilePivot>,
    @Inject('IdentificationMethodsRepositoryToken') private readonly identificationMethodsRepository: Repository<IdentificationMethods>,
    @Inject('IdentificationMethodTaxonomyPivotRepositoryToken') private readonly identificationMethodTaxonomyPivotRepository: Repository<IdentificationMethodTaxonomyPivot>,
    @Inject('TaxonomiesRepositoryToken') private readonly taxonomiesRepository: Repository<Taxonomies>,
    @Inject('IdentifiedObjectsRepositoryToken') private readonly identifiedObjectsRepository: Repository<IdentifiedObjects>,
    @Inject('LocationsRepositoryToken') private readonly locationsRepository: Repository<Locations>,

    private readonly storageService: StorageService,
    private readonly imageManagementService: ImageManagementService,
    private readonly dataFileGroupService: DataFileGroupService,
  ) {
    super(dataFilesRepository, 'dataFile');
  }

  private async getAllGrouped(pagination: PaginationModel, info?: InfoDto, filters: any = null): Promise<[IDataFileGroup[], number]> {

    const result = await this.findAll(pagination, info, filters);
    const groupedData = this.dataFileGroupService.groupByTimeStep(filters.timeStep, result[0]);

    return [groupedData, result[1]];
  }

  public findAllDataFiles(pagination: PaginationModel, info?: InfoDto, filters: any = null): Promise<[IDataFileGroup[], number]> {
    return this.getAllGrouped(pagination, info, filters);
  }

  setFilters(query: SelectQueryBuilder<DataFiles>, filters: any, info: InfoDto) {
    const projectsOfWhichUserIsOwner = this.getProjectsOfWhichUserIsOwner(info.authenticatedUser);

    if (info.pagination.includes && info.pagination.includes.indexOf('deployment') >= 0) {
      query.innerJoinAndSelect('dataFile.deployment', 'deployment');
      info.pagination.includes.splice(info.pagination.includes.indexOf('deployment'), 1);
    } else {
      query.innerJoin('dataFile.deployment', 'deployment');
    }
    if (info.params.projectId) {
      query.where('deployment.projectId = :projectId').setParameter('projectId', info.params.projectId);
      if (!projectsOfWhichUserIsOwner.includes(info.params.projectId)) {
        query.andWhere('dataFile.humanIdentified=false');
      }
    }
    if (info.params.deploymentId) {
      query.andWhere('deployment.id = :deploymentId').setParameter('deploymentId', info.params.deploymentId);
    }
    if (filters && filters.deploymentIds) {
      query.andWhere('deployment.id in (:...deploymentIds)').setParameter('deploymentIds', filters.deploymentIds);
    }
    if (filters && filters.taxonomyIds) {
      query.innerJoin('dataFile.latestIdentificationOutputs', 'identificationOutputs')
        .innerJoin('identificationOutputs.identifiedObjects', 'identifiedObjects');
      query.andWhere('identifiedObjects.taxonomyId in (:...taxonomyIds)').setParameter('taxonomyIds', filters.taxonomyIds);
    }
    if (filters && filters.dataFileIds) {
      query.andWhere('dataFile.id in (:...dataFileIds)').setParameter('dataFileIds', filters.dataFileIds);
    }

    if (filters && filters.highlighted !== undefined) {
      query.andWhere(`dataFile.highlighted = '${filters.highlighted}'`);
    }

    /**
     * See: https://www.pivotaltracker.com/story/show/169944701/comments/211227355
     */
    if (filters && filters.status) {
      if (filters.status === 'blank') {
        query.innerJoin('dataFile.latestIdentificationOutputs', 'identificationOutputs')
          // Using leftJoin() here to pick data files whose
          // latestIdentificationOutput may say that blank_yn is true, but which
          // may not have any identifiedObjects attached (not even one with
          // taxonomy "Blank")
          .leftJoin('identificationOutputs.identifiedObjects', 'identifiedObjects')
          .andWhere(new Brackets(
            (qb) => {
              qb
                .where('identifiedObjects.taxonomyId in (SELECT unique_identifier FROM taxonomies WHERE common_name_english = :blank)', { blank: 'Blank' })
                .orWhere('"identificationOutputs".blank_yn IS true');
            }),
          );
      } else if (filters.status === 'notblank') {
        query.innerJoin('dataFile.latestIdentificationOutputs', 'identificationOutputs')
          .innerJoin('identificationOutputs.identifiedObjects', 'identifiedObjects')
          .andWhere('identifiedObjects.taxonomyId in (SELECT unique_identifier FROM taxonomies WHERE common_name_english <> :blank)').setParameter('blank', 'Blank');
      }
    }

    if (info.others && info.others.notIdentification) {
      query.andWhere('dataFile.identifiedByExpert IS FALSE');
    } else {
      query.andWhere('dataFile.identifiedByExpert IS TRUE');
    }

    if (info.others && info.others.projectIds && info.others.projectIds.length > 0) {
      const projectsOnWhichUserCanSeeDataFilesWithHumans = [];
      info.others.projectIds.forEach((id) => {
        if (projectsOfWhichUserIsOwner.includes(id)) { projectsOnWhichUserCanSeeDataFilesWithHumans.push(id); }
      });

      if (projectsOnWhichUserCanSeeDataFilesWithHumans.length > 0) {
        query.andWhere(`
          ((deployment.projectId in (:...projectIds) AND dataFile.humanIdentified IS false)
          OR
          (deployment.projectId in (:...projectsOnWhichUserCanSeeDataFilesWithHumans) AND dataFile.humanIdentified IS true))`)
          .setParameter('projectIds', info.others.projectIds)
          .setParameter('projectsOnWhichUserCanSeeDataFilesWithHumans', projectsOnWhichUserCanSeeDataFilesWithHumans);
      } else {
        query.andWhere('deployment.projectId in (:...projectIds) AND dataFile.humanIdentified IS false')
          .setParameter('projectIds', info.others.projectIds);
      }
    }

    return query;
  }

  setFiltersGetById(query: SelectQueryBuilder<DataFiles>, info: InfoDto) {
    const projectsOfWhichUserIsOwner = this.getProjectsOfWhichUserIsOwner(info.authenticatedUser);

    if (info.pagination.includes && info.pagination.includes.indexOf('deployment') >= 0) {
      query.innerJoinAndSelect('dataFile.deployment', 'deployment');
      info.pagination.includes.splice(info.pagination.includes.indexOf('deployment'), 1);
    } else {
      query.innerJoin('dataFile.deployment', 'deployment');
    }
    query.andWhere('deployment.projectId = :projectId').setParameter('projectId', info.params.projectId);
    query.andWhere('deployment.id = :deploymentId').setParameter('deploymentId', info.params.deploymentId);
    if (!projectsOfWhichUserIsOwner.includes(info.params.projectId)) {
      query.andWhere('dataFile.humanIdentified=false');
    }
    return query;
  }

  setFiltersDelete(query: SelectQueryBuilder<DataFiles>, info: InfoDto) {
    query.innerJoin('dataFile.deployment', 'deployment');
    query.where('deployment.projectId = :projectId').setParameter('projectId', info.params.projectId);
    return query;
  }

  setFiltersUpdate(query: SelectQueryBuilder<DataFiles>, info: InfoDto) {
    query.innerJoin('dataFile.deployment', 'deployment');
    query.where('deployment.projectId = :projectId').setParameter('projectId', info.params.projectId);
    return query;
  }

  async getDeploymentById(id: number): Promise<Deployments> {
    return this.deploymentsRepository.findOne(id);
  }

  async getIdentificationOutputsByDataFileId(id: number): Promise<IdentificationOutputs[]> {
    return this.identificationOutputsRepository.find({ where: { dataFileId: id } });
  }

  async getParticipantById(id: number): Promise<Participants> {
    return this.participantsRepository.findOne(id);
  }

  async getExifDataFiles(id: number): Promise<ExifDataFilePivot[]> {
    return this.exifDataFilePivotRepository.find({ where: { dataFileId: id } });
  }

  async getExifTagById(id: number): Promise<ExifTags> {
    return this.exifTagsRepository.findOne(id);
  }

  async generateUploadUrl(fileName: string, contentType: string, clientId: string, info?: InfoDto) {
    logger.debug('Generating upload url');
    const project = await this.projectsRepository.findOne(info.params.projectId);
    if (!project) {
      throw new NotFoundException('Project not found with id ', info.params.projectId);
    }
    const deployment = await this.deploymentsRepository.createQueryBuilder('deployment')
      .where('deployment.projectId = :projectId').andWhere('deployment.id = :deploymentId')
      .setParameters({ deploymentId: info.params.deploymentId, projectId: info.params.projectId }).getOne();
    if (!deployment) {
      throw new NotFoundException('Deployment not found with id ', info.params.deploymentId);
    }

    const mediaType = await this.mediaTypesRepository.createQueryBuilder('mediaType')
      .where('mediaType.mime = :mime').setParameter('mime', contentType).getOne();
    if (!mediaType) {
      throw new NotFoundException('Content type not supported');
    }

    return this.storageService.getSignedUrlForUpload(project.slug, deployment.id.toString(), info.authenticatedUser.user.id.toString(), fileName, contentType, clientId);
  }

  async generateDownloadUrl(id: number, info?: InfoDto) {
    logger.debug('Generating download url of ', id);
    const project = await this.projectsRepository.findOne(info.params.projectId);
    if (!project) {
      throw new NotFoundException('Project not found with id ', info.params.projectId);
    }
    const deployment = await this.deploymentsRepository.createQueryBuilder('deployment')
      .where('deployment.projectId = :projectId').andWhere('deployment.id = :deploymentId')
      .setParameters({ deploymentId: info.params.deploymentId, projectId: info.params.projectId }).getOne();
    if (!deployment) {
      throw new NotFoundException('Deployment not found with id ', info.params.deploymentId);
    }

    const dataFile = await this.dataFilesRepository.createQueryBuilder('dataFile').innerJoin('dataFile.deployment', 'deployment')
      .where('deployment.projectId = :projectId').andWhere('deployment.id = :deploymentId')
      .andWhere('dataFile.id = :dataFileId')
      .setParameters({ deploymentId: info.params.deploymentId, projectId: info.params.projectId, dataFileId: id }).getOne();
    if (!dataFile) {
      throw new NotFoundException('Data file not found with id ', id.toString());
    }

    /**
     * We normally store a path only (to a file on a project's bucket) in the
     * filepath field of a dataFile. This is used to obtain the full URL via
     * `getSignedUrlWIFile()`.
     * However, when we delete a file because a human is identified in it, in
     * projects whose settings dictate that we should outright delete any data
     * files with humans, we set this field to the URL of a placeholder image.
     * The following logic handles this scenario.
     */
    if (UrlUtil.isUrl(dataFile.filepath)) { return dataFile.filepath; }

    return this.storageService.getSignedUrlWIFile(project.slug, dataFile.filepath);
  }

  async validateBeforeCreate(createModel: CreateDataFileDto, info: InfoDto): Promise<void> {
    const existMime = await this.mediaTypesRepository.findOne({ where: { mime: createModel.mimetype } });
    if (!existMime) {
      throw new BadRequestException('File not supported');
    }
    const deployment = await this.deploymentsRepository.findOne({ where: { id: createModel.deploymentId, projectId: info.params.projectId } });
    if (!deployment) {
      throw new NotFoundException('Deployment not found');
    }
    if (createModel.sequenceId) {
      const sequence = await this.identificationMethodTaxonomyPivotRepository.findOne();
      if (!sequence) {
        throw new NotFoundException('Sequence not found');
      }
    }
  }

  private async identifyImage(path: string, lat?: number, lon?: number, country?: string): Promise<IdentificationOutputs> {
    // TODO -- need to pass the model as parameter
    const model = await this.identificationMethodsRepository.findOne({
      where: { default_model: true }, // Adding the possibility of using other models in other contexts.
    });
    logger.debug('Model attributes: ', model);

    const modelName = model.name;
    const modelThresh = model.id_threshold;
    const modelEndpoint = model.endpoint;
    const modelOutput = await CVUtils.identify(path, modelEndpoint, modelName, { lat, lon, country });
    logger.debug('type:', typeof(modelOutput));
    logger.debug('model_output:', modelOutput);

    const tagsOverThreshold = modelOutput.filter(ident => ident.value > modelThresh);
    logger.debug('tags_over_threshold', tagsOverThreshold);

    const identificationOutput = new IdentificationOutputs();
    let identifiedObject: IdentifiedObjects; // Will models have more than one identification in the future?
    let finalTag;
    let confidence = null;

    if (tagsOverThreshold.length < 1) {
      const unknownSpecies = await this.taxonomiesRepository.findOne({
        where: {
          scientificName: 'Unknown species',
        },
      });

      logger.debug('unknownSpecies', unknownSpecies);
      logger.debug('CV UNKNOWN');
      // identificationOutput = new IdentificationOutputs();
      identificationOutput.blankYn = false;
      identificationOutput.identificationMethodId = model.id;
      identifiedObject = new IdentifiedObjects();
      identifiedObject.individualIdentified = false;
      identifiedObject.taxonomyId = unknownSpecies.uniqueIdentifier;
      identificationOutput.identifiedObjects = [identifiedObject];
      return identificationOutput;
      // return null
    }
    confidence = tagsOverThreshold[0].value;
    if (confidence >= 0.99) {
      confidence = 0.99;
    }
    finalTag = tagsOverThreshold[0].tag;

    identificationOutput.confidence = confidence;
    // final_tag = ';;;;;';
    logger.debug('final_tag', finalTag);
    // TODO -- some kind of alert if a model outputs more than one tag.
    // Shouldn't happen if we keep using softmax outputs (i.e. th > .5
    // excludes the possibility of two tags over the threshold.

    logger.debug('Finding associated taxonomy for tag', finalTag, 'and model', modelName);

    const finalUuid = finalTag.split(';', 1)[0];
    logger.debug('final_uuid:', finalUuid);

    const tagTaxonomy = await this.taxonomiesRepository.findOne({
      where: {
        uniqueIdentifier: finalUuid,
      },
    });
    logger.debug('Taxonomy found:', tagTaxonomy);

    // HACK ↓↓↓↓↓ - REDO
    if (finalUuid === 'f1856211-cfb7-4a5b-9158-c0f72fd09ee6') {
      logger.debug('HERE');
      // identificationOutput = new IdentificationOutputs();
      identificationOutput.blankYn = true;
      identificationOutput.identificationMethodId = model.id;
      return identificationOutput;
    }
    // HACK ↑↑↑↑↑ - REDO

    if (tagTaxonomy) {
      // identificationOutput = new IdentificationOutputs();
      identificationOutput.blankYn = false;
      identificationOutput.identificationMethodId = model.id;
      identifiedObject = new IdentifiedObjects();
      identifiedObject.individualIdentified = false;
      identifiedObject.taxonomyId = tagTaxonomy.uniqueIdentifier;
      identificationOutput.identifiedObjects = [identifiedObject];
      // identificationOutputsRepository
      // identificationOutputsRepository.push(identificationOutput);
      logger.debug('identificationOutput', identificationOutput);
    } else {
      logger.debug('No taxonomy found associated');
      return null;
    }
    return identificationOutput;
  }

  private async obtainExifTags(path: string): Promise<ExifDataFilePivot[]> {
    const exifDataFiles = [];
    try {
      const metadata: Object = await ExifUtils.metadata(path);
      for (const key in metadata) {
        logger.debug('Searching if exist exif tag: ', key);
        let exifTag = await this.exifTagsRepository.findOne({ where: { tagName: key } });
        if (!exifTag) {
          exifTag = new ExifTags();
          exifTag.tagName = key;
          await this.exifTagsRepository.save(exifTag);
        }
        const exifDataFile = new ExifDataFilePivot();
        exifDataFile.exifTagId = exifTag.id;
        exifDataFile.value = metadata[key];
        exifDataFiles.push(exifDataFile);
      }

    } catch (err) {
      logger.error('Error obtaining tags', err);
    }

    return exifDataFiles;
  }

  async create(createModel: CreateDataFileDto, info?: InfoDto, noCV: boolean = false): Promise<DataFiles> {
    logger.debug(`Creating ${this.alias}`);
    await this.validateBeforeCreate(createModel, info);
    logger.debug('noCV:', noCV);
    logger.debug(`info.params: ${JSON.stringify(info.params)}`);
    try {
      logger.debug('create', createModel);
      const project = await this.projectsRepository.findOne(info.params.projectId);
      const deployment = await this.deploymentsRepository.findOne(info.params.deploymentId);
      const location = await this.locationsRepository.findOne(deployment.locationId);

      logger.debug('project:', project);
      logger.debug('deployment:', deployment);
      logger.debug('location:', location);

      const countryCode = location.country;
      const lat = location.latitude;
      const lon = location.longitude;

      const exifs = await this.obtainExifTags(createModel.localPath);

      // Identifying image
      let identification;
      let status;
      let cvRan = false;
      if (noCV) {
        logger.debug('Skipping identification as `noCV` was requested');
        identification = null;
        status = 'NOCV';
      } else {
        try {
          identification = await this.identifyImage(createModel.localPath, lat, lon, countryCode);
          cvRan = true;
          status = 'CV';
          // identification.participantId = info.authenticatedUser.user.id;
          logger.debug('identification', identification);
        } catch (err) {
          logger.error('There was a problem getting the identification from the CV model:', err);
          identification = null;
          status = 'CVFAILED';
        }
      }

      // Creating thumbnail // TODO: delete thumbnail
      const thumb = await CVUtils.createThumbnail(createModel.localPath);
      logger.debug('thumb:', thumb);
      const paths = await this.storageService.uploadToBuckets(
        project.slug,
        createModel.deploymentId.toString(),
        createModel.localPath,
        thumb,
      );
      const finalName = paths[0];
      const finalThumbUrl = paths[1];

      // const finalName = await this.storageService.uploadToTempBucket(project.slug, createModel.deploymentId.toString(), info.authenticatedUser.user.id.toString(), createModel.localPath, true, noCv);
      const dataFile = new DataFiles();
      dataFile.deploymentId = createModel.deploymentId;
      dataFile.dataFileId = createModel.dataFileId;
      dataFile.filename = createModel.fileName;
      dataFile.originalLocationUrl = createModel.originalLocationUrl;
      dataFile.filepath = finalName;
      dataFile.filesize = createModel.size;
      dataFile.timestamp = createModel.timestamp;
      dataFile.exifDataFilePivots = exifs;
      dataFile.participantId = info.authenticatedUser.user.id;
      dataFile.mediaType = await this.mediaTypesRepository.findOne({ where: { mime: createModel.mimetype } });
      dataFile.identificationOutputs = [identification];
      dataFile.status =  status; // CVRan ? 'CV' : null;
      dataFile.thumbnailUrl = finalThumbUrl;
      if (createModel.sequenceId) {
        const dataFileSequence = new DataFileSequencePivot();
        dataFileSequence.sequence = await this.sequencesRepository.findOne(createModel.sequenceId);
        dataFileSequence.position = createModel.position;
        dataFile.dataFileSequencePivots = [dataFileSequence];
      }

      logger.debug('final dataFile', dataFile);
      await this.dataFilesRepository.save(dataFile);

      /**
       * Scan image using imagemagic
       */
      const imageInfo = await this.imageManagementService.getInfo(createModel.localPath);
      const imageFsInfo = await fs.stat(createModel.localPath);
      imageInfo.size = imageFsInfo.size;
      logger.debug('imageInfo', imageInfo);
      // logger.debug('imageFsInfo', imageFsInfo);
      const imageMetakeyList = await this.dataFileMetakeysRepository.find({ where: { mediaTypes: dataFile.mediaType.id } });
      const dataFileMetavalues = [];

      /**
       * Create Data File Metavalues instances
       */

      imageMetakeyList.forEach((metaKey) => {
        if (imageInfo[metaKey.keyName]) {
          const item = new DataFileMetavalues();
          item.keyId = metaKey.id;
          item.dataFileId = dataFile.id;
          item.value = imageInfo[metaKey.keyName];

          dataFileMetavalues.push(this.dataFileMetavaluesRepository.save(item));
        }
      });

      await Promise.all(dataFileMetavalues);

      return dataFile;
    } catch (err) {
      logger.error('Error', err);
      throw err;
    } finally {
      try {
        logger.debug('Removing file', createModel.localPath);
        await fs.unlink(createModel.localPath);
        logger.debug('Removing thumbnail');
        await fs.unlink(`${createModel.localPath}-thumb`);
      } catch (err) {
        logger.error('Error removing file', err);
      }
    }
  }

  async remove(id: number, info?: InfoDto): Promise<DataFiles> {
    const DELETION_TIMEOUT = 7200; // seconds

    logger.debug('Remove');

    let query = this.repository.createQueryBuilder(this.alias);
    query = this.setFiltersDelete(query, info);

    // Search for matching data file, and include taxonomy data of identified
    // objects (if any)
    query
      .leftJoinAndSelect('dataFile.identificationOutputs', 'identificationOutputs')
      .leftJoinAndSelect('identificationOutputs.identifiedObjects', 'identifiedObjects')
      .leftJoinAndSelect('identifiedObjects.taxonomy', 'taxonomy')
       // using 'depl' alias to avoid clash in generated SQL with the
       // 'deployments' name already used as part of the dataFile entity's
       // relationships
      .leftJoinAndSelect('dataFile.deployment', 'depl')
      .leftJoinAndSelect('depl.project', 'project')
      .andWhere(`${this.alias}.id = :id`).setParameter('id', id);
    const model = await query.getOne();
    if (!model) {
      throw new NotFoundException(`${this.alias} not found`);
    }

    logger.debug(`Model: ${JSON.stringify(model)}`);

    // Have any humans been identified in this data file?
    // For each of the identified objects of each identification output of
    // the data file, check if genus/species is homo/sapiens; then flatten
    // the resulting array, and finally filter only the true values and count
    // them - if > 0, humans have been identified.
    const humansIdentified = model.identificationOutputs && [].concat(
      model.identificationOutputs.map((element) => {
        return element.identifiedObjects.map((element) => {
          return element.taxonomy &&
            element.taxonomy.genus && element.taxonomy.genus.toLowerCase() === 'homo' &&
            element.taxonomy.species && element.taxonomy.species.toLowerCase() === 'sapiens';
        });
      }),
    ).filter(element => element).length > 0;

    logger.debug(`humansIdentified: ${JSON.stringify(humansIdentified)}`);

    logger.debug(`Project deleteDataFilesWithIdentifiedHumans: ${model.deployment.project.deleteDataFilesWithIdentifiedHumans === true}`);

    const timeDiff = Math.floor(((new Date().getTime() - new Date(model.createdAt).getTime()) / 1000) / 60);

    // Refuse to process data file deletion request if more than DELETION_TIMEOUT seconds
    // have elapsed since the data file was created, AND either no humans have
    // been identified in the data file, or the parent project is not set to
    // allow deletion of data files in which humans have been identified
    if (timeDiff > DELETION_TIMEOUT && (!humansIdentified || !model.deployment.project.deleteDataFilesWithIdentifiedHumans)) {
      throw new BadRequestException(`Data files can only be deleted if they have been uploaded less than ${DELETION_TIMEOUT} seconds ago.`);
    }

    await this.repository.remove(model);
    model.id = id;

    return model;
  }

  async setDataCreate(create: CreateDataFileDto, info: InfoDto) {
    const project = await this.projectsRepository.findOne(info.params.projectId);

    const model = new DataFiles();

    return model;

  }

  // TODO: find another solution to make it work. This is due the AfterLoad hook defined in the DataFiles Model
  // @ts-ignore TS2416
  async setDataUpdate(model: DataFiles, update: UpdateDataFileDto, info: InfoDto) {
    const result = { ...model, ...update };
    return result;
  }

  async findAllWithoutOrganizationByIdentificationPermission(pagination: PaginationModel, info?: InfoDto, filters: any = null): Promise<[IDataFileGroup[], number]> {
    // getting project of organizationId with view image permission
    const projectIds = PermissionsUtils.getProjectsInAllOrganizationsWithPermission(info.authenticatedUser, PERMISSIONS.IDENTIFICATION_CREATE);
    if (!projectIds || projectIds.length === 0) {
      return [[], 0];
    }
    info.others = { ...info.others, projectIds: projectIds.map((p: ProjectsDto) => p.id), notIdentification: true };
    return this.getAllGrouped(pagination, info, filters);
  }

  async findAllInProjectByIdentificationPermission(projectId: number, pagination: PaginationModel, info?: InfoDto, filters: any = null): Promise<[IDataFileGroup[], number]> {

    info.others = { ...info.others, projectIds: [projectId], notIdentification: true };
    return this.getAllGrouped(pagination, info, filters);
  }

  async findAllInOrganizationByIdentificationPermission(organizationId: number, pagination: PaginationModel, info?: InfoDto, filters: any = null): Promise<[IDataFileGroup[], number]> {
    // getting project of organizationId with view image permission
    const projectIds = PermissionsUtils.getProjectsInOrganizationWithPermission(info.authenticatedUser, PERMISSIONS.DATA_FILE_GET_ALL, organizationId);
    if (!projectIds || projectIds.length === 0) {
      return [[], 0];
    }
    info.others = { ...info.others, projectIds: projectIds.map((p: ProjectsDto) => p.id), notIdentification: true };
    return this.getAllGrouped(pagination, info, filters);
  }

  async findAllWithoutOrganization(pagination: PaginationModel, info?: InfoDto, filters: any = null): Promise<[IDataFileGroup[], number]> {
    // getting project of organizationId with view image permission
    const projectIds = PermissionsUtils.getProjectsInAllOrganizationsWithPermission(info.authenticatedUser, PERMISSIONS.DATA_FILE_GET_ALL);
    if (!projectIds || projectIds.length === 0) {
      return [[], 0];
    }
    info.others = { ...info.others, projectIds: projectIds.map((p: ProjectsDto) => p.id) };
    return this.getAllGrouped(pagination, info, filters);
  }

  async findAllInOrganization(organizationId: number, pagination: PaginationModel, info?: InfoDto, filters: any = null): Promise<[IDataFileGroup[], number]> {
    // getting project of organizationId with view image permission
    const projectIds = PermissionsUtils.getProjectsInOrganizationWithPermission(info.authenticatedUser, PERMISSIONS.DATA_FILE_GET_ALL, organizationId);
    if (!projectIds || projectIds.length === 0) {
      return [[], 0];
    }
    info.others = { ...info.others, projectIds: projectIds.map((p: ProjectsDto) => p.id) };
    return this.getAllGrouped(pagination, info, filters);
  }

  async findAllInInitiative(initiativeId: number, pagination: PaginationModel, info?: InfoDto, filters: any = null): Promise<[IDataFileGroup[], number]> {
    const projectIds = PermissionsUtils.getProjectsInInitiativeWithPermission(info.authenticatedUser, PERMISSIONS.DATA_FILE_GET_ALL, initiativeId);
    if (!projectIds || projectIds.length === 0) {
      return [[], 0];
    }
    info.others = { ...info.others, projectIds: projectIds.map((p: ProjectsDto) => p.id) };
    return this.getAllGrouped(pagination, info, filters);
  }

  async findAllInInitiativeByIdentificationPermission(initiativeId: number, pagination: PaginationModel, info?: InfoDto, filters: any = null): Promise<[IDataFileGroup[], number]> {
    const projectIds = PermissionsUtils.getProjectsInInitiativeWithPermission(info.authenticatedUser, PERMISSIONS.DATA_FILE_GET_ALL, initiativeId);
    if (!projectIds || projectIds.length === 0) {
      return [[], 0];
    }
    info.others = { ...info.others, projectIds: projectIds.map((p: ProjectsDto) => p.id), notIdentification: true };
    return this.getAllGrouped(pagination, info, filters);
  }

  async getByClientId(clientId: string, pagination: PaginationModel, info?: InfoDto): Promise<DataFiles> {
    logger.debug('Getting by clientId');
    let query = this.repository.createQueryBuilder(this.alias);
    info.pagination = pagination;
    query.andWhere(`${this.alias}.clientId = :id`).setParameter('id', clientId);
    query = PaginationUtil.addIncludesFields(query, this.alias, pagination);

    const model = await query.getOne();
    if (!model) {
      throw new NotFoundException(`${this.alias} not found`);
    }
    return model;
  }

  /**
   * highlights bulk data files
   * @param deploymentId
   * @param fileDataIdList
   * @param isHighlighted
   * @param info
   */
  async highlight(fileDataIdList: number[], isHighlighted: boolean, info?: InfoDto) : Promise<DataFiles[]> {
    logger.debug(`Set highlight status to ${isHighlighted} for data files with id: ${fileDataIdList}`);

    try {
      // Compute list of project ids of projects on which the user has
      // DATA_FILE_UPDATE permission
      const userProjectIdWithDataFileUpdatePermission = info.authenticatedUser.projectRole
        .filter((projRole) => {
          return projRole.role && projRole.role.permissions && projRole.role.permissions.find((permission) => {
            if (permission.slug === PERMISSIONS.DATA_FILE_UPDATE) {
              return projRole;
            }
          });
        })
        .map((projRole) => {
          return projRole.project.id;
        });

      // compute list of ids of DataFiles belonging to projects on which the
      // user has update permission
      const dataFilesThatUserCanUpdate = await this.dataFilesRepository.createQueryBuilder('dataFile')
        .innerJoin('dataFile.deployment', 'deployment')
        .where('dataFile.id IN(:...fileDataIdList)', { fileDataIdList })
        .andWhere('deployment.projectId IN(:...userProjectIdWithDataFileUpdatePermission)', { userProjectIdWithDataFileUpdatePermission })
        .getMany();

      logger.debug(`DataFiles that can be updated: ${JSON.stringify(dataFilesThatUserCanUpdate.map(df => df.id))}`);

      return await Promise.all(dataFilesThatUserCanUpdate.map(async (dataFile) => {
        dataFile.highlighted = isHighlighted;
        return this.repository.save<DeepPartial<DataFiles>>(dataFile);
      }));

    } catch (error) {
      logger.error(`Error highlighting data files: ${fileDataIdList}, ${error}`);
    }
  }

  checkDataFilePermissions (authenticatedUser, projectId) {
    let editIdentifications: Boolean;
    let highlightPhotos: Boolean;
    let deletePhotos: Boolean = false;

    try {
      const { projectRole: roles } = authenticatedUser;
      const projectRole = roles.find(item => item.project.id === projectId);

      editIdentifications = projectRole.role.permissions.some(item => item.slug === PERMISSIONS.IDENTIFICATION_UPDATE);
      highlightPhotos = projectRole.role.permissions.some(item => item.slug === PERMISSIONS.DATA_FILE_UPDATE);
      deletePhotos = projectRole.role.permissions.some(item => item.slug === PERMISSIONS.DATA_FILE_DELETE);
    } catch (err) {
      logger.error('Error check DataFile permissions', err);
    }

    return { editIdentifications, highlightPhotos, deletePhotos };
  }

  enrichDataFilesByPermissions = async (authenticatedUser, data) => {
    let result = data;
    try {
      const deploymentIds = data.map(item => item.data[0].deploymentId);
      const uniqueDeploymentIds = [...new Set(deploymentIds)];
      const deployments = await Promise.all(uniqueDeploymentIds.map((id: number) => this.getDeploymentById(id)));

      result = data.map((dataFile) => {
        const { projectId } = deployments.find(item => item.id === dataFile.data[0].deploymentId);
        const permissions = this.checkDataFilePermissions(authenticatedUser, projectId);
        dataFile.data[0].permissions = permissions;
        return dataFile;
      });

    } catch (err) {
      logger.error('Error getting permissions for data file', err);
    }

    return result;
  }

  /**
   * Add to the data file object a list of permissions that the user has on
   * the given data_file
   */
  enrichDataFileByPermissions = async (authenticatedUser, dataFile) => {
    const result = { ...dataFile };
    try {
      const { deploymentId, humanIdentified } = dataFile;
      const { projectId } = await this.getDeploymentById(deploymentId);
      const userRoleOnProject = this.getUserRoleOnProject(authenticatedUser, projectId);
      if (humanIdentified && userRoleOnProject !== ROLES.PROJECT_OWNER) {
        throw new Error(`The current user doesn't have suitable permissions on project ${projectId} to access data files which contain human identifications.`);
      }
      const permissions = this.checkDataFilePermissions(authenticatedUser, projectId);
      result.permissions = permissions;
    } catch (err) {
      logger.error('Error getting permissions for data file', err);
    }

    return result;
  }

  /**
   * Retrieve user's role on given project
   */
  getUserRoleOnProject = (authenticatedUser: AuthenticatedUserDto, projectId: number) : string => {
    const { projectRole: roles } = authenticatedUser;
    const { role: { slug: role } } = roles.find(item => item.project.id === projectId);
    return role;
  }

  /**
   * Retrieve list of project ids of projects on which the user has
   * `PROJECT_OWNER` role
   */
  getProjectsOfWhichUserIsOwner = (authenticatedUser: AuthenticatedUserDto) : number[] => {
    const { projectRole: roles } = authenticatedUser;
    return roles
      .filter(projectRoles => projectRoles.role.slug === ROLES.PROJECT_OWNER)
      .map(item => item.project.id);
  }

  // Update the data file status and identifiedByExpert fields if it doesn't have Expert Identification outputs
  async updateDataFileWithIdentifications(dataFileId: number, identficationOutputsAfterDelete: IdentificationOutputs[]): Promise<void> {
    try {
      const expertIdentificationTypeName: string = 'Expert identification';
      const expertIdentificationOutputsCount: number = await this.identificationOutputsRepository.createQueryBuilder('io')
        .innerJoin('io.identificationMethod', 'identificationMethod')
        .where('io.dataFileId = :dataFileId', { dataFileId })
        .andWhere('identificationMethod.name = :expertIdentificationTypeName', { expertIdentificationTypeName })
        .getCount();

      if (expertIdentificationOutputsCount === 0) {
        const newDataFileStatus: string = (identficationOutputsAfterDelete.length > 0) ? 'CV' : 'CVFAILED';

        await this.dataFilesRepository.createQueryBuilder()
          .update<DeepPartial<DataFiles>>(DataFiles)
          .set({
            identifiedByExpert: false,
            status: newDataFileStatus,
          })
          .where('id = :id', { id: dataFileId })
          .execute();
      }
    }  catch (error) {
      logger.error('Error updating data files identified field, ', error);
    }
  }

}
