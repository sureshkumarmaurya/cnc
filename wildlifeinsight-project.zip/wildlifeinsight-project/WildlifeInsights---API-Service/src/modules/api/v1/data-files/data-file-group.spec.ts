import { DataFileGroupService } from './data-file-group.service';
import * as faker from 'faker';

const dateList = [
  '2019-04-05T07:21:50.087Z', // 5  // 1  // 1
  '2019-04-05T07:20:10.087Z', // 1  // 2  // 3
  '2019-04-05T07:21:55.087Z', // 6  // 3  // 2
  '2019-04-05T07:20:11.087Z', // 2  // 4  // 4
  '2019-04-05T07:22:30.087Z', // 7  // 5  // 6
  '2019-04-05T07:20:51.087Z', // 4  // 6  // 7
  '2019-04-05T07:20:20.087Z', // 3  // 7  // 5
];

const createRandomDataFiles = (count: number = 1) => {
  const output = [];

  for (let index = 0; index < count; index++) {
    const currentItem = {
      id: faker.random.uuid(),
      createdAt: faker.date.past(),
      timestamp: null,
      filepath: 'https://storage.googleapis.com/file/deployment/1/file.jpg',
      thumbnailUrl: 'https://storage.googleapis.com/file_thumbnails/deployment/1/file_thumbnails.jpg',
      highlighted: faker.random.boolean(),
      clientId: faker.random.uuid(),
    };

    output.push(currentItem);
  }

  return output;
}

const dataFileListMapped = createRandomDataFiles(7).map((item, index) => {
  item.timestamp = new Date(dateList[index]);
  return item;
});

describe('# DataFileGroupService', () => {
  let dataFileGroupService: DataFileGroupService;

  beforeEach(() => {
    dataFileGroupService = new DataFileGroupService();
  });

  describe('# GroupByTimeStep', () => {

    it('(30, []) should return an empty array', () => {
      const result = dataFileGroupService.groupByTimeStep(30, []);
      expect(result.length).toEqual(0);
    });

    it('(0, []) should return an empty array', () => {
      const result = dataFileGroupService.groupByTimeStep(0, []);
      expect(result.length).toEqual(0);
    });

    it('(0, dataFileListMapped) should return an array with 7 elements', () => {
      const result = dataFileGroupService.groupByTimeStep(0, dataFileListMapped);
      expect(result.length).toEqual(7);
      expect(result[0].data.length).toEqual(1);
    });

    it('(30, dataFileListMapped) should return array of DataFileGroup objects', () => {
      const result = dataFileGroupService.groupByTimeStep(30, dataFileListMapped);
      expect(result.length).toEqual(4);

      expect(result[0].data.length).toEqual(2);
      expect(result[1].data.length).toEqual(3);
      expect(result[2].data.length).toEqual(1);
      expect(result[3].data.length).toEqual(1);
      
      expect(result[0].data[0].indexInitial).toEqual(0);
      expect(result[0].data[1].indexInitial).toEqual(2);

      expect(result[1].data[0].indexInitial).toEqual(1);
      expect(result[1].data[1].indexInitial).toEqual(3);
      expect(result[1].data[2].indexInitial).toEqual(6);

      expect(result[2].data[0].indexInitial).toEqual(4);

      expect(result[3].data[0].indexInitial).toEqual(5);
    });
  });
});



