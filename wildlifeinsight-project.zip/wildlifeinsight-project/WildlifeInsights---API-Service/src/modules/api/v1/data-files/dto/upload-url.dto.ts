import { IsString, MaxLength, IsOptional } from 'class-validator';
import { ApiModelProperty } from '@nestjs/swagger';

export class UploadUrlDto {

  @IsString()
  @MaxLength(255)
  @ApiModelProperty({ required: true })
  fileName: string;

  @IsString()
  @MaxLength(255)
  @ApiModelProperty({ required: true })
  contentType: string;

  @IsString()
  @IsOptional()
  @MaxLength(255)
  @ApiModelProperty({ required: false })
  clientId: string;

}
