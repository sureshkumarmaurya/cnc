import { DataFileService } from './data-file.service';
import { Resolver, Query, ResolveProperty, Mutation, Args, Parent } from '@nestjs/graphql';
import { UpdateDataFileDto } from './dto/update-data-file.dto';
import { HighlightDataFileListDto } from './dto/highlight-data-file-list.dto';
import { UseInterceptors, UseGuards, ParseIntPipe } from '@nestjs/common';
import { ValidationGraphqlInterceptor } from 'interceptors/validation-graphql.interceptor';
import { PaginationGraphqlInterceptor } from 'interceptors/pagination-graphql.interceptor';
import { Permissions } from 'decorators/permissions.decorator';
import { GraphqlAuthGuard } from 'guards/graphql-passport.guard';
import { GraphqlUserWithPermissions } from 'decorators/graphql-user.decorator';
import { DataFiles } from 'modules/database/entities/data-files.entity';
import { PERMISSIONS } from 'utils/permissions.enum';
import { DataFilesPaginatedDto } from './dto/data-files.dto';

@Resolver('DataFile')
export class DataFileResolver {
  constructor(private readonly dataFileService: DataFileService) { }

  @Query()
  @UseGuards(GraphqlAuthGuard)
  @UseInterceptors(PaginationGraphqlInterceptor)
  @Permissions(PERMISSIONS.DATA_FILE_GET_ALL)
  async getDataFilesForProject(@GraphqlUserWithPermissions(PERMISSIONS.DATA_FILE_GET_ALL) authenticatedUser, @Args() args) {
    const data = await this.dataFileService.findAllDataFiles(args.pagination, { authenticatedUser, params: args }, args.filters);
    const dataFilesWithPermissions = await this.dataFileService.enrichDataFilesByPermissions(authenticatedUser, data[0]);
    return new DataFilesPaginatedDto(dataFilesWithPermissions, data[1], args.pagination.pageSize, args.pagination.pageNumber);
  }

  @Query()
  @UseGuards(GraphqlAuthGuard)
  @UseInterceptors(PaginationGraphqlInterceptor)
  async getDataFilesForInitiative(@Args('initiativeId') initiativeId: number, @GraphqlUserWithPermissions() authenticatedUser, @Args() args) {
    const data = await this.dataFileService.findAllInInitiative(initiativeId, args.pagination, { authenticatedUser, params: args }, args.filters);
    const dataFilesWithPermissions = await this.dataFileService.enrichDataFilesByPermissions(authenticatedUser, data[0]);
    return new DataFilesPaginatedDto(dataFilesWithPermissions, data[1], args.pagination.pageSize, args.pagination.pageNumber);
  }

  @Query()
  @UseGuards(GraphqlAuthGuard)
  @UseInterceptors(PaginationGraphqlInterceptor)
  async getDataFilesForIdentifyForInitiative(@GraphqlUserWithPermissions() authenticatedUser, @Args('initiativeId') initiativeId: number, @Args() args) {
    const data = await this.dataFileService.findAllInInitiativeByIdentificationPermission(initiativeId, args.pagination, { authenticatedUser, params: args }, args.filters);
    const dataFilesWithPermissions = await this.dataFileService.enrichDataFilesByPermissions(authenticatedUser, data[0]);
    return new DataFilesPaginatedDto(dataFilesWithPermissions, data[1], args.pagination.pageSize, args.pagination.pageNumber);
  }

  @Query()
  @UseGuards(GraphqlAuthGuard)
  @UseInterceptors(PaginationGraphqlInterceptor)
  async getDataFilesForOrganization(@Args('organizationId') organizationId: number, @GraphqlUserWithPermissions() authenticatedUser, @Args() args) {
    const data = await this.dataFileService.findAllInOrganization(organizationId, args.pagination, { authenticatedUser, params: args }, args.filters);
    const dataFilesWithPermissions = await this.dataFileService.enrichDataFilesByPermissions(authenticatedUser, data[0]);
    return new DataFilesPaginatedDto(dataFilesWithPermissions, data[1], args.pagination.pageSize, args.pagination.pageNumber);
  }

  @Query()
  @UseGuards(GraphqlAuthGuard)
  @UseInterceptors(PaginationGraphqlInterceptor)
  async getDataFiles(@GraphqlUserWithPermissions() authenticatedUser, @Args() args) {
    const data = await this.dataFileService.findAllWithoutOrganization(args.pagination, { authenticatedUser, params: args }, args.filters);
    const dataFilesWithPermissions = await this.dataFileService.enrichDataFilesByPermissions(authenticatedUser, data[0]);
    return new DataFilesPaginatedDto(dataFilesWithPermissions, data[1], args.pagination.pageSize, args.pagination.pageNumber);
  }

  @Query()
  @UseGuards(GraphqlAuthGuard)
  @UseInterceptors(PaginationGraphqlInterceptor)
  @Permissions(PERMISSIONS.DATA_FILE_GET_ALL)
  async getDataFilesForIdentifyForProject(@GraphqlUserWithPermissions(PERMISSIONS.DATA_FILE_GET_ALL) authenticatedUser, @Args('projectId') projectId: number, @Args() args) {
    const data = await this.dataFileService.findAllInProjectByIdentificationPermission(projectId, args.pagination, { authenticatedUser, params: args }, args.filters);
    const dataFilesWithPermissions = await this.dataFileService.enrichDataFilesByPermissions(authenticatedUser, data[0]);
    return new DataFilesPaginatedDto(dataFilesWithPermissions, data[1], args.pagination.pageSize, args.pagination.pageNumber);
  }

  @Query()
  @UseGuards(GraphqlAuthGuard)
  @UseInterceptors(PaginationGraphqlInterceptor)
  async getDataFilesForIdentifyForOrganization(@GraphqlUserWithPermissions() authenticatedUser, @Args('organizationId') organizationId: number, @Args() args) {
    const data = await this.dataFileService.findAllInOrganizationByIdentificationPermission(organizationId, args.pagination, { authenticatedUser, params: args }, args.filters);
    const dataFilesWithPermissions = await this.dataFileService.enrichDataFilesByPermissions(authenticatedUser, data[0]);
    return new DataFilesPaginatedDto(dataFilesWithPermissions, data[1], args.pagination.pageSize, args.pagination.pageNumber);
  }

  @Query()
  @UseGuards(GraphqlAuthGuard)
  @UseInterceptors(PaginationGraphqlInterceptor)
  async getDataFilesForIdentify(@GraphqlUserWithPermissions() authenticatedUser, @Args('organizationId') organizationId: number, @Args() args) {
    const data = await this.dataFileService.findAllWithoutOrganizationByIdentificationPermission(args.pagination, { authenticatedUser, params: args }, args.filters);
    const dataFilesWithPermissions = await this.dataFileService.enrichDataFilesByPermissions(authenticatedUser, data[0]);
    return new DataFilesPaginatedDto(dataFilesWithPermissions, data[1], args.pagination.pageSize, args.pagination.pageNumber);
  }

  @Query()
  @UseGuards(GraphqlAuthGuard)
  @Permissions(PERMISSIONS.DATA_FILE_GET_ONE)
  async getDataFile(@GraphqlUserWithPermissions(PERMISSIONS.DATA_FILE_GET_ONE) authenticatedUser, @Args() args) {
    const { id } = args;
    const data = await this.dataFileService.getById(id, {}, { authenticatedUser, params: args });
    const dataFileWithPermissions = await this.dataFileService.enrichDataFileByPermissions(authenticatedUser, data);
    return dataFileWithPermissions;
  }

  @Query()
  @UseGuards(GraphqlAuthGuard)
  @Permissions(PERMISSIONS.DATA_FILE_GET_ONE)
  async getDataFileForClientId(@GraphqlUserWithPermissions(PERMISSIONS.DATA_FILE_GET_ONE) authenticatedUser, @Args() args) {
    const { id } = args;
    const data = await this.dataFileService.getByClientId(id, {}, { authenticatedUser, params: args });
    const dataFileWithPermissions = await this.dataFileService.enrichDataFileByPermissions(authenticatedUser, data);
    return dataFileWithPermissions;
  }

  @Query()
  @UseGuards(GraphqlAuthGuard)
  @Permissions(PERMISSIONS.DATA_FILE_DOWNLOAD)
  async getDataFileDownloadUrl(@GraphqlUserWithPermissions(PERMISSIONS.DATA_FILE_DOWNLOAD) authenticatedUser, @Args() args) {
    const { id } = args;
    const url = await this.dataFileService.generateDownloadUrl(id, { authenticatedUser, params: args });
    return { url };
  }

  @Query()
  @UseGuards(GraphqlAuthGuard)
  @Permissions(PERMISSIONS.DATA_FILE_CREATE)
  async getUploadUrl(@GraphqlUserWithPermissions(PERMISSIONS.DATA_FILE_CREATE) authenticatedUser, @Args() args) {
    const url = await this.dataFileService.generateUploadUrl(args.fileName, args.contentType, args.clientId, { authenticatedUser, params: args });
    return { url };
  }

  @ResolveProperty()
  async deployment(@Parent() dataFile: DataFiles) {
    return this.dataFileService.getDeploymentById(dataFile.deploymentId);
  }

  @ResolveProperty()
  async exifDataFiles(@Parent() dataFile: DataFiles) {
    return this.dataFileService.getExifDataFiles(dataFile.id);
  }

  @ResolveProperty()
  async identificationOutputs(@Parent() dataFile: DataFiles) {
    return this.dataFileService.getIdentificationOutputsByDataFileId(dataFile.id);
  }

  @ResolveProperty()
  async participant(@Parent() dataFile: DataFiles) {
    if (!dataFile.participantId) {
      return null;
    }
    return this.dataFileService.getParticipantById(dataFile.participantId);
  }

  @Mutation()
  @UseGuards(GraphqlAuthGuard)
  @Permissions(PERMISSIONS.DATA_FILE_UPDATE)
  @UseInterceptors(new ValidationGraphqlInterceptor(UpdateDataFileDto))
  async updateDataFile(@GraphqlUserWithPermissions(PERMISSIONS.DATA_FILE_UPDATE) authenticatedUser, @Args() args) {
    const { id, body } = args;
    return this.dataFileService.update(id, body, { authenticatedUser, params: args });
  }

  /**
   * Highlight bulk data files
   * @param authenticatedUser
   * @param args
   */
  @Mutation()
  @UseGuards(GraphqlAuthGuard)
  @Permissions(PERMISSIONS.DATA_FILE_GET_ONE)
  @UseInterceptors(new ValidationGraphqlInterceptor(HighlightDataFileListDto))
  highlightDataFileList(@GraphqlUserWithPermissions() authenticatedUser, @Args() args) {
    const { body } = args;
    return this.dataFileService.highlight(body.dataFileIdList, body.highlighted, { authenticatedUser, params: args });
  }

  @Mutation()
  @UseGuards(GraphqlAuthGuard)
  @Permissions(PERMISSIONS.DATA_FILE_DELETE)
  async deleteDataFile(@GraphqlUserWithPermissions(PERMISSIONS.DATA_FILE_DELETE) authenticatedUser, @Args() args) {
    const { id } = args;
    return this.dataFileService.remove(id, { authenticatedUser, params: args });
  }

  @Mutation()
  @UseGuards(GraphqlAuthGuard)
  @Permissions(PERMISSIONS.DATA_FILE_DELETE)
  async deleteDataFileList(@GraphqlUserWithPermissions() authenticatedUser, @Args() args) {
    const { idList } = args;
    const result = await this.dataFileService.removeMany(idList, { authenticatedUser, params: args });
    return { count: result.length };
  }
}
