import { ApiModelProperty } from '@nestjs/swagger';
import { DataFileMetavaluesDto } from 'modules/database/dto/data-file-metavalues.dto';
import { MetaDto } from 'modules/database/dto/meta.dto';

export class DataFileMetavaluesPaginatedDto {

  @ApiModelProperty({ type: DataFileMetavaluesDto, isArray: true })
  readonly data: DataFileMetavaluesDto[];

  @ApiModelProperty()
  readonly meta: MetaDto;

  constructor(data, totalItems: number, pageSize: number, page: number) {
    this.data = data;
    this.meta = new MetaDto(Math.ceil(totalItems / pageSize), totalItems, pageSize, page);
  }
}
