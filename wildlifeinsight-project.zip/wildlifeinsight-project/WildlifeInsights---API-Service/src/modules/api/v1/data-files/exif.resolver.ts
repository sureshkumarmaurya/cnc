import { CreateDataFileDto } from './dto/create-data-file.dto';
import { DataFileService } from './data-file.service';
import { Resolver, Query, ResolveProperty, Mutation, Args, Parent } from '@nestjs/graphql';
import { UseGuards } from '@nestjs/common';
import { PermissionsGraphQlGuard } from 'guards/permissions-graphql.guard';

import { ExifDataFilePivot } from 'modules/database/entities/exif-data-file-pivot.entity';

const logger = require('logger');

@Resolver('ExifDataFilePivot')
@UseGuards(PermissionsGraphQlGuard)
export class ExifResolver {
  constructor(private readonly dataFileService: DataFileService) {}

  @ResolveProperty()
  async exifTag(@Parent() exifDataFilePivot: ExifDataFilePivot) {
    return this.dataFileService.getExifTagById(exifDataFilePivot.exifTagId);
  }

}
