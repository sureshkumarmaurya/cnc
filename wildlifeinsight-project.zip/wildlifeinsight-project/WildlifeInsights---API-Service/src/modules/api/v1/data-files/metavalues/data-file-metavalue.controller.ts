import { Permissions } from 'decorators/permissions.decorator';
import { UpdateDataFileMetavalueDto } from './dto/update-data-file-metavalue.dto';
import { CreateDataFileMetavalueDto } from './dto/create-data-file-metavalue.dto';
import { Get, Controller, Req, Post, Body, Patch, Param, Delete, ParseIntPipe, UseGuards, UseInterceptors } from '@nestjs/common';
import { DataFileMetavalueService } from './data-file-metavalue.service';
import { ApiUseTags, ApiBearerAuth, ApiOperation, ApiResponse, ApiImplicitQuery, ApiImplicitParam } from '@nestjs/swagger';
import { DataFileMetavaluesPaginatedDto } from './dto/data-file-metavalues.dto';
import { Pagination } from 'decorators/pagination.decorator';
import { ValidationPipe } from 'pipes/validation.pipe';
import { DataFileMetavaluesDto } from 'modules/database/dto/data-file-metavalues.dto';
import { PermissionsGuard } from 'guards/permissions.guard';
import { User } from 'decorators/user.decorator';
import { AuthenticatedUserDto } from 'dto/authenticated-user.dto';
import { PERMISSIONS } from 'utils/permissions.enum';
import { DataFileMetavalueInterceptor } from 'interceptors/data-file-metavalue-interceptor';
import { PaginationModel } from 'utils/pagination.model';

const logger = require('logger');

export const dataFileMetavaluesRelations = ['key'];

@Controller('/api/v1/project/:projectId/deployment/:deploymentId/data-file/:dataFileId/data-file-metavalue')
@ApiUseTags('DataFileMetavalues')
@ApiBearerAuth()
@UseGuards(PermissionsGuard)
export class DataFileMetavalueController {
  constructor(private readonly dataFileMetavalueService: DataFileMetavalueService) { }

  @Get()
  @ApiOperation({
    title: 'Get DataFileMetavalues by organization', description: `
    Get all data-file-metavalues:
  `, operationId: 'GetAllDataFileMetavalues',
  })
  @ApiResponse({ status: 200, description: 'DataFileMetavalues have been successfully returned', isArray: false, type: DataFileMetavaluesPaginatedDto })
  @ApiResponse({ status: 403, description: 'Not authorized.' })
  @ApiResponse({ status: 401, description: 'Not authenticated.' })
  @ApiImplicitQuery({
    name: 'includes', description: `
  Allows include the DataFileMetavalues's relations. Available ${dataFileMetavaluesRelations}
  `, type: String, required: false,
  })
  @ApiImplicitParam({ name: 'organizationId', description: 'Organization the device belongs to', type: Number, required: true })
  @ApiImplicitParam({ name: 'deviceId', description: 'Device the data-file-metavalue belongs to', type: Number, required: true })
  @ApiImplicitQuery({ name: 'fields', description: 'DataFileMetavalues\'s fields to select', type: String, required: false })
  @ApiImplicitQuery({ name: 'page[size]', description: 'Page size. Default 10', type: String, required: false })
  @ApiImplicitQuery({ name: 'page[number]', description: 'Page number', type: String, required: false })
  @ApiImplicitQuery({ name: 'sort', description: 'Sort results', type: String, required: false })
  @Permissions(PERMISSIONS.DATA_FILE_GET_ONE)
  @UseInterceptors(DataFileMetavalueInterceptor)
  async findAll(@Pagination() pagination: PaginationModel, @Param() params, @User() authenticatedUser: AuthenticatedUserDto) {
    logger.info('Getting all data file metavalues for data file');
    const data = await this.dataFileMetavalueService.findAll(pagination, { authenticatedUser, params });
    return new DataFileMetavaluesPaginatedDto(data[0], data[1], pagination.pageSize, pagination.pageNumber);
  }

  @Get('/:id')
  @ApiOperation({
    title: 'Get data-file-metavalue by id', description: `
    Get data-file-metavalue by id
  `, operationId: 'GetDataFileMetavalueById',
  })
  @ApiImplicitQuery({
    name: 'includes', description: `
  Allows include the DataFileMetavalues's relations. Available ${dataFileMetavaluesRelations}
  `, type: String, required: false,
  })
  @ApiImplicitParam({ name: 'id', description: 'Id of the data-file-metavalue' })
  @ApiImplicitParam({ name: 'organizationId', description: 'Organization the device belongs to', type: Number, required: true })
  @ApiImplicitParam({ name: 'deviceId', description: 'Device the data-file-metavalue belongs to', type: Number, required: true })
  @ApiResponse({ status: 200, description: 'DataFileMetavalue has been successfully returned', isArray: false, type: DataFileMetavaluesDto })
  @ApiResponse({ status: 404, description: 'DataFileMetavalue does not exist or you don\'t have permission' })
  @ApiResponse({ status: 401, description: 'Not authenticated.' })
  @Permissions(PERMISSIONS.DATA_FILE_GET_ONE)
  async getById(@Param('id', new ParseIntPipe()) id: number, @Pagination() pagination: PaginationModel, @User() authenticatedUser: AuthenticatedUserDto, @Param() params) {
    logger.info('Get data file metavalue by id ', id);
    return await this.dataFileMetavalueService.getById(id, pagination, { authenticatedUser, params });
  }

  @Post()
  @ApiOperation({
    title: 'Create data-file-metavalue', description: `
    Create new data-file-metavalue
  `, operationId: 'CreateDataFileMetavalue',
  })
  @ApiImplicitParam({ name: 'organizationId', description: 'Organization the device belongs to', type: Number, required: true })
  @ApiImplicitParam({ name: 'deviceId', description: 'Device the data-file-metavalue belongs to', type: Number, required: true })
  @ApiResponse({ status: 200, description: 'DataFileMetavalue has been successfully created', isArray: false, type: DataFileMetavaluesDto })
  @ApiResponse({ status: 400, description: 'Body contains errors' })
  @ApiResponse({ status: 401, description: 'Not authenticated.' })
  @Permissions(PERMISSIONS.DATA_FILE_UPDATE)
  async create(@Body(new ValidationPipe()) createDataFileMetavalueDto: CreateDataFileMetavalueDto, @User() authenticatedUser: AuthenticatedUserDto, @Param() params) {
    logger.info('Creating data-file-metavalue');
    return await this.dataFileMetavalueService.create(createDataFileMetavalueDto, { authenticatedUser, params });
  }

  @Patch('/:id')
  @ApiOperation({
    title: 'Update data-file-metavalue', description: `
    Update data-file-metavalue
  `, operationId: 'UpdateDataFileMetavalue',
  })
  @ApiImplicitParam({ name: 'organizationId', description: 'Organization the device belongs to', type: Number, required: true })
  @ApiImplicitParam({ name: 'deviceId', description: 'Device the data-file-metavalue belongs to', type: Number, required: true })
  @ApiImplicitParam({ name: 'id', description: 'Id of the data-file-metavalue' })
  @ApiResponse({ status: 200, description: 'DataFileMetavalue has been successfully updated', isArray: false, type: DataFileMetavaluesDto })
  @ApiResponse({ status: 404, description: 'DataFileMetavalue does not exist or you don\'t have permission' })
  @ApiResponse({ status: 401, description: 'Not authenticated.' })
  @Permissions(PERMISSIONS.DATA_FILE_UPDATE)
  async update(@Param('id', new ParseIntPipe()) id: number, @Body(new ValidationPipe()) updateDataFileMetavalueDto: UpdateDataFileMetavalueDto, @User() authenticatedUser: AuthenticatedUserDto, @Param() params) {
    logger.info('Updating data-file-metavalue');
    // TODO: Add security
    return await this.dataFileMetavalueService.update(id, updateDataFileMetavalueDto, { authenticatedUser, params });
  }

  @Delete('/:id')
  @ApiOperation({
    title: 'Delete data-file-metavalue', description: `
    Delete data-file-metavalue
  `, operationId: 'DeleteDataFileMetavalue',
  })
  @ApiImplicitParam({ name: 'organizationId', description: 'Organization the device belongs to', type: Number, required: true })
  @ApiImplicitParam({ name: 'deviceId', description: 'Device the data-file-metavalue belongs to', type: Number, required: true })
  @ApiImplicitParam({ name: 'id', description: 'Id of the data-file-metavalue' })
  @ApiResponse({ status: 200, description: 'DataFileMetavalue has been successfully deleted', isArray: false, type: DataFileMetavaluesDto })
  @ApiResponse({ status: 404, description: 'DataFileMetavalue does not exist or you don\'t have permission' })
  @ApiResponse({ status: 401, description: 'Not authenticated.' })
  @Permissions(PERMISSIONS.DATA_FILE_UPDATE)
  async remove(@Param('id', new ParseIntPipe()) id: number, @User() authenticatedUser: AuthenticatedUserDto, @Param() params) {
    logger.info('Deleting data-file-metavalue');
    return await this.dataFileMetavalueService.remove(id, { authenticatedUser, params });
  }
}
