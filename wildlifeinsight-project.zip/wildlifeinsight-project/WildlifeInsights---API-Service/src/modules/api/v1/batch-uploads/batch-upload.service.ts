import { UpdateBatchUploadDto } from './dto/update-batch-upload.dto';
import { CreateBatchUploadDto, CreateBatchUploadProcessDto } from './dto/create-batch-upload.dto';
import { BatchUploads } from 'modules/database/entities/batch-uploads.entity';
import { Repository, SelectQueryBuilder } from 'typeorm';
import { Injectable, Inject, NotFoundException, BadRequestException, UnauthorizedException } from '@nestjs/common';
import { GenericService } from 'utils/generic.service';
import { StorageService } from 'modules/google/storage.service';
import { InfoDto } from 'dto/info.dto';
import { exec } from 'ts-process-promises';

const logger = require('logger');
const fs = require('fs');

@Injectable()
export class BatchUploadService extends GenericService<BatchUploads, CreateBatchUploadDto, UpdateBatchUploadDto>  {

  constructor(
    @Inject('BatchUploadsRepositoryToken') private readonly batchUploadsRepository: Repository<BatchUploads>,
    private readonly storageService: StorageService,
  ) {
    super(batchUploadsRepository, 'batchUpload');
  }

  setFilters(query: SelectQueryBuilder<BatchUploads>, filters: any, info: InfoDto) {
    if (filters && filters.status) {
      query.andWhere('batchUpload.status = :status').setParameter('status', filters.status);
    }
    if (filters && filters.target) {
      query.andWhere('lower(batchUpload.target) like :target').setParameter('target', `%${filters.target.toLowerCase()}%`);
    }
    if (filters && filters.organizationId) {
      query.andWhere('batchUpload.organizationId = :organizationId').setParameter('organizationId', filters.organizationId);
    }
    if (filters && filters.id) {
      query.andWhere('id = :id').setParameter('id', filters.id);
    }
    return query;
  }

  async setDataCreate(create: CreateBatchUploadDto, info: InfoDto) {
    const model = new BatchUploads();
    model.target = create.target;
    model.status = create.status;
    model.organizationId = create.organizationId;
    model.participantId = info.authenticatedUser.user.id;
    return model;
  }

  async setDataUpdate(model: BatchUploads, update: UpdateBatchUploadDto, info: InfoDto) {
    if (update.target !== undefined) {
      model.target = update.target;
    }
    if (update.status !== undefined) {
      model.status = update.status;
    }
    if (update.organizationId !== undefined) {
      model.organizationId = update.organizationId;
    }
    if (update.participantId !== undefined) {
      model.participantId = update.participantId;
    }
    return model;
  }

  async createDeployments(model: CreateBatchUploadProcessDto, info: InfoDto) {
    logger.debug('Getting data manifest from target');

    // target, in this case, needs to point to a folder in the root of the bucket
    // wildlife_insights_bulk_uploads
    const target = model.target;
    logger.debug('target', target);

    // Should validate that organization exists? Think so
    const organizationId = model.organizationId;
    // As above re validation
    const participantId = model.participantId;

    // Downloading the file to a temporary file
    let manifestFile;
    try {
      manifestFile = await this.storageService.downloadFileGeneric(
        'wildlife_insights_bulk_uploads',
        `${target}/payload.json`,
      );
      logger.debug('manifestFile', manifestFile);

      const importResult = exec( // can be awaited for sync
        `ts-node -r tsconfig-paths/register src/bulk-import/bulk-import.ts ${organizationId} ${participantId} ${manifestFile} ${target}`,
      );
    } catch (error) {
      logger.error(`Error while creating project and deployments: ${error}`);
    } finally {
      if (fs.statSync(manifestFile)) {
        // delete manifestFile -- fine in here as long as the await is up there
        // logger.debug(`Deleting manifest file ${manifestFile}`);
        // fs.unlinkSync(manifestFile);
      }
    }
    return 'OK';
  }

  async ingestImages(model: CreateBatchUploadProcessDto, info: InfoDto) {
    logger.debug('Getting data manifest from target');

    // target, in this case, needs to point to a folder in the root of the bucket
    // wildlife_insights_bulk_uploads
    const target = model.target;
    logger.debug('target', target);

    // Should validate that organization exists? Think so
    const organizationId = model.organizationId;

    // Downloading the file to a temporary file
    let manifestFile;
    try {
      manifestFile = await this.storageService.downloadFileGeneric(
        'wildlife_insights_bulk_uploads',
        `${target}/payload.json`,
      );
      logger.debug('manifestFile', manifestFile);

      const out = fs.openSync(`/tmp/${target}.out.log`, 'a');
      const err = fs.openSync(`/tmp/${target}.err.log`, 'a');

      // can be awaited for sync, though this is likely not suitable for
      // anything but smaller projects, as the CLI script for this can take 10
      // minutes or more
      const importResult = exec(
        `ts-node -r tsconfig-paths/register src/bulk-import/ingest-images.ts ${organizationId} ${manifestFile} ${target}`,
      );

    } catch (error) {
      logger.error(`Error while importing data files: ${error}`);
    } finally {
      if (fs.statSync(manifestFile)) {
        // delete manifestFile -- fine in here as long as the await is up there
        logger.debug(`Deleting manifest file ${manifestFile}`);
        // fs.unlinkSync(manifestFile);
      }
    }
    return 'OK';
  }

}
