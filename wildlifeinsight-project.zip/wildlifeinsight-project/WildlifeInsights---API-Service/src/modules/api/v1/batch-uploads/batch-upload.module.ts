import { BatchUploadController } from './batch-upload.controller';
import { BatchUploadService } from './batch-upload.service';
import { Module, RequestMethod, MiddlewareConsumer } from '@nestjs/common';
import { PaginationMiddleware } from 'middlewares/pagination.middleware';
import { DatabaseModule } from 'modules/database/database.module';
import { GoogleModule } from 'modules/google/google.module';

@Module({
  imports: [DatabaseModule, GoogleModule],
  controllers: [BatchUploadController],
  providers: [BatchUploadService],
})
export class BatchUploadModule {
  public configure(consumer: MiddlewareConsumer) {
    consumer
      .apply(PaginationMiddleware)
      .with({ includes: [] })
      .forRoutes(
        { path: '/api/v1/batch-uploads', method: RequestMethod.GET },
        { path: '/api/v1/batch-uploads/:id', method: RequestMethod.GET },
      );
  }
}
