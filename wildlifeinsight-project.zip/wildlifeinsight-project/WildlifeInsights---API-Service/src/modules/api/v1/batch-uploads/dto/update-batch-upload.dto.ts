import { IsString, IsInt, IsNumber, IsOptional, MaxLength, IsISO8601 } from 'class-validator';
import { ApiModelProperty, ApiModelPropertyOptional } from '@nestjs/swagger';

export class UpdateBatchUploadDto {
  @IsString()
  @MaxLength(255)
  @IsOptional()
  @ApiModelProperty({ required: false, type: String, maxLength: 255 })
  target: string;

  @IsString()
  @MaxLength(255)
  @IsOptional()
  @ApiModelProperty({ required: false, type: String, maxLength: 255 })
  status: string;

  @IsInt()
  @ApiModelProperty({ required: true, type: Number })
  organizationId: number;

  @IsInt()
  @IsOptional()
  @ApiModelPropertyOptional({ type: Number })
  participantId: number;
}
