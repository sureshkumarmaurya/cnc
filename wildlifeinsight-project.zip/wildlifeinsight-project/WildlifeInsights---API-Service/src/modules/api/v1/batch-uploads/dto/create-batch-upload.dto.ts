import { ApiModelProperty } from '@nestjs/swagger';
import { IsString, MaxLength, IsOptional, IsInt } from 'class-validator';

export class CreateBatchUploadDto {

  @IsString()
  @MaxLength(255)
  @ApiModelProperty({ required: true, type: String, maxLength: 255 })
  target: string;

  @IsString()
  @MaxLength(255)
  @ApiModelProperty({ required: true, type: String, maxLength: 255 })
  status: string;

  @IsInt()
  @ApiModelProperty({ required: true, type: Number })
  organizationId: number;
}

export class CreateBatchUploadProcessDto {
  @IsString()
  @MaxLength(255)
  @ApiModelProperty({ required: true, type: String, maxLength: 255 })
  target: string;

  @IsInt()
  @ApiModelProperty({ required: true, type: Number })
  organizationId: number;

  @IsInt()
  @ApiModelProperty({ required: true, type: Number })
  participantId: number;
}
