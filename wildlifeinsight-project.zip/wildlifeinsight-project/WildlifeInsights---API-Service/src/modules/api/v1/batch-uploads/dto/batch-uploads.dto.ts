import { ApiModelProperty } from '@nestjs/swagger';
import { BatchUploadsDto } from 'modules/database/dto/batch-uploads.dto';
import { MetaDto } from 'modules/database/dto/meta.dto';

export class BatchUploadsPaginatedDto {

  @ApiModelProperty({ type: BatchUploadsDto, isArray: true })
  readonly data: BatchUploadsDto[];

  @ApiModelProperty()
  readonly meta: MetaDto;

  constructor(data, totalItems: number, pageSize: number, page: number) {
    this.data = data;
    this.meta = new MetaDto(Math.ceil(totalItems / pageSize), totalItems, pageSize, page);
  }
}
