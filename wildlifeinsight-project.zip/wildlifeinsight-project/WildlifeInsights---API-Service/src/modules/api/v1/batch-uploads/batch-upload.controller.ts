import { UpdateBatchUploadDto } from './dto/update-batch-upload.dto';
import { CreateBatchUploadDto, CreateBatchUploadProcessDto } from './dto/create-batch-upload.dto';
import { BatchUploadsDto } from 'modules/database/dto/batch-uploads.dto';
import { Get, Controller, Post, Body, Patch, Param, Delete, ParseIntPipe, UseGuards, Query } from '@nestjs/common';
import { BatchUploadService } from './batch-upload.service';
import { ApiUseTags, ApiBearerAuth, ApiOperation, ApiResponse, ApiImplicitQuery, ApiImplicitParam } from '@nestjs/swagger';
import { BatchUploadsPaginatedDto } from './dto/batch-uploads.dto';
import { Pagination } from 'decorators/pagination.decorator';
import { ValidationPipe } from 'pipes/validation.pipe';
import { PermissionsGuard } from 'guards/permissions.guard';
import { User } from 'decorators/user.decorator';
import { AuthenticatedUserDto } from 'dto/authenticated-user.dto';
import { PaginationModel } from 'utils/pagination.model';

const logger = require('logger');

@Controller('/api/v1/batch-uploads')
@ApiUseTags('BatchUploads')
@ApiBearerAuth()
@UseGuards(PermissionsGuard)
export class BatchUploadController {
  constructor(private readonly batchUploadService: BatchUploadService) { }

  @Get('')
  @ApiOperation({ title: 'Get batch uploads', description: 'Get all batch uploads:', operationId: 'BatchUploadGetAll' })
  @ApiResponse({ status: 200, description: 'Batch uploads have been successfully returned', isArray: false, type: BatchUploadsPaginatedDto })
  @ApiResponse({ status: 403, description: 'Not authorized.' })
  @ApiResponse({ status: 401, description: 'Not authenticated.' })
  @ApiImplicitQuery({ name: 'fields', description: 'Sequences\'s fields to select', type: String, required: false })
  @ApiImplicitQuery({ name: 'page[size]', description: 'Page size. Default 10', type: String, required: false })
  @ApiImplicitQuery({ name: 'page[number]', description: 'Page number', type: String, required: false })
  @ApiImplicitQuery({ name: 'sort', description: 'Sort results', type: String, required: false })
  @ApiImplicitQuery({ name: 'status', description: 'Filter by status', type: String, required: false })
  @ApiImplicitQuery({ name: 'target', description: 'Filter by target', type: String, required: false })
  @ApiImplicitQuery({ name: 'organizationId', description: 'Filter by parent organization id', type: Number, required: false })
  @ApiImplicitQuery({ name: 'id', description: 'Filter by id', type: Number, required: false })
  async findAll(@Pagination() pagination: PaginationModel, @Param() params, @User() authenticatedUser: AuthenticatedUserDto, @Query() filters) {
    logger.info('Getting all');
    const data = await this.batchUploadService.findAll(pagination, { authenticatedUser, params }, filters);
    return new BatchUploadsPaginatedDto(data[0], data[1], pagination.pageSize, pagination.pageNumber);
  }

  @Get('/:id')
  @ApiOperation({
    title: 'Get batch upload by id', description: `
    Get batch upload by id
  `, operationId: 'GetBatchUploadById',
  })
  @ApiImplicitParam({ name: 'id', description: 'Id of the batch upload' })
  @ApiResponse({ status: 200, description: 'Batch upload has been successfully returned', isArray: false, type: BatchUploadsDto })
  @ApiResponse({ status: 404, description: 'Batch upload does not exist or you don\'t have permission' })
  @ApiResponse({ status: 401, description: 'Not authenticated.' })
  async getById(@Param('id', new ParseIntPipe()) id: number, @User() authenticatedUser: AuthenticatedUserDto, @Param() params, @Pagination() pagination: PaginationModel) {
    logger.info('Get by id ', id);
    return await this.batchUploadService.getById(id, pagination, { authenticatedUser, params });
  }

  @Post()
  @ApiOperation({
    title: 'Create batch upload', description: `
    Create new batch upload
  `, operationId: 'CreateBatchUpload',
  })
  @ApiResponse({ status: 200, description: 'Batch upload has been successfully created', isArray: false, type: BatchUploadsDto })
  @ApiResponse({ status: 400, description: 'Body contains errors' })
  @ApiResponse({ status: 401, description: 'Not authenticated.' })
  async create(@Body(new ValidationPipe()) createBatchUploadDto: CreateBatchUploadDto, @User() authenticatedUser: AuthenticatedUserDto, @Param() params) {
    logger.info('Creating project');
    return await this.batchUploadService.create(createBatchUploadDto, { authenticatedUser, params });
  }

  @Post('/create-deployments')
  @ApiOperation({
    title: 'Batch upload: create deployments', description: `
    Creates deployments via batch upload manifest
  `, operationId: 'BatchUploadDeployments',
  })
  @ApiResponse({ status: 200, description: 'Batch upload has been successfully launched' })
  @ApiResponse({ status: 400, description: 'Body contains errors' })
  @ApiResponse({ status: 401, description: 'Not authenticated.' })
  async createDeployments(
    @Body(new ValidationPipe()) createBatchUploadProcessDto: CreateBatchUploadProcessDto,
    @User() authenticatedUser: AuthenticatedUserDto,
    @Param() params,
  ) {
    logger.info('Launching batch upload process');
    return await this.batchUploadService.createDeployments(createBatchUploadProcessDto, { authenticatedUser, params });
  }

  @Post('/ingest-images')
  @ApiOperation({
    title: 'Batch upload: upload images', description: `
    Creates dataFiles via batch upload manifest
  `, operationId: 'BatchUploadDataFiles',
  })
  @ApiResponse({ status: 200, description: 'Batch upload has been successfully launched' })
  @ApiResponse({ status: 400, description: 'Body contains errors' })
  @ApiResponse({ status: 401, description: 'Not authenticated.' })
  async ingestImages(
    @Body(new ValidationPipe()) createBatchUploadProcessDto: CreateBatchUploadProcessDto,
    @User() authenticatedUser: AuthenticatedUserDto,
    @Param() params,
  ) {
    logger.info('Launching batch upload process');
    return await this.batchUploadService.ingestImages(createBatchUploadProcessDto, { authenticatedUser, params });
  }

  @Patch('/:id')
  @ApiOperation({
    title: 'Update batch upload', description: `
    Update batch upload
  `, operationId: 'UpdateBatchUpload',
  })
  @ApiImplicitParam({ name: 'id', description: 'Id of the batch upload' })
  @ApiResponse({ status: 200, description: 'Sequence has been successfully updated', isArray: false, type: BatchUploadsDto })
  @ApiResponse({ status: 404, description: 'Sequence does not exist or you don\'t have permission' })
  @ApiResponse({ status: 401, description: 'Not authenticated.' })
  async update(@Param('id', new ParseIntPipe()) id: number, @Body(new ValidationPipe()) updateBatchUploadDto: UpdateBatchUploadDto, @User() authenticatedUser: AuthenticatedUserDto, @Param() params) {
    logger.info('Updating batch upload');
    return await this.batchUploadService.update(id, updateBatchUploadDto, { authenticatedUser, params });
  }

  @Delete('/:id')
  @ApiOperation({
    title: 'Delete batch upload', description: `
    Delete batch upload
  `, operationId: 'DeleteBatchUpload',
  })
  @ApiImplicitParam({ name: 'id', description: 'Id of the sequence' })
  @ApiResponse({ status: 200, description: 'Batch upload has been successfully deleted', isArray: false, type: BatchUploadsDto })
  @ApiResponse({ status: 404, description: 'Batch upload doesn\'t exist or you don\'t have permission' })
  @ApiResponse({ status: 401, description: 'Not authenticated.' })
  async remove(@Param('id', new ParseIntPipe()) id: number, @User() authenticatedUser: AuthenticatedUserDto, @Param() params) {
    logger.info('Deleting batch upload');
    return await this.batchUploadService.remove(id, { authenticatedUser, params });
  }
}
