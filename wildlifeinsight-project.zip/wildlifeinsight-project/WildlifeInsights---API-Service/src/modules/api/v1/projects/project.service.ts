import { UpdateProjectDto } from './dto/update-project.dto';
import { CreateProjectDto } from './dto/create-project.dto';
import { Projects } from 'modules/database/entities/projects.entity';
import { ProjectScienceData } from 'modules/database/entities/project-science-data.entity';
import { Repository, SelectQueryBuilder } from 'typeorm';
import { Injectable, Inject, NotFoundException, BadRequestException, UnauthorizedException } from '@nestjs/common';
import { GenericService } from 'utils/generic.service';
import { SlugUtils, NameUtils } from 'utils/slug.utils';
import { Organizations } from 'modules/database/entities/organizations.entity';
import { Initiatives } from 'modules/database/entities/initiatives.entity';
import { InfoDto } from 'dto/info.dto';
import { ParticipantTypes } from 'modules/database/entities/participant-types.entity';
import { ROLES } from 'utils/roles.enum';
import { Roles } from 'modules/database/entities/roles.entity';
import { ParticipantTypeProjectPivot } from 'modules/database/entities/participant-type-project-pivot.entity';
import { StorageService } from 'modules/google/storage.service';
import { CloudFunctionsService } from 'modules/google/cloudfunctions.service';
import { CloudBuildService } from 'modules/google/cloudbuild.service';
import { UsersACLCache } from 'modules/database/entities/users-acl-cache.entity';
import { PermissionsUtils } from 'utils/permissions.utils';
import { AuthenticatedUserDto } from 'dto/authenticated-user.dto';
import { PERMISSIONS } from 'utils/permissions.enum';
import { EntityType } from 'utils/entities.utils';
import { PaginationModel } from 'utils/pagination.model';
import { getLatLong } from '../../../../utils/lat-long';

const logger = require('logger');

@Injectable()
export class ProjectService extends GenericService<Projects, CreateProjectDto, UpdateProjectDto>  {

  readonly projectsDTOFields: string[] = [
    'name',
    'abbreviation',
    'shortName',
    'design',
    'objectives',
    'rightsHolder',
    'accessRights',
    'projectUrl',
    'projectStatus',
    'methodology',
    'startDate',
    'endDate',
    'remarks',
    'projectCreditLine',
    'acknowledgements',
    'dataCitation',
    'initiativeId',
    'embargo',
    'metadata',
    'metadataLicense',
    'dataFilesLicense',
    'deleteDataFilesWithIdentifiedHumans',
    'disableAnalytics',
    'publicLatitude',
    'publicLongitude',
  ];

  constructor(
    @Inject('ProjectsRepositoryToken') private readonly projectsRepository: Repository<Projects>,
    @Inject('ProjectScienceDataRepositoryToken') private readonly projectScienceDataRepository: Repository<ProjectScienceData>,
    @Inject('OrganizationsRepositoryToken') private readonly organizationsRepository: Repository<Organizations>,
    @Inject('InitiativesRepositoryToken') private readonly initiativesRepository: Repository<Initiatives>,
    @Inject('ParticipantTypesRepositoryToken') private readonly participantTypesRepository: Repository<ParticipantTypes>,
    @Inject('RolesRepositoryToken') private readonly rolesRepository: Repository<Roles>,
    @Inject('ParticipantTypeProjectPivotRepositoryToken') private readonly participantTypeProjectPivotRepository: Repository<ParticipantTypeProjectPivot>,
    @Inject('UsersACLCacheRepositoryToken') private readonly usersACLCacheRepository: Repository<UsersACLCache>,
    private readonly storageService: StorageService,
    private readonly cloudFunctionsService: CloudFunctionsService,
    private readonly cloudBuildService: CloudBuildService,
  ) {
    super(projectsRepository, 'project');
  }

  setFilters(query: SelectQueryBuilder<Projects>, filters: any, info: InfoDto) {
    if (info.authenticatedUser.user) {
      query.innerJoin('project.participantTypeProjectPivot', 'ptpp')
      .andWhere('ptpp.participantId = :userId').setParameter('userId', info.authenticatedUser.user.id);
    }

    if (info.params.organizationId) {
      query.andWhere('project.organizationId = :organizationId').setParameter('organizationId', info.params.organizationId);
    }

    if (info.params.initiativeId) {
      query.andWhere('project.initiativeId = :initiativeId').setParameter('initiativeId', info.params.initiativeId);
    }

    if (filters && filters.name) {
      query.andWhere('lower(project.name) like :name').setParameter('name', `%${filters.name.toLowerCase()}%`);
    }
    return query;
  }

  setFiltersGetById(query: SelectQueryBuilder<Projects>, info: InfoDto): SelectQueryBuilder<Projects> {
    query.innerJoin('project.participantTypeProjectPivot', 'ptpp')
    .andWhere('ptpp.participantId = :userId').setParameter('userId', info.authenticatedUser.user.id);

    query.andWhere('project.organizationId = :organizationId').setParameter('organizationId', info.params.organizationId);
    return query;
  }

  async getById(id: number, pagination: PaginationModel, info?: InfoDto): Promise<Projects> {
    logger.debug('Getting by id');
    let query = this.repository.createQueryBuilder(this.alias);
    info.pagination = pagination;
    query = this.setFiltersGetById(query, info);
    query.andWhere(`${this.alias}.id = :id`).setParameter('id', id);

    const model = await query.getOne();
    if (!model) {
      throw new NotFoundException(`${this.alias} not found`);
    }
    model.publicLatitudeStr = getLatLong(model.publicLatitude);
    model.publicLongitudeStr = getLatLong(model.publicLongitude);
    return model;
  }

  setFiltersDelete(query: SelectQueryBuilder<Projects>, info: InfoDto): SelectQueryBuilder<Projects> {
    query.innerJoin('project.participantTypeProjectPivot', 'ptpp')
    .andWhere('ptpp.participantId = :userId').setParameter('userId', info.authenticatedUser.user.id);
    query.andWhere('project.organizationId = :organizationId').setParameter('organizationId', info.params.organizationId);
    return query;
  }

  async getOrganizationById(id: number): Promise<Organizations> {
    logger.debug('Getting organization by id: ', id);
    return this.organizationsRepository.findOne(id);
  }

  async getInitiativeById(id: number): Promise<Initiatives> {
    logger.debug('Getting initiative by id: ', id);
    return this.initiativesRepository.findOne(id);
  }

  async getScienceData(id: number, pagination: PaginationModel, options) {
    logger.debug(`Getting science data for project with id ${id}`);
    return this.projectScienceDataRepository.find({
      where: { project_id: id },
    });
  }

  async setDataCreate(create: CreateProjectDto, info: InfoDto) {

    const model = new Projects();
    create.name = NameUtils.prefix(create.name);
    create.shortName = NameUtils.trimShortName(create.shortName);

    this.projectsDTOFields.forEach((fieldName) => { model[fieldName] = create[fieldName]; });

    model.slug = SlugUtils.convertAndPrefix(create.name);
    model.status = 'CREATED';

    const principalInvestigatorType = await this.participantTypesRepository.findOne({ where: { typeName: 'PRINCIPAL INVESTIGATOR' } });
    const projectOwnerRole = await this.rolesRepository.findOne({ where: { slug: ROLES.PROJECT_OWNER } });

    const participantTypeProject = new ParticipantTypeProjectPivot();
    participantTypeProject.startDate = new Date();
    participantTypeProject.startDate = new Date(Date.now() + 24 * 60 * 60 * 1000);
    participantTypeProject.participantId = info.authenticatedUser.user.id;
    participantTypeProject.role = projectOwnerRole;
    participantTypeProject.participantType = principalInvestigatorType;
    model.participantTypeProjectPivot = [participantTypeProject];

    model.organization = await this.organizationsRepository.findOne(info.params.organizationId);
    if(create.publicLatitudeStr) {
      model.publicLatitude = Number(create.publicLatitudeStr);
    }
    if(create.publicLongitudeStr) {
      model.publicLongitude = Number(create.publicLongitudeStr);
    }
    
    
    return model;

  }

  async create(createModel: CreateProjectDto, info?: InfoDto): Promise<Projects> {
    logger.debug(`Creating ${this.alias}`);

    await this.validateBeforeCreate(createModel, info);
    const model = await this.setDataCreate(createModel, info);

    const project = await this.projectsRepository.save(model);
    await this.usersACLCacheRepository.clear();
    await this.storageService.createWIBuckets(project.slug);
    project['publicLatitudeStr'] = getLatLong(project.publicLatitude);
    project['publicLongitudeStr'] = getLatLong(project.publicLongitude);

    return project;
  }

  async validateBeforeCreate(create: CreateProjectDto, info: InfoDto) {

    const name = NameUtils.prefix(create.name);
    const count = await this.projectsRepository.count({ where: { name } });
    if (count > 0) {
      throw new BadRequestException(`Project: ${name} is not unique`);
    }
    const slug = SlugUtils.convertAndPrefix(name);
    const countSlug = await this.projectsRepository.count({ where: { slug } });
    if (countSlug > 0) {
      throw new BadRequestException(`Project: ${name} is not unique`);
    }
    const organization = await this.organizationsRepository.findOne(info.params.organizationId);
    if (!organization) {
      throw new BadRequestException(`Organization with id ${info.params.organizationId} not found`);
    }
  }

  async validateBeforeUpdate(id: number, update: UpdateProjectDto, info: InfoDto) {
    const project = await this.projectsRepository.findOne(id);

    if (update.name && project.name !== update.name) {
      const count = await this.projectsRepository.createQueryBuilder('project')
      .where('lower(project.name) = :name').andWhere('project.id <> :id').setParameters({ id, name: update.name.toLowerCase() }).getCount();
      if (count > 0) {
        throw new BadRequestException(`ProjectName: ${update.name} is not unique`);
      }
    }
  }

  async setDataUpdate(model: Projects, update: UpdateProjectDto, info: any) {

    this.projectsDTOFields.forEach((fieldName) => { if (update[fieldName] !== undefined) { model[fieldName] = update[fieldName]; } });
    if (update.publicLatitudeStr) {
      model.publicLatitude = Number(update.publicLatitudeStr);
    }
    if (update.publicLongitudeStr) {
      model.publicLongitude = Number(update.publicLongitudeStr);
    }
    return model;
  }

  async getParticipants(projectId: number) {
    try {
      return await this.participantTypeProjectPivotRepository.createQueryBuilder('p')
        .where('p.projectId = :projectId')
        .innerJoinAndSelect('p.participant', 'participant')
        .innerJoinAndSelect('p.role', 'role')
        .innerJoinAndSelect('role.permissions', 'permissions')
        .setParameter('projectId', projectId).getMany();
    } catch (err) {
      throw new BadRequestException(`Get project participants error. projectId: ${projectId}, ${err}`);
    }
  }

  /**
   * Given an entity type (`organization`, `initiative` or `project`) and its
   * numeric id, list all projects that are accessible to the user (on which the
   * user has `PERMISSIONS.DEPLOYMENT_GET_ALL` permission, which is granted to
   * all of owner, editor and viewer roles) and are contained within the given
   * organization or initiative; or, if entityType is `project`, check that the
   * user has access to the given project and return a singleton array with its
   * id.
   *
   * @param entityType `organization`, `initiative` or `project`
   * @param entityId The id of the entity whose projects should be listed
   * @param authenticatedUser User data of the current user
   */
  static async getProjectsAccessibleToUserWithinEntity(authenticatedUser: AuthenticatedUserDto, entityType: EntityType | null, entityId: number | null): Promise<number[]> {
    let projectIds : number[] = [];

    const projects = PermissionsUtils.getProjectsInAllOrganizationsWithPermission(authenticatedUser!, PERMISSIONS.DEPLOYMENT_GET_ALL);

    if (entityType === 'project') {
      projectIds = projects.filter(p => p.id === entityId).map(p => p.id);
    } else if (entityType === 'initiative') {
      projectIds = projects.filter(p => p.initiativeId != null && p.initiativeId === entityId).map(p => p.id);
    } else if (entityType === 'organization') {
      projectIds = projects.filter(p => p.organizationId != null && p.organizationId === entityId).map(p => p.id);
    } else {
      // If no entityType is provided, return the full list of projects the user has access to
      projectIds = projects.map(p => p.id);
    }

    return projectIds;

  }

  async update(id: number, updateModel: UpdateProjectDto, info?: InfoDto): Promise<Projects> {
    logger.debug(`Updating ${this.alias}`);
    await this.validateBeforeUpdate(id, updateModel, info);
    let query = this.repository.createQueryBuilder(this.alias);
    query = this.setFiltersUpdate(query, info);
    query.andWhere(`${this.alias}.id = :id`).setParameter('id', id);
    let model = await query.getOne();
    if (!model) {
      throw new NotFoundException(`${this.alias} not found`);
    }
    model = await this.setDataUpdate(model, updateModel, info);
    model['publicLatitudeStr'] = getLatLong(model.publicLatitude);
    model['publicLongitudeStr'] = getLatLong(model.publicLongitude);
    return new Promise((resolve, reject) => {
      this.repository.save(model)
        .then((result) => {
          if (this.actionAfterUpdate) this.actionAfterUpdate(result, updateModel);
          resolve(result);
        })
        .catch(e => reject(e));
    });
  }
}
