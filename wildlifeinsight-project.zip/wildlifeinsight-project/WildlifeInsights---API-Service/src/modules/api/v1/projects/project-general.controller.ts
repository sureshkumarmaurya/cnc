import { Get, Controller, Param, Query } from '@nestjs/common';
import { ProjectService } from './project.service';
import { ApiUseTags, ApiBearerAuth, ApiOperation, ApiResponse, ApiImplicitQuery } from '@nestjs/swagger';
import { ProjectsPaginatedDto } from './dto/projects.dto';
import { Pagination } from 'decorators/pagination.decorator';
import { User } from 'decorators/user.decorator';
import { AuthenticatedUserDto } from 'dto/authenticated-user.dto';
import { PaginationModel } from 'utils/pagination.model';

const logger = require('logger');

export const projectsRelations = ['localTaxonomies', 'organization', 'initiatives', 'dataUse', 'deployments', 'participantTypeProjectPivot', 'tags'];

@Controller('/api/v1/project')
@ApiUseTags('Projects')
@ApiBearerAuth()
export class ProjectGeneralController {
  constructor(private readonly projectService: ProjectService) { }

  @Get('/')
  @ApiOperation({
    title: 'Get Projects of user', description: `
    Get all projects:
  `, operationId: 'GetAllProjects',
  })
  @ApiResponse({ status: 200, description: 'Projects have been successfully returned', isArray: false, type: ProjectsPaginatedDto })
  @ApiResponse({ status: 403, description: 'Not authorized.' })
  @ApiResponse({ status: 401, description: 'Not authenticated.' })
  @ApiImplicitQuery({
    name: 'includes', description: `
  Allows include the Projects's relations. Available ${projectsRelations}
  `, type: String, required: false,
  })
  @ApiImplicitQuery({ name: 'fields', description: 'Projects\'s fields to select', type: String, required: false })
  @ApiImplicitQuery({ name: 'page[size]', description: 'Page size. Default 10', type: String, required: false })
  @ApiImplicitQuery({ name: 'page[number]', description: 'Page number', type: String, required: false })
  @ApiImplicitQuery({ name: 'sort', description: 'Sort results', type: String, required: false })
  @ApiImplicitQuery({ name: 'name', description: 'Filter by name', type: String, required: false })
  async findAll(@Query() filters, @Pagination() pagination: PaginationModel, @Param() params, @User() authenticatedUser: AuthenticatedUserDto) {
    logger.info('Getting all');
    const data = await this.projectService.findAll(pagination, { authenticatedUser, params }, filters);
    return new ProjectsPaginatedDto(data[0], data[1], pagination.pageSize, pagination.pageNumber);
  }

}
