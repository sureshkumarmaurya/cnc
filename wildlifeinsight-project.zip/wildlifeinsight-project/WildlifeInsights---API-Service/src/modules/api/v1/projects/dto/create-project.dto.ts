import { ApiModelProperty } from '@nestjs/swagger';
import { IsString, IsNumber, IsArray, IsOptional, MaxLength, IsPositive, IsISO8601, ValidateIf, Validate, ValidateNested, IsEnum, IsDefined } from 'class-validator';
import { ProjectMetadataLicenseType, DataFilesLicenseType } from 'modules/database/entities/projects.entity';
import { DecimalChecker } from "../../../../../decorators/validation/decimal-validator";

export class CreateProjectDto {

  @IsString()
  @MaxLength(47)
  @ApiModelProperty({ required: true })
  name: string;

  @IsString()
  @MaxLength(255)
  @IsOptional()
  @ApiModelProperty({ required: false })
  abbreviation: string | null;

  @IsString()
  @MaxLength(255)
  @IsOptional()
  @ApiModelProperty({ required: false })
  shortName: string | null;

  @IsString()
  @MaxLength(255)
  @IsOptional()
  @ApiModelProperty({ required: false })
  design: string | null;

  @IsString()
  @MaxLength(255)
  @IsOptional()
  @ApiModelProperty({ required: false })
  objectives: string | null;

  @IsString()
  @MaxLength(255)
  @IsOptional()
  @ApiModelProperty({ required: false })
  rightsHolder: string | null;

  @IsString()
  @MaxLength(255)
  @IsOptional()
  @ApiModelProperty({ required: false })
  accessRights: string | null;

  @IsString()
  @MaxLength(255)
  @IsOptional()
  @ApiModelProperty({ required: false })
  projectUrl: string | null;

  @IsString()
  @MaxLength(255)
  @IsOptional()
  @ApiModelProperty({ required: false })
  projectStatus: string | null;

  @IsString()
  @MaxLength(255)
  @IsOptional()
  @ApiModelProperty({ required: false })
  methodology: string;

  @ValidateIf(o => !(o.startDate instanceof Date))
  @IsString()
  @IsISO8601()
  @ApiModelProperty({ required: true })
  startDate: Date;

  @ValidateIf(o => !(o.endDate instanceof Date))
  @IsString()
  @IsISO8601()
  @IsOptional()
  @ApiModelProperty({ required: false })
  endDate: Date;

  @IsString()
  @MaxLength(255)
  @IsOptional()
  @ApiModelProperty({ required: false })
  remarks: string | null;

  @IsString()
  @MaxLength(255)
  @IsOptional()
  @ApiModelProperty({ required: false })
  projectCreditLine: string;

  @IsString()
  @MaxLength(255)
  @IsOptional()
  @ApiModelProperty({ required: false })
  acknowledgements: string;

  @IsString()
  @MaxLength(255)
  @IsOptional()
  @ApiModelProperty({ required: false })
  dataCitation: string;

  @IsNumber()
  @IsPositive()
  @IsOptional()
  @ApiModelProperty({ required: false })
  initiativeId: number;

  @IsNumber()
  @IsPositive()
  @IsOptional()
  @ApiModelProperty({ required: false })
  embargo: number;

  @IsOptional()
  @IsPositive()
  @ApiModelProperty({ required: false })
  dataUse: number;

  @IsOptional()
  @ApiModelProperty({ required: false })
  deleteDataFilesWithIdentifiedHumans: boolean;

  @IsOptional()
  @IsArray()
  @ApiModelProperty({ required: false })
  tags: number[];

  @ValidateNested()
  @IsOptional()
  @ApiModelProperty({ required: false })
  metadata: object;

  @IsOptional()
  @IsEnum(['CC0', 'CC-BY', 'CC-BY-NC', null])
  @ApiModelProperty({ required: false })
  metadataLicense: ProjectMetadataLicenseType;

  @IsOptional()
  @IsEnum(['CC0', 'CC-BY', 'CC-BY-NC', null])
  @ApiModelProperty({ required: false })
  dataFilesLicense: DataFilesLicenseType;

  @IsOptional()
  @ApiModelProperty({ required: false })
  disableAnalytics: boolean;

  @IsOptional()
  @ApiModelProperty({
    description: '(Public Latitude field has been deprecated.)',
    required: false
  })
  publicLatitude: number | null;

  @IsOptional()
  @Validate(DecimalChecker, {
    message: "Public Latitude must be string and also contain at least four and maximum eight decimal digits"
  })
  @ApiModelProperty({
    description: '(Minimum 4 decimal and maximum 8 decimal.)',
    required: false
  })
  publicLatitudeStr: string;

  @IsOptional()
  @ApiModelProperty({
    description: '(Public Longitude field has been deprecated.)',
    required: false
  })
  publicLongitude: number | null;

  @IsOptional()
  @ApiModelProperty({
    description: '(Minimum 4 decimal and maximum 8 decimal.)',
    required: false
  })
  @Validate(DecimalChecker, {
    message: "Public Longitude must be string and also contain at least four and maximum eight decimal digits"
  })
  publicLongitudeStr: string;

}
