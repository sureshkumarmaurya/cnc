import { ApiModelProperty } from '@nestjs/swagger';
import { ProjectsDto } from 'modules/database/dto/projects.dto';
import { MetaDto } from 'modules/database/dto/meta.dto';
import { getLatLong } from '../../../../../utils/lat-long';

export class ProjectsPaginatedDto {

  @ApiModelProperty({ type: ProjectsDto, isArray: true })
  readonly data: ProjectsDto[];

  @ApiModelProperty()
  readonly meta: MetaDto;

  constructor(data, totalItems: number, pageSize: number, page: number) {
    this.data = data.map((project) => {
      return {
        ...project,
        publicLatitudeStr: getLatLong(project.publicLatitude),
        publicLongitudeStr: getLatLong(project.publicLongitude)
      }
    })
    this.meta = new MetaDto(Math.ceil(totalItems / pageSize), totalItems, pageSize, page);
  }
}
