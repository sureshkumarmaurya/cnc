import { ProjectController, projectsRelations } from './project.controller';
import { ProjectService } from './project.service';
import { Module, RequestMethod, MiddlewareConsumer } from '@nestjs/common';
import { PaginationMiddleware } from 'middlewares/pagination.middleware';
import { ProjectResolver } from './project.resolver';
import { DatabaseModule } from 'modules/database/database.module';
import { GoogleModule } from 'modules/google/google.module';
import { ProjectGeneralController } from './project-general.controller';
import { RoleChangesService } from '../role-changes/role-changes.service';
import { RolesUtils } from 'utils/roles.utils';

@Module({
  imports: [DatabaseModule, GoogleModule],
  controllers: [ProjectController, ProjectGeneralController],
  providers: [ProjectService, ProjectResolver, RoleChangesService, RolesUtils],
})
export class ProjectModule {
  public configure(consumer: MiddlewareConsumer) {
    consumer
      .apply(PaginationMiddleware)
      .with({ includes: [], allowIncludes: projectsRelations })
      .forRoutes(
        { path: '/api/v1/organization/:organizationId/project*', method: RequestMethod.GET },
        { path: '/api/v1/project*', method: RequestMethod.GET },
      );
  }
}
