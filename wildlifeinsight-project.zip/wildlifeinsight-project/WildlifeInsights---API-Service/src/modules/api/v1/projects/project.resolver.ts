import { CreateProjectDto } from './dto/create-project.dto';
import { ProjectService } from './project.service';
import { Resolver, Query, ResolveProperty, Mutation, Args, Parent } from '@nestjs/graphql';
import { UpdateProjectDto } from './dto/update-project.dto';
import { UseInterceptors, UseGuards } from '@nestjs/common';
import { ValidationGraphqlInterceptor } from 'interceptors/validation-graphql.interceptor';
import { PaginationGraphqlInterceptor } from 'interceptors/pagination-graphql.interceptor';
import { Projects } from 'modules/database/entities/projects.entity';
import { GraphqlAuthGuard } from 'guards/graphql-passport.guard';
import { Permissions } from 'decorators/permissions.decorator';
import { GraphqlUserWithPermissions } from 'decorators/graphql-user.decorator';
import { PERMISSIONS } from 'utils/permissions.enum';
import { ProjectsPaginatedDto } from './dto/projects.dto';
import { RoleChangesService } from '../role-changes/role-changes.service';
import { RolesUtils } from 'utils/roles.utils';

const logger = require('logger');

@Resolver('Project')
export class ProjectResolver {
  constructor(
    private readonly projectService: ProjectService,
    private readonly roleChangesService: RoleChangesService,
    private readonly rolesUtils: RolesUtils,
  ) {}

  @Query()
  @UseInterceptors(PaginationGraphqlInterceptor)
  async getProjects(@GraphqlUserWithPermissions() authenticatedUser, @Args() args) {
    const data = await this.projectService.findAll(args.pagination, { authenticatedUser, params: args }, args.filters);
    return new ProjectsPaginatedDto(data[0], data[1], args.pagination.pageSize, args.pagination.pageNumber);
  }

  @Query()
  @UseGuards(GraphqlAuthGuard)
  @Permissions(PERMISSIONS.PROJECT_GET_ONE)
  async getProject(@GraphqlUserWithPermissions(PERMISSIONS.PROJECT_GET_ONE) authenticatedUser, @Args() args) {
    const { projectId } = args;
    return await this.projectService.getById(projectId, {}, { authenticatedUser, params: args });
  }

  @Query()
  @UseGuards(GraphqlAuthGuard)
  async getProjectParticipants(@GraphqlUserWithPermissions(PERMISSIONS.PROJECT_GET_ONE) authenticatedUser, @Args() args) {
    const { projectId } = args;
    const participants = await this.projectService.getParticipants(projectId);
    return await this.rolesUtils.addAllowableRoleChangeOperationsToParticipantData('project', parseInt(projectId, 10), authenticatedUser, participants);
  }

  @ResolveProperty()
  async organization(@Parent() project: Projects) {
    return this.projectService.getOrganizationById(project.organizationId);
  }

  @ResolveProperty()
  async initiative(@Parent() project: Projects) {
    return this.projectService.getInitiativeById(project.initiativeId);
  }

  @Mutation()
  @UseGuards(GraphqlAuthGuard)
  @UseInterceptors(new ValidationGraphqlInterceptor(CreateProjectDto))
  @Permissions(PERMISSIONS.PROJECT_CREATE)
  async createProject(@GraphqlUserWithPermissions(PERMISSIONS.PROJECT_CREATE) authenticatedUser, @Args() args) {
    const { body } = args;
    return this.projectService.create(body, { authenticatedUser, params: args });
  }

  @Mutation()
  @UseGuards(GraphqlAuthGuard)
  @UseInterceptors(new ValidationGraphqlInterceptor(UpdateProjectDto))
  @Permissions(PERMISSIONS.PROJECT_UPDATE)
  async updateProject(@GraphqlUserWithPermissions(PERMISSIONS.PROJECT_UPDATE) authenticatedUser, @Args() args) {
    const { projectId, body } = args;
    return this.projectService.update(projectId, body, { authenticatedUser, params: args });
  }

  @Mutation()
  @UseGuards(GraphqlAuthGuard)
  @Permissions(PERMISSIONS.PROJECT_DELETE)
  async deleteProject(@GraphqlUserWithPermissions(PERMISSIONS.PROJECT_DELETE) authenticatedUser, @Args() args) {
    const { projectId } = args;
    return this.projectService.remove(projectId, { authenticatedUser, params: args });
  }

  @Mutation()
  @UseGuards(GraphqlAuthGuard)
  async manageProjectParticipant(@GraphqlUserWithPermissions() authenticatedUser, @Args() args) {
    const { body } = args;
    const result = await this.rolesUtils.manageEntityParticipants(
      body,
      authenticatedUser,
      'project',
      this.roleChangesService,
    );
    return result;
  }
}
