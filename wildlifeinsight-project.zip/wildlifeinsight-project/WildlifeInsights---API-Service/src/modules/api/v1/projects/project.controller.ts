import { Permissions } from 'decorators/permissions.decorator';
import { UpdateProjectDto } from './dto/update-project.dto';
import { CreateProjectDto } from './dto/create-project.dto';
import { Get, Controller, Req, Post, Body, Patch, Param, Delete, ParseIntPipe, UseGuards, Query } from '@nestjs/common';
import { ProjectService } from './project.service';
import { ApiUseTags, ApiBearerAuth, ApiOperation, ApiResponse, ApiImplicitQuery, ApiImplicitParam } from '@nestjs/swagger';
import { ProjectsPaginatedDto } from './dto/projects.dto';
import { Pagination } from 'decorators/pagination.decorator';
import { ValidationPipe } from 'pipes/validation.pipe';
import { ProjectsDto } from 'modules/database/dto/projects.dto';
import { PermissionsGuard } from 'guards/permissions.guard';
import { User } from 'decorators/user.decorator';
import { AuthenticatedUserDto } from 'dto/authenticated-user.dto';
import { PERMISSIONS } from 'utils/permissions.enum';
import { PaginationModel } from 'utils/pagination.model';

const logger = require('logger');

export const projectsRelations = ['localTaxonomies', 'organization', 'initiatives', 'dataUse', 'deployments', 'participantTypeProjectPivot', 'tags'];

@Controller('/api/v1/organization/:organizationId/project')
@ApiUseTags('Projects')
@ApiBearerAuth()
@UseGuards(PermissionsGuard)
export class ProjectController {
  constructor(private readonly projectService: ProjectService) { }

  @Get('/')
  @ApiOperation({
    title: 'Get Projects', description: `
    Get all projects:
  `, operationId: 'GetAllProjectsByOrganization',
  })
  @ApiResponse({ status: 200, description: 'Projects have been successfully returned', isArray: false, type: ProjectsPaginatedDto })
  @ApiResponse({ status: 403, description: 'Not authorized.' })
  @ApiResponse({ status: 401, description: 'Not authenticated.' })
  @ApiImplicitQuery({
    name: 'includes', description: `
  Allows include the Projects' relations. Available ${projectsRelations}
  `, type: String, required: false,
  })
  @ApiImplicitParam({ name: 'organizationId', description: 'Organization the project belongs to', type: Number, required: true })
  @ApiImplicitQuery({ name: 'fields', description: 'Projects\'s fields to select', type: String, required: false })
  @ApiImplicitQuery({ name: 'page[size]', description: 'Page size. Default 10', type: String, required: false })
  @ApiImplicitQuery({ name: 'page[number]', description: 'Page number', type: String, required: false })
  @ApiImplicitQuery({ name: 'sort', description: 'Sort results', type: String, required: false })
  @ApiImplicitQuery({ name: 'name', description: 'Filter by name', type: String, required: false })
  @Permissions(PERMISSIONS.PROJECT_GET_ALL)
  async findAll(@Query() filters, @Pagination() pagination: PaginationModel, @Param() params, @User() authenticatedUser: AuthenticatedUserDto) {
    logger.info('Getting all projects');
    const data = await this.projectService.findAll(pagination, { authenticatedUser, params }, filters);
    return new ProjectsPaginatedDto(data[0], data[1], pagination.pageSize, pagination.pageNumber);
  }

  @Get('/:projectId')
  @ApiOperation({
    title: 'Get project by id', description: `
    Get project by id
  `, operationId: 'GetProjectById',
  })
  @ApiImplicitQuery({
    name: 'includes', description: `
  Allows include the Projects's relations. Available ${projectsRelations}
  `, type: String, required: false,
  })
  @ApiImplicitParam({ name: 'projectId', description: 'Id of the project' })
  @ApiImplicitParam({ name: 'organizationId', description: 'Organization the project belongs to', type: Number, required: true })
  @ApiResponse({ status: 200, description: 'Project has been successfully returned', isArray: false, type: ProjectsDto })
  @ApiResponse({ status: 404, description: 'Project does not exist or you don\'t have permission' })
  @ApiResponse({ status: 401, description: 'Not authenticated.' })
  @Permissions(PERMISSIONS.PROJECT_GET_ONE)
  async getById(@Param('projectId', new ParseIntPipe()) id: number, @Pagination() pagination: PaginationModel, @Param() params, @User() authenticatedUser: AuthenticatedUserDto) {
    logger.info('Get project by id ', id);
    return await this.projectService.getById(id, pagination, { authenticatedUser, params });
  }

  @Get('/:projectId/science-data')
  @ApiOperation({
    title: 'Get science data by project id', description: `
    Get science data
  `, operationId: 'GetScienceDataByProject',
  })
  @ApiImplicitParam({ name: 'projectId', description: 'Id of the project' })
  @ApiImplicitParam({ name: 'organizationId', description: 'Organization the project belongs to', type: Number, required: true })
  @ApiResponse({ status: 200, description: 'Data has been successfully returned', isArray: false, type: ProjectsDto })
  @ApiResponse({ status: 404, description: 'Project does not exist or you don\'t have permission' })
  @ApiResponse({ status: 401, description: 'Not authenticated.' })
  @Permissions(PERMISSIONS.PROJECT_GET_ONE)
  async getScienceData(@Param('projectId', new ParseIntPipe()) id: number, @Pagination() pagination: PaginationModel, @Param() params, @User() authenticatedUser: AuthenticatedUserDto) {
    logger.info('Get science data for project with id ', id);
    return await this.projectService.getScienceData(id, pagination, { authenticatedUser, params });
  }

  @Post()
  @ApiOperation({
    title: 'Create project', description: `
    Create new project
  `, operationId: 'CreateProject',
  })
  @ApiImplicitParam({ name: 'organizationId', description: 'Organization the project belongs to', type: Number, required: true })
  @ApiResponse({ status: 200, description: 'Project has been successfully created', isArray: false, type: ProjectsDto })
  @ApiResponse({ status: 400, description: 'Body contains errors' })
  @ApiResponse({ status: 401, description: 'Not authenticated.' })
  @Permissions(PERMISSIONS.PROJECT_CREATE)
  async create(@Body(new ValidationPipe()) createProjectDto: CreateProjectDto, @User() authenticatedUser: AuthenticatedUserDto, @Param() params) {
    logger.info('Creating project');
    // logger.debug(createProjectDto.startDate);
    return await this.projectService.create(createProjectDto, { authenticatedUser, params });
  }

  @Patch('/:projectId')
  @ApiOperation({
    title: 'Update project', description: `
    Update project
  `, operationId: 'UpdateProject',
  })
  @ApiImplicitParam({ name: 'projectId', description: 'Id of the project' })
  @ApiImplicitParam({ name: 'organizationId', description: 'Organization the project belongs to', type: Number, required: true })
  @ApiResponse({ status: 200, description: 'Project has been successfully updated', isArray: false, type: ProjectsDto })
  @ApiResponse({ status: 404, description: 'Project does not exist or you don\'t have permission' })
  @ApiResponse({ status: 401, description: 'Not authenticated.' })
  @Permissions(PERMISSIONS.PROJECT_UPDATE)
  async update(
    @Param('projectId', new ParseIntPipe()) id: number,
    @Param() params,
    @Body(new ValidationPipe()) updateProjectDto: UpdateProjectDto,
    @User() authenticatedUser: AuthenticatedUserDto,
  ) {
    logger.info('Updating project');
    // TODO: Add security
    return await this.projectService.update(id, updateProjectDto, { authenticatedUser, params });
  }

  @Delete('/:projectId')
  @ApiOperation({
    title: 'Delete project', description: `
    Delete project
  `, operationId: 'DeleteProject',
  })
  @ApiImplicitParam({ name: 'projectId', description: 'Id of the project' })
  @ApiImplicitParam({ name: 'organizationId', description: 'Organization the project belongs to', type: Number, required: true })
  @ApiResponse({ status: 200, description: 'Project has been successfully deleted', isArray: false, type: ProjectsDto })
  @ApiResponse({ status: 404, description: 'Project does not exist or you don\'t have permission' })
  @ApiResponse({ status: 401, description: 'Not authenticated.' })
  @Permissions(PERMISSIONS.PROJECT_DELETE)
  async remove(@Param('projectId', new ParseIntPipe()) id: number,  @Param() params, @User() authenticatedUser: AuthenticatedUserDto) {
    logger.info('Deleting project');
    return await this.projectService.remove(id, { authenticatedUser, params });
  }
}
