import { Get, Controller, Req, Post, Body, Patch, Param, Delete, ParseIntPipe, UseGuards } from '@nestjs/common';
import { IdentificationMethodService } from './identification-method.service';
import { ApiUseTags, ApiBearerAuth, ApiOperation, ApiResponse, ApiImplicitQuery, ApiImplicitParam } from '@nestjs/swagger';
import { IdentificationMethodsPaginatedDto } from './dto/identification-methods.dto';
import { Pagination } from 'decorators/pagination.decorator';
import { IdentificationMethodsDto } from 'modules/database/dto/identification-methods.dto';
import { PermissionsGuard } from 'guards/permissions.guard';
import { User } from 'decorators/user.decorator';
import { AuthenticatedUserDto } from 'dto/authenticated-user.dto';
import { PaginationModel } from 'utils/pagination.model';

const logger = require('logger');

export const identificationMethodsRelations = ['features'];

@Controller('/api/v1/identification-methods')
@ApiUseTags('IdentificationMethods')
@ApiBearerAuth()
@UseGuards(PermissionsGuard)
export class IdentificationMethodController {
  constructor(private readonly identificationMethodsService: IdentificationMethodService) { }

  @Get()
  @ApiOperation({
    title: 'Get Identification Methods', description: `
    Get all identification-methods:
  `, operationId: 'GetAllIdentificationMethods',
  })
  @ApiResponse({ status: 200, description: 'Identification Methods have been successfully returned', isArray: false, type: IdentificationMethodsPaginatedDto })
  @ApiResponse({ status: 403, description: 'Not authorized.' })
  @ApiResponse({ status: 401, description: 'Not authenticated.' })
  @ApiImplicitQuery({
    name: 'includes', description: `
  Allows include the IdentificationMethods's relations. Available ${identificationMethodsRelations}
  `, type: String, required: false,
  })
  @ApiImplicitQuery({ name: 'fields', description: 'IdentificationMethods\'s fields to select', type: String, required: false })
  @ApiImplicitQuery({ name: 'page[size]', description: 'Page size. Default 10', type: String, required: false })
  @ApiImplicitQuery({ name: 'page[number]', description: 'Page number', type: String, required: false })
  @ApiImplicitQuery({ name: 'sort', description: 'Sort results', type: String, required: false })
  async findAll(@Pagination() pagination: PaginationModel, @Param() params, @User() authenticatedUser: AuthenticatedUserDto) {
    logger.info('Getting all');
    const data = await this.identificationMethodsService.findAll(pagination, { authenticatedUser, params });
    return new IdentificationMethodsPaginatedDto(data[0], data[1], pagination.pageSize, pagination.pageNumber);
  }

  @Get('/:id')
  @ApiOperation({
    title: 'Get identification methods by id', description: `
    Get identificationMethods by id
  `, operationId: 'GetIdentificationMethodById',
  })
  @ApiImplicitQuery({
    name: 'includes', description: `
  Allows include the Identification Methods's relations. Available ${identificationMethodsRelations}
  `, type: String, required: false,
  })
  @ApiImplicitParam({ name: 'id', description: 'Id of the identification Methods' })
  @ApiResponse({ status: 200, description: 'IdentificationMethod has been successfully returned', isArray: false, type: IdentificationMethodsDto })
  @ApiResponse({ status: 404, description: 'IdentificationMethod does not exist or you don\'t have permission' })
  @ApiResponse({ status: 401, description: 'Not authenticated.' })
  async getById(@Param('id', new ParseIntPipe()) id: number, @User() authenticatedUser: AuthenticatedUserDto, @Param() params, @Pagination() pagination: PaginationModel) {
    logger.info('Get by id ', id);
    return await this.identificationMethodsService.getById(id, pagination, { authenticatedUser, params });
  }
}
