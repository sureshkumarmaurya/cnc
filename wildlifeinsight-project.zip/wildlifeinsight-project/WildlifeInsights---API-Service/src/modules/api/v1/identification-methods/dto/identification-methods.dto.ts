import { ApiModelProperty } from '@nestjs/swagger';
import { IdentificationMethodsDto } from 'modules/database/dto/identification-methods.dto';
import { MetaDto } from 'modules/database/dto/meta.dto';

export class IdentificationMethodsPaginatedDto {

  @ApiModelProperty({ type: IdentificationMethodsDto, isArray: true })
  readonly data: IdentificationMethodsDto[];

  @ApiModelProperty()
  readonly meta: MetaDto;

  constructor(data, totalItems: number, pageSize: number, page: number) {
    this.data = data;
    this.meta = new MetaDto(Math.ceil(totalItems / pageSize), totalItems, pageSize, page);
  }
}
