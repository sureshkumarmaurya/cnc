import { IdentificationMethodController, identificationMethodsRelations } from './identification-method.controller';
import { IdentificationMethodService } from './identification-method.service';
import { Module, RequestMethod, MiddlewareConsumer } from '@nestjs/common';
import { PaginationMiddleware } from 'middlewares/pagination.middleware';
import { IdentificationMethodResolver } from './identification-method.resolver';
import { DatabaseModule } from 'modules/database/database.module';

@Module({
  imports: [DatabaseModule],
  controllers: [IdentificationMethodController],
  providers: [IdentificationMethodService, IdentificationMethodResolver],
})
export class IdentificationMethodModule {
  public configure(consumer: MiddlewareConsumer) {
    consumer
      .apply(PaginationMiddleware)
      .with({ includes: [], allowIncludes: identificationMethodsRelations })
      .forRoutes(
        { path: '/api/v1/identification-method', method: RequestMethod.GET },
        { path: '/api/v1/identification-method/:identification-methodId', method: RequestMethod.GET },
      );
  }
}
