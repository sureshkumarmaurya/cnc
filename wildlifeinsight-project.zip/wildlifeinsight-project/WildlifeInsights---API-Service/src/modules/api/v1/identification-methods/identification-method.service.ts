import { IdentificationMethods } from 'modules/database/entities/identification-methods.entity';
import { Repository } from 'typeorm';
import { Injectable, Inject } from '@nestjs/common';
import { GenericService } from 'utils/generic.service';
import { InfoDto } from 'dto/info.dto';
import { IucnRedListCategories } from 'modules/database/entities/iucn-red-list-categories.entity';
import { CommonNames } from 'modules/database/entities/common-names.entity';

const logger = require('logger');

@Injectable()
export class IdentificationMethodService extends GenericService<IdentificationMethods, any, any>  {

  constructor(
    @Inject('IdentificationMethodsRepositoryToken') private readonly identificationMethodsRepository: Repository<IdentificationMethods>,
    @Inject('IucnRedListCategoriesRepositoryToken') private readonly iucnRedListCategoriesRepository: Repository<IucnRedListCategories>,
    @Inject('CommonNamesRepositoryToken') private readonly commonNamesRepository: Repository<CommonNames>,
  ) {
    super(identificationMethodsRepository, 'identificationMethod');
  }

  async getIucnCategoryById(id: number): Promise<IucnRedListCategories> {
    return this.iucnRedListCategoriesRepository.findOne(id);
  }

  async setDataCreate(create: any, info: InfoDto) {
    return null;
  }

  async setDataUpdate(model: IdentificationMethods, update: any, info: InfoDto) {

    return model;
  }

}
