import { IdentificationMethodService } from './identification-method.service';
import { Resolver, Query, Args } from '@nestjs/graphql';
import { UseInterceptors } from '@nestjs/common';
import { PaginationGraphqlInterceptor } from 'interceptors/pagination-graphql.interceptor';
import { User } from 'decorators/user.decorator';
import { IdentificationMethodsPaginatedDto } from './dto/identification-methods.dto';

@Resolver('IdentificationMethod')
export class IdentificationMethodResolver {
  constructor(private readonly identificationMethodService: IdentificationMethodService) {}

  @Query()
  @UseInterceptors(PaginationGraphqlInterceptor)
  async getIdentificationMethods(@User() authenticatedUser, @Args() args) {
    const data = await this.identificationMethodService.findAll(args.pagination, { authenticatedUser, params: args });
    return new IdentificationMethodsPaginatedDto(data[0], data[1], args.pagination.pageSize, args.pagination.pageNumber);
  }

  @Query()
  async getIdentificationMethod(@User() authenticatedUser, @Args() args) {
    const { id } = args;
    return await this.identificationMethodService.getById(id, {}, { authenticatedUser, params: args });
  }

}
