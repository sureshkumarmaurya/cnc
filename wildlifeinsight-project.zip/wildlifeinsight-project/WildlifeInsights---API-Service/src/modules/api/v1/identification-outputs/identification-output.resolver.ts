import { IdentificationOutputService } from './identification-output.service';
import { Resolver, Query, Args, Parent, ResolveProperty, Mutation, Subscription } from '@nestjs/graphql';
import { UseInterceptors, UseGuards } from '@nestjs/common';
import { PaginationGraphqlInterceptor } from 'interceptors/pagination-graphql.interceptor';
import { User } from 'decorators/user.decorator';
import { IdentificationOutputsPaginatedDto } from './dto/identification-outputs.dto';
import { IdentificationOutputs } from 'modules/database/entities/identification-outputs.entity';
import { IdentificationMethods } from 'modules/database/entities/identification-methods.entity';
import { IdentifiedObjects } from 'modules/database/entities/identified-objects.entity';
import { Participants } from 'modules/database/entities/participants.entity';
import { GraphqlAuthGuard } from 'guards/graphql-passport.guard';
import { GraphqlUserWithPermissions } from 'decorators/graphql-user.decorator';
import { ValidationGraphqlInterceptor } from 'interceptors/validation-graphql.interceptor';
import { CreateIdentificationOutputDto } from './dto/create-identification-output.dto';
import { PERMISSIONS } from 'utils/permissions.enum';
import { Permissions } from 'decorators/permissions.decorator';
import { PubSub, withFilter } from 'graphql-subscriptions';
import { CreateIdentificationOutputBulkDto } from './dto/create-identification-output-bulk.dto';

const pubSub = new PubSub();

@Resolver('IdentificationOutput')
export class IdentificationOutputResolver {
  constructor(private readonly identificationOutputService: IdentificationOutputService) {}

  @Query()
  @UseGuards(GraphqlAuthGuard)
  @UseInterceptors(PaginationGraphqlInterceptor)
  async getIdentificationOutputs(@GraphqlUserWithPermissions() authenticatedUser, @Args() args) {
    const data = await this.identificationOutputService.findAll(args.pagination, { authenticatedUser, params: args });
    return new IdentificationOutputsPaginatedDto(data[0], data[1], args.pagination.pageSize, args.pagination.pageNumber);
  }

  @Query()
  async getIdentificationOutput(@GraphqlUserWithPermissions() authenticatedUser, @Args() args) {
    const { id } = args;
    return await this.identificationOutputService.getById(id, {}, { authenticatedUser, params: args });
  }

  @ResolveProperty()
  async identificationMethod(@Parent() identificationOutput: IdentificationOutputs): Promise<IdentificationMethods> {
    return this.identificationOutputService.getIdentificationMethod(identificationOutput.identificationMethodId);
  }

  @ResolveProperty()
  async participant(@Parent() identificationOutput: IdentificationOutputs): Promise<Participants> {
    return this.identificationOutputService.getParticipantById(identificationOutput.participantId);
  }

  @ResolveProperty()
  async identifiedObjects(@Parent() identificationOutput: IdentificationOutputs): Promise<IdentifiedObjects[]> {
    return this.identificationOutputService.getIdentifiedObjectsByIdentificationOutputId(identificationOutput.id);
  }

  @Mutation()
  @UseGuards(GraphqlAuthGuard)
  @UseInterceptors(new ValidationGraphqlInterceptor(CreateIdentificationOutputDto))
  @Permissions(PERMISSIONS.IDENTIFICATION_CREATE)
  async createIdentificationOutput(@GraphqlUserWithPermissions(PERMISSIONS.IDENTIFICATION_CREATE) authenticatedUser, @Args() args) {
    const { body } = args;
    const identificationOutputCreated = await this.identificationOutputService.create(body, { authenticatedUser, params: args });
    pubSub.publish('identificationOutputAdded', { identificationOutputCreated });
    return identificationOutputCreated;
  }

  @Mutation()
  @UseGuards(GraphqlAuthGuard)
  @UseInterceptors(new ValidationGraphqlInterceptor(CreateIdentificationOutputBulkDto))
  async createIdentificationOutputBulk(@GraphqlUserWithPermissions() authenticatedUser, @Args() args) {
    const { body } = args;
    const result = await this.identificationOutputService.createBulk(body, { authenticatedUser, params: args });
    // pubSub.publish('identificationOutputAdded', { identificationOutputCreated });
    return result;
  }

  @Mutation()
  @UseGuards(GraphqlAuthGuard)
  @Permissions(PERMISSIONS.IDENTIFICATION_DELETE)
  async deleteIdentificationOutput(@GraphqlUserWithPermissions(PERMISSIONS.IDENTIFICATION_DELETE) authenticatedUser, @Args() args) {
    const { id } = args;
    return this.identificationOutputService.remove(id, { authenticatedUser, params: args });
  }

  // @Subscription()
  // identificationOutputAdded() {
  //   return {
  //     subscribe: withFilter(() => pubSub.asyncIterator('identificationOutputAdded'), (payload, variables) => {
  //       console.log('payload', payload);
  //       console.log('variables', variables);
  //       return true;
  //     }),
  //   };
  // }

}
