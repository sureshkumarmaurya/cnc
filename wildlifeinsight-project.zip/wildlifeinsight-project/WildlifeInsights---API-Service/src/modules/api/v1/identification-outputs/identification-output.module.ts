import { IdentificationOutputController, identificationOutputsRelations } from './identification-output.controller';
import { IdentificationOutputService } from './identification-output.service';
import { Module, RequestMethod, MiddlewareConsumer } from '@nestjs/common';
import { PaginationMiddleware } from 'middlewares/pagination.middleware';
import { IdentificationOutputResolver } from './identification-output.resolver';
import { DatabaseModule } from 'modules/database/database.module';
import { IdentifiedObjectResolver } from './identified-object.resolver';
import { IdentificationOutputGeneralController } from './identification-output-general.controller';
import { GoogleModule } from 'modules/google/google.module';
import { DataFileModule } from '../data-files/data-file.module';

@Module({
  imports: [DatabaseModule, GoogleModule, DataFileModule],
  controllers: [IdentificationOutputController, IdentificationOutputGeneralController],
  providers: [IdentificationOutputService, IdentificationOutputResolver, IdentifiedObjectResolver],
})
export class IdentificationOutputModule {
  public configure(consumer: MiddlewareConsumer) {
    consumer
      .apply(PaginationMiddleware)
      .with({ includes: [], allowIncludes: identificationOutputsRelations })
      .forRoutes(
        { path: '/api/v1/project/:projectId/deployment/:deploymentId/data-file/:dataFileId/identification-output', method: RequestMethod.GET },
        { path: '/api/v1/project/:projectId/deployment/:deploymentId/data-file/:dataFileId/identification-output/:id', method: RequestMethod.GET },
      );
  }
}
