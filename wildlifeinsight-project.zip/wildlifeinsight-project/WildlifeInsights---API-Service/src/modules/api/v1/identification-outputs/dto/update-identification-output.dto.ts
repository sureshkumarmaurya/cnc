import { ApiModelProperty } from '@nestjs/swagger';
import { IsInt, IsBoolean, IsString, IsOptional, MaxLength, IsISO8601, IsArray } from 'class-validator';

export class UpdateIdentificationOutputDto {

  @IsBoolean()
  @ApiModelProperty({ required: false })
  blankYn: boolean;

  @IsInt()
  @ApiModelProperty({ required: false })
  identificationMethodId: number;

}
