import { IdentificationOutputs } from 'modules/database/entities/identification-outputs.entity';
import { Repository, SelectQueryBuilder, Connection, EntityManager } from 'typeorm';
import { Injectable, Inject, NotFoundException, BadRequestException, UnauthorizedException } from '@nestjs/common';
import { GenericService } from 'utils/generic.service';
import { InfoDto } from 'dto/info.dto';
import { IdentificationMethods } from 'modules/database/entities/identification-methods.entity';
import { CreateIdentificationOutputDto } from './dto/create-identification-output.dto';
import { DataFiles } from 'modules/database/entities/data-files.entity';
import { UpdateIdentificationOutputDto } from './dto/update-identification-output.dto';
import { Taxonomies } from '../../../database/entities/taxonomies.entity';
import { IdentifiedObjects } from '../../../database/entities/identified-objects.entity';
import { Participants } from 'modules/database/entities/participants.entity';
import { CreateIdentificationOutputBulkDto } from './dto/create-identification-output-bulk.dto';
import { IdentificationOutputsDto } from 'modules/database/dto/identification-outputs.dto';
import { Projects } from 'modules/database/entities/projects.entity';
import { StorageService, WIBucketType } from 'modules/google/storage.service';
import { PermissionsUtils } from 'utils/permissions.utils';
import { ProjectsDto } from 'modules/database/dto/projects.dto';
import { PERMISSIONS } from 'utils/permissions.enum';
import { DATA_FILE_STATUS_VERIFIED, DATA_FILE_STATUS_BLANK, DATA_FILE_STATUS_UNKNOWN } from 'app.constants';
import { ROLES } from 'utils/roles.enum';

const logger = require('logger');
const config = require('config');

@Injectable()
export class IdentificationOutputService extends GenericService<IdentificationOutputs, any, any>  {

  constructor(
    @Inject('IdentificationOutputsRepositoryToken') private readonly identificationOutputsRepository: Repository<IdentificationOutputs>,
    @Inject('IdentificationMethodsRepositoryToken') private readonly identificationMethodsRepository: Repository<IdentificationMethods>,
    @Inject('IdentifiedObjectsRepositoryToken') private readonly identifiedObjectsRepository: Repository<IdentifiedObjects>,
    @Inject('DataFilesRepositoryToken') private readonly dataFilesRepository: Repository<DataFiles>,
    @Inject('TaxonomiesRepositoryToken') private readonly taxonomiesRepository: Repository<Taxonomies>,
    @Inject('ParticipantsRepositoryToken') private readonly participantsRepository: Repository<Participants>,
    @Inject('ProjectsRepositoryToken') private readonly projectsRepository: Repository<Projects>,
    @Inject('DbConnectionToken') private readonly connection: Connection,

    private readonly storageService: StorageService,
  ) {
    super(identificationOutputsRepository, 'identificationOutput');
  }

  setFilters(query: SelectQueryBuilder<IdentificationOutputs>, filters: any, info: InfoDto) {
    if (info.pagination.includes && info.pagination.includes.indexOf('dataFile') >= 0) {
      query.innerJoinAndSelect('identificationOutput.dataFile', 'dataFile');
      info.pagination.includes.splice(info.pagination.includes.indexOf('dataFile'), 1);
    } else {
      query.innerJoin('identificationOutput.dataFile', 'dataFile');
    }
    query.innerJoin('dataFile.deployment', 'deployment');

    // According to the GraphQL spec
    // (http://spec.graphql.org/June2018/#sec-Type-System.List), I would expect
    // dataFileId to be coerced to a singleton list if a single value is
    // provided by the client, but since apparently this isn't done by the
    // current version of Apollo server, we coerce this ourselves here.
    query
      .andWhere('dataFile.id IN(:...dataFileId)')
      .setParameter(
        'dataFileId',
        Array.isArray(info.params.dataFileId) ? info.params.dataFileId : [info.params.dataFileId],
      );

    query.andWhere('deployment.projectId = :projectId').setParameter('projectId', info.params.projectId);
    return query;
  }

  setFiltersGetById(query: SelectQueryBuilder<IdentificationOutputs>, info: InfoDto) {
    if (info.pagination.includes && info.pagination.includes.indexOf('dataFile') >= 0) {
      query.innerJoinAndSelect('identificationOutput.dataFile', 'dataFile');
      info.pagination.includes.splice(info.pagination.includes.indexOf('dataFile'), 1);
    } else {
      query.innerJoin('identificationOutput.dataFile', 'dataFile');
    }
    query.innerJoin('dataFile.deployment', 'deployment');
    query.andWhere('dataFile.id = :dataFileId').setParameter('dataFileId', info.params.dataFileId);
    query.andWhere('deployment.id = :deploymentId').setParameter('deploymentId', info.params.deploymentId);
    query.andWhere('deployment.projectId = :projectId').setParameter('projectId', info.params.projectId);
    return query;
  }

  setFiltersDelete(query: SelectQueryBuilder<IdentificationOutputs>, info: InfoDto) {
    query.innerJoin('identificationOutput.dataFile', 'dataFile');
    query.innerJoin('dataFile.deployment', 'deployment');
    query.andWhere('dataFile.id = :dataFileId').setParameter('dataFileId', info.params.dataFileId);
    query.andWhere('deployment.id = :deploymentId').setParameter('deploymentId', info.params.deploymentId);
    query.andWhere('deployment.projectId = :projectId').setParameter('projectId', info.params.projectId);
    return query;
  }

  setFiltersUpdate(query: SelectQueryBuilder<IdentificationOutputs>, info: InfoDto) {
    query.innerJoin('identificationOutput.dataFile', 'dataFile');
    query.innerJoin('dataFile.deployment', 'deployment');
    query.andWhere('dataFile.id = :dataFileId').setParameter('dataFileId', info.params.dataFileId);
    query.andWhere('deployment.id = :deploymentId').setParameter('deploymentId', info.params.deploymentId);
    query.andWhere('deployment.projectId = :projectId').setParameter('projectId', info.params.projectId);
    return query;
  }

  async getIdentificationMethod(id: number): Promise<IdentificationMethods> {
    return this.identificationMethodsRepository.findOne(id);
  }

  async getTaxonomyById(id: string): Promise<Taxonomies> {
    return this.taxonomiesRepository.findOne({ where: { uniqueIdentifier: id } });
  }

  async getParticipantById(id: number): Promise<Participants> {
    return this.participantsRepository.findOne(id);
  }

  async getIdentifiedObjectsByIdentificationOutputId(id: number): Promise<IdentifiedObjects[]> {
    return this.identifiedObjectsRepository.find({ where: { identificationId: id } });
  }

  async validateBeforeCreate(createModel: CreateIdentificationOutputDto, info: InfoDto): Promise<void> {
    const dataFile = await this.dataFilesRepository.createQueryBuilder('dataFile')
    .innerJoin('dataFile.deployment', 'deployment')
    .andWhere('dataFile.id = :dataFileId').setParameter('dataFileId', info.params.dataFileId)
    .andWhere('deployment.id = :deploymentId').setParameter('deploymentId', info.params.deploymentId)
    .andWhere('deployment.projectId = :projectId').setParameter('projectId', info.params.projectId)
    .getOne();

    if (!dataFile) {
      throw new NotFoundException('Data file not found');
    }

    // const exists = await this.identificationOutputsRepository.createQueryBuilder('idOutput').andWhere('idOutput.dataFileId = :dataFileId')
    // .andWhere('idOutput.participantId = :participantId')
    // .setParameters({
    //   dataFileId: info.params.dataFileId,
    //   participantId: info.authenticatedUser.user.id,
    // }).getCount();

    // if (exists > 0) {
    //   throw new BadRequestException('Only one identification by user for the same datafile');
    // }

    const method = await this.identificationMethodsRepository.findOne(createModel.identificationMethodId);
    if (!method) {
      throw new NotFoundException('Identification method not found');
    }

    if (createModel.identifiedObjects && createModel.identifiedObjects.length > 0) {
      for (let i = 0, { length } = createModel.identifiedObjects; i < length; i++) {
        const taxonomy = await this.taxonomiesRepository.findOne({ where: { uniqueIdentifier: createModel.identifiedObjects[i].taxonomyId } });
        if (!taxonomy) {
          throw new NotFoundException(`Taxonomy not found with id ${createModel.identifiedObjects[i].taxonomyId}`);
        }
      }
    }
  }

  async setDataCreate(create: CreateIdentificationOutputDto, info: InfoDto) {
    const dataFile = await this.dataFilesRepository.findOne(info.params.dataFileId);
    const method = await this.identificationMethodsRepository.findOne(create.identificationMethodId);

    const model = new IdentificationOutputs();
    model.blankYn = create.blankYn;
    model.dataFile = dataFile;
    model.identificationMethod = method;
    model.timestamp = new Date();
    model.participantId = info.authenticatedUser.user.id;

    if (create.identifiedObjects && create.identifiedObjects.length > 0) {
      model.identifiedObjects = [];
      for (let i = 0, { length } = create.identifiedObjects; i < length; i++) {
        const idObj = create.identifiedObjects[i];
        const taxonomy = await this.taxonomiesRepository.findOne({ where: { uniqueIdentifier: idObj.taxonomyId } });
        const identifiedObject = new IdentifiedObjects();
        identifiedObject.taxonomy = taxonomy;
        identifiedObject.relativeAge = idObj.relativeAge;
        identifiedObject.sex = idObj.sex;
        identifiedObject.markings = idObj.markings;
        identifiedObject.individualIdentified = idObj.individualIdentified;
        identifiedObject.behavior = idObj.behavior;
        identifiedObject.remarks = idObj.remarks;
        identifiedObject.date = new Date();
        identifiedObject.certainity = idObj.certainity;
        model.identifiedObjects.push(identifiedObject);
      }
    }

    return model;
  }

  async create(createModel: CreateIdentificationOutputDto, info?: InfoDto): Promise<IdentificationOutputs> {
    logger.debug('Creating identification');

    await this.validateBeforeCreate(createModel, info);
    let model = await this.setDataCreate(createModel, info);

    return await this.connection.manager.transaction(async (entityManager: EntityManager) => {
      model = await entityManager.save(IdentificationOutputs, model);
      let dataFile = await this.dataFilesRepository.findOne(info.params.dataFileId);
      logger.debug('Updating data-file status');
      const speciesOfIdentifiedObject : Taxonomies = model.identifiedObjects && model.identifiedObjects.slice(-1).pop().taxonomy;

      dataFile = await this.tagOrDeleteDataFilesWithHumans(info.params.projectId, createModel.identificationMethodId, dataFile, speciesOfIdentifiedObject);

      if (speciesOfIdentifiedObject && speciesOfIdentifiedObject.scientificName === 'Unknown species') {
        dataFile.status = DATA_FILE_STATUS_UNKNOWN;
      } else if (createModel.blankYn) {
        dataFile.status = DATA_FILE_STATUS_BLANK;
      } else {
        dataFile.status = DATA_FILE_STATUS_VERIFIED;
      }

      dataFile.identifiedByExpert = true;
      await entityManager.save(DataFiles, dataFile);
      return model;
    });
  }

  async validateBeforeCreateBulk(createModel: CreateIdentificationOutputBulkDto, info: InfoDto): Promise<void> {

    const projects = PermissionsUtils.getProjectsInAllOrganizationsWithPermission(info.authenticatedUser, PERMISSIONS.IDENTIFICATION_CREATE);
    if (!projects || projects.length === 0) {
      throw new UnauthorizedException('User not authorized to create identification output');
    }
    const projectIds = projects.map((p: ProjectsDto) => p.id);
    logger.debug('Checking if the user has permission to create identification in all project that the datafiles belong');
    for (let i = 0, length = createModel.dataFileIds.length; i < length; i++) {
      const dataFile = await this.dataFilesRepository.createQueryBuilder('dataFile')
      .innerJoin('dataFile.deployment', 'deployment')
      .andWhere('dataFile.id = :dataFileId').setParameter('dataFileId', createModel.dataFileIds[i])
      .andWhere('deployment.projectId in (:...projectIds)').setParameter('projectIds', projectIds)
      .getOne();

      if (!dataFile) {
        throw new NotFoundException('Data file not found');
      }
      // const exists = await this.identificationOutputsRepository.createQueryBuilder('idOutput').andWhere('idOutput.dataFileId = :dataFileId')
      // .andWhere('idOutput.participantId = :participantId')
      // .setParameters({
      //   dataFileId: createModel.dataFileIds[i],
      //   participantId: info.authenticatedUser.user.id,
      // }).getCount();

      // if (exists > 0) {
      //   throw new BadRequestException('Only one identification by user for the same datafile');
      // }
    }

    const method = await this.identificationMethodsRepository.findOne(createModel.identificationOutput.identificationMethodId);
    if (!method) {
      throw new NotFoundException('Identification method not found');
    }

    if (createModel.identificationOutput.identifiedObjects && createModel.identificationOutput.identifiedObjects.length > 0) {
      for (let i = 0, { length } = createModel.identificationOutput.identifiedObjects; i < length; i++) {
        const taxonomy = await this.taxonomiesRepository.findOne({ where: { uniqueIdentifier: createModel.identificationOutput.identifiedObjects[i].taxonomyId } });
        if (!taxonomy) {
          throw new NotFoundException(`Taxonomy not found with id ${createModel.identificationOutput.identifiedObjects[i].taxonomyId}`);
        }
      }
    }

  }

  async createBulk(createModel: CreateIdentificationOutputBulkDto, info?: InfoDto): Promise<IdentificationOutputsDto[]> {
    logger.debug('Creating bulk');

    await this.validateBeforeCreateBulk(createModel, info);

    return await this.connection.manager.transaction(async (entityManager: EntityManager) => {
      const result = [];
      for (let i = 0, length = createModel.dataFileIds.length; i < length; i++) {
        const infoClone = Object.assign({}, info);
        infoClone.params.dataFileId = createModel.dataFileIds[i];
        let model = await this.setDataCreate(createModel.identificationOutput, infoClone);
        model = await entityManager.save(IdentificationOutputs, model);
        let dataFile = await entityManager.findOne(DataFiles, createModel.dataFileIds[i]);
        logger.debug('Updating data-file status');
        const speciesOfIdentifiedObject : Taxonomies = model.identifiedObjects && model.identifiedObjects.slice(-1).pop().taxonomy;

        dataFile = await this.tagOrDeleteDataFilesWithHumans(info.params.projectId, model.identificationMethodId, dataFile, speciesOfIdentifiedObject);

        if (speciesOfIdentifiedObject && speciesOfIdentifiedObject.scientificName === 'Unknown species') {
          dataFile.status = DATA_FILE_STATUS_UNKNOWN;
        } else  if (createModel.identificationOutput.blankYn) {
          dataFile.status = DATA_FILE_STATUS_BLANK;
        } else {
          dataFile.status = DATA_FILE_STATUS_VERIFIED;
        }

        dataFile.identifiedByExpert = true;
        await entityManager.save(DataFiles, dataFile);
        result.push(model);
      }
      return result;
    });

  }

  async validateBeforeUpdate(id:number, updateModel: UpdateIdentificationOutputDto, info?: InfoDto): Promise<void> {
    if (updateModel.identificationMethodId !== undefined) {
      const method = await this.identificationMethodsRepository.findOne(updateModel.identificationMethodId);
      if (!method) {
        throw new NotFoundException('Identification method not found');
      }
    }
  }

  async setDataUpdate(model: IdentificationOutputs, update: UpdateIdentificationOutputDto, info: InfoDto) {
    if (update.blankYn !== undefined) {
      model.blankYn = update.blankYn;
    }

    if (update.identificationMethodId !== undefined) {
      const method = await this.identificationMethodsRepository.findOne(update.identificationMethodId);
      model.identificationMethod = method;
    }
    return model;
  }

  /**
   * Given a data file and the taxonomy of objects identified in it, if taxonomy
   * is that of a human, tag the data file as containing a human, and if the
   * parent project is set to request deletion of such images, remove the actual
   * binary blob and thumbnail from bucket storage.
   */
  async tagOrDeleteDataFilesWithHumans(projectId: number, identificationMethodId: number, dataFile: DataFiles, species: Taxonomies) {
    const humanGenusSpecies = { genus: 'Homo', species: 'sapiens' };
    const isHumanDetected = Object.keys(humanGenusSpecies).every(key => species && species[key] && species[key].toLowerCase() === humanGenusSpecies[key].toLowerCase());

    if (isHumanDetected) {
      dataFile.humanIdentified = true;

      const expertIdentification = await this.identificationMethodsRepository.findOne({
        where: { type_name: 'Expert identification' },
      });

      const isExpertIdentification = identificationMethodId === expertIdentification.id;
      const project = await this.projectsRepository.findOne(projectId);

      const shouldDeleteRawData = (isExpertIdentification && project.deleteDataFilesWithIdentifiedHumans);

      if (shouldDeleteRawData) {
        try {
          await this.storageService.deleteWIFile(project.slug, dataFile.filepath, WIBucketType.main);
          await this.storageService.deleteWIFile(project.slug, dataFile.filepath, WIBucketType.thumbnail);
        } catch (err) {
          logger.error('Error while deleting data file', err);
        }
        const humanObfuscationSettings = config.get('humanObfuscation');

        dataFile.filepath = humanObfuscationSettings.placeholder;
        dataFile.thumbnailUrl = humanObfuscationSettings.thumbnail;
        dataFile.filesize = null;
      }
    }
    return dataFile;
  }

  async getIdentificationOutputsByDataFileId(dataFileId: number): Promise<IdentificationOutputs[]> {
    try {
      return await this.identificationOutputsRepository.createQueryBuilder('io')
        .where('io.dataFileId = :dataFileId', { dataFileId })
        .getMany();
    } catch (error) {
      logger.error('Error retrieving identification ouputs for data file: ', dataFileId);
    }
  }

}
