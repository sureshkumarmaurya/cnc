import { Controller, Post, Body, Param, UseGuards, ValidationPipe } from '@nestjs/common';
import { IdentificationOutputService } from './identification-output.service';
import { ApiUseTags, ApiBearerAuth, ApiOperation, ApiResponse } from '@nestjs/swagger';
import { IdentificationOutputsDto } from 'modules/database/dto/identification-outputs.dto';
import { PermissionsGuard } from 'guards/permissions.guard';
import { User } from 'decorators/user.decorator';
import { AuthenticatedUserDto } from 'dto/authenticated-user.dto';
import { CreateIdentificationOutputBulkDto } from './dto/create-identification-output-bulk.dto';

const logger = require('logger');

@Controller('/api/v1/identification-output')
@ApiUseTags('IdentificationOutputs')
@ApiBearerAuth()
@UseGuards(PermissionsGuard)
export class IdentificationOutputGeneralController {
  constructor(private readonly identificationOutputsService: IdentificationOutputService) { }

  @Post('/bulk')
  @ApiOperation({
    title: 'Create shared identification output (bulk)', description: `
    Create new shared (i.e. not data file-specific) identification outputs (bulk)
  `, operationId: 'BulkCreateSharedIdentificationOutput',
  })
  @ApiResponse({ status: 200, description: 'IdentificationOutput has been successfully created', isArray: false, type: IdentificationOutputsDto })
  @ApiResponse({ status: 400, description: 'Body contains errors' })
  @ApiResponse({ status: 401, description: 'Not authenticated.' })
  async createBulk(@Body(new ValidationPipe()) createIdentificationOutputBulkDto: CreateIdentificationOutputBulkDto, @User() authenticatedUser: AuthenticatedUserDto, @Param() params) {
    logger.info('Creating identification output (bulk)');
    return await this.identificationOutputsService.createBulk(createIdentificationOutputBulkDto, { authenticatedUser, params });
  }

}
