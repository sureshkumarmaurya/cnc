import { Get, Controller, Req, Post, Body, Patch, Param, Delete, ParseIntPipe, UseGuards, ValidationPipe } from '@nestjs/common';
import { IdentificationOutputService } from './identification-output.service';
import { ApiUseTags, ApiBearerAuth, ApiOperation, ApiResponse, ApiImplicitQuery, ApiImplicitParam } from '@nestjs/swagger';
import { IdentificationOutputsPaginatedDto } from './dto/identification-outputs.dto';
import { Pagination } from 'decorators/pagination.decorator';
import { IdentificationOutputsDto } from 'modules/database/dto/identification-outputs.dto';
import { PermissionsGuard } from 'guards/permissions.guard';
import { User } from 'decorators/user.decorator';
import { AuthenticatedUserDto } from 'dto/authenticated-user.dto';
import { Permissions } from 'decorators/permissions.decorator';
import { PERMISSIONS } from 'utils/permissions.enum';
import { CreateIdentificationOutputDto } from './dto/create-identification-output.dto';
import { UpdateIdentificationOutputDto } from './dto/update-identification-output.dto';
import { CreateIdentificationOutputBulkDto } from './dto/create-identification-output-bulk.dto';
import { PaginationModel } from 'utils/pagination.model';
import { DataFileService } from '../data-files/data-file.service';

const logger = require('logger');

export const identificationOutputsRelations = ['dataFile', 'identificationMethod', 'identifiedObjects', 'participant'];

@Controller('/api/v1/project/:projectId/deployment/:deploymentId/data-file/:dataFileId/identification-output')
@ApiUseTags('IdentificationOutputs')
@ApiBearerAuth()
@UseGuards(PermissionsGuard)
export class IdentificationOutputController {
  constructor(
    private readonly identificationOutputsService: IdentificationOutputService,
    private readonly dataFileService: DataFileService,
  ) {}

  @Get()
  @ApiOperation({
    title: 'Get Identification Outputs', description: `
    Get all identification outputs
  `, operationId: 'GetAllIdentificationOutputs',
  })
  @ApiResponse({ status: 200, description: 'Identification Outputs have been successfully returned', isArray: false, type: IdentificationOutputsPaginatedDto })
  @ApiResponse({ status: 403, description: 'Not authorized.' })
  @ApiResponse({ status: 401, description: 'Not authenticated.' })
  @ApiImplicitParam({ name: 'projectId', description: 'Project the deployment belongs to', type: Number, required: true })
  @ApiImplicitParam({ name: 'deploymentId', description: 'Id of the deployment', required: true, type: Number })
  @ApiImplicitParam({ name: 'dataFileId', description: 'Id of the data file', required: true, type: Number })
  @ApiImplicitQuery({
    name: 'includes', description: `
  Allows include the IdentificationOutputs's relations. Available ${identificationOutputsRelations}
  `, type: String, required: false,
  })
  @ApiImplicitQuery({ name: 'fields', description: 'IdentificationOutputs\'s fields to select', type: String, required: false })
  @ApiImplicitQuery({ name: 'page[size]', description: 'Page size. Default 10', type: String, required: false })
  @ApiImplicitQuery({ name: 'page[number]', description: 'Page number', type: String, required: false })
  @ApiImplicitQuery({ name: 'sort', description: 'Sort results', type: String, required: false })
  @Permissions(PERMISSIONS.IDENTIFICATION_GET_ALL)
  async findAll(@Pagination() pagination: PaginationModel, @Param() params, @User() authenticatedUser: AuthenticatedUserDto) {
    logger.info('Getting all identification outputs');
    const data = await this.identificationOutputsService.findAll(pagination, { authenticatedUser, params });
    return new IdentificationOutputsPaginatedDto(data[0], data[1], pagination.pageSize, pagination.pageNumber);
  }

  @Get('/:id')
  @ApiOperation({
    title: 'Get identification output by id', description: `
    Get identification output by id
  `, operationId: 'GetIdentificationOutputById',
  })
  @ApiImplicitQuery({
    name: 'includes', description: `
  Allows include the Identification Outputs's relations. Available ${identificationOutputsRelations}
  `, type: String, required: false,
  })
  @ApiImplicitParam({ name: 'projectId', description: 'Project the deployment belongs to', type: Number, required: true })
  @ApiImplicitParam({ name: 'deploymentId', description: 'Id of the deployment', required: true, type: Number })
  @ApiImplicitParam({ name: 'dataFileId', description: 'Id of the data file', required: true, type: Number })
  @ApiImplicitParam({ name: 'id', description: 'Id of the identification output', required: true, type: Number })
  @ApiResponse({ status: 200, description: 'IdentificationOutput has been successfully returned', isArray: false, type: IdentificationOutputsDto })
  @ApiResponse({ status: 404, description: 'IdentificationOutput does not exist or you don\'t have permission' })
  @ApiResponse({ status: 401, description: 'Not authenticated.' })
  @Permissions(PERMISSIONS.IDENTIFICATION_GET_ONE)
  async getById(@Param('id', new ParseIntPipe()) id: number, @User() authenticatedUser: AuthenticatedUserDto, @Param() params, @Pagination() pagination: PaginationModel) {
    logger.info('Get by id ', id);
    return await this.identificationOutputsService.getById(id, pagination, { authenticatedUser, params });
  }

  @Post('/')
  @ApiOperation({
    title: 'Create identification output', description: `
    Create new identification output
  `, operationId: 'CreateIdentificationOutput',
  })
  @ApiImplicitParam({ name: 'projectId', description: 'Project the deployment belongs to', type: Number, required: true })
  @ApiImplicitParam({ name: 'deploymentId', description: 'Deployment the data file belongs to', type: Number, required: true })
  @ApiImplicitParam({ name: 'dataFileId', description: 'Datafile this identification output belongs to', type: Number, required: true })
  @ApiResponse({ status: 200, description: 'IdentificationOutput has been successfully created', isArray: false, type: IdentificationOutputsDto })
  @ApiResponse({ status: 400, description: 'Body contains errors' })
  @ApiResponse({ status: 401, description: 'Not authenticated.' })
  @Permissions(PERMISSIONS.IDENTIFICATION_CREATE)
  async create(@Body(new ValidationPipe()) createIdentificationOutputDto: CreateIdentificationOutputDto, @User() authenticatedUser: AuthenticatedUserDto, @Param() params) {
    logger.info('Creating identification output');
    return await this.identificationOutputsService.create(createIdentificationOutputDto, { authenticatedUser, params });
  }

  @Post('/bulk')
  @ApiOperation({
    title: 'Create identification outputs (bulk)', description: `
    Create identification outputs (bulk)
  `, operationId: 'BulkCreateIdentificationOutputs',
  })
  @ApiImplicitParam({ name: 'projectId', description: 'Project the deployment belongs to', type: Number, required: true })
  @ApiImplicitParam({ name: 'deploymentId', description: 'Deployment the data file belongs to', type: Number, required: true })
  @ApiImplicitParam({ name: 'dataFileId', description: 'Datafile this identification output belongs to', type: Number, required: true })
  @ApiResponse({ status: 200, description: 'IdentificationOutput has been successfully created', isArray: false, type: IdentificationOutputsDto })
  @ApiResponse({ status: 400, description: 'Body contains errors' })
  @ApiResponse({ status: 401, description: 'Not authenticated.' })
  @Permissions(PERMISSIONS.IDENTIFICATION_CREATE)
  async createBulk(@Body(new ValidationPipe()) createIdentificationOutputBulkDto: CreateIdentificationOutputBulkDto, @User() authenticatedUser: AuthenticatedUserDto, @Param() params) {
    logger.info('Bulk-creating identification outputs');
    return await this.identificationOutputsService.createBulk(createIdentificationOutputBulkDto, { authenticatedUser, params });
  }

  /**
   * Patches existing identification-output entities (performs partial update)
   * @param id
   * @param updateIdentificationOutputDto
   * @param authenticatedUser
   * @param params
   */
  @Patch('/:id')
  @ApiOperation({ title: 'Update dataFile', description: 'Update dataFile', operationId: 'UpdateIdentificationOutput' })
  @ApiImplicitParam({ name: 'id', description: 'Id of the dataFile' })
  @ApiImplicitParam({ name: 'projectId', description: 'Project the deployment belongs to', type: Number, required: true })
  @ApiImplicitParam({ name: 'deploymentId', description: 'Deployment the data file belongs to', type: Number, required: true })
  @ApiImplicitParam({ name: 'dataFileId', description: 'Datafile this identification output belongs to', type: Number, required: true })
  @ApiResponse({ status: 200, description: 'IdentificationOutput has been successfully updated', isArray: false, type: IdentificationOutputsDto })
  @ApiResponse({ status: 404, description: 'IdentificationOutput does not exist or you don\'t have permission' })
  @ApiResponse({ status: 401, description: 'Not authenticated.' })
  @Permissions(PERMISSIONS.IDENTIFICATION_UPDATE)
  async update(@Param('id', new ParseIntPipe()) id: number, @Body(new ValidationPipe()) updateIdentificationOutputDto: UpdateIdentificationOutputDto, @User() authenticatedUser: AuthenticatedUserDto, @Param() params) {
    logger.info('Updating identification output');
    return await this.identificationOutputsService.update(id, updateIdentificationOutputDto, { authenticatedUser, params });
  }

  /**
   * Deletes identification-output entities
   * @param id
   * @param authenticatedUser
   * @param params
   */
  @Delete('/:id')
  @ApiOperation({ title: 'Delete dataFile', description: 'Delete dataFile', operationId: 'DeleteIdentificationOutput' })
  @ApiImplicitParam({ name: 'id', description: 'Id of the dataFile' })
  @ApiImplicitParam({ name: 'projectId', description: 'Project the deployment belongs to', type: Number, required: true })
  @ApiImplicitParam({ name: 'deploymentId', description: 'Deployment the data file belongs to', type: Number, required: true })
  @ApiImplicitParam({ name: 'dataFileId', description: 'Datafile this identification output belongs to', type: Number, required: true })
  @ApiResponse({ status: 200, description: 'IdentificationOutput has been successfully deleted', isArray: false, type: IdentificationOutputsDto })
  @ApiResponse({ status: 404, description: 'IdentificationOutput does not exist or you don\'t have permission' })
  @ApiResponse({ status: 401, description: 'Not authenticated.' })
  @Permissions(PERMISSIONS.IDENTIFICATION_DELETE)
  async remove(@Param('id', new ParseIntPipe()) id: number, @User() authenticatedUser: AuthenticatedUserDto, @Param() params) {
    logger.info('Deleting identification output');
    const { dataFileId } = params;
    const removeidentificationOutputResult = await this.identificationOutputsService.remove(id, { authenticatedUser, params });
    const identificationOutputsAfterDelete = await this.identificationOutputsService.getIdentificationOutputsByDataFileId(dataFileId);
    await this.dataFileService.updateDataFileWithIdentifications(dataFileId, identificationOutputsAfterDelete);
    return removeidentificationOutputResult;
  }
}
