import { ApiModelProperty } from '@nestjs/swagger';
import { IdentificationOutputsDto } from 'modules/database/dto/identification-outputs.dto';
import { MetaDto } from 'modules/database/dto/meta.dto';

export class IdentificationOutputsPaginatedDto {

  @ApiModelProperty({ type: IdentificationOutputsDto, isArray: true })
  readonly data: IdentificationOutputsDto[];

  @ApiModelProperty()
  readonly meta: MetaDto;

  constructor(data, totalItems: number, pageSize: number, page: number) {
    this.data = data;
    this.meta = new MetaDto(Math.ceil(totalItems / pageSize), totalItems, pageSize, page);
  }
}
