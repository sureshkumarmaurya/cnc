import { IdentificationOutputService } from './identification-output.service';
import { Resolver, Query, Args, Parent, ResolveProperty } from '@nestjs/graphql';
import { IdentifiedObjects } from 'modules/database/entities/identified-objects.entity';
import { Taxonomies } from 'modules/database/entities/taxonomies.entity';

@Resolver('IdentifiedObject')
export class IdentifiedObjectResolver {
  constructor(private readonly identificationOutputService: IdentificationOutputService) {}

  @ResolveProperty()
  async taxonomy(@Parent() identifiedObject: IdentifiedObjects): Promise<Taxonomies> {
    return this.identificationOutputService.getTaxonomyById(identifiedObject.taxonomyId);
  }

}
