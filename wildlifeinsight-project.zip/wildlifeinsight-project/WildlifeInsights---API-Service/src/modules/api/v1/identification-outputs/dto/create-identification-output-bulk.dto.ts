import { ApiModelProperty } from '@nestjs/swagger';
import { IsInt, IsArray, ValidateNested } from 'class-validator';
import { CreateIdentificationOutputDto } from './create-identification-output.dto';

export class CreateIdentificationOutputBulkDto {

  @IsArray()
  @ApiModelProperty({ required: true })
  dataFileIds: number[];

  @ValidateNested()
  @ApiModelProperty({ required: true, type: CreateIdentificationOutputDto })
  identificationOutput: CreateIdentificationOutputDto;

}
