import { ApiModelProperty } from '@nestjs/swagger';
import { IsInt, IsBoolean, IsString, IsOptional, MaxLength, IsISO8601, IsArray, ValidateIf } from 'class-validator';

export class CreateIdentifiedObjectDto {

  @IsString()
  @IsOptional()
  @MaxLength(255)
  @ApiModelProperty({ required: false })
  commonName: string;

  @IsString()
  @IsOptional()
  @MaxLength(255)
  @ApiModelProperty({ required: false })
  relativeAge: string;

  @IsString()
  @IsOptional()
  @MaxLength(255)
  @ApiModelProperty({ required: false })
  sex: string;

  @IsString()
  @IsOptional()
  @ApiModelProperty({ required: false })
  markings: string;

  @IsBoolean()
  @IsOptional()
  @ApiModelProperty({ required: true })
  individualIdentified: boolean;

  @IsString()
  @IsOptional()
  @ApiModelProperty({ required: false })
  remarks: string;

  @IsString()
  @IsOptional()
  @ApiModelProperty({ required: false })
  behavior: string;

  @ValidateIf(o => !(o.date instanceof Date))
  @IsISO8601()
  @IsOptional()
  @ApiModelProperty({ required: false })
  date: Date;

  @IsInt()
  @IsOptional()
  @ApiModelProperty({ required: false })
  certainity: number;

  @IsString()
  @ApiModelProperty({ required: true })
  taxonomyId: string;

}

export class CreateIdentificationOutputDto {

  @IsBoolean()
  @ApiModelProperty({ required: true })
  blankYn: boolean;

  @IsInt()
  @ApiModelProperty({ required: true })
  identificationMethodId: number;

  @IsArray()
  @IsOptional()
  @ApiModelProperty({ required: false, isArray: true, type: CreateIdentifiedObjectDto })
  identifiedObjects: CreateIdentifiedObjectDto[];

}
