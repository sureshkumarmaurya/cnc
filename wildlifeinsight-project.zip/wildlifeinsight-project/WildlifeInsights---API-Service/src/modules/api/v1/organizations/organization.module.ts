import { OrganizationController, organizationsRelations } from './organization.controller';
import { OrganizationService } from './organization.service';
import { RoleChangesService } from '../role-changes/role-changes.service';
import { Module, RequestMethod, MiddlewareConsumer } from '@nestjs/common';
import { PaginationMiddleware } from 'middlewares/pagination.middleware';
import { OrganizationResolver } from './organization.resolver';
import { DatabaseModule } from 'modules/database/database.module';
import { RolesUtils } from 'utils/roles.utils';
@Module({
  imports: [DatabaseModule],
  controllers: [OrganizationController],
  providers: [OrganizationService, RoleChangesService, OrganizationResolver, RolesUtils],
})
export class OrganizationModule {
  public configure(consumer: MiddlewareConsumer) {
    consumer
      .apply(PaginationMiddleware)
      .with({ includes: [], allowIncludes: organizationsRelations })
      .forRoutes(
        { path: '/api/v1/organization', method: RequestMethod.GET },
        { path: '/api/v1/organization/:organizationId', method: RequestMethod.GET },
      );
  }
}
