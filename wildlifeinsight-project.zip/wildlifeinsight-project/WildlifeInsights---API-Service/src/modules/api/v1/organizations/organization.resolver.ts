import { CreateOrganizationDto } from './dto/create-organization.dto';
import { OrganizationService } from './organization.service';
import { RoleChangesService } from '../role-changes/role-changes.service';
import { Resolver, Query, ResolveProperty, Mutation, Args } from '@nestjs/graphql';
import { UpdateOrganizationDto } from './dto/update-organization.dto';
import { UseInterceptors, UseGuards, HttpException } from '@nestjs/common';
import { GraphqlAuthGuard } from 'guards/graphql-passport.guard';
import { GraphqlUserWithPermissions } from 'decorators/graphql-user.decorator';
import { ValidationGraphqlInterceptor } from 'interceptors/validation-graphql.interceptor';
import { PaginationGraphqlInterceptor } from 'interceptors/pagination-graphql.interceptor';
import { Permissions } from 'decorators/permissions.decorator';
import { PERMISSIONS } from 'utils/permissions.enum';
import { OrganizationsPaginatedDto } from './dto/organizations.dto';
import { RolesUtils } from 'utils/roles.utils';

@Resolver('Organization')
export class OrganizationResolver {
  constructor(
    private readonly organizationService: OrganizationService,
    private readonly roleChangesService: RoleChangesService,
    private readonly rolesUtils: RolesUtils,
  ) {}

  @Query()
  @UseGuards(GraphqlAuthGuard)
  @Permissions(PERMISSIONS.ORGANIZATION_GET_ALL)
  @UseInterceptors(PaginationGraphqlInterceptor)
  async getOrganizations(@GraphqlUserWithPermissions(PERMISSIONS.ORGANIZATION_GET_ALL) authenticatedUser, @Args() args) {
    const data = await this.organizationService.findAll(args.pagination, { authenticatedUser, params: args }, args.filters);
    return new OrganizationsPaginatedDto(data[0], data[1], args.pagination.pageSize, args.pagination.pageNumber);
  }

  @Query()
  @UseGuards(GraphqlAuthGuard)
  @Permissions(PERMISSIONS.ORGANIZATION_GET_ONE)
  async getOrganization(@GraphqlUserWithPermissions(PERMISSIONS.ORGANIZATION_GET_ONE) authenticatedUser, @Args() args) {
    const { organizationId } = args;
    return await this.organizationService.getById(organizationId, {}, { authenticatedUser, params: args });
  }

  @Query()
  @UseGuards(GraphqlAuthGuard)
  @Permissions(PERMISSIONS.ORGANIZATION_GET_ONE)
  async getOrganizationParticipants(@GraphqlUserWithPermissions(PERMISSIONS.ORGANIZATION_GET_ONE) authenticatedUser, @Args() args) {
    const { organizationId } = args;
    const participants = await this.organizationService.getParticipants(organizationId);
    return await this.rolesUtils.addAllowableRoleChangeOperationsToParticipantData('organization', parseInt(organizationId, 10), authenticatedUser, participants);
  }

  @Mutation()
  @UseGuards(GraphqlAuthGuard)
  @Permissions(PERMISSIONS.ORGANIZATION_CREATE)
  @UseInterceptors(new ValidationGraphqlInterceptor(CreateOrganizationDto))
  async createOrganization(@GraphqlUserWithPermissions(PERMISSIONS.ORGANIZATION_CREATE) authenticatedUser, @Args() args) {
    const { body } = args;
    return this.organizationService.create(body, { authenticatedUser, params: args });
  }

  @Mutation()
  @UseGuards(GraphqlAuthGuard)
  @Permissions(PERMISSIONS.ORGANIZATION_UPDATE)
  @UseInterceptors(new ValidationGraphqlInterceptor(UpdateOrganizationDto))
  async updateOrganization(@GraphqlUserWithPermissions(PERMISSIONS.ORGANIZATION_UPDATE) authenticatedUser, @Args() args) {
    const { organizationId, body } = args;
    return this.organizationService.update(organizationId, body, { authenticatedUser, params: args });
  }

  @Mutation()
  @UseGuards(GraphqlAuthGuard)
  @Permissions(PERMISSIONS.ORGANIZATION_DELETE)
  async deleteOrganization(@GraphqlUserWithPermissions(PERMISSIONS.ORGANIZATION_DELETE) authenticatedUser, @Args() args) {
    const { organizationId } = args;
    try {
      await this.organizationService.remove(organizationId, { authenticatedUser, params: args });
    } catch (err) {
      throw new HttpException({ error: `Error while deleting organization ${organizationId}: either the organization is linked to projects or initiatives, which should be deleted first, or a temporary error occurred.` }, 400);
    }

  }

  @Mutation()
  @UseGuards(GraphqlAuthGuard)
  async manageOrganizationParticipant(@GraphqlUserWithPermissions() authenticatedUser, @Args() args) {
    const { body } = args;
    const result = await this.rolesUtils.manageEntityParticipants(
      body,
      authenticatedUser,
      'organization',
      this.roleChangesService,
    );
    return result;
  }
}
