import { Permissions } from 'decorators/permissions.decorator';
import { UpdateOrganizationDto } from './dto/update-organization.dto';
import { CreateOrganizationDto } from './dto/create-organization.dto';
import { Get, Controller, Req, Post, Body, Patch, Param, Delete, ParseIntPipe, UseGuards, Query, HttpException } from '@nestjs/common';
import { OrganizationService } from './organization.service';
import { ApiUseTags, ApiBearerAuth, ApiOperation, ApiResponse, ApiImplicitQuery, ApiImplicitParam } from '@nestjs/swagger';
import { OrganizationsPaginatedDto } from './dto/organizations.dto';
import { Pagination } from 'decorators/pagination.decorator';
import { ValidationPipe } from 'pipes/validation.pipe';
import { OrganizationsDto } from 'modules/database/dto/organizations.dto';
import { PermissionsGuard } from 'guards/permissions.guard';
import { User } from 'decorators/user.decorator';
import { AuthenticatedUserDto } from 'dto/authenticated-user.dto';
import { PERMISSIONS } from 'utils/permissions.enum';
import { PaginationModel } from 'utils/pagination.model';

const logger = require('logger');

export const organizationsRelations = [];

@Controller('/api/v1/organization')
@ApiUseTags('Organizations')
@ApiBearerAuth()
@UseGuards(PermissionsGuard)
export class OrganizationController {
  constructor(private readonly organizationService: OrganizationService) { }

  @Get()
  @ApiOperation({
    title: 'Get Organizations', description: `
    Get all organizations:
  `, operationId: 'GetAllOrganizations',
  })
  @ApiResponse({ status: 200, description: 'Organizations have been successfully returned', isArray: false, type: OrganizationsPaginatedDto })
  @ApiResponse({ status: 403, description: 'Not authorized.' })
  @ApiResponse({ status: 401, description: 'Not authenticated.' })
  @ApiImplicitQuery({
    name: 'includes', description: `
  Allows include the Organizations's relations. Available ${organizationsRelations}
  `, type: String, required: false,
  })
  @ApiImplicitQuery({ name: 'fields', description: 'Organizations\'s fields to select', type: String, required: false })
  @ApiImplicitQuery({ name: 'page[size]', description: 'Page size. Default 10', type: String, required: false })
  @ApiImplicitQuery({ name: 'page[number]', description: 'Page number', type: String, required: false })
  @ApiImplicitQuery({ name: 'sort', description: 'Sort results', type: String, required: false })
  @ApiImplicitQuery({ name: 'name', description: 'Filter by name', type: String, required: false })
  @Permissions(PERMISSIONS.ORGANIZATION_GET_ALL)
  async findAll(@Pagination() pagination: PaginationModel, @Param() params, @User() authenticatedUser: AuthenticatedUserDto, @Query() filters) {
    logger.info('Getting all');
    const data = await this.organizationService.findAll(pagination, { authenticatedUser, params }, filters);
    return new OrganizationsPaginatedDto(data[0], data[1], pagination.pageSize, pagination.pageNumber);
  }

  @Get('/:organizationId')
  @ApiOperation({
    title: 'Get organization by id', description: `
    Get organization by id
  `, operationId: 'GetOrganizationById',
  })
  @ApiImplicitQuery({
    name: 'includes', description: `
  Allows include the Organizations's relations. Available ${organizationsRelations}
  `, type: String, required: false,
  })
  @ApiImplicitParam({ name: 'organizationId', description: 'Id of the organization', type: Number })
  @ApiResponse({ status: 200, description: 'Organization has been successfully returned', isArray: false, type: OrganizationsDto })
  @ApiResponse({ status: 404, description: 'Organization does not exist or you don\'t have permission' })
  @ApiResponse({ status: 401, description: 'Not authenticated.' })
  @Permissions(PERMISSIONS.ORGANIZATION_GET_ONE)
  async getById(@Param('organizationId', new ParseIntPipe()) id: number, @Pagination() pagination: PaginationModel, @Param() params, @User() authenticatedUser: AuthenticatedUserDto) {
    logger.info('Get by id ', id);
    return await this.organizationService.getById(id, pagination, { authenticatedUser, params });
  }

  @Post()
  @ApiOperation({
    title: 'Create organization', description: `
    Create new organization
  `, operationId: 'CreateOrganization',
  })
  @ApiResponse({ status: 200, description: 'Organization has been successfully created', isArray: false, type: OrganizationsDto })
  @ApiResponse({ status: 400, description: 'Body contains errors' })
  @ApiResponse({ status: 401, description: 'Not authenticated.' })
  @Permissions(PERMISSIONS.ORGANIZATION_CREATE)
  async create(@Body(new ValidationPipe()) createOrganizationDto: CreateOrganizationDto, @User() authenticatedUser: AuthenticatedUserDto, @Param() params) {
    logger.info('Creating organization');
    return await this.organizationService.create(createOrganizationDto, { authenticatedUser, params });
  }

  @Patch('/:organizationId')
  @ApiOperation({
    title: 'Update organization', description: `
    Update organization
  `, operationId: 'UpdateOrganization',
  })
  @ApiImplicitParam({ name: 'organizationId', description: 'Id of the organization', type: Number })
  @ApiResponse({ status: 200, description: 'Organization has been successfully updated', isArray: false, type: OrganizationsDto })
  @ApiResponse({ status: 404, description: 'Organization does not exist or you don\'t have permission' })
  @ApiResponse({ status: 401, description: 'Not authenticated.' })
  @Permissions(PERMISSIONS.ORGANIZATION_UPDATE)
  async update(@Param('organizationId', new ParseIntPipe()) id: number, @Body(new ValidationPipe()) updateOrganizationDto: UpdateOrganizationDto, @User() authenticatedUser: AuthenticatedUserDto, @Param() params) {
    logger.info('Updating company');
    // TODO: Add security
    return await this.organizationService.update(id, updateOrganizationDto, { authenticatedUser, params });
  }

  @Delete('/:organizationId')
  @ApiOperation({
    title: 'Delete organization', description: `
    Delete organization
  `, operationId: 'DeleteOrganization',
  })
  @ApiImplicitParam({ name: 'organizationId', description: 'Id of the organization', type: Number })
  @ApiResponse({ status: 200, description: 'Organization has been successfully deleted', isArray: false, type: OrganizationsDto })
  @ApiResponse({ status: 404, description: 'Organization does not exist or you don\'t have permission' })
  @ApiResponse({ status: 401, description: 'Not authenticated.' })
  @ApiResponse({ status: 400, description: 'Organization is linked to projects or initiatives, which should be deleted first, or a temporary error occurred.' })
  @Permissions(PERMISSIONS.ORGANIZATION_DELETE)
  async remove(@Param('organizationId', new ParseIntPipe()) id: number, @User() authenticatedUser: AuthenticatedUserDto, @Param() params) {
    logger.info('Deleting organization');
    try {
      return await this.organizationService.remove(id, { authenticatedUser, params });
    } catch (err) {
      throw new HttpException({ error: `Error while deleting organization ${id}: either the organization is linked to projects or initiatives, which should be deleted first, or a temporary error occurred.` }, 400);
    }
  }
}
