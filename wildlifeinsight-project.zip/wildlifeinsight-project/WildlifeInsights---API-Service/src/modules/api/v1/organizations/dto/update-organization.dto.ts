import { ApiModelProperty } from '@nestjs/swagger';
import { IsString, IsInt, IsEmail, IsIn, IsNumber, IsBoolean, IsArray, IsOptional, IsIP, MaxLength, IsUrl } from 'class-validator';

export class UpdateOrganizationDto {

  @IsString()
  @IsOptional()
  @MaxLength(255)
  @ApiModelProperty({ required: true })
  name: string;

  @IsString()
  @MaxLength(255)
  @IsOptional()
  @ApiModelProperty({ required: false })
  streetAddress: string | null;

  @IsString()
  @MaxLength(255)
  @IsOptional()
  @ApiModelProperty({ required: false })
  city: string | null;

  @IsString()
  @MaxLength(255)
  @IsOptional()
  @ApiModelProperty({ required: false })
  state: string | null;

  @IsString()
  @MaxLength(255)
  @IsOptional()
  @ApiModelProperty({ required: false })
  postalCode: string | null;

  @IsString()
  @MaxLength(255)
  @IsOptional()
  @ApiModelProperty({ required: false })
  phone: string | null;

  @IsString()
  @MaxLength(255)
  @IsOptional()
  @IsEmail()
  @ApiModelProperty({ required: false })
  email: string | null;

  @IsString()
  @MaxLength(255)
  @IsOptional()
  @ApiModelProperty({ required: false })
  countryCode: string | null;

  @IsString()
  @MaxLength(255)
  @IsOptional()
  @ApiModelProperty({ required: false })
  @IsUrl()
  organizationUrl: string | null;

  @IsString()
  @IsOptional()
  @ApiModelProperty({ required: false })
  remarks: string | null;
}
