import { ApiModelProperty } from '@nestjs/swagger';
import { OrganizationsDto } from '../../../../database/dto/organizations.dto';
import { MetaDto } from '../../../../database/dto/meta.dto';

export class OrganizationsPaginatedDto {

  @ApiModelProperty({ type: OrganizationsDto, isArray: true })
  readonly data: OrganizationsDto[];

  @ApiModelProperty()
  readonly meta: MetaDto;

  constructor(data, totalItems: number, pageSize: number, page: number) {
    this.data = data;
    this.meta = new MetaDto(Math.ceil(totalItems / pageSize), totalItems, pageSize, page);
  }
}
