import { UpdateOrganizationDto } from './dto/update-organization.dto';
import { CreateOrganizationDto } from './dto/create-organization.dto';
import { Organizations } from '../../../database/entities/organizations.entity';
import { Repository, SelectQueryBuilder } from 'typeorm';
import { Injectable, Inject, NotFoundException, BadRequestException, UnauthorizedException } from '@nestjs/common';
import { GenericService } from 'utils/generic.service';
import { InfoDto } from 'dto/info.dto';
import { OrganizationParticipantPivot } from '../../../database/entities/organization-participant-pivot.entity';
import { UsersACLCache } from 'modules/database/entities/users-acl-cache.entity';
import { Roles } from '../../../database/entities/roles.entity';
import { ROLES } from 'utils/roles.enum';

const logger = require('logger');

@Injectable()
export class OrganizationService extends GenericService<Organizations, CreateOrganizationDto, UpdateOrganizationDto>  {

  constructor(
    @Inject('OrganizationsRepositoryToken') private readonly organizationsRepository: Repository<Organizations>,
    @Inject('RolesRepositoryToken') private readonly rolesRepository: Repository<Roles>,
    @Inject('OrganizationParticipantPivotRepositoryToken') private readonly organizationParticipantPivotRepository: Repository<OrganizationParticipantPivot>,
    @Inject('UsersACLCacheRepositoryToken') private readonly usersACLCacheRepository: Repository<UsersACLCache>,
  ) {
    super(organizationsRepository, 'organization');
  }

  setFilters(query: SelectQueryBuilder<Organizations>, filters: any, info: InfoDto) {
    query.innerJoin('organization.organizationParticipantPivot', 'opp')
    .andWhere('opp.participantId = :userId').setParameter('userId', info.authenticatedUser.user.id);
    if (filters && filters.name) {
      query.andWhere('lower(organization.name) like :name').setParameter('name', `%${filters.name.toLowerCase()}%`);
    }
    return query;
  }

  setFiltersGetById(query: SelectQueryBuilder<Organizations>, info: InfoDto): SelectQueryBuilder<Organizations> {
    query.innerJoin('organization.organizationParticipantPivot', 'opp')
    .andWhere('opp.participantId = :userId').setParameter('userId', info.authenticatedUser.user.id);
    return query;
  }

  setFiltersDelete(query: SelectQueryBuilder<Organizations>, info: InfoDto): SelectQueryBuilder<Organizations> {
    query.innerJoin('organization.organizationParticipantPivot', 'opp')
    .andWhere('opp.participantId = :userId').setParameter('userId', info.authenticatedUser.user.id);
    return query;
  }

  async setDataCreate(create: CreateOrganizationDto, info: InfoDto) {

    const model = new Organizations();
    // model.owner = info.authenticatedUser.user;
    model.city = create.city;
    model.countryCode = create.countryCode;
    model.email = create.email;
    model.name = create.name;
    model.streetAddress = create.streetAddress;
    model.state = create.state;
    model.postalCode = create.postalCode;
    model.phone = create.phone;
    model.organizationUrl = create.organizationUrl;
    model.remarks = create.remarks;

    const organizationParticipant = new OrganizationParticipantPivot();
    organizationParticipant.participantId = info.authenticatedUser.user.id;
    organizationParticipant.role = await this.rolesRepository.findOne({ where: { slug: ROLES.ORGANIZATION_OWNER } });
    model.organizationParticipantPivot = [organizationParticipant];

    return model;
  }

  async validateBeforeCreate(create: CreateOrganizationDto, info: any) {
    const count = await this.organizationsRepository.createQueryBuilder('organization')
    .where('lower(organization.name) = :name').setParameters({ name: create.name.toLowerCase() }).getCount();
    if (count > 0) {
      throw new BadRequestException(`TypeName: ${create.name} is not unique`);
    }
  }

  async validateBeforeUpdate(id: number, create: UpdateOrganizationDto, info: any) {
    if (create.name) {
      const count = await this.organizationsRepository.createQueryBuilder('organization')
      .where('lower(organization.name) = :name').andWhere('organization.id <> :id').setParameters({ id, name: create.name.toLowerCase() }).getCount();
      if (count > 0) {
        throw new BadRequestException(`TypeName: ${create.name} is not unique`);
      }
    }
  }

  async setDataUpdate(model: Organizations, update: UpdateOrganizationDto, info: any) {

    if (update.city !== undefined) {
      model.city = update.city;
    }
    if (update.countryCode !== undefined) {
      model.countryCode = update.countryCode;
    }
    if (update.email !== undefined) {
      model.email = update.email;
    }
    if (update.name !== undefined) {
      model.name = update.name;
    }
    if (update.streetAddress !== undefined) {
      model.streetAddress = update.streetAddress;
    }
    if (update.state !== undefined) {
      model.state = update.state;
    }
    if (update.postalCode !== undefined) {
      model.postalCode = update.postalCode;
    }
    if (update.phone !== undefined) {
      model.phone = update.phone;
    }
    if (update.organizationUrl !== undefined) {
      model.organizationUrl = update.organizationUrl;
    }
    if (update.remarks !== undefined) {
      model.remarks = update.remarks;
    }

    return model;
  }

  async getParticipants(organizationId: number) {
    try {
      return await this.organizationParticipantPivotRepository.createQueryBuilder('o')
        .where('o.organizationId = :organizationId')
        .innerJoinAndSelect('o.participant', 'participant')
        .innerJoinAndSelect('o.role', 'role')
        .innerJoinAndSelect('role.permissions', 'permissions')
        .setParameter('organizationId', organizationId).getMany();
    } catch (err) {
      throw new BadRequestException(`Get organization participants error. organizationId: ${organizationId}, ${err}`);
    }
  }

  /**
   * actionAfterCreate
   * @description After create hook for Organization service. Truncate user's ACL cache.
  */
  async actionAfterCreate() {
    await this.usersACLCacheRepository.clear();
  }

}
