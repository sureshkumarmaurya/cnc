import { InitiativeService } from './initiative.service';
import { Module } from '@nestjs/common';
import { InitiativePublicResolver } from './initiative-public.resolver';
import { DatabaseModule } from 'modules/database/database.module';

@Module({
  imports: [DatabaseModule],
  controllers: [],
  providers: [InitiativeService, InitiativePublicResolver],
})
export class InitiativePublicModule {

}
