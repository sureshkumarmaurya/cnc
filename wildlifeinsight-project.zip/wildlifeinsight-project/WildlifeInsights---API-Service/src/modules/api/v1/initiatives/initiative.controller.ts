import { Permissions } from 'decorators/permissions.decorator';
import { UpdateInitiativeDto } from './dto/update-initiative.dto';
import { CreateInitiativeDto } from './dto/create-initiative.dto';
import { Get, Controller, Req, Post, Body, Patch, Param, Delete, ParseIntPipe } from '@nestjs/common';
import { InitiativeService } from './initiative.service';
import { ApiUseTags, ApiBearerAuth, ApiOperation, ApiResponse, ApiImplicitQuery, ApiImplicitParam } from '@nestjs/swagger';
import { InitiativesPaginatedDto } from './dto/initiative.dto';
import { Pagination } from 'decorators/pagination.decorator';
import { ValidationPipe } from 'pipes/validation.pipe';
import { InitiativesDto } from 'modules/database/dto/initiatives.dto';
import { User } from 'decorators/user.decorator';
import { AuthenticatedUserDto } from 'dto/authenticated-user.dto';
import { PERMISSIONS } from 'utils/permissions.enum';
import { PaginationModel } from 'utils/pagination.model';

const logger = require('logger');

export const initiativesRelations = ['ownerOrganization', 'photos'];
// Not using @Controller('/api/v1/initiative') here as we need to use a
// different prefix for create() - this needs to include the parent organization
// id in order for permissions to be checked correctly.
// We do define controllerPrefix as const, though, so that we can easily reuse
// this for all the other endpoints within this controller
const controllerPrefix = '/api/v1/initiative';
@Controller()
@ApiUseTags('Initiatives')
@ApiBearerAuth()
export class InitiativeController {
  constructor(private readonly initiativeService: InitiativeService) { }

  @Get(controllerPrefix)
  @ApiOperation({
    title: 'Get Initiatives', description: `
    Get all initiatives:
  `, operationId: 'GetAllInitiatives',
  })
  @ApiResponse({ status: 200, description: 'Initiatives have been successfully returned', isArray: false, type: InitiativesPaginatedDto })
  @ApiResponse({ status: 403, description: 'Not authorized.' })
  @ApiResponse({ status: 401, description: 'Not authenticated.' })
  @ApiImplicitQuery({
    name: 'includes', description: `
  Allows to request the Initiatives's relations (${initiativesRelations})
  `, type: String, required: false,
  })
  @ApiImplicitQuery({ name: 'fields', description: 'Initiatives\'s fields to select', type: String, required: false })
  @ApiImplicitQuery({ name: 'page[size]', description: 'Page size. Default 10', type: String, required: false })
  @ApiImplicitQuery({ name: 'page[number]', description: 'Page number', type: String, required: false })
  @ApiImplicitQuery({ name: 'sort', description: 'Sort results', type: String, required: false })
  async findAll(@Pagination() pagination: PaginationModel, @Param() params, @User() authenticatedUser: AuthenticatedUserDto) {
    logger.info('Getting all');
    const data = await this.initiativeService.findAll(pagination, { authenticatedUser, params });
    return new InitiativesPaginatedDto(data[0], data[1], pagination.pageSize, pagination.pageNumber);
  }

  @Get(`${controllerPrefix}/:initiativeId`)
  @ApiOperation({
    title: 'Get initiative by id', description: `
    Get initiative by id
  `, operationId: 'GetInitiativeById',
  })
  @ApiImplicitQuery({
    name: 'includes', description: `
  Allows to request the Initiatives' relations (${initiativesRelations})
  `, type: String, required: false,
  })
  @ApiImplicitParam({ name: 'initiativeId', description: 'Id of the initiative' })
  @ApiResponse({ status: 200, description: 'Initiative has been successfully returned', isArray: false, type: InitiativesDto })
  @ApiResponse({ status: 404, description: 'Initiative does not exist or you don\'t have permission' })
  @ApiResponse({ status: 401, description: 'Not authenticated.' })
  async getById(@Param('initiativeId', new ParseIntPipe()) id: number, @Pagination() pagination: PaginationModel,  @User() authenticatedUser: AuthenticatedUserDto, @Param() params) {
    logger.info('Get initiative by id ', id);
    return await this.initiativeService.getById(id, pagination, { authenticatedUser, params });
  }

  @Post('/api/v1/organization/:organizationId/initiative')
  @ApiOperation({
    title: 'Create initiative', description: `
    Create new initiative
  `, operationId: 'CreateInitiative',
  })
  @ApiImplicitParam({ name: 'organizationId', description: 'Organization the initiative belongs to' })
  @ApiResponse({ status: 200, description: 'Initiative has been successfully created', isArray: false, type: InitiativesDto })
  @ApiResponse({ status: 400, description: 'Body contains errors' })
  @ApiResponse({ status: 401, description: 'Not authenticated.' })
  @Permissions(PERMISSIONS.INITIATIVE_CREATE)
  async create(@Body(new ValidationPipe()) createInitiativeDto: CreateInitiativeDto, @User() authenticatedUser: AuthenticatedUserDto, @Param() params) {
    logger.info('Creating initiative');
    return await this.initiativeService.create(createInitiativeDto, { authenticatedUser, params });
  }

  @Patch(`${controllerPrefix}/:initiativeId`)
  @ApiOperation({
    title: 'Update initiative', description: `
    Update initiative
  `, operationId: 'UpdateInitiative',
  })
  @ApiImplicitParam({ name: 'initiativeId', description: 'Id of the initiative' })
  @ApiResponse({ status: 200, description: 'Initiative has been successfully updated', isArray: false, type: InitiativesDto })
  @ApiResponse({ status: 404, description: 'Initiative does not exist or you don\'t have permission' })
  @ApiResponse({ status: 401, description: 'Not authenticated.' })
  @Permissions(PERMISSIONS.INITIATIVE_UPDATE)
  async update(@Param('initiativeId', new ParseIntPipe()) id: number, @Body(new ValidationPipe()) updateInitiativeDto: UpdateInitiativeDto, @User() authenticatedUser: AuthenticatedUserDto, @Param() params) {
    logger.info('Updating initiative');
    // TODO: Add security
    return await this.initiativeService.update(id, updateInitiativeDto, { authenticatedUser, params });
  }

  @Delete(`${controllerPrefix}/:initiativeId`)
  @ApiOperation({
    title: 'Delete initiative', description: `
    Delete initiative
  `, operationId: 'DeleteInitiative',
  })
  @ApiImplicitParam({ name: 'initiativeId', description: 'Id of the initiative' })
  @ApiResponse({ status: 200, description: 'Initiative has been successfully deleted', isArray: false, type: InitiativesDto })
  @ApiResponse({ status: 404, description: 'Initiative does not exist or you don\'t have permission' })
  @ApiResponse({ status: 401, description: 'Not authenticated.' })
  @Permissions(PERMISSIONS.INITIATIVE_DELETE)
  async remove(@Param('initiativeId', new ParseIntPipe()) id: number, @User() authenticatedUser: AuthenticatedUserDto, @Param() params) {
    logger.info('Deleting initiative');
    return await this.initiativeService.remove(id, { authenticatedUser, params });
  }
}
