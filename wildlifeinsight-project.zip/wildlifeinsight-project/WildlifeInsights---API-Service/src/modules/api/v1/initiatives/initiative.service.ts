import { Inject, BadRequestException, Injectable } from '@nestjs/common';
import { Repository, SelectQueryBuilder } from 'typeorm';
import { CreateInitiativeDto } from './dto/create-initiative.dto';
import { UpdateInitiativeDto } from './dto/update-initiative.dto';
import { GenericService } from 'utils/generic.service';
import { Initiatives } from 'modules/database/entities/initiatives.entity';
import { Organizations } from 'modules/database/entities/organizations.entity';
import { InitiativeParticipantPivot } from 'modules/database/entities/initiative-participant-pivot.entity';
import { InfoDto } from 'dto/info.dto';
import { Roles } from 'modules/database/entities/roles.entity';
import { ROLES } from 'utils/roles.enum';
import { UsersACLCache } from 'modules/database/entities/users-acl-cache.entity';

const logger = require('logger');
@Injectable()
export class InitiativeService extends GenericService<Initiatives, CreateInitiativeDto, UpdateInitiativeDto>{

  readonly initiativesDTOFields: string[] = [
    'name',
    'purpose',
    'remarks',
    'isLocationPublic',
    'contactEmail',
    'contactContent',
    'videoUrl',
    'introduction',
    'content',
    'description',
  ];

  constructor(
    @Inject('InitiativesRepositoryToken') private readonly initiativesRepository: Repository<Initiatives>,
    @Inject('OrganizationsRepositoryToken') private readonly organizationsRepository: Repository<Organizations>,
    @Inject('InitiativeParticipantPivotRepositoryToken') private readonly initiativeParticipantPivotRepository: Repository<InitiativeParticipantPivot>,
    @Inject('RolesRepositoryToken') private readonly rolesRepository: Repository<Roles>,
    @Inject('UsersACLCacheRepositoryToken') private readonly usersACLCacheRepository: Repository<UsersACLCache>,
  ) {
    super(initiativesRepository, 'initiative');
  }

  setFilters(query: SelectQueryBuilder<Initiatives>, filters: any, info: InfoDto) {
    if (info.authenticatedUser.user) {
      query.innerJoin('initiative.initiativeParticipantPivot', 'ipp')
      .andWhere('ipp.participantId = :userId').setParameter('userId', info.authenticatedUser.user.id);
    }
    if (info.params.organizationId) {
      query.andWhere('initiative.ownerOrganizationId = :organizationId').setParameter('organizationId', info.params.organizationId);
    }

    if (filters && filters.name) {
      query.andWhere('lower(initiative.name) like :name').setParameter('name', `%${filters.name.toLowerCase()}%`);
    }
    return query;
  }

  async getOrganizationById(id: number): Promise<Organizations> {
    return await this.organizationsRepository.findOne(id);
  }

  async initiativeByNameExcludeId(id: number, name: string): Promise<Initiatives> {
    return await this.initiativesRepository
      .createQueryBuilder()
      .where('name = :name', { name })
      .andWhere('id != :id', { id })
      .getOne();
  }

  async initiativesByOrganization(organizationId: number) {
    return await this.initiativesRepository
      .createQueryBuilder()
      .where('owner_organizations_id = :organizationId', { organizationId })
      .getMany();
  }

  async setDataCreate(create: CreateInitiativeDto, info: InfoDto) {
    const organization = await this.getOrganizationById(info.params.organizationId);
    const model = new Initiatives();

    // set model fields from create fields
    this.initiativesDTOFields.forEach((fieldName) => { model[fieldName] = create[fieldName]; });

    // set relationships
    model.ownerOrganization = organization;

    // make initiative creator the first user with INITIATIVE_OWNER role on the
    // initiative itself
    const initiativeOwner = new InitiativeParticipantPivot();
    initiativeOwner.participantId = info.authenticatedUser.user.id;
    initiativeOwner.role = await this.rolesRepository.findOne({ where: { slug: ROLES.INITIATIVE_OWNER } });
    model.initiativeParticipantPivot = [initiativeOwner];

    return model;
  }

  async findAllByOrganization(organizationId: number): Promise<[Initiatives[], number]> {
    const data: Initiatives[] = await this.initiativesByOrganization(organizationId);
    return [data, data.length];
  }

  async validateBeforeCreate(create: CreateInitiativeDto, info: InfoDto) {
    const count = await this.initiativesRepository.count({ where: { name: create.name } });
    if (count > 0) {
      throw new BadRequestException(`Name: ${create.name} is not unique`);
    }

    const organization = await this.getOrganizationById(info.params.organizationId);
    if (!organization) {
      throw new BadRequestException(`Organization with id ${info.params.organizationId} does not exist`);
    }
  }

  async validateBeforeUpdate(id: number, create: UpdateInitiativeDto) {
    const hasInitiativeWithTitle = await this.initiativeByNameExcludeId(id, create.name);
    if (hasInitiativeWithTitle) {
      throw new BadRequestException(`Initiative with name: ${create.name} already exists`);
    }
  }

  async setDataUpdate(model: Initiatives, update: UpdateInitiativeDto) {
    return { ...model, ...update };
  }

  async getParticipants(initiativeId: number) {
    try {
      return await this.initiativeParticipantPivotRepository.createQueryBuilder('i')
        .where('i.initiativeId = :initiativeId')
        .innerJoinAndSelect('i.participant', 'participant')
        .innerJoinAndSelect('i.role', 'role')
        .innerJoinAndSelect('role.permissions', 'permissions')
        .setParameter('initiativeId', initiativeId).getMany();
    } catch (err) {
      throw new BadRequestException(`Get initiative participants error. initiativeId: ${initiativeId}, ${err}`);
    }
  }

  /**
   * actionAfterCreate
   * @description After create hook for Initiative service. Truncate user's ACL cache.
  */
  async actionAfterCreate() {
    await this.usersACLCacheRepository.clear();
  }

}
