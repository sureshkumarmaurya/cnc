import { InitiativeFileService } from './initiativeFile.service';
import { Resolver, Mutation, Args } from '@nestjs/graphql';
import { UseGuards } from '@nestjs/common';
import { GraphqlAuthGuard } from 'guards/graphql-passport.guard';
import { GraphqlUserWithPermissions } from 'decorators/graphql-user.decorator';
import { PERMISSIONS } from 'utils/permissions.enum';

@Resolver('InitiativeFile')
export class InitiativeFileResolver {
  constructor(private readonly initiativeFileService: InitiativeFileService) { }

  @Mutation()
  @UseGuards(GraphqlAuthGuard)
  async updateInitiativeLogo(@GraphqlUserWithPermissions(PERMISSIONS.INITIATIVE_UPDATE) authenticatedUser, @Args() args) {
    const { id, body } = args;
    return this.initiativeFileService.setPartnerLogoFileText(id, body);
  }

  @Mutation()
  @UseGuards(GraphqlAuthGuard)
  async deleteInitiativePartnersLogoList(@GraphqlUserWithPermissions(PERMISSIONS.INITIATIVE_UPDATE) authenticatedUser, @Args() args) {
    const { id } = args;
    const idList = Array.isArray(id) ? id : [id];
    return this.initiativeFileService.deletePartnersLogoFileList(idList);
  }

  @Mutation()
  @UseGuards(GraphqlAuthGuard)
  async deleteInitiativePhotoList(@GraphqlUserWithPermissions(PERMISSIONS.INITIATIVE_UPDATE) authenticatedUser, @Args() args) {
    const { id } = args;
    const idList = Array.isArray(id) ? id : [id];
    return this.initiativeFileService.deletePhotoFileList(idList);
  }
}
