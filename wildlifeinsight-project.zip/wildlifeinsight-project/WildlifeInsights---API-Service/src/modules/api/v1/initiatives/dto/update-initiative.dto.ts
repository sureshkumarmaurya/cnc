import { IsString, IsBoolean, IsOptional, MaxLength, IsJSON } from 'class-validator';
import { IFileUploadObject } from '../../../../../interfaces/fileUpload.interface';

export class UpdateInitiativeDto {

  @IsString()
  @MaxLength(255)
  @IsOptional()
  name: string;

  @IsString()
  @MaxLength(255)
  @IsOptional()
  purpose: string;

  @IsString()
  @IsOptional()
  remarks: string;

  @IsBoolean()
  @IsOptional()
  isLocationPublic: boolean;

  @IsString()
  @IsOptional()
  @MaxLength(255)
  contactEmail: string;

  @IsString()
  @IsOptional()
  @MaxLength(255)
  contactContent: string;

  @IsJSON()
  @IsOptional()
  logo: IFileUploadObject;

  @IsString()
  @IsOptional()
  @MaxLength(255)
  videoUrl: string;

  @IsJSON()
  @IsOptional()
  coverImage: IFileUploadObject;

  @IsString()
  @IsOptional()
  @MaxLength(511)
  introduction: string;

  @IsString()
  @IsOptional()
  @MaxLength(1024)
  content: string;

  @IsString()
  @IsOptional()
  @MaxLength(255)
  description: string;

}
