import { Injectable } from '@nestjs/common';
import { FileUploadService, IFileUploadService } from '../../../../services/FileStorage.service';
import { InitiativeService } from './initiative.service';

@Injectable()
export class InitiativeUploadService {

  private _uploadProvider: IFileUploadService;
  private static bucketName: string = 'initiatives-files-public';

  constructor(
    private readonly initiativeService: InitiativeService,

    fileUploadService: FileUploadService,
  ) {
    this._uploadProvider = fileUploadService;
  }

  public async uploadFile(filePath: string) {
    return this._uploadProvider.uploadFile(InitiativeUploadService.bucketName, filePath);
  }

  public async replaceFile(filePath: string, oldFileName: string) {
    await this._uploadProvider.removeFile(InitiativeUploadService.bucketName, oldFileName);
    return this._uploadProvider.uploadFile(InitiativeUploadService.bucketName, filePath);
  }

  public async deleteFile(filePath: string) {
    return this._uploadProvider.removeFile(InitiativeUploadService.bucketName, filePath);
  }

  public uploadPhotoList() {

  }
}
