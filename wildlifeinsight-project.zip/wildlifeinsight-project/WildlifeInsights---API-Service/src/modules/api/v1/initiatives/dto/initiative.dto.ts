import { ApiModelProperty } from '@nestjs/swagger';
import { InitiativesDto } from 'modules/database/dto/initiatives.dto';
import { MetaDto } from 'modules/database/dto/meta.dto';

export class InitiativesPaginatedDto {

  @ApiModelProperty({ type: InitiativesDto, isArray: true })
  readonly data: InitiativesDto[];

  @ApiModelProperty()
  readonly meta: MetaDto;

  constructor(data, totalItems: number, pageSize: number, page: number) {
    this.data = data;
    this.meta = new MetaDto(Math.ceil(totalItems / pageSize), totalItems, pageSize, page);
  }
}
