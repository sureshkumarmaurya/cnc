import { InitiativeController, initiativesRelations } from './initiative.controller';
import { InitiativeFileController } from './initiativeFile.controller';
import { InitiativeService } from './initiative.service';
import { Module, RequestMethod, MiddlewareConsumer } from '@nestjs/common';
import { PaginationMiddleware } from 'middlewares/pagination.middleware';
import { InitiativeResolver } from './initiative.resolver';
import { InitiativeFileResolver } from './initiativeFile.resolver';
import { DatabaseModule } from 'modules/database/database.module';
import { InitiativeUploadService } from './initiativeUpload.service';
import { InitiativeFileService } from './initiativeFile.service';
import { FileUploadService } from '../../../../services/FileStorage.service';
import { RoleChangesService } from '../role-changes/role-changes.service';
import { RolesUtils } from 'utils/roles.utils';

@Module({
  imports: [DatabaseModule],
  controllers: [InitiativeController, InitiativeFileController],
  providers: [
    InitiativeService,
    FileUploadService,
    InitiativeUploadService,
    InitiativeFileService,
    InitiativeResolver,
    InitiativeFileResolver,
    RoleChangesService,
    RolesUtils,
  ],
})
export class InitiativeModule {
  public configure(consumer: MiddlewareConsumer) {
    consumer
      .apply(PaginationMiddleware)
      .with({ includes: ['photos'], allowIncludes: initiativesRelations })
      .forRoutes({ path: '/api/v1/initiative*', method: RequestMethod.GET });
  }
}
