import { CreateInitiativeDto } from './dto/create-initiative.dto';
import { InitiativeService } from './initiative.service';
import { Resolver, Query, ResolveProperty, Mutation, Args, Parent } from '@nestjs/graphql';
import { UpdateInitiativeDto } from './dto/update-initiative.dto';
import { UseInterceptors, UseGuards } from '@nestjs/common';
import { GraphqlAuthGuard } from 'guards/graphql-passport.guard';
import { GraphqlUserWithPermissions } from 'decorators/graphql-user.decorator';
import { ValidationGraphqlInterceptor } from 'interceptors/validation-graphql.interceptor';
import { PaginationGraphqlInterceptor } from 'interceptors/pagination-graphql.interceptor';
import { Initiatives } from 'modules/database/entities/initiatives.entity';
import { InitiativesPaginatedDto } from './dto/initiative.dto';
import { RoleChangesService } from '../role-changes/role-changes.service';
import { RolesUtils } from 'utils/roles.utils';
import { PERMISSIONS } from 'utils/permissions.enum';

@Resolver('Initiative')
export class InitiativeResolver {
  constructor(
    private readonly initiativeService: InitiativeService,
    private readonly roleChangesService: RoleChangesService,
    private readonly rolesUtils: RolesUtils,
  ) {}

  @Query()
  @UseInterceptors(PaginationGraphqlInterceptor)
  async getInitiatives(@GraphqlUserWithPermissions() authenticatedUser, @Args() args) {
    let data: [Initiatives[], number];
    data = await this.initiativeService.findAll(args.pagination, { authenticatedUser, params: args }, args.filters);

    return new InitiativesPaginatedDto(data[0], data[1], args.pagination.pageSize, args.pagination.pageNumber);
  }

  @Query()
  @UseGuards(GraphqlAuthGuard)
  async getInitiative(@GraphqlUserWithPermissions(PERMISSIONS.INITIATIVE_GET_ONE) authenticatedUser, @Args() args) {
    const { initiativeId, pagination = {} } = args;
    pagination.includes = ['photos', 'partnerLogos'];
    return await this.initiativeService.getById(initiativeId, pagination, { authenticatedUser, params: args });
  }

  @ResolveProperty()
  async ownerOrganization(@Parent() initiative: Initiatives) {
    return this.initiativeService.getOrganizationById(initiative.ownerOrganizationId);
  }

  @Query()
  @UseGuards(GraphqlAuthGuard)
  async getInitiativeParticipants(@GraphqlUserWithPermissions(PERMISSIONS.INITIATIVE_GET_ONE) authenticatedUser, @Args() args) {
    const { initiativeId } = args;
    const participants = await this.initiativeService.getParticipants(initiativeId);
    return await this.rolesUtils.addAllowableRoleChangeOperationsToParticipantData('initiative', parseInt(initiativeId, 10), authenticatedUser, participants);
  }

  @Mutation()
  @UseGuards(GraphqlAuthGuard)
  @UseInterceptors(new ValidationGraphqlInterceptor(CreateInitiativeDto))
  async createInitiative(@GraphqlUserWithPermissions(PERMISSIONS.INITIATIVE_CREATE) authenticatedUser, @Args() args) {
    const { body } = args;
    return this.initiativeService.create(body, { authenticatedUser, params: args });
  }

  @Mutation()
  @UseGuards(GraphqlAuthGuard)
  @UseInterceptors(new ValidationGraphqlInterceptor(UpdateInitiativeDto))
  async updateInitiative(@GraphqlUserWithPermissions(PERMISSIONS.INITIATIVE_UPDATE) authenticatedUser, @Args() args) {
    const { initiativeId, body } = args;
    return this.initiativeService.update(initiativeId, body, { authenticatedUser, params: args });
  }

  @Mutation()
  @UseGuards(GraphqlAuthGuard)
  async deleteInitiative(@GraphqlUserWithPermissions(PERMISSIONS.INITIATIVE_DELETE) authenticatedUser, @Args() args) {
    const { initiativeId } = args;
    return this.initiativeService.remove(initiativeId, { authenticatedUser, params: args });
  }

  @Mutation()
  @UseGuards(GraphqlAuthGuard)
  async manageInitiativeParticipant(@GraphqlUserWithPermissions() authenticatedUser, @Args() args) {
    const { body } = args;
    const result = await this.rolesUtils.manageEntityParticipants(
      body,
      authenticatedUser,
      'initiative',
      this.roleChangesService,
    );
    return result;
  }
}
