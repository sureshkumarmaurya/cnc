import { Injectable, Inject } from '@nestjs/common';
import { Repository } from 'typeorm';
import { InitiativeUploadService } from './initiativeUpload.service';
import { Photos } from '../../../database/entities/photos.entity';
import { Logos } from '../../../database/entities/logos.entity';
import { UpdateInitiativePartnerLogoDto } from './dto/update-initiative-partner-logo.dto';

interface IFileListList {
  path: string;
}

@Injectable()
export class InitiativeFileService {
  constructor(
    private readonly initiativeUploadService: InitiativeUploadService,
    @Inject('PhotosRepositoryToken') private readonly photosRepository: Repository<Photos>,
    @Inject('PartnersLogosRepositoryToken') private readonly partnersLogosRepository: Repository<Logos>,
  ) {

  }

  private uploadFileList(fileList: IFileListList[]) {
    const promiseUpload = [];
    fileList.forEach((singleItem) => {
      promiseUpload.push(this.initiativeUploadService.uploadFile(singleItem.path));
    });
    return Promise.all(promiseUpload);
  }

  public async createPhotoListForInitiative(initiativeId: number, photoList: IFileListList[]) {

    const uploadResult = await this.uploadFileList(photoList);
    const dbEntities = [];

    uploadResult.forEach((uploadedItem) => {
      const photo = new Photos();
      const { linkPublic, name, contentType } = uploadedItem;
      dbEntities.push(this.photosRepository.save({ ...photo, linkPublic, name, initiativeId, contentType }));
    });

    return Promise.all(dbEntities);
  }

  public async createPartnersLogoListForInitiative(initiativeId: number, logoList: IFileListList[]) {
    const uploadResult = await this.uploadFileList(logoList);
    const dbEntities = [];

    uploadResult.forEach((uploadedItem) => {
      const logo = new Logos();
      const { linkPublic, name } = uploadedItem;
      dbEntities.push(this.partnersLogosRepository.save({ ...logo, linkPublic, name, initiativeId }));
    });

    return Promise.all(dbEntities);
  }

  public async setPartnerLogoFileText(logoId: number, updateData: UpdateInitiativePartnerLogoDto) {
    const logoFound = await this.partnersLogosRepository.findOne(logoId);
    const updateObject = { ...logoFound, ...updateData };
    return this.partnersLogosRepository.save(updateObject);
  }

  public async deletePartnersLogoFileList(logoIdList: number[]) {
    const result = await this.partnersLogosRepository.delete(logoIdList);
    return result.affected;
  }

  public async deletePhotoFileList(photoIdList: number[]) {
    const result = await this.photosRepository.delete(photoIdList);
    return result.affected;
  }
}
