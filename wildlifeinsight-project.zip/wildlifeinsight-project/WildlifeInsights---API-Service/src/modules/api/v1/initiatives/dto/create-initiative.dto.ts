import { ApiModelProperty } from '@nestjs/swagger';
import { IsString, IsOptional, MaxLength, IsNumber, IsBoolean, IsJSON } from 'class-validator';
import { IFileUploadObject } from '../../../../../interfaces/fileUpload.interface';

export class CreateInitiativeDto {

  @IsString()
  @MaxLength(255)
  @ApiModelProperty({ required: true })
  name: string;

  @IsString()
  @MaxLength(255)
  @IsOptional()
  @ApiModelProperty({ required: false })
  purpose: string;

  @IsString()
  @IsOptional()
  @ApiModelProperty({ required: false })
  remarks: string;

  @IsBoolean()
  @IsOptional()
  @ApiModelProperty({ required: false })
  isLocationPublic: boolean;

  @IsString()
  @IsOptional()
  @MaxLength(255)
  @ApiModelProperty({ required: false })
  contactEmail: string;

  @IsString()
  @IsOptional()
  @MaxLength(255)
  @ApiModelProperty({ required: false })
  contactContent: string;

  @IsJSON()
  @IsOptional()
  @ApiModelProperty({ required: false })
  logo: IFileUploadObject;

  @IsString()
  @IsOptional()
  @MaxLength(255)
  @ApiModelProperty({ required: false })
  videoUrl: string;

  @IsJSON()
  @IsOptional()
  @ApiModelProperty({ required: false })
  coverImage: IFileUploadObject;

  @IsString()
  @IsOptional()
  @MaxLength(511)
  @ApiModelProperty({ required: false })
  introduction: string;

  @IsString()
  @IsOptional()
  @MaxLength(1024)
  @ApiModelProperty({ required: false })
  content: string;

  @IsString()
  @IsOptional()
  @MaxLength(255)
  @ApiModelProperty({ required: false })
  description: string;
}
