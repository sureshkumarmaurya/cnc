import { IsString, IsOptional, MaxLength } from 'class-validator';

export class UpdateInitiativePartnerLogoDto {
  @IsString()
  @MaxLength(255)
  @IsOptional()
  text: string;
}
