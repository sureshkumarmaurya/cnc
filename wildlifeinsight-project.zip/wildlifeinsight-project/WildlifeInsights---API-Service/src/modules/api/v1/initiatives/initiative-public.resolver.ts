
import { Resolver, Query, Args } from '@nestjs/graphql';
import { UseInterceptors } from '@nestjs/common';
import { InitiativeService } from './initiative.service';
import { PaginationGraphqlInterceptor } from 'interceptors/pagination-graphql.interceptor';

@Resolver('InitiativePublic')
export class InitiativePublicResolver {
  constructor(private readonly initiativeService: InitiativeService) { }
  @Query()
  @UseInterceptors(PaginationGraphqlInterceptor)
  async getInitiativePublic(@Args() args) {
    const { initiativeId, pagination = {} } = args;
    pagination.includes = ['photos', 'partnerLogos'];
    return await this.initiativeService.getById(
      initiativeId,
      pagination,
      { authenticatedUser: null, params: args });
  }
}
