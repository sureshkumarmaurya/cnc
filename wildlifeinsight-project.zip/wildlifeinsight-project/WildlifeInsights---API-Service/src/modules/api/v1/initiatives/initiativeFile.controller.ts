import { BadRequestException, Controller, Post, Put, Delete, Body, ValidationPipe, UploadedFiles, UploadedFile, UseInterceptors, FileFieldsInterceptor, FileInterceptor, Param, ParseIntPipe } from '@nestjs/common';
import { ApiUseTags, ApiBearerAuth, ApiOperation, ApiResponse, ApiImplicitParam } from '@nestjs/swagger';
import { uploadOptions } from '../../../../middlewares/fileUpload.middlware';
import { InitiativeUploadService } from './initiativeUpload.service';
import { InitiativeFileService } from './initiativeFile.service';
import { InitiativeService } from './initiative.service';
import { User } from 'decorators/user.decorator';
import { AuthenticatedUserDto } from 'dto/authenticated-user.dto';
import { UpdateInitiativePartnerLogoDto } from './dto/update-initiative-partner-logo.dto';

const logger = require('logger');

@Controller('/api/v1/initiative/upload')
@ApiUseTags('InitiativesUpload')
@ApiBearerAuth()
export class InitiativeFileController {
  constructor(
    private readonly initiativeUploadService: InitiativeUploadService,
    private readonly initiativeFileService: InitiativeFileService,
    private readonly initiativeService: InitiativeService,
  ) {

  }

  /**
   * Uploads (replaces the old one with a new file) Initiative Logo (file)
   * @param initiativeId
   * @param file
   * @param authenticatedUser
   */
  @Post('/:initiativeId/logo-image')
  @ApiOperation({ title: 'Upload Initiative Logo',
    description: `Upload Initiative Logo.
    Logo image should be supplied as a field with name \`logo\` in a \`multipart/form-data\` payload`,
    operationId: 'UploadInitiativeLogo',
  })
  @ApiImplicitParam({ name: 'initiativeId', description: 'Id of the initiative' })
  @ApiResponse({ status: 200, description: 'Initiative Logo has been successfully uploaded', isArray: false })
  @ApiResponse({ status: 400, description: 'Body contains errors' })
  @ApiResponse({ status: 401, description: 'Not authenticated.' })
  @UseInterceptors(FileInterceptor('logo', uploadOptions))
  async uploadLogo(@Param('initiativeId', new ParseIntPipe()) initiativeId: number, @UploadedFile() file, @User() authenticatedUser: AuthenticatedUserDto) {

    const initiativeFound = await this.initiativeService.getById(initiativeId, {}, { authenticatedUser });

    if (!initiativeFound) {
      throw new BadRequestException('initiative id invalid');
    }

    const { path } = file;
    const oldFileName = initiativeFound.logo ? initiativeFound.logo.name : 'logo.png';

    initiativeFound.logo = await this.initiativeUploadService.replaceFile(path, oldFileName);

    return this.initiativeService.update(initiativeId, initiativeFound);
  }

  /**
   * Delete initiative logo, if set
   * @param initiativeId
   * @param authenticatedUser
   * @param params
   */
  @Delete('/:initiativeId/logo-image')
  @ApiOperation({
    title: 'Delete initiative logo', description: `
    Delete logo of the initiative.
  `, operationId: 'DeleteInitiativeLogo',
  })
  @ApiImplicitParam({ name: 'initiativeId', description: 'Id of the initiative' })
  @ApiResponse({ status: 200, description: 'Initiative logo has been successfully deleted', isArray: false })
  @ApiResponse({ status: 404, description: 'Initiative does not exist or you don\'t have permission' })
  @ApiResponse({ status: 401, description: 'Not authenticated.' })
  async deleteLogo(@Param('initiativeId', new ParseIntPipe()) initiativeId: number, @User() authenticatedUser: AuthenticatedUserDto, @Param() params) {
    logger.info('Deleting initiative logo');

    const initiativeFound = await this.initiativeService.getById(initiativeId, {}, { authenticatedUser });

    if (!initiativeFound) {
      throw new BadRequestException('initiative id invalid');
    }

    const path = initiativeFound.logo ? initiativeFound.logo.name : null;

    if (path) {
      initiativeFound.logo = null;
      this.initiativeUploadService.deleteFile(path);
    }

    return await this.initiativeService.update(initiativeId, initiativeFound);
  }

  /**
   * Uploads (replaces the old one with a new file) Initiative Cover Image (file)
   * @param initiativeId
   * @param file
   * @param authenticatedUser
   */
  @Post('/:initiativeId/cover-image')
  @ApiOperation({ title: 'Upload Initiative Cover-Image',
    description: `Upload Initiative Cover-Image.
    Cover image should be supplied as a field with name \`coverImage\` in a \`multipart/form-data\` payload`,
    operationId: 'UploadInitiativeCoverImage',
  })
  @ApiImplicitParam({ name: 'initiativeId', description: 'Id of the initiative' })
  @ApiResponse({ status: 200, description: 'Initiative Cover-Image has been successfully uploaded', isArray: false })
  @ApiResponse({ status: 400, description: 'Body contains errors' })
  @ApiResponse({ status: 401, description: 'Not authenticated.' })
  @UseInterceptors(FileInterceptor('coverImage', uploadOptions))
  async uploadCoverImage(@Param('initiativeId', new ParseIntPipe()) initiativeId: number, @UploadedFile() file, @User() authenticatedUser: AuthenticatedUserDto) {

    const initiativeFound = await this.initiativeService.getById(initiativeId, {}, { authenticatedUser });

    if (!initiativeFound) {
      throw new BadRequestException('initiative id invalid');
    }

    const { path } = file;
    const oldFileName = initiativeFound.coverImage ? initiativeFound.coverImage.name : 'cover-image.png';

    initiativeFound.coverImage = await this.initiativeUploadService.replaceFile(path, oldFileName);

    return this.initiativeService.update(initiativeId, initiativeFound);
  }

  /**
   * Delete initiative cover image, if set
   * @param initiativeId
   * @param authenticatedUser
   * @param params
   */
  @Delete('/:initiativeId/cover-image')
  @ApiOperation({
    title: 'Delete initiative cover image', description: `
    Delete cover image of the initiative.
  `, operationId: 'DeleteInitiativeCoverImage',
  })
  @ApiImplicitParam({ name: 'initiativeId', description: 'Id of the initiative' })
  @ApiResponse({ status: 200, description: 'Initiative cover image has been successfully deleted', isArray: false })
  @ApiResponse({ status: 404, description: 'Initiative does not exist or you don\'t have permission' })
  @ApiResponse({ status: 401, description: 'Not authenticated.' })
  async deleteCoverImage(@Param('initiativeId', new ParseIntPipe()) initiativeId: number, @User() authenticatedUser: AuthenticatedUserDto, @Param() params) {
    logger.info('Deleting initiative cover image');

    const initiativeFound = await this.initiativeService.getById(initiativeId, {}, { authenticatedUser });

    if (!initiativeFound) {
      throw new BadRequestException('initiative id invalid');
    }

    const path = initiativeFound.coverImage ? initiativeFound.coverImage.name : null;

    if (path) {
      initiativeFound.coverImage = null;
      this.initiativeUploadService.deleteFile(path);
    }

    return await this.initiativeService.update(initiativeId, initiativeFound);
  }

  /**
   * Uploads Initiative photos (list)
   * @param initiativeId
   * @param files
   * @param authenticatedUser
   */
  @Post('/:initiativeId/photos')
  @ApiOperation({ title: 'Upload Initiative Photo List', description: 'Upload Initiative Photo List', operationId: 'UploadPhotoList' })
  @ApiImplicitParam({ name: 'initiativeId', description: 'Id of the initiative' })
  @ApiResponse({ status: 200, description: 'Initiative Photos have been successfully uploaded', isArray: true })
  @ApiResponse({ status: 400, description: 'Body contains errors' })
  @ApiResponse({ status: 401, description: 'Not authenticated.' })
  @UseInterceptors(FileFieldsInterceptor([{ name: 'fileList', maxCount: 20 }], uploadOptions))
  async uploadPhotoList(@Param('initiativeId', new ParseIntPipe()) initiativeId: number, @UploadedFiles() files, @User() authenticatedUser: AuthenticatedUserDto) {

    const initiativeFound = await this.initiativeService.getById(initiativeId, {}, { authenticatedUser });

    if (!initiativeFound) {
      throw new BadRequestException('initiative id invalid');
    }

    if (!(files && files.fileList)) {
      throw new BadRequestException('file(s) not provided');
    }

    const { fileList } = files;
    return this.initiativeFileService.createPhotoListForInitiative(initiativeId, fileList);

  }

  /**
  * Uploads Initiative logos (list)
  * @param initiativeId
  * @param files
  * @param authenticatedUser
  */
  @Post('/:initiativeId/partners-logos')
  @ApiOperation({
    title: 'Upload initiative partners logo list',
    description: 'Upload list of logos for partners of the initiative',
    operationId: 'UploadInitiativePartnersLogoList',
  })
  @ApiImplicitParam({ name: 'initiativeId', description: 'Id of the initiative' })
  @ApiResponse({ status: 200, description: 'Initiative partner logos have been successfully uploaded', isArray: true })
  @ApiResponse({ status: 400, description: 'Body contains errors' })
  @ApiResponse({ status: 401, description: 'Not authenticated.' })
  @UseInterceptors(FileFieldsInterceptor([{ name: 'fileList', maxCount: 20 }], uploadOptions))
  async uploadLogoList(@Param('initiativeId', new ParseIntPipe()) initiativeId: number, @UploadedFiles() files, @User() authenticatedUser: AuthenticatedUserDto) {
    const initiativeFound = await this.initiativeService.getById(initiativeId, {}, { authenticatedUser });

    if (!initiativeFound) {
      throw new BadRequestException('initiative id invalid');
    }

    const { fileList } = files;
    return this.initiativeFileService.createPartnersLogoListForInitiative(initiativeId, fileList);
  }

  @Put('/:initiativeId/partners-logos/:logoId')
  @ApiOperation({
    title: 'Update initiative partner logo by id',
    description: 'Update logo of one of the partners of the initiative, by id',
    operationId: 'UpdateInitiativePartnerLogoById',
  })
  @ApiImplicitParam({ name: 'initiativeId', description: 'Id of the initiative' })
  @ApiResponse({ status: 200, description: 'Initiative partner logo has been successfully updated', isArray: true })
  @ApiResponse({ status: 400, description: 'Body contains errors' })
  @ApiResponse({ status: 401, description: 'Not authenticated.' })
  async updateLogoById(
    @Param('initiativeId', new ParseIntPipe()) initiativeId: number,
    @Param('logoId', new ParseIntPipe()) logoId: number,
    @User() authenticatedUser: AuthenticatedUserDto,
    @Body(new ValidationPipe()) updateInitiativePartnerLogoDto: UpdateInitiativePartnerLogoDto,
  ) {
    const initiativeFound = await this.initiativeService.getById(initiativeId, {}, { authenticatedUser });
    if (!initiativeFound) {
      throw new BadRequestException('initiative id invalid');
    }

    return this.initiativeFileService.setPartnerLogoFileText(logoId, updateInitiativePartnerLogoDto);
  }
}
