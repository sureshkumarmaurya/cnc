import { ApiModelProperty } from '@nestjs/swagger';
import { IdentifiedObjectsDto } from 'modules/database/dto/identified-objects.dto';
import { MetaDto } from 'modules/database/dto/meta.dto';

export class IdentifiedObjectsPaginatedDto {

  @ApiModelProperty({ type: IdentifiedObjectsDto, isArray: true })
  readonly data: IdentifiedObjectsDto[];

  @ApiModelProperty()
  readonly meta: MetaDto;

  constructor(data, totalItems: number, pageSize: number, page: number) {
    this.data = data;
    this.meta = new MetaDto(Math.ceil(totalItems / pageSize), totalItems, pageSize, page);
  }
}
