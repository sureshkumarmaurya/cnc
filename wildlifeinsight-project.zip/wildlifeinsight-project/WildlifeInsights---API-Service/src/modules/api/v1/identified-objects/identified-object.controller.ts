import { Patch, Delete, Get, Body, Param, ParseIntPipe, ValidationPipe, UseGuards, Controller, Query } from '@nestjs/common';
import { ApiUseTags, ApiBearerAuth, ApiOperation, ApiResponse, ApiImplicitParam } from '@nestjs/swagger';
import { User } from 'decorators/user.decorator';
import { Pagination } from 'decorators/pagination.decorator';
import { AuthenticatedUserDto } from 'dto/authenticated-user.dto';
import { PermissionsGuard } from 'guards/permissions.guard';
import { UpdateIdentifiedObjectDto } from './dto/update-identified-object.dto';
import { IdentifiedObjectService } from './identified-object.service';
import { IdentifiedObjectsPaginatedDto } from './dto/identified-objects.dto';
import { PaginationModel } from 'utils/pagination.model';

const logger = require('logger');

export const identifiedObjectsRelations = ['dataFile', 'identificationOutputs'];

@Controller('/api/v1/project/:projectId/deployment/:deploymentId/data-file/:dataFileId/identification-output/:identificationOutputId/identified-object')
@ApiUseTags('IdentifiedObjects')
@ApiBearerAuth()
@UseGuards(PermissionsGuard)
export class IdentifiedObjectController {
  constructor(private readonly identifiedObjectsService: IdentifiedObjectService) { }

  /**
   * Gets all Identified Objects
   * @param pagination
   * @param params
   * @param authenticatedUser
   */
  @Get('/')
  @ApiOperation({ title: 'Get All Identified Objects', description: 'Get All identified-objects', operationId: 'GetAllIdentifiedObjects' })
  @ApiImplicitParam({ name: 'projectId', description: 'project this identification output belongs to' })
  @ApiImplicitParam({ name: 'deploymentId', description: 'deployment this identification output belongs to' })
  @ApiImplicitParam({ name: 'dataFileId', description: 'data-file this identification output belongs to' })
  @ApiImplicitParam({ name: 'identificationOutputId', description: 'IdentificationOutput this identification output belongs to' })
  @ApiResponse({ status: 200, description: 'Identified Object has been successfully returned', isArray: false, type: IdentifiedObjectsPaginatedDto })
  @ApiResponse({ status: 403, description: 'Not authorized.' })
  @ApiResponse({ status: 401, description: 'Not authenticated.' })
  async findAll(@Query() filters, @Pagination() pagination: PaginationModel, @Param() params, @User() authenticatedUser: AuthenticatedUserDto) {
    logger.info('Get All Identified Object');
    const data = await this.identifiedObjectsService.findAll(pagination, { authenticatedUser, params });
    return new IdentifiedObjectsPaginatedDto(data[0], data[1], pagination.pageSize, pagination.pageNumber);
  }

  /**
   * Gets Identified Object by Id
   * @param id
   * @param authenticatedUser
   * @param params
   * @param pagination
   */
  @Get('/:id')
  @ApiOperation({ title: 'Get By Id Identified Object', description: 'Get By Id identified-object', operationId: 'GetByIdIdentifiedObject' })
  @ApiImplicitParam({ name: 'projectId', description: 'project this identification output belongs to' })
  @ApiImplicitParam({ name: 'deploymentId', description: 'deployment this identification output belongs to' })
  @ApiImplicitParam({ name: 'dataFileId', description: 'data-file this identification output belongs to' })
  @ApiImplicitParam({ name: 'identificationOutputId', description: 'IdentificationOutput this identification output belongs to' })
  @ApiResponse({ status: 200, description: 'Identified Object has been successfully returned', isArray: false })
  @ApiResponse({ status: 403, description: 'Not authorized.' })
  @ApiResponse({ status: 401, description: 'Not authenticated.' })
  @ApiResponse({ status: 404, description: 'Not Found.' })
  async getById(@Param('id', new ParseIntPipe()) id: number, @User() authenticatedUser: AuthenticatedUserDto, @Param() params, @Pagination() pagination: PaginationModel) {
    return await this.identifiedObjectsService.getById(id, pagination, { authenticatedUser, params });
  }

  /**
   * Updates Identified Object by id
   * @param id
   * @param updateIdentifiedObjectDto
   * @param authenticatedUser
   * @param params
   */
  @Patch('/:id')
  @ApiOperation({ title: 'Patch Identified Objects', description: 'Patch identified-objects', operationId: 'UpdateIdentifiedObject' })
  @ApiImplicitParam({ name: 'projectId', description: 'project this identification output belongs to' })
  @ApiImplicitParam({ name: 'deploymentId', description: 'deployment this identification output belongs to' })
  @ApiImplicitParam({ name: 'dataFileId', description: 'data-file this identification output belongs to' })
  @ApiImplicitParam({ name: 'identificationOutputId', description: 'IdentificationOutput this identification output belongs to' })
  @ApiResponse({ status: 200, description: 'Identified Object has been successfully returned', isArray: false })
  @ApiResponse({ status: 403, description: 'Not authorized.' })
  @ApiResponse({ status: 401, description: 'Not authenticated.' })
  async update(@Param('id', new ParseIntPipe()) id: number, @Body(new ValidationPipe()) updateIdentifiedObjectDto: UpdateIdentifiedObjectDto, @User() authenticatedUser: AuthenticatedUserDto, @Param() params) {
    logger.info('Update Identified Object');
    return await this.identifiedObjectsService.update(id, updateIdentifiedObjectDto, { authenticatedUser, params });
  }

  /**
   * Deletes identified object by id
   * @param id
   * @param authenticatedUser
   * @param params
   */
  @Delete('/:id')
  @ApiOperation({ title: 'Delete Identified Objects', description: 'Delete Identified Objects', operationId: 'DeleteIdentifiedObject' })
  @ApiImplicitParam({ name: 'projectId', description: 'project this identification output belongs to' })
  @ApiImplicitParam({ name: 'deploymentId', description: 'deployment this identification output belongs to' })
  @ApiImplicitParam({ name: 'dataFileId', description: 'data-file this identification output belongs to' })
  @ApiImplicitParam({ name: 'identificationOutputId', description: 'IdentificationOutput this identification output belongs to' })
  @ApiResponse({ status: 200, description: 'IdentifiedObject has been successfully deleted', isArray: false })
  @ApiResponse({ status: 404, description: 'IdentifiedObject does not exist or you don\'t have permission' })
  @ApiResponse({ status: 401, description: 'Not authenticated.' })
  async remove(@Param('id', new ParseIntPipe()) id: number, @User() authenticatedUser: AuthenticatedUserDto, @Param() params) {
    logger.info('Deleting Identified Object');
    return await this.identifiedObjectsService.remove(id, { authenticatedUser, params });
  }

}
