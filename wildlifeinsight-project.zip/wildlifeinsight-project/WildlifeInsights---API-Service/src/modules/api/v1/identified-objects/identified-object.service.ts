import { Injectable, Inject } from '@nestjs/common';
import { Repository, SelectQueryBuilder } from 'typeorm';
import { CreateIdentifiedObjectDto } from './dto/create-identified-object.dto';
import { UpdateIdentifiedObjectDto } from './dto/update-identified-object.dto';
import { InfoDto } from 'dto/info.dto';
import { IdentifiedObjects } from 'modules/database/entities/identified-objects.entity';
import { GenericService } from 'utils/generic.service';

const logger = require('logger');

@Injectable()
export class IdentifiedObjectService extends GenericService<IdentifiedObjects, any, any> {
  constructor(@Inject('IdentifiedObjectsRepositoryToken') private readonly identifiedObjectsRepository: Repository<IdentifiedObjects>) {
    super(identifiedObjectsRepository, 'identifiedObject');
  }

  setFilters(query: SelectQueryBuilder<IdentifiedObjects>, filters: any, info: InfoDto) {
    logger.debug('Setting up filters');
    logger.debug(info);
    query
      .innerJoin('identifiedObject.identification', 'identification')
      .andWhere('identification.id = :identificationId')
      .setParameter('identificationId', info.params.identificationOutputId);
    return query;
  }

  setFiltersGetById(query: SelectQueryBuilder<IdentifiedObjects>, info: InfoDto) {
    return query;
  }

  setFiltersDelete(query: SelectQueryBuilder<IdentifiedObjects>, info: InfoDto) {
    return query;
  }

  setFiltersUpdate(query: SelectQueryBuilder<IdentifiedObjects>, info: InfoDto) {
    return query;
  }

  async setDataCreate(create: CreateIdentifiedObjectDto, info: InfoDto) {
    const model = new IdentifiedObjects();
    return model;
  }

  async setDataUpdate(model: IdentifiedObjects, update: UpdateIdentifiedObjectDto, info: InfoDto) {
    const updatedModel = { ...model, ...update };
    return updatedModel;
  }
}
