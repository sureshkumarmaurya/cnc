import { IdentifiedObjectController, identifiedObjectsRelations } from './identified-object.controller';
import { IdentifiedObjectService } from './identified-object.service';
import { Module, RequestMethod, MiddlewareConsumer } from '@nestjs/common';
import { PaginationMiddleware } from 'middlewares/pagination.middleware';
import { DatabaseModule } from 'modules/database/database.module';

@Module({
  imports: [DatabaseModule],
  controllers: [IdentifiedObjectController],
  providers: [IdentifiedObjectService],
})
export class IdentifiedObjectModule {
  public configure(consumer: MiddlewareConsumer) {
    consumer
      .apply(PaginationMiddleware)
      .forRoutes(
        { path: '/api/v1/project/:projectId/deployment/:deploymentId/data-file/:dataFileId/identification-output/:identificationOutputId/identified-object', method: RequestMethod.GET },
        { path: '/api/v1/project/:projectId/deployment/:deploymentId/data-file/:dataFileId/identification-output/:identificationOutputId/identified-object/:id', method: RequestMethod.GET },
      );
  }
}
