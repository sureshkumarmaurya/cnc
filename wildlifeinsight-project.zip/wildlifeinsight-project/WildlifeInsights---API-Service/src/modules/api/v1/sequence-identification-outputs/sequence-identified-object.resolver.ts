import { SequenceIdentificationOutputService } from './sequence-identification-output.service';
import { Resolver, Query, Args, Parent, ResolveProperty } from '@nestjs/graphql';
import { UseInterceptors } from '@nestjs/common';
import { PaginationGraphqlInterceptor } from 'interceptors/pagination-graphql.interceptor';
import { User } from 'decorators/user.decorator';
import { SequenceIdentificationOutputsPaginatedDto } from './dto/sequence-identification-outputs.dto';
import { SequenceIdentificationOutputs } from 'modules/database/entities/sequence-identification-outputs.entity';
import { IdentificationMethods } from 'modules/database/entities/identification-methods.entity';
import { SequenceIdentifiedObjects } from 'modules/database/entities/sequence-identified-objects.entity';
import { Taxonomies } from 'modules/database/entities/taxonomies.entity';

@Resolver('SequenceIdentifiedObject')
export class SequenceIdentifiedObjectResolver {
  constructor(private readonly sequenceIdentificationOutputService: SequenceIdentificationOutputService) {}

  @ResolveProperty()
  async taxonomy(@Parent() sequenceIdentifiedObject: SequenceIdentifiedObjects): Promise<Taxonomies> {
    return this.sequenceIdentificationOutputService.getTaxonomyById(sequenceIdentifiedObject.taxonomyId);
  }

}
