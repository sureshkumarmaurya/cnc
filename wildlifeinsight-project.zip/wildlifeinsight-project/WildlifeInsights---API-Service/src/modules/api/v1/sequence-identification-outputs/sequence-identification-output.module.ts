import { SequenceIdentificationOutputController, sequenceIdentificationOutputsRelations } from './sequence-identification-output.controller';
import { SequenceIdentificationOutputResolver } from './sequence-identification-output.resolver';
import { SequenceIdentificationOutputService } from './sequence-identification-output.service';
import { Module, RequestMethod, MiddlewareConsumer } from '@nestjs/common';
import { PaginationMiddleware } from 'middlewares/pagination.middleware';
import { DatabaseModule } from 'modules/database/database.module';
import { SequenceIdentificationOutputGeneralController } from './sequence-identification-output-general.controller';

@Module({
  imports: [DatabaseModule],
  controllers: [SequenceIdentificationOutputController, SequenceIdentificationOutputGeneralController],
  providers: [SequenceIdentificationOutputService, SequenceIdentificationOutputResolver],
})

export class SequenceIdentificationOutputModule {
  public configure(consumer: MiddlewareConsumer) {
    consumer
      .apply(PaginationMiddleware)
      .with({ includes: [], allowIncludes: sequenceIdentificationOutputsRelations })
      .forRoutes(
        { path: '/api/v1/project/:projectId/deployment/:deploymentId/sequence/:sequenceId/identification-output', method: RequestMethod.GET },
        { path: '/api/v1/project/:projectId/deployment/:deploymentId/sequence/:sequenceId/identification-output/:id', method: RequestMethod.GET },
      );
  }
}
