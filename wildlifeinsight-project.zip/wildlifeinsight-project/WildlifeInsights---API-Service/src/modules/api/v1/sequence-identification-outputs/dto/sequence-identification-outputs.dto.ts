import { ApiModelProperty } from '@nestjs/swagger';
import { SequenceIdentificationOutputsDto } from 'modules/database/dto/sequence-identification-outputs.dto';
import { MetaDto } from 'modules/database/dto/meta.dto';

export class SequenceIdentificationOutputsPaginatedDto {

  @ApiModelProperty({ type: SequenceIdentificationOutputsDto, isArray: true })
  readonly data: SequenceIdentificationOutputsDto[];

  @ApiModelProperty()
  readonly meta: MetaDto;

  constructor(data, totalItems: number, pageSize: number, page: number) {
    this.data = data;
    this.meta = new MetaDto(Math.ceil(totalItems / pageSize), totalItems, pageSize, page);
  }
}
