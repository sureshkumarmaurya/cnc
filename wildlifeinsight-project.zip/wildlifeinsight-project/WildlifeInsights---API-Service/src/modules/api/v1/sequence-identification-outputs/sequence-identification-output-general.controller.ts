import { Controller, Post, Body, Param, UseGuards, ValidationPipe } from '@nestjs/common';
import { SequenceIdentificationOutputService } from './sequence-identification-output.service';
import { ApiUseTags, ApiBearerAuth, ApiOperation, ApiResponse } from '@nestjs/swagger';
import { SequenceIdentificationOutputsDto } from 'modules/database/dto/sequence-identification-outputs.dto';
import { PermissionsGuard } from 'guards/permissions.guard';
import { User } from 'decorators/user.decorator';
import { AuthenticatedUserDto } from 'dto/authenticated-user.dto';
import { CreateSequenceIdentificationOutputBulkDto } from './dto/create-sequence-identification-output-bulk.dto';

const logger = require('logger');

@Controller('/api/v1/sequence-identification-output')
@ApiUseTags('SequenceIdentificationOutputs')
@ApiBearerAuth()
@UseGuards(PermissionsGuard)
export class SequenceIdentificationOutputGeneralController {
  constructor(private readonly sequenceIdentificationOutputsService: SequenceIdentificationOutputService) { }
}
