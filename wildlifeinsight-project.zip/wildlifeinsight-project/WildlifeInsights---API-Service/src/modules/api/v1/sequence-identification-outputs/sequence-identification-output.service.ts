import { Repository, SelectQueryBuilder, Connection, EntityManager } from 'typeorm';
import { Injectable, Inject, NotFoundException, BadRequestException, UnauthorizedException } from '@nestjs/common';
import { GenericService } from 'utils/generic.service';
import { InfoDto } from 'dto/info.dto';
import { IdentificationMethods } from 'modules/database/entities/identification-methods.entity';
import { SequenceIdentificationOutputs } from 'modules/database/entities/sequence-identification-outputs.entity';
import { CreateSequenceIdentificationOutputDto } from './dto/create-sequence-identification-output.dto';
import { Sequences } from 'modules/database/entities/sequences.entity';
import { UpdateSequenceIdentificationOutputDto } from './dto/update-sequence-identification-output.dto';
import { Taxonomies } from '../../../database/entities/taxonomies.entity';
import { SequenceIdentifiedObjects } from '../../../database/entities/sequence-identified-objects.entity';
import { Participants } from 'modules/database/entities/participants.entity';
import { CreateSequenceIdentificationOutputBulkDto } from './dto/create-sequence-identification-output-bulk.dto';
import { SequenceIdentificationOutputsDto } from 'modules/database/dto/sequence-identification-outputs.dto';
import { PermissionsUtils } from 'utils/permissions.utils';
import { ProjectsDto } from 'modules/database/dto/projects.dto';
import { PERMISSIONS } from 'utils/permissions.enum';

const logger = require('logger');

@Injectable()
export class SequenceIdentificationOutputService extends GenericService<SequenceIdentificationOutputs, any, any>  {

  constructor(
    @Inject('SequenceIdentificationOutputsRepositoryToken') private readonly sequenceIdentificationOutputsRepository: Repository<SequenceIdentificationOutputs>,
    @Inject('IdentificationMethodsRepositoryToken') private readonly identificationMethodsRepository: Repository<IdentificationMethods>,
    @Inject('SequenceIdentifiedObjectsRepositoryToken') private readonly sequenceIdentifiedObjectsRepository: Repository<SequenceIdentifiedObjects>,
    @Inject('SequencesRepositoryToken') private readonly sequencesRepository: Repository<Sequences>,
    @Inject('TaxonomiesRepositoryToken') private readonly taxonomiesRepository: Repository<Taxonomies>,
    @Inject('ParticipantsRepositoryToken') private readonly participantsRepository: Repository<Participants>,
    @Inject('DbConnectionToken') private readonly connection: Connection,
  ) {
    super(sequenceIdentificationOutputsRepository, 'sequenceIdentificationOutput');
  }

  setFilters(query: SelectQueryBuilder<SequenceIdentificationOutputs>, filters: any, info: InfoDto) {
    if (info.pagination.includes && info.pagination.includes.indexOf('sequence') >= 0) {
      query.innerJoinAndSelect('sequenceIdentificationOutput.sequence', 'sequence');
      info.pagination.includes.splice(info.pagination.includes.indexOf('sequence'), 1);
    } else {
      query.innerJoin('sequenceIdentificationOutput.sequence', 'sequence');
    }
    query.innerJoin('sequence.deployment', 'deployment');
    query.andWhere('sequence.id = :sequenceId').setParameter('sequenceId', info.params.sequenceId);
    query.andWhere('deployment.id = :deploymentId').setParameter('deploymentId', info.params.deploymentId);
    query.andWhere('deployment.projectId = :projectId').setParameter('projectId', info.params.projectId);
    return query;
  }

  setFiltersGetById(query: SelectQueryBuilder<SequenceIdentificationOutputs>, info: InfoDto) {
    if (info.pagination.includes && info.pagination.includes.indexOf('sequence') >= 0) {
      query.innerJoinAndSelect('sequenceIdentificationOutput.sequence', 'sequence');
      info.pagination.includes.splice(info.pagination.includes.indexOf('sequence'), 1);
    } else {
      query.innerJoin('sequenceIdentificationOutput.sequence', 'sequence');
    }
    query.innerJoin('sequence.deployment', 'deployment');
    query.andWhere('sequence.id = :sequenceId').setParameter('sequenceId', info.params.sequenceId);
    query.andWhere('deployment.id = :deploymentId').setParameter('deploymentId', info.params.deploymentId);
    query.andWhere('deployment.projectId = :projectId').setParameter('projectId', info.params.projectId);
    return query;
  }

  setFiltersDelete(query: SelectQueryBuilder<SequenceIdentificationOutputs>, info: InfoDto) {
    query.innerJoin('sequenceIdentificationOutput.sequence', 'sequence');
    query.innerJoin('sequence.deployment', 'deployment');
    query.andWhere('sequence.id = :sequenceId').setParameter('sequenceId', info.params.sequenceId);
    query.andWhere('deployment.id = :deploymentId').setParameter('deploymentId', info.params.deploymentId);
    query.andWhere('deployment.projectId = :projectId').setParameter('projectId', info.params.projectId);
    return query;
  }

  setFiltersUpdate(query: SelectQueryBuilder<SequenceIdentificationOutputs>, info: InfoDto) {
    query.innerJoin('sequenceIdentificationOutput.sequence', 'sequence');
    query.innerJoin('sequence.deployment', 'deployment');
    query.andWhere('sequence.id = :sequenceId').setParameter('sequenceId', info.params.sequenceId);
    query.andWhere('deployment.id = :deploymentId').setParameter('deploymentId', info.params.deploymentId);
    query.andWhere('deployment.projectId = :projectId').setParameter('projectId', info.params.projectId);
    return query;
  }

  async getIdentificationMethod(id: number): Promise<IdentificationMethods> {
    return this.identificationMethodsRepository.findOne(id);
  }

  async getTaxonomyById(id: string): Promise<Taxonomies> {
    return this.taxonomiesRepository.findOne(id);
  }

  async getParticipantById(id: number): Promise<Participants> {
    return this.participantsRepository.findOne(id);
  }

  async getSequenceIdentifiedObjectsBySequenceIdentificationOutputId(id: number): Promise<SequenceIdentifiedObjects[]> {
    return this.sequenceIdentifiedObjectsRepository.find({ where: { sequenceIdentificationId: id } });
  }

  async validateBeforeCreate(createModel: CreateSequenceIdentificationOutputDto, info: InfoDto): Promise<void> {
    const sequence = await this.sequencesRepository.createQueryBuilder('sequence')
    .innerJoin('sequence.deployment', 'deployment')
    .andWhere('sequence.id = :sequenceId').setParameter('sequenceId', info.params.sequenceId)
    .andWhere('deployment.id = :deploymentId').setParameter('deploymentId', info.params.deploymentId)
    .andWhere('deployment.projectId = :projectId').setParameter('projectId', info.params.projectId)
    .getOne();

    if (!sequence) {
      throw new NotFoundException('Sequence not found');
    }

    const method = await this.identificationMethodsRepository.findOne(createModel.identificationMethodId);
    if (!method) {
      throw new NotFoundException('Identification method not found');
    }

    if (createModel.identifiedObjects && createModel.identifiedObjects.length > 0) {
      for (let i = 0, { length } = createModel.identifiedObjects; i < length; i++) {
        const taxonomy = await this.taxonomiesRepository.findOne(createModel.identifiedObjects[i].taxonomyId);
        if (!taxonomy) {
          throw new NotFoundException(`Taxonomy not found with id ${createModel.identifiedObjects[i].taxonomyId}`);
        }
      }
    }
  }

  async setDataCreate(create: CreateSequenceIdentificationOutputDto, info: InfoDto) {
    const sequence = await this.sequencesRepository.findOne(info.params.sequenceId);
    const method = await this.identificationMethodsRepository.findOne(create.identificationMethodId);

    const model = new SequenceIdentificationOutputs();
    model.blankYn = create.blankYn;
    model.sequence = sequence;
    model.identificationMethod = method;
    model.timestamp = new Date();
    model.participantId = info.authenticatedUser.user.id;

    if (create.identifiedObjects && create.identifiedObjects.length > 0) {
      model.identifiedObjects = [];
      for (let i = 0, { length } = create.identifiedObjects; i < length; i++) {
        const idObj = create.identifiedObjects[i];
        const taxonomy = await this.taxonomiesRepository.findOne(idObj.taxonomyId);
        const sequenceIdentifiedObject = new SequenceIdentifiedObjects();
        sequenceIdentifiedObject.taxonomy = taxonomy;
        sequenceIdentifiedObject.commonName = idObj.commonName;
        sequenceIdentifiedObject.relativeAge = idObj.relativeAge;
        sequenceIdentifiedObject.sex = idObj.sex;
        sequenceIdentifiedObject.markings = idObj.markings;
        sequenceIdentifiedObject.individualIdentified = idObj.individualIdentified;
        sequenceIdentifiedObject.behavior = idObj.behavior;
        sequenceIdentifiedObject.remarks = idObj.remarks;
        sequenceIdentifiedObject.date = new Date();
        sequenceIdentifiedObject.certainity = idObj.certainity;
        model.identifiedObjects.push(sequenceIdentifiedObject);
      }
    }

    return model;
  }

  async create(createModel: CreateSequenceIdentificationOutputDto, info?: InfoDto): Promise<SequenceIdentificationOutputs> {
    logger.debug('Creating identification');
    await this.validateBeforeCreate(createModel, info);
    let model = await this.setDataCreate(createModel, info);
    return await this.connection.manager.transaction(async (entityManager: EntityManager) => {
      model = await entityManager.save(SequenceIdentificationOutputs, model);
      // const sequence = await entityManager.findOne(Sequences, info.params.sequenceId);
      // logger.debug('Updating sequence status');
      // const identify = model.identifiedObjects && model.identifiedObjects.slice(-1).pop().taxonomy;
      return model;
    });
  }

  async validateBeforeUpdate(id:number, updateModel: UpdateSequenceIdentificationOutputDto, info?: InfoDto): Promise<void> {
    if (updateModel.identificationMethodId !== undefined) {
      const method = await this.identificationMethodsRepository.findOne(updateModel.identificationMethodId);
      if (!method) {
        throw new NotFoundException('Identification method not found');
      }
    }
  }

  async setDataUpdate(model: SequenceIdentificationOutputs, update: UpdateSequenceIdentificationOutputDto, info: InfoDto) {
    if (update.blankYn !== undefined) {
      model.blankYn = update.blankYn;
    }

    if (update.identificationMethodId !== undefined) {
      const method = await this.identificationMethodsRepository.findOne(update.identificationMethodId);
      model.identificationMethod = method;
    }
    return model;
  }

}
