import { Get, Controller, Req, Post, Body, Patch, Param, Delete, ParseIntPipe, UseGuards, ValidationPipe } from '@nestjs/common';
import { SequenceIdentificationOutputService } from './sequence-identification-output.service';
import { ApiUseTags, ApiBearerAuth, ApiOperation, ApiResponse, ApiImplicitQuery, ApiImplicitParam } from '@nestjs/swagger';
import { SequenceIdentificationOutputsPaginatedDto } from './dto/sequence-identification-outputs.dto';
import { Pagination } from 'decorators/pagination.decorator';
import { SequenceIdentificationOutputsDto } from 'modules/database/dto/sequence-identification-outputs.dto';
import { PermissionsGuard } from 'guards/permissions.guard';
import { User } from 'decorators/user.decorator';
import { AuthenticatedUserDto } from 'dto/authenticated-user.dto';
import { Permissions } from 'decorators/permissions.decorator';
import { PERMISSIONS } from 'utils/permissions.enum';
import { CreateSequenceIdentificationOutputDto } from './dto/create-sequence-identification-output.dto';
import { CreateSequenceIdentificationOutputBulkDto } from './dto/create-sequence-identification-output-bulk.dto';
import { PaginationModel } from 'utils/pagination.model';

const logger = require('logger');

export const sequenceIdentificationOutputsRelations = ['sequence', 'identificationMethod', 'identifiedObjects', 'participant'];

@Controller('/api/v1/project/:projectId/deployment/:deploymentId/sequence/:sequenceId/identification-output')
@ApiUseTags('SequenceIdentificationOutputs')
@ApiBearerAuth()
@UseGuards(PermissionsGuard)
export class SequenceIdentificationOutputController {
  constructor(private readonly sequenceIdentificationOutputsService: SequenceIdentificationOutputService) { }

  @Get()
  @ApiOperation({
    title: 'Get sequence-level identification outputs',
    description: 'Get all identification outputs for a sequence:',
    operationId: 'GetAllSequenceIdentificationOutputs',
  })
  @ApiResponse({ status: 200, description: 'Identification outputs have been successfully returned', isArray: false, type: SequenceIdentificationOutputsPaginatedDto })
  @ApiResponse({ status: 403, description: 'Not authorized.' })
  @ApiResponse({ status: 401, description: 'Not authenticated.' })
  @ApiImplicitParam({ name: 'projectId', description: 'Project the deployment belongs to', type: Number, required: true })
  @ApiImplicitParam({ name: 'deploymentId', description: 'Id of the deployment', required: true, type: Number })
  @ApiImplicitParam({ name: 'sequenceId', description: 'Id of the sequence', required: true, type: Number })
  @ApiImplicitQuery({
    name: 'includes', description: `
  Allows include the IdentificationOutputs's relations. Available ${sequenceIdentificationOutputsRelations}
  `, type: String, required: false,
  })
  @ApiImplicitQuery({ name: 'fields', description: 'IdentificationOutputs\'s fields to select', type: String, required: false })
  @ApiImplicitQuery({ name: 'page[size]', description: 'Page size. Default 10', type: String, required: false })
  @ApiImplicitQuery({ name: 'page[number]', description: 'Page number', type: String, required: false })
  @ApiImplicitQuery({ name: 'sort', description: 'Sort results', type: String, required: false })
  @Permissions(PERMISSIONS.IDENTIFICATION_GET_ALL)
  async findAll(@Pagination() pagination: PaginationModel, @Param() params, @User() authenticatedUser: AuthenticatedUserDto) {
    logger.info('Getting all identification outputs for a sequence');
    const data = await this.sequenceIdentificationOutputsService.findAll(pagination, { authenticatedUser, params });
    return new SequenceIdentificationOutputsPaginatedDto(data[0], data[1], pagination.pageSize, pagination.pageNumber);
  }

  @Get('/:id')
  @ApiOperation({
    title: 'Get identification outputs by id', description: `
    Get identificationOutputs by id
  `, operationId: 'GetSequenceIdentificationOutputById',
  })
  @ApiImplicitQuery({
    name: 'includes', description: `
  Allows include the Identification Outputs's relations. Available ${sequenceIdentificationOutputsRelations}
  `, type: String, required: false,
  })
  @ApiImplicitParam({ name: 'projectId', description: 'Project the deployment belongs to', type: Number, required: true })
  @ApiImplicitParam({ name: 'deploymentId', description: 'Id of the deployment', required: true, type: Number })
  @ApiImplicitParam({ name: 'sequenceId', description: 'Id of the sequence', required: true, type: Number })
  @ApiImplicitParam({ name: 'id', description: 'Id of the identification output', required: true, type: Number })
  @ApiResponse({ status: 200, description: 'IdentificationOutput has been successfully returned', isArray: false, type: SequenceIdentificationOutputsDto })
  @ApiResponse({ status: 404, description: 'IdentificationOutput does not exist or you don\'t have permission' })
  @ApiResponse({ status: 401, description: 'Not authenticated.' })
  @Permissions(PERMISSIONS.IDENTIFICATION_GET_ONE)
  async getById(@Param('id', new ParseIntPipe()) id: number, @User() authenticatedUser: AuthenticatedUserDto, @Param() params, @Pagination() pagination: PaginationModel) {
    logger.info('Get sequence-level identification output by id ', id);
    return await this.sequenceIdentificationOutputsService.getById(id, pagination, { authenticatedUser, params });
  }

  @Post('/')
  @ApiOperation({
    title: 'Create sequence-level identification output', description: `
    Create new sequence-level identification output
  `, operationId: 'CreateSequenceIdentificationOutput',
  })
  @ApiImplicitParam({ name: 'projectId', description: 'Project the deployment belongs to', type: Number, required: true })
  @ApiImplicitParam({ name: 'deploymentId', description: 'Deployment the data file belongs to', type: Number, required: true })
  @ApiImplicitParam({ name: 'sequenceId', description: 'Sequence this identification output belongs to', type: Number, required: true })
  @ApiResponse({ status: 200, description: 'IdentificationOutput has been successfully created', isArray: false, type: SequenceIdentificationOutputsDto })
  @ApiResponse({ status: 400, description: 'Body contains errors' })
  @ApiResponse({ status: 401, description: 'Not authenticated.' })
  @Permissions(PERMISSIONS.IDENTIFICATION_CREATE)
  async create(@Body(new ValidationPipe()) createSequenceIdentificationOutputDto: CreateSequenceIdentificationOutputDto, @User() authenticatedUser: AuthenticatedUserDto, @Param() params) {
    logger.info('Creating sequenc-level identification output');
    return await this.sequenceIdentificationOutputsService.create(createSequenceIdentificationOutputDto, { authenticatedUser, params });
  }

  @Delete('/:id')
  @ApiOperation({
    title: 'Delete sequence-level identification', description: `
    Delete sequence-level identification
  `, operationId: 'DeleteSequenceIdentificationOutput',
  })
  @ApiImplicitParam({ name: 'id', description: 'Id of the sequence-level identification output' })
  @ApiImplicitParam({ name: 'projectId', description: 'Project the deployment belongs to', type: Number, required: true })
  @ApiImplicitParam({ name: 'deploymentId', description: 'Deployment the sequence belongs to', type: Number, required: true })
  @ApiResponse({ status: 200, description: 'IdentificationOutput has been successfully deleted', isArray: false, type: SequenceIdentificationOutputsDto })
  @ApiResponse({ status: 404, description: 'IdentificationOutput does not exist or you don\'t have permission' })
  @ApiResponse({ status: 401, description: 'Not authenticated.' })
  @Permissions(PERMISSIONS.IDENTIFICATION_DELETE)
  async remove(@Param('id', new ParseIntPipe()) id: number, @User() authenticatedUser: AuthenticatedUserDto, @Param() params) {
    logger.info('Deleting sequence-level identification output');
    return await this.sequenceIdentificationOutputsService.remove(id, { authenticatedUser, params });
  }

  // @Patch('/:id')
  // @ApiOperation({
  //   title: 'Update sequence-level identification output', description: `
  //   Update sequence-level identification output
  // `, operationId: 'UpdateSequenceIdentificationOutput',
  // })
  // @ApiImplicitParam({ name: 'id', description: 'Id of the dataFile' })
  // @ApiImplicitParam({ name: 'projectId', description: 'Project the deployment belongs to', type: Number, required: true })
  // @ApiImplicitParam({ name: 'deploymentId', description: 'Deployment the data file belongs to', type: Number, required: true })
  // @ApiImplicitParam({ name: 'sequenceId', description: 'Id of the sequence', required: true, type: Number })
  // @ApiResponse({ status: 200, description: 'SequenceIdentificationOutput has been successfully updated', isArray: false, type: SequenceIdentificationOutputsDto })
  // @ApiResponse({ status: 404, description: 'SequenceIdentificationOutput does not exist or you don\'t have permission' })
  // @ApiResponse({ status: 401, description: 'Not authenticated.' })
  // @Permissions(PERMISSIONS.IDENTIFICATION_UPDATE)
  // async update(@Param('id', new ParseIntPipe()) id: number, @Body(new ValidationPipe()) updateSequenceIdentificationOutputDto: UpdateSequenceIdentificationOutputDto, @User() authenticatedUser: AuthenticatedUserDto, @Param() params) {
  //   logger.info('Updating sequence-level identification output');
  //   return await this.sequenceIdentificationOutputsService.update(id, updateSequenceIdentificationOutputDto, { authenticatedUser, params });
  // }

}
