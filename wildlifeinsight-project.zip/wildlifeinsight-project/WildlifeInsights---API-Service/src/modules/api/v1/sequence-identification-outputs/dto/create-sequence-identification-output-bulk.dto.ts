import { ApiModelProperty } from '@nestjs/swagger';
import { IsInt, IsArray, ValidateNested } from 'class-validator';
import { CreateSequenceIdentificationOutputDto } from './create-sequence-identification-output.dto';

export class CreateSequenceIdentificationOutputBulkDto {

  @IsArray()
  @ApiModelProperty({ required: true })
  dataFileIds: number[];

  @ValidateNested()
  @ApiModelProperty({ required: true, type: CreateSequenceIdentificationOutputDto })
  sequenceIdentificationOutput: CreateSequenceIdentificationOutputDto;

}
