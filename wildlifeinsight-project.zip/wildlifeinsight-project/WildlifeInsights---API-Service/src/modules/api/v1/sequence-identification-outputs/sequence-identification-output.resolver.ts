import { Resolver, Query, Mutation, Args } from '@nestjs/graphql';
import { UseInterceptors, UseGuards } from '@nestjs/common';
import { GraphqlAuthGuard } from 'guards/graphql-passport.guard';
import { ValidationGraphqlInterceptor } from 'interceptors/validation-graphql.interceptor';
import { GraphqlUserWithPermissions } from 'decorators/graphql-user.decorator';
import { Permissions } from 'decorators/permissions.decorator';
import { PERMISSIONS } from 'utils/permissions.enum';
import { SequenceIdentificationOutputService } from './sequence-identification-output.service';
import { CreateSequenceIdentificationOutputDto } from './dto/create-sequence-identification-output.dto';
import { SequenceIdentificationOutputsPaginatedDto } from './dto/sequence-identification-outputs.dto';

@Resolver('SequenceIdentificationOutput')
export class SequenceIdentificationOutputResolver {
  constructor(private readonly sequenceIdentificationOutputsService: SequenceIdentificationOutputService) { }

  /**
   * Gets one SequenceIdentificationOutput by Id
   * @param authenticatedUser
   * @param args
   */
  @Query()
  async getSequenceIdentificationOutput(@GraphqlUserWithPermissions() authenticatedUser, @Args() args) {
    const { id } = args;
    return await this.sequenceIdentificationOutputsService.getById(id, {}, { authenticatedUser, params: args });
  }

  /**
   * Gets Many/All SequenceIdentificationOutputs
   * @param authenticatedUser
   * @param args
   */
  @Query()
  async getSequenceIdentificationOutputs(@GraphqlUserWithPermissions() authenticatedUser, @Args() args) {
    const data = await this.sequenceIdentificationOutputsService.findAll(args.pagination, { authenticatedUser, params: args });
    return new SequenceIdentificationOutputsPaginatedDto(data[0], data[1], args.pagination.pageSize, args.pagination.pageNumber);
  }

  /**
   * Creates one SequenceIdentificationOutput
   * @param authenticatedUser
   * @param args
   */
  @Mutation()
  @UseGuards(GraphqlAuthGuard)
  @UseInterceptors(new ValidationGraphqlInterceptor(CreateSequenceIdentificationOutputDto))
  async createSequenceIdentificationOutput(@GraphqlUserWithPermissions() authenticatedUser, @Args() args) {
    const { body } = args;
    return await this.sequenceIdentificationOutputsService.create(body, { authenticatedUser, params: args });
  }

  /**
   * Deletes one SequenceIdentificationOutput by Id
   * @param authenticatedUser
   * @param args
   */
  @Mutation()
  @UseGuards(GraphqlAuthGuard)
  @Permissions(PERMISSIONS.IDENTIFICATION_DELETE)
  async deleteSequenceIdentificationOutput(@GraphqlUserWithPermissions(PERMISSIONS.IDENTIFICATION_DELETE) authenticatedUser, @Args() args) {
    const { id } = args;
    return this.sequenceIdentificationOutputsService.remove(id, { authenticatedUser, params: args });
  }

}
