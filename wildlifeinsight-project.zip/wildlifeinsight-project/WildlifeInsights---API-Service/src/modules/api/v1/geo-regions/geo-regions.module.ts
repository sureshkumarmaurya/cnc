import { GeoRegionService } from './geo-regions.service';
import { Module } from '@nestjs/common';
import { GeoRegionResolver } from './geo-regions.resolver';
import { DatabaseModule } from 'modules/database/database.module';

@Module({
  imports: [DatabaseModule],
  providers: [GeoRegionService, GeoRegionResolver],
})
export class GeoRegionModule {

}
