import { Resolver, Query, Args } from '@nestjs/graphql';
import { GeoRegionService } from './geo-regions.service';
import { UseGuards } from '@nestjs/common';
import { GraphqlAuthGuard } from 'guards/graphql-passport.guard';
import { GraphqlUserWithPermissions } from 'decorators/graphql-user.decorator';

const logger = require('logger');

@Resolver('GeoRegions')
export class GeoRegionResolver {
  constructor(private readonly geoRegionService: GeoRegionService) {}

  @Query()
  @UseGuards(GraphqlAuthGuard)
  async reverseGeocodeCountryFromCoordinates(@GraphqlUserWithPermissions() authenticatedUser, @Args() args) {
    const { longitude, latitude } = args;
    logger.info(`Reverse geocode country from coordinates: ${longitude} ${latitude}`);
    const countryCode = await this.geoRegionService.reverseGeocodeCountryFromCoordinates(longitude, latitude);

    return countryCode;
  }
}
