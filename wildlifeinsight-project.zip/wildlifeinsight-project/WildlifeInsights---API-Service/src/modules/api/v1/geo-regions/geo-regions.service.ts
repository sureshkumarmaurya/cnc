import { Repository } from 'typeorm';
import { Injectable, Inject } from '@nestjs/common';
import { Countries } from 'modules/database/entities/countries.entity';

@Injectable()
export class GeoRegionService {
  constructor(
    @Inject('CountriesRepositoryToken') private readonly countriesRepository: Repository<Countries>,
  ) {}

  /**
   * Given a point as (longitude, latitude), return the country within whose
   * boundaries the point falls, if any.
   *
   * @param longitude Longitude of the point to reverse-geocode
   * @param latitude Latitude of the point to reverse-geocode
   */
  async reverseGeocodeCountryFromCoordinates(longitude: number, latitude: number) {
    const country = await this.countriesRepository
      .createQueryBuilder('country')
      .innerJoinAndSelect('country.geoRegion', 'geo_region')
      .where('ST_Intersects(geo_region.region::geometry, ST_SetSRID(ST_Point(:longitude, :latitude), 4326))', { longitude, latitude })
      .getOne();

    if (country) {
      return {
        name: country.name,
        officialName: country.officialName,
        countryCodeISO3166Alpha2: country.iso3166A2,
        countryCodeISO3166Alpha3: country.iso3166A3,
      };
    }
    return null;
  }
}
