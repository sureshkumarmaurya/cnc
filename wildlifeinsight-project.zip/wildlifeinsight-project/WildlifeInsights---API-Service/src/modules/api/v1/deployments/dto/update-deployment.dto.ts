import { IsDefined, IsString, IsInt, IsNumber, IsOptional, MaxLength, IsISO8601, ValidateIf,  ValidateNested } from 'class-validator';
import { ApiModelProperty } from '@nestjs/swagger';
import { IsMetaPropertyExists } from "../../../../../decorators/validation/metaProperty";

export class UpdateDeploymentDto {

  @IsString()
  @MaxLength(255)
  @IsOptional()
  @ApiModelProperty({ required: false })
  deploymentIdentifier: string;

  @IsString()
  @MaxLength(255)
  @ApiModelProperty({ required: true })
  deploymentName: string;

  @IsString()
  @IsDefined()
  @ApiModelProperty({ required: true })
  sensorHeight: string | null;

  // @ValidateIf(o => o.quietPeriod instanceof Date === false)
  // @IsISO8601()
  @IsNumber()
  @IsDefined()
  @ApiModelProperty({ required: true })
  quietPeriod: number | null;

  @IsNumber()
  @IsOptional()
  @ApiModelProperty({ required: false })
  detectionDistance: number | null;

  @IsString()
  @MaxLength(255)
  @IsOptional()
  @ApiModelProperty({ required: false })
  sampleRate: string | null;

  @IsString()
  @MaxLength(255)
  @IsDefined()
  @ApiModelProperty({ required: true })
  sensorOrientation: string | null;

  @IsString()
  @MaxLength(255)
  @IsOptional()
  @ApiModelProperty({ required: false })
  sensorSchedule: string | null;

  @IsString()
  @MaxLength(255)
  @IsOptional()
  @ApiModelProperty({ required: false })
  sensorResolution: string | null;

  @IsString()
  @MaxLength(255)
  @IsOptional()
  @ApiModelProperty({ required: false })
  sensorSensitivity: string | null;

  @IsString()
  @IsDefined()
  @ApiModelProperty({ required: true })
  sensorFailureDetails: string | null;

  @IsString()
  @MaxLength(255)
  @IsOptional()
  @ApiModelProperty({ required: false })
  sensorEndStatus: string | null;

  @ValidateIf(o => !(o.startDatetime instanceof Date))
  @IsISO8601()
  @IsDefined()
  @ApiModelProperty({ required: true })
  startDatetime: Date | null;

  @ValidateIf(o => !(o.endDatetime instanceof Date))
  @IsISO8601()
  @IsDefined()
  @ApiModelProperty({ required: true })
  endDatetime: Date | null;

  @IsString()
  @IsOptional()
  @ApiModelProperty({ required: false })
  remarks: string | null;

  @IsInt()
  @IsDefined()
  @ApiModelProperty({ required: true })
  deviceId: number;

  @IsInt()
  @IsOptional()
  @ApiModelProperty({ required: false })
  subprojectId: number;

  @IsInt()
  @IsOptional()
  @ApiModelProperty({ required: false })
  baitTypeId: number;

  @IsInt()
  @IsDefined()
  @ApiModelProperty({ required: true })
  locationId: number;

  @IsInt()
  @IsOptional()
  @ApiModelProperty({ required: false })
  participantSetSensorId: number;

  @IsInt()
  @IsOptional()
  @ApiModelProperty({ required: false })
  participantRemoveSensorId: number;

  @IsDefined()
  @IsMetaPropertyExists(['feature_type'])
  @ApiModelProperty({ required: true })
  metadata: object;

  @IsString()
  @IsDefined()
  @ApiModelProperty({ required: true })
  baitTypeName: string | null;
}
