import { Permissions } from 'decorators/permissions.decorator';
import { UpdateDeploymentDto } from './dto/update-deployment.dto';
import { CreateDeploymentDto } from './dto/create-deployment.dto';
import { Get, Controller, Req, Post, Body, Patch, Param, Delete, ParseIntPipe, UseGuards, Query } from '@nestjs/common';
import { DeploymentService } from './deployment.service';
import { ApiUseTags, ApiBearerAuth, ApiOperation, ApiResponse, ApiImplicitQuery, ApiImplicitParam } from '@nestjs/swagger';
import { DeploymentsPaginatedDto } from './dto/deployments.dto';
import { Pagination } from 'decorators/pagination.decorator';
import { ValidationPipe } from 'pipes/validation.pipe';
import { DeploymentsDto } from 'modules/database/dto/deployments.dto';
import { PermissionsGuard } from 'guards/permissions.guard';
import { User } from 'decorators/user.decorator';
import { AuthenticatedUserDto } from 'dto/authenticated-user.dto';
import { PERMISSIONS } from 'utils/permissions.enum';
import { PaginationModel } from 'utils/pagination.model';

const logger = require('logger');

export const deploymentsRelations = ['features', 'device', 'subproject'];

@Controller('/api/v1/project/:projectId/deployment')
@ApiUseTags('Deployments')
@ApiBearerAuth()
@UseGuards(PermissionsGuard)
export class DeploymentController {
  constructor(private readonly deploymentService: DeploymentService) { }

  @Get()
  @ApiOperation({
    title: 'Get Deployments by project', description: `
    Get all deployments:
  `, operationId: 'GetAllDeploymentsByProject',
  })
  @ApiResponse({ status: 200, description: 'Deployments have been successfully returned', isArray: false, type: DeploymentsPaginatedDto })
  @ApiResponse({ status: 403, description: 'Not authorized.' })
  @ApiResponse({ status: 401, description: 'Not authenticated.' })
  @ApiImplicitParam({ name: 'projectId', description: 'Project the deployment belongs to', type: Number, required: true })
  @ApiImplicitQuery({
    name: 'includes', description: `
  Allows include the Deployments's relations. Available ${deploymentsRelations}
  `, type: String, required: false,
  })
  @ApiImplicitQuery({ name: 'fields', description: 'Deployments\'s fields to select', type: String, required: false })
  @ApiImplicitQuery({ name: 'page[size]', description: 'Page size. Default 10', type: String, required: false })
  @ApiImplicitQuery({ name: 'page[number]', description: 'Page number', type: String, required: false })
  @ApiImplicitQuery({ name: 'sort', description: 'Sort results', type: String, required: false })
  @ApiImplicitQuery({ name: 'locationIds', description: 'Filter by locations', type: String, required: false, collectionFormat: 'csv' })
  @ApiImplicitQuery({ name: 'name', description: 'Filter by name', type: String, required: false })
  @Permissions(PERMISSIONS.DEPLOYMENT_GET_ALL)
  async findAll(@Pagination() pagination: PaginationModel, @Param() params, @User() authenticatedUser: AuthenticatedUserDto, @Query() filters) {
    logger.info('Getting all');
    if (filters.locationIds) {
      filters.locationIds = filters.locationIds.split(',');
    }
    const data = await this.deploymentService.findAll(pagination, { authenticatedUser, params }, filters);
    return new DeploymentsPaginatedDto(data[0], data[1], pagination.pageSize, pagination.pageNumber);
  }

  @Get('/:id')
  @ApiOperation({
    title: 'Get deployment by id', description: `
    Get deployment by id
  `, operationId: 'GetDeploymentById',
  })
  @ApiImplicitQuery({
    name: 'includes', description: `
  Allows include the Deployments's relations. Available ${deploymentsRelations}
  `, type: String, required: false,
  })
  @ApiImplicitParam({ name: 'projectId', description: 'Project the deployment belongs to', type: Number, required: true })
  @ApiImplicitParam({ name: 'id', description: 'Id of the deployment' })
  @ApiResponse({ status: 200, description: 'Deployment has been successfully returned', isArray: false, type: DeploymentsDto })
  @ApiResponse({ status: 404, description: 'Deployment does not exist or you don\'t have permission' })
  @ApiResponse({ status: 401, description: 'Not authenticated.' })
  @Permissions(PERMISSIONS.DEPLOYMENT_GET_ONE)
  async getById(@Param('id', new ParseIntPipe()) id: number, @User() authenticatedUser: AuthenticatedUserDto, @Param() params, @Pagination() pagination: PaginationModel) {
    logger.info('Get by id ', id);
    return await this.deploymentService.getById(id, pagination, { authenticatedUser, params });
  }

  @Post()
  @ApiOperation({
    title: 'Create deployment', description: `
    Create new deployment
  `, operationId: 'CreateDeployment',
  })
  @ApiImplicitParam({ name: 'projectId', description: 'Project the deployment belongs to', type: Number, required: true })
  @ApiResponse({ status: 200, description: 'Deployment has been successfully created', isArray: false, type: DeploymentsDto })
  @ApiResponse({ status: 400, description: 'Body contains errors' })
  @ApiResponse({ status: 401, description: 'Not authenticated.' })
  @Permissions(PERMISSIONS.DEPLOYMENT_CREATE)
  async create(@Body(new ValidationPipe()) createDeploymentDto: CreateDeploymentDto, @User() authenticatedUser: AuthenticatedUserDto, @Param() params) {
    logger.info('Creating deployment');
    return await this.deploymentService.create(createDeploymentDto, { authenticatedUser, params });
  }

  @Patch('/:id')
  @ApiOperation({
    title: 'Update deployment', description: `
    Update deployment
  `, operationId: 'UpdateDeployment',
  })
  @ApiImplicitParam({ name: 'id', description: 'Id of the deployment' })
  @ApiImplicitParam({ name: 'projectId', description: 'Project the deployment belongs to', type: Number, required: true })
  @ApiResponse({ status: 200, description: 'Deployment has been successfully updated', isArray: false, type: DeploymentsDto })
  @ApiResponse({ status: 404, description: 'Deployment does not exist or you don\'t have permission' })
  @ApiResponse({ status: 401, description: 'Not authenticated.' })
  @Permissions(PERMISSIONS.DEPLOYMENT_UPDATE)
  async update(@Param('id', new ParseIntPipe()) id: number, @Body(new ValidationPipe()) updateDeploymentDto: UpdateDeploymentDto, @User() authenticatedUser: AuthenticatedUserDto, @Param() params) {
    logger.info('Updating company');
    return await this.deploymentService.update(id, updateDeploymentDto, { authenticatedUser, params });
  }

  @Delete('/:id')
  @ApiOperation({
    title: 'Delete deployment', description: `
    Delete deployment
  `, operationId: 'DeleteDeployment',
  })
  @ApiImplicitParam({ name: 'projectId', description: 'Project the deployment belongs to', type: Number, required: true })
  @ApiImplicitParam({ name: 'id', description: 'Id of the deployment' })
  @ApiResponse({ status: 200, description: 'Deployment has been successfully deleted', isArray: false, type: DeploymentsDto })
  @ApiResponse({ status: 404, description: 'Deployment does not exist or you don\'t have permission' })
  @ApiResponse({ status: 401, description: 'Not authenticated.' })
  @Permissions(PERMISSIONS.DEPLOYMENT_DELETE)
  async remove(@Param('id', new ParseIntPipe()) id: number, @User() authenticatedUser: AuthenticatedUserDto, @Param() params) {
    logger.info('Deleting deployment');
    return await this.deploymentService.remove(id, { authenticatedUser, params });
  }
}
