import { ApiModelProperty } from '@nestjs/swagger';
import { DeploymentsDto } from 'modules/database/dto/deployments.dto';
import { MetaDto } from 'modules/database/dto/meta.dto';

export class DeploymentsPaginatedDto {

  @ApiModelProperty({ type: DeploymentsDto, isArray: true })
  readonly data: DeploymentsDto[];

  @ApiModelProperty()
  readonly meta: MetaDto;

  constructor(data, totalItems: number, pageSize: number, page: number) {
    this.data = data;
    this.meta = new MetaDto(Math.ceil(totalItems / pageSize), totalItems, pageSize, page);
  }
}
