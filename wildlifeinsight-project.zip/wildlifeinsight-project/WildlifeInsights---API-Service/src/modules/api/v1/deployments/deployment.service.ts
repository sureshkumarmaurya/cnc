import { Participants } from 'modules/database/entities/participants.entity';
import { Sensors } from 'modules/database/entities/sensors.entity';
import { BaitTypes } from 'modules/database/entities/bait-types.entity';
import { UpdateDeploymentDto } from './dto/update-deployment.dto';
import { CreateDeploymentDto } from './dto/create-deployment.dto';
import { Deployments } from 'modules/database/entities/deployments.entity';
import { Repository, SelectQueryBuilder, In } from 'typeorm';
import { Injectable, Inject, NotFoundException, BadRequestException, UnauthorizedException, InternalServerErrorException } from '@nestjs/common';
import { GenericService } from 'utils/generic.service';
import { InfoDto } from 'dto/info.dto';
import { Projects } from 'modules/database/entities/projects.entity';
import { Locations } from 'modules/database/entities/locations.entity';
import { Devices } from 'modules/database/entities/devices.entity';
import { PermissionsUtils } from 'utils/permissions.utils';
import { PERMISSIONS } from 'utils/permissions.enum';
import { ProjectsDto } from 'modules/database/dto/projects.dto';
import { StorageService } from 'modules/google/storage.service';
import { AuthenticatedUserDto } from 'dto/authenticated-user.dto';
import { PaginationModel } from 'utils/pagination.model';

const logger = require('logger');

@Injectable()
export class DeploymentService extends GenericService<Deployments, CreateDeploymentDto, UpdateDeploymentDto>  {

  constructor(
    @Inject('DeploymentsRepositoryToken') private readonly deploymentsRepository: Repository<Deployments>,
    @Inject('ProjectsRepositoryToken') private readonly projectsRepository: Repository<Projects>,
    @Inject('BaitTypesRepositoryToken') private readonly baitTypesRepository: Repository<BaitTypes>,
    @Inject('LocationsRepositoryToken') private readonly locationsRepository: Repository<Locations>,
    @Inject('SensorsRepositoryToken') private readonly sensorsRepository: Repository<Sensors>,
    @Inject('ParticipantsRepositoryToken') private readonly participantsRepository: Repository<Participants>,
    @Inject('DevicesRepositoryToken') private readonly devicesRepository: Repository<Devices>,
    private readonly storageService: StorageService,
  ) {
    super(deploymentsRepository, 'deployment');
  }

  setFilters(query: SelectQueryBuilder<Deployments>, filters: any, info: InfoDto) {
    if (info && info.params && info.params.projectId) {
      query.where('deployment.projectId = :projectId').setParameter('projectId', info.params.projectId);
    }
    if (info.others && info.others.projectIds) {
      query.andWhere('deployment.projectId in (:...projectIds)').setParameter('projectIds', info.others.projectIds);
    }
    if (filters && filters.locationId) {
      query.andWhere('deployment.locationId in (:...locationId)').setParameter('locationId', filters.locationId);
    }
    if (filters && filters.name) {
      query.andWhere('lower(deployment.deploymentName) like :name').setParameter('name', `%${filters.name.toLowerCase()}%`);
    }
    if (filters && filters.baitTypeName) {
      query.innerJoin('deployment.baitType', 'baitType');
      query.andWhere('baitType.typeName=:typeName').setParameter('typeName', filters.baitTypeName);
    }
    if (filters && filters.baitTypeDescription && filters.baitTypeDescription.length > 0) {
      query.innerJoin('deployment.baitType', 'baitType');
      query.andWhere('baitType.description=:description').setParameter('description', filters.baitTypeDescription);
    }
    return query;
  }

  setFiltersGetById(query: SelectQueryBuilder<Deployments>, info: InfoDto) {
    query
    .andWhere('deployment.projectId = :projectId')
    .setParameter('projectId', info.params.projectId);
    return query;
  }

  setFiltersDelete(query: SelectQueryBuilder<Deployments>, info: InfoDto) {
    query.andWhere('deployment.projectId = :projectId').setParameter('projectId', info.params.projectId);
    return query;
  }

  setFiltersUpdate(query: SelectQueryBuilder<Deployments>, info: InfoDto) {
    query.andWhere('deployment.projectId = :projectId').setParameter('projectId', info.params.projectId);
    return query;
  }

  async getBaitTypeById(id: number): Promise<BaitTypes> {
    return id ? this.baitTypesRepository.findOne(id) : null;
  }

  async getLocationById(id: number): Promise<Locations> {
    return id ? this.locationsRepository.findOne(id) : null;
  }

  async getParticipantById(id: number): Promise<Participants> {
    return id ? this.participantsRepository.findOne(id) : null;
  }

  async getProjectById(id: number): Promise<Projects> {
    return id ? this.projectsRepository.findOne(id) : null;
  }

  /**
   * Retrieve device (camera) data from its numeric id.
   *
   * We first check if the current user has a role on the device's parent
   * organization, as only in this case users are allowed to see devices
   * information.
   */
  async getDeviceById(id: number, authenticatedUser : AuthenticatedUserDto): Promise<Devices | null> {
    const organizationsOnWhichUserHasAnyRoles : number[] = authenticatedUser.organizationRole.map(item => item.organization.id);
    if (organizationsOnWhichUserHasAnyRoles.length > 0) {
      return this.devicesRepository.findOne({ where: { id, organizationId: In(organizationsOnWhichUserHasAnyRoles) } });
    }
    return null;
  }

  async findAllInOrganization(organizationId: number, pagination: PaginationModel, info?: InfoDto, filters: any = null): Promise<[Deployments[], number]> {
    // getting project of organizationId with view deployment permission
    const projectIds = PermissionsUtils.getProjectsInOrganizationWithPermission(info.authenticatedUser, PERMISSIONS.DEPLOYMENT_GET_ALL, organizationId);
    if (!projectIds || projectIds.length === 0) {
      return [[], 0];
    }
    info.others = { ...info.others, projectIds: projectIds.map((p: ProjectsDto) => p.id) };
    return this.findAll(pagination, info, filters);
  }

  async findAllWithoutOrganization(pagination: PaginationModel, info?: InfoDto, filters: any = null): Promise<[Deployments[], number]> {
    // getting project of all organizations with view deployment permission
    const projectIds = PermissionsUtils.getProjectsInAllOrganizationsWithPermission(info.authenticatedUser, PERMISSIONS.DEPLOYMENT_GET_ALL);
    if (!projectIds || projectIds.length === 0) {
      return [[], 0];
    }
    info.others = { ...info.others, projectIds: projectIds.map((p: ProjectsDto) => p.id) };
    return this.findAll(pagination, info, filters);
  }

  async validateBeforeCreate(createModel: CreateDeploymentDto, info: InfoDto): Promise<void> {
    if (createModel.sensorId) {
      const sensor = await this.sensorsRepository.findOne(createModel.sensorId);
      if (!sensor) {
        throw new NotFoundException(`Sensor not found with id ${createModel.sensorId}`);
      }
    }
    if (createModel.locationId) {
      const location = await this.locationsRepository.findOne(createModel.locationId);
      if (!location) {
        throw new NotFoundException(`Location not found with id ${createModel.locationId}`);
      }
    }
    if (createModel.baitTypeId) {
      const baitType = await this.baitTypesRepository.findOne(createModel.baitTypeId);
      if (!baitType) {
        throw new NotFoundException(`Bait type not found with id ${createModel.baitTypeId}`);
      }
    }
    if (createModel.participantRemoveSensorId) {
      const participant = await this.participantsRepository.findOne(createModel.participantRemoveSensorId);
      if (!participant) {
        throw new NotFoundException(`Participant remove not found with id ${createModel.participantRemoveSensorId}`);
      }
    }

    if (createModel.participantSetSensorId) {
      const participant = await this.participantsRepository.findOne(createModel.participantSetSensorId);
      if (!participant) {
        throw new NotFoundException(`Participant remove not found with id ${createModel.participantSetSensorId}`);
      }
    }

    if (createModel.baitTypeName) {
      const baitType = await this.baitTypesRepository.findOne({ typeName: createModel.baitTypeName });
      if (!baitType) {
        throw new NotFoundException(`Bait type not found with name ${createModel.baitTypeName}`);
      }
    }
  }

  async setDataCreate(create: CreateDeploymentDto, info: InfoDto) {
    const project = await this.projectsRepository.findOne(info.params.projectId);

    if (!create.baitTypeId && create.baitTypeName) {
      const { id } = await this.baitTypesRepository.findOne({ typeName: create.baitTypeName });
      create.baitTypeId = id;
    }

    const model = new Deployments();

    model.remarks = create.remarks;
    model.project = project;
    model.participantRemoveSensorId = create.participantRemoveSensorId;
    model.participantSetSensorId = create.participantSetSensorId;
    model.deviceId = create.deviceId;
    model.locationId = create.locationId;
    model.baitTypeId = create.baitTypeId;

    model.deploymentIdentifier = create.deploymentIdentifier;
    model.deploymentName = create.deploymentName;
    model.sensorHeight = create.sensorHeight;
    model.quietPeriod = create.quietPeriod;
    model.detectionDistance = create.detectionDistance;
    model.sampleRate = create.sampleRate;
    model.sensorOrientation = create.sensorOrientation;
    model.sensorSchedule = create.sensorSchedule;
    model.sensorResolution = create.sensorResolution;
    model.sensorSensitivity = create.sensorSensitivity;
    model.sensorFailureDetails = create.sensorFailureDetails;
    model.sensorEndStatus = create.sensorEndStatus;
    model.metadata = create.metadata;
    model.subprojectId = create.subprojectId;
    if (create.startDatetime) {
      model.startDatetime = new Date(create.startDatetime);
    }
    if (create.endDatetime) {
      model.endDatetime = new Date(create.endDatetime);
    }

    return model;

  }

  async validateBeforeUpdate(id:number, updateModel: UpdateDeploymentDto, info?: InfoDto): Promise<void> {
    if (updateModel.baitTypeName) {
      const baitType = await this.baitTypesRepository.findOne({ typeName: updateModel.baitTypeName });
      if (!baitType) {
        throw new Error(`Bait type not found with name ${updateModel.baitTypeName}`);
      }
    }
  }

  async setDataUpdate(model: Deployments, update: UpdateDeploymentDto, info: InfoDto) {

    if (!update.baitTypeId && update.baitTypeName) {
      const { id } = await this.baitTypesRepository.findOne({ typeName: update.baitTypeName });
      update.baitTypeId = id;
    }

    if (update.remarks !== undefined) {
      model.remarks = update.remarks;
    }
    if (update.participantRemoveSensorId !== undefined) {
      model.participantRemoveSensorId = update.participantRemoveSensorId;
    }
    if (update.participantSetSensorId !== undefined) {
      model.participantSetSensorId = update.participantSetSensorId;
    }
    if (update.deviceId !== undefined) {
      model.deviceId = update.deviceId;
    }
    if (update.locationId !== undefined) {
      model.locationId = update.locationId;
    }
    if (update.baitTypeId !== undefined) {
      model.baitTypeId = update.baitTypeId;
    }
    if (update.deploymentIdentifier !== undefined) {
      model.deploymentIdentifier = update.deploymentIdentifier;
    }
    if (update.deploymentName !== undefined) {
      model.deploymentName = update.deploymentName;
    }
    if (update.sensorHeight !== undefined) {
      model.sensorHeight = update.sensorHeight;
    }
    if (update.quietPeriod !== undefined) {
      model.quietPeriod = update.quietPeriod;
    }
    if (update.detectionDistance !== undefined) {
      model.detectionDistance = update.detectionDistance;
    }
    if (update.sampleRate !== undefined) {
      model.sampleRate = update.sampleRate;
    }
    if (update.sensorOrientation !== undefined) {
      model.sensorOrientation = update.sensorOrientation;
    }
    if (update.sensorSchedule !== undefined) {
      model.sensorSchedule = update.sensorSchedule;
    }
    if (update.sensorResolution !== undefined) {
      model.sensorResolution = update.sensorResolution;
    }
    if (update.sensorSensitivity !== undefined) {
      model.sensorSensitivity = update.sensorSensitivity;
    }
    if (update.sensorFailureDetails !== undefined) {
      model.sensorFailureDetails = update.sensorFailureDetails;
    }
    if (update.sensorEndStatus !== undefined) {
      model.sensorEndStatus = update.sensorEndStatus;
    }

    if (update.startDatetime !== undefined) {
      model.startDatetime = new Date(update.startDatetime);
    }
    if (update.endDatetime !== undefined) {
      model.endDatetime = new Date(update.endDatetime);
    }
    if (update.metadata !== undefined) {
      model.metadata = update.metadata;
    }
    if (update.subprojectId !== undefined) {
      model.subprojectId = update.subprojectId;
    }

    return model;
  }

  async remove(id: number, info?: InfoDto): Promise<Deployments> {
    logger.debug('Removing deployment');
    try {
      const projectSlug = await this.projectsRepository.findOne(info.params.projectId).then(project => project.slug);
      await this.storageService.deleteWIDeployment(projectSlug, info.params.id);
    } catch (err) {
      throw new InternalServerErrorException(`Error deleting storage blobs of deployment with id ${info.params.id}: ${err}`);
    }
    return await super.remove(id, info);
  }

}
