import { CreateDeploymentDto } from './dto/create-deployment.dto';
import { DeploymentService } from './deployment.service';
import { Resolver, Query, ResolveProperty, Mutation, Args, Parent } from '@nestjs/graphql';
import { UpdateDeploymentDto } from './dto/update-deployment.dto';
import { UseInterceptors, UseGuards } from '@nestjs/common';
import { ValidationGraphqlInterceptor } from 'interceptors/validation-graphql.interceptor';
import { PaginationGraphqlInterceptor } from 'interceptors/pagination-graphql.interceptor';
import { Permissions } from 'decorators/permissions.decorator';
import { GraphqlUserWithPermissions } from 'decorators/graphql-user.decorator';
import { GraphqlAuthGuard } from 'guards/graphql-passport.guard';
import { Deployments } from 'modules/database/entities/deployments.entity';
import { PERMISSIONS } from 'utils/permissions.enum';
import { DeploymentsPaginatedDto } from './dto/deployments.dto';
import { AuthenticatedUserDto } from 'dto/authenticated-user.dto';

const logger = require('logger');

@Resolver('Deployment')
export class DeploymentResolver {
  constructor(private readonly deploymentService: DeploymentService) {}

  @Query()
  @UseGuards(GraphqlAuthGuard)
  @UseInterceptors(PaginationGraphqlInterceptor)
  @Permissions(PERMISSIONS.DEPLOYMENT_GET_ALL)
  async getDeploymentsByProject(@GraphqlUserWithPermissions(PERMISSIONS.DEPLOYMENT_GET_ALL) authenticatedUser, @Args() args) {
    const data = await this.deploymentService.findAll(args.pagination, { authenticatedUser, params: args }, args.filters);
    return new DeploymentsPaginatedDto(data[0], data[1], args.pagination.pageSize, args.pagination.pageNumber);
  }

  @Query()
  @UseGuards(GraphqlAuthGuard)
  @Permissions(PERMISSIONS.DEPLOYMENT_GET_ONE)
  async getDeployment(@GraphqlUserWithPermissions(PERMISSIONS.DEPLOYMENT_GET_ONE) authenticatedUser, @Args() args) {
    const { id } = args;
    return this.deploymentService.getById(id, {}, { authenticatedUser, params: args });
  }

  @Query()
  @UseGuards(GraphqlAuthGuard)
  @UseInterceptors(PaginationGraphqlInterceptor)
  async getDeploymentsByOrganization(@GraphqlUserWithPermissions() authenticatedUser, @Args() args) {
    const data =  await this.deploymentService.findAllInOrganization(args.organizationId, args.pagination, { authenticatedUser, params: args }, args.filters);
    return new DeploymentsPaginatedDto(data[0], data[1], args.pagination.pageSize, args.pagination.pageNumber);
  }

  @Query()
  @UseGuards(GraphqlAuthGuard)
  @UseInterceptors(PaginationGraphqlInterceptor)
  async getDeployments(@GraphqlUserWithPermissions() authenticatedUser, @Args() args) {
    const data = await this.deploymentService.findAllWithoutOrganization(args.pagination, { authenticatedUser, params: args }, args.filters);
    return new DeploymentsPaginatedDto(data[0], data[1], args.pagination.pageSize, args.pagination.pageNumber);
  }

  @ResolveProperty()
  async project(@Parent() deployment: Deployments) {
    return this.deploymentService.getProjectById(deployment.projectId);
  }

  @ResolveProperty()
  async baitType(@Parent() deployment: Deployments) {
    return this.deploymentService.getBaitTypeById(deployment.baitTypeId);
  }

  @ResolveProperty()
  async location(@Parent() deployment: Deployments) {
    return this.deploymentService.getLocationById(deployment.locationId);
  }

  @ResolveProperty()
  async participantSetSensor(@Parent() deployment: Deployments) {
    return this.deploymentService.getParticipantById(deployment.participantSetSensorId);
  }

  @ResolveProperty()
  async participantRemoveSensor(@Parent() deployment: Deployments) {
    return this.deploymentService.getParticipantById(deployment.participantRemoveSensorId);
  }

  @ResolveProperty()
  @UseGuards(GraphqlAuthGuard)
  async device(@GraphqlUserWithPermissions() authenticatedUser : AuthenticatedUserDto, @Parent() deployment: Deployments) {
    return this.deploymentService.getDeviceById(deployment.deviceId, authenticatedUser);
  }

  @Mutation()
  @UseGuards(GraphqlAuthGuard)
  @UseInterceptors(new ValidationGraphqlInterceptor(CreateDeploymentDto))
  @Permissions(PERMISSIONS.DEPLOYMENT_CREATE)
  async createDeployment(@GraphqlUserWithPermissions(PERMISSIONS.DEPLOYMENT_CREATE) authenticatedUser, @Args() args) {
    const { body } = args;
    return this.deploymentService.create(body, { authenticatedUser, params: args });
  }

  @Mutation()
  @UseGuards(GraphqlAuthGuard)
  @Permissions(PERMISSIONS.DEPLOYMENT_UPDATE)
  @UseInterceptors(new ValidationGraphqlInterceptor(UpdateDeploymentDto))
  async updateDeployment(@GraphqlUserWithPermissions(PERMISSIONS.DEPLOYMENT_UPDATE) authenticatedUser, @Args() args) {
    const { id, body } = args;
    return this.deploymentService.update(id, body, { authenticatedUser, params: args });
  }

  @Mutation()
  @UseGuards(GraphqlAuthGuard)
  @Permissions(PERMISSIONS.DEPLOYMENT_DELETE)
  async deleteDeployment(@GraphqlUserWithPermissions(PERMISSIONS.DEPLOYMENT_DELETE) authenticatedUser, @Args() args) {
    const { id } = args;
    return this.deploymentService.remove(id, { authenticatedUser, params: args });
  }
}
