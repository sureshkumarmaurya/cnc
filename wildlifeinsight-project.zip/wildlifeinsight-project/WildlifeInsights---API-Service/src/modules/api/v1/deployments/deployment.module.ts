import { DeploymentController, deploymentsRelations } from './deployment.controller';
import { DeploymentService } from './deployment.service';
import { Module, RequestMethod, MiddlewareConsumer } from '@nestjs/common';
import { PaginationMiddleware } from 'middlewares/pagination.middleware';
import { DeploymentResolver } from './deployment.resolver';
import { DatabaseModule } from 'modules/database/database.module';
import { GoogleModule } from 'modules/google/google.module';
import { DeploymentGeneralController } from './deployment-general.controller';

@Module({
  imports: [DatabaseModule, GoogleModule],
  controllers: [DeploymentController, DeploymentGeneralController],
  providers: [DeploymentService, DeploymentResolver],
})
export class DeploymentModule {
  public configure(consumer: MiddlewareConsumer) {
    consumer
      .apply(PaginationMiddleware)
      .with({ includes: [], allowIncludes: deploymentsRelations })
      .forRoutes(
        { path: '/api/v1/project/:projectId/deployment', method: RequestMethod.GET },
        { path: '/api/v1/project/:projectId/deployment/:deploymentId', method: RequestMethod.GET },
        { path: '/api/v1/organization/:organizationId/deployment', method: RequestMethod.GET },
        { path: '/api/v1/deployment', method: RequestMethod.GET },
      );
  }
}
