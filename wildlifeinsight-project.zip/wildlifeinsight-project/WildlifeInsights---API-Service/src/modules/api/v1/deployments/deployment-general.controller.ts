import { Get, Controller, Param, Query, ParseIntPipe } from '@nestjs/common';
import { DeploymentService } from './deployment.service';
import { ApiUseTags, ApiBearerAuth, ApiOperation, ApiResponse, ApiImplicitQuery, ApiImplicitParam } from '@nestjs/swagger';
import { DeploymentsPaginatedDto } from './dto/deployments.dto';
import { Pagination } from 'decorators/pagination.decorator';
import { User } from 'decorators/user.decorator';
import { AuthenticatedUserDto } from 'dto/authenticated-user.dto';
import { PaginationModel } from 'utils/pagination.model';

const logger = require('logger');

export const deploymentsRelations = ['features', 'device'];

@Controller('/api/v1')
@ApiUseTags('Deployments')
@ApiBearerAuth()
export class DeploymentGeneralController {
  constructor(private readonly deploymentService: DeploymentService) { }

  @Get('/organization/:organizationId/deployment')
  @ApiOperation({
    title: 'Get Deployments of organization', description: `
    Get all deployments:
  `, operationId: 'GetAllDeploymentsByOrganization',
  })
  @ApiResponse({ status: 200, description: 'Deployments have been successfully returned', isArray: false, type: DeploymentsPaginatedDto })
  @ApiResponse({ status: 403, description: 'Not authorized.' })
  @ApiResponse({ status: 401, description: 'Not authenticated.' })
  @ApiImplicitQuery({
    name: 'includes', description: `
  Allows include the Deployments's relations. Available ${deploymentsRelations}
  `, type: String, required: false,
  })
  @ApiImplicitQuery({ name: 'fields', description: 'Deployments\'s fields to select', type: String, required: false })
  @ApiImplicitQuery({ name: 'page[size]', description: 'Page size. Default 10', type: String, required: false })
  @ApiImplicitQuery({ name: 'page[number]', description: 'Page number', type: String, required: false })
  @ApiImplicitQuery({ name: 'sort', description: 'Sort results', type: String, required: false })
  @ApiImplicitQuery({ name: 'name', description: 'Filter by name', type: String, required: false })
  @ApiImplicitParam({ name: 'organizationId', description: 'Organization the deployment belongs to', type: Number, required: true })
  async findAllByOrganization(@Param('organizationId', new ParseIntPipe()) organizationId: number, @Query() filters, @Pagination() pagination: PaginationModel, @Param() params, @User() authenticatedUser: AuthenticatedUserDto) {
    logger.info('Getting all');
    const data = await this.deploymentService.findAllInOrganization(organizationId, pagination, { authenticatedUser, params }, filters);
    return new DeploymentsPaginatedDto(data[0], data[1], pagination.pageSize, pagination.pageNumber);
  }

  @Get('/deployment')
  @ApiOperation({
    title: 'Get Deployments ', description: `
    Get all deployments:
  `, operationId: 'GetAllDeployments',
  })
  @ApiResponse({ status: 200, description: 'Deployments have been successfully returned', isArray: false, type: DeploymentsPaginatedDto })
  @ApiResponse({ status: 403, description: 'Not authorized.' })
  @ApiResponse({ status: 401, description: 'Not authenticated.' })
  @ApiImplicitQuery({
    name: 'includes', description: `
  Allows include the Deployments's relations. Available ${deploymentsRelations}
  `, type: String, required: false,
  })
  @ApiImplicitQuery({ name: 'fields', description: 'Deployments\'s fields to select', type: String, required: false })
  @ApiImplicitQuery({ name: 'page[size]', description: 'Page size. Default 10', type: String, required: false })
  @ApiImplicitQuery({ name: 'page[number]', description: 'Page number', type: String, required: false })
  @ApiImplicitQuery({ name: 'sort', description: 'Sort results', type: String, required: false })
  @ApiImplicitQuery({ name: 'name', description: 'Filter by name', type: String, required: false })
  async findAll(@Query() filters, @Pagination() pagination: PaginationModel, @Param() params, @User() authenticatedUser: AuthenticatedUserDto) {
    logger.info('Getting all');
    const data = await this.deploymentService.findAllWithoutOrganization(pagination, { authenticatedUser, params }, filters);
    return new DeploymentsPaginatedDto(data[0], data[1], pagination.pageSize, pagination.pageNumber);
  }

}
