import { Repository, getManager } from 'typeorm';
import { Injectable, Inject, BadRequestException } from '@nestjs/common';
import { Organizations } from 'modules/database/entities/organizations.entity';
import { Projects } from 'modules/database/entities/projects.entity';
import { CreateInitDataDto } from './dto/create-init-data.dto';
import { Roles } from 'modules/database/entities/roles.entity';
import { ParticipantTypes } from 'modules/database/entities/participant-types.entity';
import { RoleChanges } from 'modules/database/entities/role-changes.entity';
import { Participants } from 'modules/database/entities/participants.entity';
import { SlugUtils, NameUtils } from 'utils/slug.utils';
import { ROLES } from 'utils/roles.enum';
import { ParticipantTypeProjectPivot } from 'modules/database/entities/participant-type-project-pivot.entity';
import { UpdateRoleChangesDto } from 'modules/api/v1/role-changes/dto/update-role-changes.dto';
import { OrganizationParticipantPivot } from 'modules/database/entities/organization-participant-pivot.entity';
import { StorageService } from 'modules/google/storage.service';
import { RoleChangesService } from 'modules/api/v1/role-changes/role-changes.service';
import { MailService } from 'utils/mail.utils';
import { DatabaseOperationsDto } from './dto/database-operations.dto';

const logger = require('logger');
const _ = require('lodash');

export type DatabaseOperationType = 'refresh_materialized_view' | 'execute_function';

@Injectable()
export class ManageService  {

  constructor(
    @Inject('RolesRepositoryToken') private readonly rolesRepository: Repository<Roles>,
    @Inject('ParticipantTypesRepositoryToken') private readonly participantTypesRepository: Repository<ParticipantTypes>,
    @Inject('ProjectsRepositoryToken') private readonly projectsRepository: Repository<Projects>,
    @Inject('OrganizationParticipantPivotRepositoryToken') private readonly organizationParticipantPivotRepository: Repository<OrganizationParticipantPivot>,
    @Inject('OrganizationsRepositoryToken') private readonly organizationsRepository: Repository<Organizations>,
    @Inject('RoleChangesRepositoryToken') private readonly roleChangesRepository: Repository<RoleChanges>,
    @Inject('ParticipantsRepositoryToken') private readonly participantsRepository: Repository<Participants>,

    private readonly storageService: StorageService,
    private readonly roleChangesService: RoleChangesService,
    private readonly mailService: MailService,

  ) {}

  private async generateProjectName() {
    let name;
    let slug;

    while (!slug) {
      name = NameUtils.prefix(`My First Project ${Date.now()}`);
      slug = SlugUtils.convertAndPrefix(name);
      const count = await this.projectsRepository.count({ where: { slug } });
      if (count > 0) {
        slug = null;
      }
    }
    name = 'My First Project';
    return { name, slug };
  }

  private async generateOrganizationName() {
    let name;
    while (!name) {
      name = `My First Organization ${Date.now()}`;
      const count = await this.organizationsRepository.createQueryBuilder('organization')
      .where('lower(organization.name) = :name').setParameters({ name: name.toLowerCase() }).getCount();
      if (count > 0) {
        name = null;
      }
    }
    return name;
  }

  private async createProject(organizationId: number, userId: number) {
    logger.debug('Creating project');

    const infoName = await this.generateProjectName();

    const model = new Projects();
    model.name = infoName.name;
    model.slug = infoName.slug;
    model.status = 'CREATED';
    model.startDate = new Date();

    const principalInvestigatorType = await this.participantTypesRepository.findOne({ where: { name: 'PRINCIPAL INVESTIGATOR' } });
    const projectOwnerRole = await this.rolesRepository.findOne({ where: { slug: ROLES.PROJECT_OWNER } });

    const participantTypeProject = new ParticipantTypeProjectPivot();
    participantTypeProject.startDate = new Date();
    participantTypeProject.startDate = new Date(Date.now() + 24 * 60 * 60 * 1000);
    participantTypeProject.participantId = userId;
    participantTypeProject.role = projectOwnerRole;
    participantTypeProject.participantType = principalInvestigatorType;
    model.participantTypeProjectPivot = [participantTypeProject];

    model.organization = await this.organizationsRepository.findOne(organizationId);

    const project = await this.projectsRepository.save(model);

    await this.storageService.createWIBuckets(model.slug);

    return project;
  }

  private async createOrganization(userId: number): Promise<Organizations> {
    logger.debug('Creating organization');

    const model = new Organizations();
    model.name = await this.generateOrganizationName();

    const organizationParticipant = new OrganizationParticipantPivot();
    organizationParticipant.participantId = userId;
    organizationParticipant.role = await this.rolesRepository.findOne({ where: { slug: ROLES.ORGANIZATION_OWNER } });
    model.organizationParticipantPivot = [organizationParticipant];

    await this.organizationsRepository.save(model);
    return model;

  }

  async createInitData(createInitDataDto: CreateInitDataDto) {
    logger.debug('Creating init data for user ', createInitDataDto.userId);

    const organization = await this.createOrganization(createInitDataDto.userId);
    let project = null;
    try {
      project = this.createProject(organization.id, createInitDataDto.userId);
    } catch (err) {
      logger.error('Error creating project');
      if (organization) {
        this.organizationParticipantPivotRepository.delete({ organizationId: organization.organizationParticipantPivot[0].organizationId });
        this.organizationsRepository.delete(organization.id);
      }
    }

    const { email } = await this.participantsRepository.findOne(createInitDataDto.userId);
    const roleChanges = await this.roleChangesRepository.find({ where: { email, participants_id: null, status: 'new' } });

    const updatePromises = roleChanges.map(roleChange => new Promise((resolve, reject) => {
      const body = new UpdateRoleChangesDto();
      body.participantId = createInitDataDto.userId;
      this.roleChangesService.update(roleChange.id, body)
      .then(res => resolve(res))
      .catch(e => reject(e));
    }));

    try {
      await Promise.all(updatePromises);
    } catch (err) {
      logger.error('Error updating roles changes');
    }

    return { organization, project };

  }

  /**
   * Update whitelisted status for participant and send confirmation mail
   * @param participantId
   * @param whitelisted
   */
  async updateUserWhitelistedStatus(participantId: number, whitelisted: boolean): Promise<boolean> {
    try {
      const participant = await this.participantsRepository
        .createQueryBuilder('p')
        .where('p.id = :participantId', { participantId })
        .getOne();
      const mailService = this.mailService;
      const update = await this.participantsRepository.update({ id: participantId }, { whitelisted });

      if (_.get(update, 'affected', false)) {
        const { email } = await this.roleChangesService.getParticipantData(participantId);
        const messageData = {
          userEmail: participant.email,
        };

        // Only notify user if they have been whitelisted (i.e. not if their
        // whitelisted status has been revoked)
        if (whitelisted) {
          await mailService.sendTransactionalEmail(messageData, [{ address: email }], 'wi-account-whitelisted');
        }

        return true;
      }
      return false;
    } catch (err) {
      logger.error(`Error updating whitelisted status for participant: ${participantId}`, err);
      return false;
    }
  }

  async manageDatabaseOperations(databaseOperations: DatabaseOperationsDto[]) {
    const promises = databaseOperations.map((item: DatabaseOperationsDto) => {
      return new Promise((resolve) => {
        logger.info(`Execute database operation: ${item.operation} for entity: ${item.entity}. Options: ${JSON.stringify(item.options)}`);

        if (item.options && item.options.async) {
          this.executeDatabaseOperation(item.operation, item.entity, item.options && item.options.concurrently);
          resolve(true);
        } else {
          this.executeDatabaseOperation(item.operation, item.entity, item.options && item.options.concurrently)
          .then(res => resolve(res))
          .catch(err => resolve(false));
        }
      });
    });
    await Promise.all(promises);
  }

  async executeDatabaseOperation(operation: DatabaseOperationType, entity: string, concurrently: boolean) {
    const entityManager = getManager();
    let query: string;
    if (operation === 'refresh_materialized_view') {
      // Get list of all materialized view names and reject the request if the
      // `entity` for which the operation has been requested is not an actual
      // materialized view that exists in the database (since we need to use
      // raw SQL here, this should provide some basic input sanitization)
      const allValidMaterializedViews : string[] = await entityManager.query('SELECT matviewname FROM pg_matviews;')
        .then(names => names.map(item => item.matviewname));
      if (!allValidMaterializedViews.includes(entity)) {
        throw new BadRequestException('No such materialized view exists.');
      }
      query = `REFRESH MATERIALIZED VIEW ${concurrently ? 'CONCURRENTLY' : ''} ${entity};`;
    } else if (operation === 'execute_function') {
      // Get list of all function names and reject the request if the
      // `entity` for which the operation has been requested is not an actual
      // function defined in the database (since we need to use
      // raw SQL here, this should provide some basic input sanitization)
      const allValidUserDefinedFunctions : string[] = await entityManager
        .query('SELECT proname FROM pg_proc p JOIN pg_namespace n ON n.oid = p.pronamespace WHERE n.nspname NOT LIKE \'pg%\';')
        .then(names => names.map(item => item.proname));
      if (!allValidUserDefinedFunctions.includes(entity)) {
        throw new BadRequestException('No such user-defined function exists.');
      }
      query = `SELECT ${entity}();`;
    }

    logger.info(`Executing SQL query: '${query}`);
    return entityManager.query(query);
  }

}
