import { ManageController } from './manage.controller';
import { ManageService } from './manage.service';
import { Module, RequestMethod, MiddlewareConsumer } from '@nestjs/common';
import { DatabaseModule } from 'modules/database/database.module';
import { GoogleModule } from 'modules/google/google.module';
import { RoleChangesService } from 'modules/api/v1/role-changes/role-changes.service';
import { ManageResolver } from './manage.resolver';
import { MailService } from 'utils/mail.utils';

@Module({
  imports: [DatabaseModule, GoogleModule],
  controllers: [ManageController],
  providers: [ManageService, RoleChangesService, ManageResolver, MailService],
})
export class ManageModule {
  public configure(consumer: MiddlewareConsumer) {}
}
