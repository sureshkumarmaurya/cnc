import { Controller, Post, Body, UseGuards, ValidationPipe } from '@nestjs/common';
import { ManageService } from './manage.service';
import { ApiUseTags, ApiBearerAuth, ApiOperation, ApiResponse } from '@nestjs/swagger';
import { CreateInitDataDto } from './dto/create-init-data.dto';
import { SuperAdminGuard } from 'guards/super-admin.guard';
import { DatabaseOperationsDto } from './dto/database-operations.dto';
import { Permissions } from 'decorators/permissions.decorator';
import { PERMISSIONS } from 'utils/permissions.enum';
import { PermissionsGuard } from 'guards/permissions.guard';

const logger = require('logger');

@Controller('/api/v1/manage')
@ApiUseTags('Manage')
export class ManageController {
  constructor(private readonly manageService: ManageService) { }

  @Post('/init-data')
  @ApiBearerAuth()
  @UseGuards(SuperAdminGuard)
  @ApiOperation({
    title: 'Init basic data of a user', description: `
    Create a initial organization and project
  `, operationId: 'Init',
  })
  @ApiResponse({ status: 200, description: 'Init data has been successfully created', isArray: false, type: CreateInitDataDto })
  @ApiResponse({ status: 400, description: 'Body contains errors' })
  @ApiResponse({ status: 401, description: 'Not authenticated.' })
  async initBasicData(@Body(new ValidationPipe()) createInitDataDto: CreateInitDataDto) {
    logger.info('Creating manage');
    this.manageService.createInitData(createInitDataDto);
  }

  @Post('/database-operations')
  @ApiBearerAuth()
  @UseGuards(PermissionsGuard)
  @ApiOperation({
    title: 'Manage database operations',
    description: 'Refresh materialized views or execute psql functions',
    operationId: 'ManageDatabaseOperations',
  })
  @ApiResponse({ status: 400, description: 'Body contains errors' })
  @ApiResponse({ status: 401, description: 'Not authenticated.' })
  @Permissions(PERMISSIONS.PERFORM_DB_ADMIN_OPERATIONS)
  async manageDatabaseOperations(@Body(new ValidationPipe()) databaseOperations: DatabaseOperationsDto[]) {
    logger.info('Manage database operations');
    await this.manageService.manageDatabaseOperations(databaseOperations);
  }

}
