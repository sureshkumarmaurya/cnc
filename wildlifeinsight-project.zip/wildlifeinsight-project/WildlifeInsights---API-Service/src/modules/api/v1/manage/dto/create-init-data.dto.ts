import { IsInt } from 'class-validator';

export class CreateInitDataDto {

  @IsInt()
  userId: number;

}
