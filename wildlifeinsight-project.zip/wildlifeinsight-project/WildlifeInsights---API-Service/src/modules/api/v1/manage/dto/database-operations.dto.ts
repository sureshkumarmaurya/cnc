import { IsEnum, IsString, IsObject } from 'class-validator';
import { ApiModelProperty } from '@nestjs/swagger';

import { DatabaseOperationType } from 'modules/api/v1/manage/manage.service';

type DatabaseOperationOptions = {
  async: boolean,
  concurrently: boolean,
};

export class DatabaseOperationsDto {
  @IsEnum(['refresh_materialized_view', 'execute_function'])
    @ApiModelProperty({ required: true })
    operation: DatabaseOperationType;

  @IsString()
    @ApiModelProperty({ required: true })
    entity: string;

  @IsObject()
    @ApiModelProperty({ required: false })
    options: DatabaseOperationOptions;
}
