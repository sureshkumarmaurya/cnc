import { Resolver, Mutation, Args } from '@nestjs/graphql';
import { UseGuards } from '@nestjs/common';
import { GraphqlUserWithPermissions } from 'decorators/graphql-user.decorator';
import { ManageService } from './manage.service';
import { Permissions } from 'decorators/permissions.decorator';
import { GraphqlAuthGuard } from 'guards/graphql-passport.guard';
import { PERMISSIONS } from 'utils/permissions.enum';

@Resolver('Manage')
export class ManageResolver {
  constructor(
    private readonly manageService: ManageService,
  ) {}

  @Mutation()
  @UseGuards(GraphqlAuthGuard)
  @Permissions(PERMISSIONS.PARTICIPANT_ACTIVATE_ACCOUNT)
  /**
   * Set whitelisted status for a list of users.
   */
  async manageUserWhitelistedStatus(@GraphqlUserWithPermissions(PERMISSIONS.PARTICIPANT_ACTIVATE_ACCOUNT) authenticatedUser, @Args() args) {
    const { body } = args;

    const updatingPromises = body.map((item) => {
      return new Promise((resolve) => {
        this.manageService.updateUserWhitelistedStatus(item.participantId, item.whitelisted)
        .then(res => resolve(res))
        .catch(e => resolve(false));
      });
    });

    const result = await Promise.all(updatingPromises);
    return {
      successfulOperationsCount: result.filter(item => item).length,
      failedOperationsCount: result.filter(item => !item).length,
    };
  }

}
