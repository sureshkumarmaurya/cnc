import { DataFileAnnotations } from './entities/data-file-annotations.entity';
import { CommonNames } from './entities/common-names.entity';
import { BaitTypes } from './entities/bait-types.entity';
import { createConnection, Repository, Connection } from 'typeorm';
import { Countries } from './entities/countries.entity';
import { DataFileMetakeys } from './entities/data-file-metakeys.entity';
import { DataFileMetavalues } from './entities/data-file-metavalues.entity';
import { DataFiles } from './entities/data-files.entity';
import { Deployments } from './entities/deployments.entity';
import { Devices } from './entities/devices.entity';
import { DiscoverFilters } from './entities/discover-filters.entity';
import { DiscoverObservations } from './entities/discover-observations.entity';
import { DiscoverProjects } from './entities/discover-projects.entity';
import { ExifDataFilePivot } from './entities/exif-data-file-pivot.entity';
import { ExifTags } from './entities/exif-tags.entity';
import { Features } from './entities/features.entity';
import { FirstOrderDivisions } from './entities/first-order-divisions.entity';
import { GeoRegions } from './entities/geo-regions.entity';
import { IdentificationMetakeys } from './entities/identification-metakeys.entity';
import { IdentificationMetavalues } from './entities/identification-metavalues.entity';
import { IdentificationOutputs } from './entities/identification-outputs.entity';
import { IdentifiedIndividuals } from './entities/identified-individuals.entity';
import { IdentifiedObjects } from './entities/identified-objects.entity';
import { Initiatives } from './entities/initiatives.entity';
import { IucnRedListCategories } from './entities/iucn-red-list-categories.entity';
import { LocalTaxonomies } from './entities/local-taxonomies.entity';
import { Logos } from './entities/logos.entity';
import { Locations } from './entities/locations.entity';
import { MediaTypes } from './entities/media-types.entity';
import { Organizations } from './entities/organizations.entity';
import { PairedDeployments } from './entities/paired-deployments.entity';
import { ParticipantTypeProjectPivot } from './entities/participant-type-project-pivot.entity';
import { ParticipantTypes } from './entities/participant-types.entity';
import { Participants } from './entities/participants.entity';
import { PlacementConfiguration } from './entities/placement-configuration.entity';
import { PreviousIdentifiers } from './entities/previous-identifiers.entity';
import { Projects, ProjectHighlightedPhotos } from './entities/projects.entity';
import { ProjectScienceData } from './entities/project-science-data.entity';
import { Photos } from './entities/photos.entity';
import { Sensors } from './entities/sensors.entity';
import { Sequences } from './entities/sequences.entity';
import { Tags } from './entities/tags.entity';
import { Taxonomies } from './entities/taxonomies.entity';
import { Roles } from './entities/roles.entity';
import { Permissions } from './entities/permissions.entity';
import { Providers } from './entities/providers.entity';
import { IdentificationMethods } from './entities/identification-methods.entity';
import { DataFileSequencePivot } from './entities/data-file-sequence-pivot.entity';
import { OrganizationParticipantPivot } from './entities/organization-participant-pivot.entity';
import { InitiativeParticipantPivot } from './entities/initiative-participant-pivot.entity';
import { IdentificationMethodTaxonomyPivot } from './entities/identification-method-taxonomy-pivot.entity';
import { SequenceIdentificationOutputs } from './entities/sequence-identification-outputs.entity';
import { SequenceIdentifiedObjects } from './entities/sequence-identified-objects.entity';
import { Subprojects } from './entities/subprojects.entity';
import { BatchUploads } from './entities/batch-uploads.entity';
import { BatchDownloads } from './entities/batch-downloads.entity';
import { BatchDownloadsImages } from './entities/batch-downloads-images.entity';
import { RoleChanges } from './entities/role-changes.entity';
import { BatchDownloadsCameras } from './entities/batch-downloads-cameras.entity';
import { BatchDownloadsDeployments } from './entities/batch-downloads-deployments.entity';
import { BatchDownloadsProjects } from './entities/batch-downloads-projects.entity';
import { ProjectsOperationalAnalytics } from './entities/projects-operational-analytics.entity';
import { UsersACLCache } from './entities/users-acl-cache.entity';
import { DataCache } from './entities/data-cache.entity';
import { PublicDownloadRequest } from './entities/public-download-requests.entity';
import * as config from 'config';
import { LatestIdentificationOutputs } from './entities/latest-identification-outputs.entity';

export const databaseProviders = [
  {
    provide: 'DbConnectionToken',
    useFactory: async () => await createConnection({
      type: 'postgres',
      url: process.env.POSTGRES_URL,
      entities: [
        `${__dirname}/entities/*.entity.ts`,
      ],
      migrations: [`${__dirname}/../../../migration/**/*.ts`],
      synchronize: false,
      migrationsRun: true,
      logging: config.get('postgres.logging'),
      cache: false,
    }),
  },
  {
    provide: 'BaitTypesRepositoryToken',
    useFactory: (connection: Connection) => connection.getRepository(BaitTypes),
    inject: ['DbConnectionToken'],
  },
  {
    provide: 'CommonNamesRepositoryToken',
    useFactory: (connection: Connection) => connection.getRepository(CommonNames),
    inject: ['DbConnectionToken'],
  },
  {
    provide: 'CountriesRepositoryToken',
    useFactory: (connection: Connection) => connection.getRepository(Countries),
    inject: ['DbConnectionToken'],
  },
  {
    provide: 'DataFileAnnotationsRepositoryToken',
    useFactory: (connection: Connection) => connection.getRepository(DataFileAnnotations),
    inject: ['DbConnectionToken'],
  },
  {
    provide: 'DataFileMetakeysRepositoryToken',
    useFactory: (connection: Connection) => connection.getRepository(DataFileMetakeys),
    inject: ['DbConnectionToken'],
  },
  {
    provide: 'DataFileMetavaluesRepositoryToken',
    useFactory: (connection: Connection) => connection.getRepository(DataFileMetavalues),
    inject: ['DbConnectionToken'],
  },
  {
    provide: 'DataFilesRepositoryToken',
    useFactory: (connection: Connection) => connection.getRepository(DataFiles),
    inject: ['DbConnectionToken'],
  },
  {
    provide: 'DeploymentsRepositoryToken',
    useFactory: (connection: Connection) => connection.getRepository(Deployments),
    inject: ['DbConnectionToken'],
  },
  {
    provide: 'DevicesRepositoryToken',
    useFactory: (connection: Connection) => connection.getRepository(Devices),
    inject: ['DbConnectionToken'],
  },
  {
    provide: 'DiscoverFiltersToken',
    useFactory: (connection: Connection) => connection.getRepository(DiscoverFilters),
    inject: ['DbConnectionToken'],
  },
  {
    provide: 'DiscoverObservationsToken',
    useFactory: (connection: Connection) => connection.getRepository(DiscoverObservations),
    inject: ['DbConnectionToken'],
  },
  {
    provide: 'DiscoverProjectsToken',
    useFactory: (connection: Connection) => connection.getRepository(DiscoverProjects),
    inject: ['DbConnectionToken'],
  },
  {
    provide: 'ExifDataFilePivotRepositoryToken',
    useFactory: (connection: Connection) => connection.getRepository(ExifDataFilePivot),
    inject: ['DbConnectionToken'],
  },
  {
    provide: 'ExifTagsRepositoryToken',
    useFactory: (connection: Connection) => connection.getRepository(ExifTags),
    inject: ['DbConnectionToken'],
  },
  {
    provide: 'FeaturesRepositoryToken',
    useFactory: (connection: Connection) => connection.getRepository(Features),
    inject: ['DbConnectionToken'],
  },
  {
    provide: 'FirstOrderDivisionsRepositoryToken',
    useFactory: (connection: Connection) => connection.getRepository(FirstOrderDivisions),
    inject: ['DbConnectionToken'],
  },
  {
    provide: 'GeoRegionsRepositoryToken',
    useFactory: (connection: Connection) => connection.getRepository(GeoRegions),
    inject: ['DbConnectionToken'],
  },
  {
    provide: 'IdentificationMetakeysRepositoryToken',
    useFactory: (connection: Connection) => connection.getRepository(IdentificationMetakeys),
    inject: ['DbConnectionToken'],
  },
  {
    provide: 'IdentificationMetavaluesRepositoryToken',
    useFactory: (connection: Connection) => connection.getRepository(IdentificationMetavalues),
    inject: ['DbConnectionToken'],
  },
  {
    provide: 'IdentificationOutputsRepositoryToken',
    useFactory: (connection: Connection) => connection.getRepository(IdentificationOutputs),
    inject: ['DbConnectionToken'],
  },
  {
    provide: 'IdentificationMethodsRepositoryToken',
    useFactory: (connection: Connection) => connection.getRepository(IdentificationMethods),
    inject: ['DbConnectionToken'],
  },
  {
    provide: 'IdentifiedIndividualsRepositoryToken',
    useFactory: (connection: Connection) => connection.getRepository(IdentifiedIndividuals),
    inject: ['DbConnectionToken'],
  },
  {
    provide: 'IdentifiedObjectsRepositoryToken',
    useFactory: (connection: Connection) => connection.getRepository(IdentifiedObjects),
    inject: ['DbConnectionToken'],
  },
  {
    provide: 'InitiativesRepositoryToken',
    useFactory: (connection: Connection) => connection.getRepository(Initiatives),
    inject: ['DbConnectionToken'],
  },
  {
    provide: 'IucnRedListCategoriesRepositoryToken',
    useFactory: (connection: Connection) => connection.getRepository(IucnRedListCategories),
    inject: ['DbConnectionToken'],
  },
  {
    provide: 'LatestIdentificationOutputsRepositoryToken',
    useFactory: (connection: Connection) => connection.getRepository(LatestIdentificationOutputs),
    inject: ['DbConnectionToken'],
  },
  {
    provide: 'LocalTaxonomiesRepositoryToken',
    useFactory: (connection: Connection) => connection.getRepository(LocalTaxonomies),
    inject: ['DbConnectionToken'],
  },
  {
    provide: 'PartnersLogosRepositoryToken',
    useFactory: (connection: Connection) => connection.getRepository(Logos),
    inject: ['DbConnectionToken'],
  },
  {
    provide: 'LocationsRepositoryToken',
    useFactory: (connection: Connection) => connection.getRepository(Locations),
    inject: ['DbConnectionToken'],
  },
  {
    provide: 'MediaTypesRepositoryToken',
    useFactory: (connection: Connection) => connection.getRepository(MediaTypes),
    inject: ['DbConnectionToken'],
  },
  {
    provide: 'OrganizationsRepositoryToken',
    useFactory: (connection: Connection) => connection.getRepository(Organizations),
    inject: ['DbConnectionToken'],
  },
  {
    provide: 'PairedDeploymentsRepositoryToken',
    useFactory: (connection: Connection) => connection.getRepository(PairedDeployments),
    inject: ['DbConnectionToken'],
  },
  {
    provide: 'ParticipantTypeProjectPivotRepositoryToken',
    useFactory: (connection: Connection) => connection.getRepository(ParticipantTypeProjectPivot),
    inject: ['DbConnectionToken'],
  },
  {
    provide: 'ParticipantTypesRepositoryToken',
    useFactory: (connection: Connection) => connection.getRepository(ParticipantTypes),
    inject: ['DbConnectionToken'],
  },
  {
    provide: 'ParticipantsRepositoryToken',
    useFactory: (connection: Connection) => connection.getRepository(Participants),
    inject: ['DbConnectionToken'],
  },
  {
    provide: 'PlacementConfigurationRepositoryToken',
    useFactory: (connection: Connection) => connection.getRepository(PlacementConfiguration),
    inject: ['DbConnectionToken'],
  },
  {
    provide: 'PreviousIdentifiersRepositoryToken',
    useFactory: (connection: Connection) => connection.getRepository(PreviousIdentifiers),
    inject: ['DbConnectionToken'],
  },
  {
    provide: 'ProjectsRepositoryToken',
    useFactory: (connection: Connection) => connection.getRepository(Projects),
    inject: ['DbConnectionToken'],
  },
  {
    provide: 'ProjectHighlightedPhotosRepositoryToken',
    useFactory: (connection: Connection) => connection.getRepository(ProjectHighlightedPhotos),
    inject: ['DbConnectionToken'],
  },
  {
    provide: 'ProjectScienceDataRepositoryToken',
    useFactory: (connection: Connection) => connection.getRepository(ProjectScienceData),
    inject: ['DbConnectionToken'],
  },
  {
    provide: 'PhotosRepositoryToken',
    useFactory: (connection: Connection) => connection.getRepository(Photos),
    inject: ['DbConnectionToken'],
  },
  {
    provide: 'SensorsRepositoryToken',
    useFactory: (connection: Connection) => connection.getRepository(Sensors),
    inject: ['DbConnectionToken'],
  },
  {
    provide: 'SequencesRepositoryToken',
    useFactory: (connection: Connection) => connection.getRepository(Sequences),
    inject: ['DbConnectionToken'],
  },
  {
    provide: 'TagsRepositoryToken',
    useFactory: (connection: Connection) => connection.getRepository(Tags),
    inject: ['DbConnectionToken'],
  },
  {
    provide: 'TaxonomiesRepositoryToken',
    useFactory: (connection: Connection) => connection.getRepository(Taxonomies),
    inject: ['DbConnectionToken'],
  },
  {
    provide: 'RolesRepositoryToken',
    useFactory: (connection: Connection) => connection.getRepository(Roles),
    inject: ['DbConnectionToken'],
  },
  {
    provide: 'PermissionsRepositoryToken',
    useFactory: (connection: Connection) => connection.getRepository(Permissions),
    inject: ['DbConnectionToken'],
  },
  {
    provide: 'ProvidersRepositoryToken',
    useFactory: (connection: Connection) => connection.getRepository(Providers),
    inject: ['DbConnectionToken'],
  },
  {
    provide: 'DataFileSequencePivotRepositoryToken',
    useFactory: (connection: Connection) => connection.getRepository(DataFileSequencePivot),
    inject: ['DbConnectionToken'],
  },
  {
    provide: 'OrganizationParticipantPivotRepositoryToken',
    useFactory: (connection: Connection) => connection.getRepository(OrganizationParticipantPivot),
    inject: ['DbConnectionToken'],
  },
  {
    provide: 'InitiativeParticipantPivotRepositoryToken',
    useFactory: (connection: Connection) => connection.getRepository(InitiativeParticipantPivot),
    inject: ['DbConnectionToken'],
  },
  {
    provide: 'IdentificationMethodTaxonomyPivotRepositoryToken',
    useFactory: (connection: Connection) => connection.getRepository(IdentificationMethodTaxonomyPivot),
    inject: ['DbConnectionToken'],
  },
  {
    provide: 'SequenceIdentificationOutputsRepositoryToken',
    useFactory: (connection: Connection) => connection.getRepository(SequenceIdentificationOutputs),
    inject: ['DbConnectionToken'],
  },
  {
    provide: 'SequenceIdentifiedObjectsRepositoryToken',
    useFactory: (connection: Connection) => connection.getRepository(SequenceIdentifiedObjects),
    inject: ['DbConnectionToken'],
  },
  {
    provide: 'SubprojectsRepositoryToken',
    useFactory: (connection: Connection) => connection.getRepository(Subprojects),
    inject: ['DbConnectionToken'],
  },
  {
    provide: 'BatchUploadsRepositoryToken',
    useFactory: (connection: Connection) => connection.getRepository(BatchUploads),
    inject: ['DbConnectionToken'],
  },
  {
    provide: 'BatchDownloadsRepositoryToken',
    useFactory: (connection: Connection) => connection.getRepository(BatchDownloads),
    inject: ['DbConnectionToken'],
  },
  {
    provide: 'PublicDownloadRequestRepositoryToken',
    useFactory: (connection: Connection) => connection.getRepository(PublicDownloadRequest),
    inject: ['DbConnectionToken'],
  },
  {
    provide: 'BatchDownloadsProjectsRepositoryToken',
    useFactory: (connection: Connection) => connection.getRepository(BatchDownloadsProjects),
    inject: ['DbConnectionToken'],
  },
  {
    provide: 'BatchDownloadsDeploymentsRepositoryToken',
    useFactory: (connection: Connection) => connection.getRepository(BatchDownloadsDeployments),
    inject: ['DbConnectionToken'],
  },
  {
    provide: 'BatchDownloadsCamerasRepositoryToken',
    useFactory: (connection: Connection) => connection.getRepository(BatchDownloadsCameras),
    inject: ['DbConnectionToken'],
  },
  {
    provide: 'BatchDownloadsImagesRepositoryToken',
    useFactory: (connection: Connection) => connection.getRepository(BatchDownloadsImages),
    inject: ['DbConnectionToken'],
  },
  {
    provide: 'RoleChangesRepositoryToken',
    useFactory: (connection: Connection) => connection.getRepository(RoleChanges),
    inject: ['DbConnectionToken'],
  },
  {
    provide: 'ProjectsOperationalAnalyticsRepositoryToken',
    useFactory: (connection: Connection) => connection.getRepository(ProjectsOperationalAnalytics),
    inject: ['DbConnectionToken'],
  },
  {
    provide: 'UsersACLCacheRepositoryToken',
    useFactory: (connection: Connection) => connection.getRepository(UsersACLCache),
    inject: ['DbConnectionToken'],
  },
  {
    provide: 'DataCacheRepositoryToken',
    useFactory: (connection: Connection) => connection.getRepository(DataCache),
    inject: ['DbConnectionToken'],
  },
];
