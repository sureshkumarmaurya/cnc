import { ApiModelProperty } from '@nestjs/swagger';
import { OrganizationsDto } from './organizations.dto';
import { ParticipantTypeProjectPivotDto } from './participant-type-project-pivot.dto';
import { DeploymentsDto } from './deployments.dto';
import { RolesDto } from './roles.dto';
import { ProvidersDto } from './providers.dto';
import { OrganizationParticipantPivotDto } from './organization-participant-pivot.dto';
import { InitiativeParticipantPivotDto } from './initiative-participant-pivot.dto';
import { IdentificationOutputsDto } from './identification-outputs.dto';
import { DataFilesDto } from './data-files.dto';

export class ParticipantsDto {

  @ApiModelProperty({ required: true })
  id: number;

  @ApiModelProperty({ required: false })
  firstName: string | null;

  @ApiModelProperty({ required: false })
  lastName: string | null;

  @ApiModelProperty({ required: false })
  phone: string | null;

  @ApiModelProperty({ required: false })
  streetAddress: string | null;

  @ApiModelProperty({ required: false })
  city: string | null;

  @ApiModelProperty({ required: false })
  state: string | null;

  @ApiModelProperty({ required: false })
  countryCode: string | null;

  @ApiModelProperty({ required: false })
  postalCode: string | null;

  @ApiModelProperty({ required: false })
  useCommonNames: boolean | null;

  @ApiModelProperty({ required: false })
  email: string | null;

  @ApiModelProperty({ required: false })
  password: string | null;

  @ApiModelProperty({ required: false })
  salt: string | null;

  @ApiModelProperty({ required: true })
  active: boolean;

  @ApiModelProperty({ required: true })
  whitelisted: boolean;

  @ApiModelProperty({ required: false })
  recoverToken: string | null;

  @ApiModelProperty({ required: false })
  activateToken: string | null;

  @ApiModelProperty({ isArray: false, type: OrganizationsDto, required: false })
  organization: OrganizationsDto | null;

  @ApiModelProperty({ isArray: true, type: DataFilesDto, required: false })
  dataFiles: DataFilesDto[] | null;

  @ApiModelProperty({ isArray: true, type: ParticipantTypeProjectPivotDto, required: false })
  participantTypeProjectPivot: ParticipantTypeProjectPivotDto[] | null;

  @ApiModelProperty({ isArray: true, type: DeploymentsDto, required: false })
  deploymentsSeted: DeploymentsDto[];

  @ApiModelProperty({ isArray: true, type: DeploymentsDto, required: false })
  deploymentsRemoved: DeploymentsDto[];

  @ApiModelProperty({ isArray: true, type: IdentificationOutputsDto, required: false })
  identificationOutputs: IdentificationOutputsDto[];

  @ApiModelProperty({ isArray: true, type: OrganizationParticipantPivotDto, required: false })
  organizationParticipantPivot: OrganizationParticipantPivotDto[];

  @ApiModelProperty({ isArray: true, type: InitiativeParticipantPivotDto, required: false })
  initiativeParticipantPivot: InitiativeParticipantPivotDto[];

  @ApiModelProperty({ isArray: false, type: RolesDto, required: false })
  role: RolesDto | null;

  @ApiModelProperty({ isArray: true, type: ProvidersDto, required: false })
  providers: ProvidersDto | null;

  @ApiModelProperty({ isArray: false, type: OrganizationsDto, required: false })
  organizationOwner: OrganizationsDto | null;

}
