import { ApiModelProperty } from '@nestjs/swagger';
import { LocationsDto } from './locations.dto';
import { PlacementConfigurationDto } from './placement-configuration.dto';

export class FeaturesDto {

  @ApiModelProperty({ required: true })
  id: number;

  @ApiModelProperty({ required: false })
  featureName: string | null;

  @ApiModelProperty({ required: false })
  description: string | null;

  @ApiModelProperty({ isArray: false, type: LocationsDto, required: false })
  locations: LocationsDto | null;

  @ApiModelProperty({ isArray: true, type: PlacementConfigurationDto, required: false })
  placementConfigurations: PlacementConfigurationDto[];

}
