import { ApiModelProperty } from '@nestjs/swagger';
import { IdentificationMetavaluesDto } from './identification-metavalues.dto';

export class IdentificationMetakeysDto {

  @ApiModelProperty({ required: true })
  id: number;

  @ApiModelProperty({ required: true })
  keyVariable: string;

  @ApiModelProperty({ required: true })
  keyName: string;

  @ApiModelProperty({ required: true })
  remarks: number;

  @ApiModelProperty({ isArray: true, type: IdentificationMetavaluesDto, required: false })
  identificationMetavaluess: IdentificationMetavaluesDto[];

}
