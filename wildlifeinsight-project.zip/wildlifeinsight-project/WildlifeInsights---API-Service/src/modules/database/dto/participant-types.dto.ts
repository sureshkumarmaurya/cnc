import { ApiModelProperty } from '@nestjs/swagger';
import { ParticipantTypeProjectPivotDto } from './participant-type-project-pivot.dto';

export class ParticipantTypesDto {

  @ApiModelProperty({ required: true })
  id: number;

  @ApiModelProperty({ required: false })
  typeName: string | null;

  @ApiModelProperty({ required: false })
  remarks: string | null;

  @ApiModelProperty({ required: false })
  function: string | null;

  @ApiModelProperty({ isArray: true, type: ParticipantTypeProjectPivotDto, required: false })
  participantTypeProjectPivot: ParticipantTypeProjectPivotDto[] | null;

}
