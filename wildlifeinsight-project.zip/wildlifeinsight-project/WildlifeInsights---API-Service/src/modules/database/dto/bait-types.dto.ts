import { DeploymentsDto } from './deployments.dto';
import { ApiModelProperty } from '@nestjs/swagger';

export class BaitTypesDto {

  @ApiModelProperty({ required: true })
  id: number;

  @ApiModelProperty({ required: true })
  typeName: string | null;

  @ApiModelProperty({ required: false })
  description: string | null;

  @ApiModelProperty({ required: true })
  schedule: string;

  @ApiModelProperty({ required: true })
  scheme: string;

  @ApiModelProperty({ isArray: true, type: DeploymentsDto, required: false })
  deployments: DeploymentsDto[];

}
