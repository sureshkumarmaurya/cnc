import { ApiModelProperty } from '@nestjs/swagger';
import { DeploymentsDto } from './deployments.dto';

export class PairedDeploymentsDto {

  @ApiModelProperty({ required: true })
  id: number;

  @ApiModelProperty({ required: false })
  name: string | null;

  @ApiModelProperty({ required: false })
  description: string | null;

  @ApiModelProperty({ required: false })
  remarks: string | null;

  @ApiModelProperty({ required: true })
  startDate: Date;

  @ApiModelProperty({ required: true })
  endDate: Date;

  @ApiModelProperty({ isArray: true, type: DeploymentsDto, required: false })
  deployments: DeploymentsDto[];

}
