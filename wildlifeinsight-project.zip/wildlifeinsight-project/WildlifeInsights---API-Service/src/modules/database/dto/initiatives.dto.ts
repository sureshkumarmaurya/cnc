import { ApiModelProperty } from '@nestjs/swagger';
import { OrganizationsDto } from './organizations.dto';
import { ProjectsDto } from './projects.dto';
import { InitiativeParticipantPivotDto } from './initiative-participant-pivot.dto';

export class InitiativesDto {

  @ApiModelProperty({ required: true })
  id: number;

  @ApiModelProperty({ required: true })
  name: string;

  @ApiModelProperty({ required: false })
  purpose: string;

  @ApiModelProperty({ required: true })
  remarks: string;

  @ApiModelProperty({ isArray: false, type: OrganizationsDto, required: false })
  ownerOrganization: OrganizationsDto | null;

  @ApiModelProperty({ isArray: true, type: OrganizationsDto, required: false })
  members: OrganizationsDto[] | null;

  @ApiModelProperty({ isArray: true, type: ProjectsDto, required: false })
  projects: ProjectsDto[];

  @ApiModelProperty({ isArray: true, type: InitiativeParticipantPivotDto, required: false })
  initiativeParticipantPivot: InitiativeParticipantPivotDto[];

}
