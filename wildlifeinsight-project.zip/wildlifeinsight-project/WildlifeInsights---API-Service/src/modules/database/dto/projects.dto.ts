import { ApiModelProperty } from '@nestjs/swagger';
import { InitiativesDto } from './initiatives.dto';
import { DeploymentsDto } from './deployments.dto';
import { ParticipantTypeProjectPivotDto } from './participant-type-project-pivot.dto';
import { TagsDto } from './tags.dto';
import { LocalTaxonomiesDto } from './local-taxonomies.dto';
import { OrganizationsDto } from './organizations.dto';
import { LocationsDto } from './locations.dto';
import { DataFilesLicenseType, ProjectMetadataLicenseType } from '../../database/entities/projects.entity';

export class ProjectsDto {

  @ApiModelProperty({ required: true })
  id: number;

  @ApiModelProperty({ required: true })
  name: string;

  @ApiModelProperty({ required: false })
  abbreviation: string | null;

  @ApiModelProperty({ required: false })
  shortName: string | null;

  @ApiModelProperty({ required: false })
  design: string | null;

  @ApiModelProperty({ required: false })
  objectives: string | null;

  @ApiModelProperty({ required: false })
  rightsHolder: string | null;

  @ApiModelProperty({ required: false })
  accessRights: string | null;

  @ApiModelProperty({ required: false })
  projectUrl: string | null;

  @ApiModelProperty({ required: false })
  projectStatus: string | null;

  @ApiModelProperty({ required: false })
  methodology: string;

  @ApiModelProperty({ required: false })
  status: string;

  @ApiModelProperty({ required: false })
  startDate: string;

  @ApiModelProperty({ required: false })
  endDate: string;

  @ApiModelProperty({ required: false })
  remarks: string | null;

  @ApiModelProperty({ required: false })
  projectCreditLine: string;

  @ApiModelProperty({ required: false })
  acknowledgements: string;

  @ApiModelProperty({ required: false })
  dataCitation: string;

  @ApiModelProperty({ required: false })
  embargo: number;

  @ApiModelProperty({ required: true })
  organizationId: number;

  @ApiModelProperty({ required: false })
  initiativeId: number;

  @ApiModelProperty({ required: false })
  trigger: string;

  @ApiModelProperty({ required: false })
  metadata: object;

  @ApiModelProperty({ required: false })
  deleteDataFilesWithIdentifiedHumans: boolean;

  @ApiModelProperty({ required: false })
  metadataLicense: ProjectMetadataLicenseType;

  @ApiModelProperty({ required: false })
  dataFilesLicense: DataFilesLicenseType;

  @ApiModelProperty({ isArray: false, type: InitiativesDto, required: false })
  initiative: InitiativesDto | null;

  @ApiModelProperty({ isArray: true, type: DeploymentsDto, required: false })
  deployments: DeploymentsDto[];

  @ApiModelProperty({ isArray: true, type: ParticipantTypeProjectPivotDto, required: false })
  participantTypeProjectPivot: ParticipantTypeProjectPivotDto[] | null;

  @ApiModelProperty({ isArray: true, type: TagsDto, required: false })
  tags: TagsDto[];

  @ApiModelProperty({ isArray: true, type: LocalTaxonomiesDto, required: false })
  localTaxonomies: LocalTaxonomiesDto[];

  @ApiModelProperty({ isArray: true, type: OrganizationsDto, required: false })
  organization: OrganizationsDto;

  @ApiModelProperty({ isArray: true, type: LocationsDto, required: false })
  locations: LocationsDto[];

  @ApiModelProperty({ required: false })
  disableAnalytics: boolean;

  @ApiModelProperty({ required: false })
  publicLatitude: number | null;

  @ApiModelProperty({ required: false })
  publicLongitude: number | null;
}
