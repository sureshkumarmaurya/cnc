import { ApiModelProperty } from '@nestjs/swagger';
import { RolesDto } from './roles.dto';

export class PermissionsDto {

  @ApiModelProperty({ required: true })
  id: number;

  @ApiModelProperty({ required: true })
  name: string;

  @ApiModelProperty({ required: true })
  slug: string;

  @ApiModelProperty({ required: false })
  description: string;

  @ApiModelProperty({ isArray: true, type: RolesDto, required: false })
  roles: RolesDto[] | null;

}
