import { ApiModelProperty } from '@nestjs/swagger';
import { PairedDeploymentsDto } from './paired-deployments.dto';
import { SensorsDto } from './sensors.dto';
import { BaitTypesDto } from './bait-types.dto';
import { LocationsDto } from './locations.dto';
import { ParticipantsDto } from './participants.dto';
import { ProjectsDto } from './projects.dto';
import { DataFilesDto } from './data-files.dto';
import { PlacementConfigurationDto } from './placement-configuration.dto';
import { TagsDto } from './tags.dto';
import { SequencesDto } from './sequences.dto';

export class DeploymentsDto {

  @ApiModelProperty({ required: true })
  id: number;

  @ApiModelProperty({ required: true })
  deploymentIdentifier: string;

  @ApiModelProperty({ required: true })
  deploymentName: string;

  @ApiModelProperty({ required: false })
  sensorHeight: string | null;

  @ApiModelProperty({ required: false })
  quietPeriod: number | null;

  @ApiModelProperty({ required: false })
  detectionDistance: number | null;

  @ApiModelProperty({ required: false })
  sampleRate: string | null;

  @ApiModelProperty({ required: false })
  sensorOrientation: string | null;

  @ApiModelProperty({ required: false })
  sensorSchedule: string | null;

  @ApiModelProperty({ required: false })
  sensorResolution: string | null;

  @ApiModelProperty({ required: false })
  sensorSensitivity: string | null;

  @ApiModelProperty({ required: false })
  sensorFailureDetails: string | null;

  @ApiModelProperty({ required: false })
  sensorEndStatus: string | null;

  @ApiModelProperty({ required: false })
  startDatetime: Date | null;

  @ApiModelProperty({ required: false })
  endDatetime: Date | null;

  @ApiModelProperty({ required: false })
  remarks: string | null;

  @ApiModelProperty({ required: false })
  metadata: object;

  @ApiModelProperty({ required: true })
  projectId: number;

  @ApiModelProperty({ required: false })
  participantRemoveSensorId: number;

  @ApiModelProperty({ required: false })
  participantSetSensorId: number;

  @ApiModelProperty({ required: false })
  baitTypeId: number;

  @ApiModelProperty({ required: false })
  sensorId: number;

  @ApiModelProperty({ required: false })
  locationId: number;

  @ApiModelProperty({ isArray: false, type: PairedDeploymentsDto, required: false })
  pairedDeployments: PairedDeploymentsDto | null;

  @ApiModelProperty({ isArray: false, type: SensorsDto, required: false })
  sensor: SensorsDto | null;

  @ApiModelProperty({ isArray: false, type: BaitTypesDto, required: false })
  baitType: BaitTypesDto | null;

  @ApiModelProperty({ isArray: false, type: LocationsDto, required: false })
  locations: LocationsDto | null;

  @ApiModelProperty({ isArray: false, type: ParticipantsDto, required: false })
  participantSetSensor: ParticipantsDto | null;

  @ApiModelProperty({ isArray: false, type: ParticipantsDto, required: false })
  participantRemoveSensor: ParticipantsDto | null;

  @ApiModelProperty({ isArray: false, type: ProjectsDto, required: false })
  project: ProjectsDto | null;

  @ApiModelProperty({ isArray: true, type: DataFilesDto, required: false })
  dataFiles: DataFilesDto[];

  @ApiModelProperty({ isArray: true, type: PlacementConfigurationDto, required: false })
  placementConfigurations: PlacementConfigurationDto[];

  @ApiModelProperty({ isArray: true, type: SequencesDto, required: false })
  sequences: SequencesDto[];

  @ApiModelProperty({ isArray: true, type: TagsDto, required: false })
  tags: TagsDto[];

}
