import { ApiModelProperty } from '@nestjs/swagger';
import { DataFilesDto } from './data-files.dto';

export class DataFileAnnotationsDto {

  @ApiModelProperty({ required: true })
  id: number;

  @ApiModelProperty({ required: true })
  description: string;

  @ApiModelProperty({ required: true })
  remarks: string;

  @ApiModelProperty({ required: true })
  rating: number;

  @ApiModelProperty({ required: true })
  favoriteYn: boolean;

  @ApiModelProperty({ required: true })
  identifications: string;

  @ApiModelProperty({ required: true })
  flagIndentification: boolean;

  @ApiModelProperty({ isArray: false, type: DataFilesDto, required: false })
  dataFile: DataFilesDto | null;

}
