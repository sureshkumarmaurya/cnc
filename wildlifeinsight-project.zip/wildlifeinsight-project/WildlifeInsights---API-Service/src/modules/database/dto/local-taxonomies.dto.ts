import { ApiModelProperty } from '@nestjs/swagger';
import { TaxonomiesDto } from './taxonomies.dto';
import { ProjectsDto } from './projects.dto';

export class LocalTaxonomiesDto {

  @ApiModelProperty({ required: true })
  localCommonName: string;

  @ApiModelProperty({ isArray: false, type: TaxonomiesDto, required: false })
  taxonomy: TaxonomiesDto | null;

  @ApiModelProperty({ isArray: false, type: ProjectsDto, required: false })
  projects: ProjectsDto | null;

}
