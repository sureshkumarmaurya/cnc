import { ApiModelProperty } from '@nestjs/swagger';
import { MediaTypesDto } from './media-types.dto';
import { DataFileMetavaluesDto } from './data-file-metavalues.dto';

export class DataFileMetakeysDto {

  @ApiModelProperty({ required: true })
  id: number;

  @ApiModelProperty({ required: true })
  mediaTypeId: number;

  @ApiModelProperty({ required: true })
  keyVariable: string;

  @ApiModelProperty({ required: true })
  keyName: string;

  @ApiModelProperty({ required: true })
  remarks: string;

  @ApiModelProperty({ isArray: false, type: MediaTypesDto, required: false })
  mediaTypes: MediaTypesDto | null;

  @ApiModelProperty({ isArray: true, type: DataFileMetavaluesDto, required: true })
  dataFileMetavalues: DataFileMetavaluesDto[];

}
