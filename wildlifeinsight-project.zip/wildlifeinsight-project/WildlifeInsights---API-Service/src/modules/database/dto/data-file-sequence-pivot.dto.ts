import { ApiModelProperty } from '@nestjs/swagger';
import { SequencesDto } from './sequences.dto';
import { DataFilesDto } from './data-files.dto';

export class DataFileSequencePivotDto {

  @ApiModelProperty({ required: true })
  position: number;

  @ApiModelProperty({ isArray: false, type: SequencesDto, required: false })
  sequence: SequencesDto | null;

  @ApiModelProperty({ isArray: false, type: DataFilesDto, required: false })
  dataFile: DataFilesDto | null;

}
