import { ApiModelProperty } from '@nestjs/swagger';

export class PreviousIdentifiersDto {

  @ApiModelProperty({ required: true })
  id: number;

  @ApiModelProperty({ required: true })
  prevIdentifierStr: string;

  @ApiModelProperty({ required: true })
  prevIdentifierInt: number;

  @ApiModelProperty({ required: true })
  description: string;

  @ApiModelProperty({ required: true })
  source: string;

  @ApiModelProperty({ required: true })
  associatedTable: string;

}
