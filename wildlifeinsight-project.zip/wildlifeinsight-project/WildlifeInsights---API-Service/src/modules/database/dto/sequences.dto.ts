import { ApiModelProperty } from '@nestjs/swagger';
import { DataFilesDto } from './data-files.dto';
import { DeploymentsDto } from './deployments.dto';
import { DataFileSequencePivotDto } from './data-file-sequence-pivot.dto';

export class SequencesDto {

  @ApiModelProperty({ required: true })
  id: number;

  @ApiModelProperty({ required: true })
  name: string;

  @ApiModelProperty({ required: false })
  controlField: string;

  @ApiModelProperty({ required: false })
  rule: number;

  @ApiModelProperty({ required: false })
  remarks: string;

  @ApiModelProperty({ required: false })
  sequenceIdentifier: string;

  @ApiModelProperty({ isArray: true, type: DataFileSequencePivotDto, required: false })
  dataFileSequencePivots: DataFileSequencePivotDto[];

  @ApiModelProperty({ isArray: false, type: DeploymentsDto, required: true })
  deployment: DeploymentsDto;

}
