import { ApiModelProperty } from '@nestjs/swagger';
import { DataFileMetakeysDto } from './data-file-metakeys.dto';
import { DataFilesDto } from './data-files.dto';

export class DataFileMetavaluesDto {

  @ApiModelProperty({ required: true })
  id: number;

  @ApiModelProperty({ required: true })
  value: string;

  @ApiModelProperty({ required: true })
  remarks: string;

  @ApiModelProperty({ isArray: false, type: DataFileMetakeysDto, required: false })
  key: DataFileMetakeysDto | null;

  @ApiModelProperty({ isArray: false, type: DataFilesDto, required: false })
  dataFile: DataFilesDto | null;
}
