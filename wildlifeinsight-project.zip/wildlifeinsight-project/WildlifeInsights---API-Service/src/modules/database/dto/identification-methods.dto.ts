import { IdentificationOutputsDto } from './identification-outputs.dto';
import { ApiModelProperty } from '@nestjs/swagger';

export class IdentificationMethodsDto {

  @ApiModelProperty({ required: true })
  id: number;

  @ApiModelProperty({ required: true })
  name: string;

  @ApiModelProperty({ required: false })
  endpoint: string;

  @ApiModelProperty({ isArray: true, type: IdentificationOutputsDto, required: false })
  identificationOutputs: IdentificationOutputsDto[];

}
