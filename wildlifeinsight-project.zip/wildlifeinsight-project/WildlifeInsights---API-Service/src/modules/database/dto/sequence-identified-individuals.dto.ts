import { ApiModelProperty } from '@nestjs/swagger';
import { SequenceIdentifiedObjectsDto } from './sequence-identified-objects.dto';

export class SequenceIdentifiedIndividualsDto {

  @ApiModelProperty({ required: true })
  id: number;

  @ApiModelProperty({ required: true })
  name: number;

  @ApiModelProperty({ isArray: false, type: SequenceIdentifiedObjectsDto, required: false })
  identifiedAnimals: SequenceIdentifiedObjectsDto | null;
}
