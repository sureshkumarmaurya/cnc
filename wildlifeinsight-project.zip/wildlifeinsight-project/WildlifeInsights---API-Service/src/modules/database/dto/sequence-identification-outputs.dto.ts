import { ApiModelProperty } from '@nestjs/swagger';
import { SequencesDto } from './sequences.dto';
import { SequenceIdentifiedObjectsDto } from './sequence-identified-objects.dto';
import { IdentificationMethodsDto } from './identification-methods.dto';
import { ParticipantsDto } from './participants.dto';

export class SequenceIdentificationOutputsDto {

  @ApiModelProperty({ required: true })
  id: number;

  @ApiModelProperty({ required: true })
  blankYn: boolean;

  @ApiModelProperty({ required: true })
  sequenceId: number;

  @ApiModelProperty({ required: true })
  participantId: number;

  @ApiModelProperty({ required: true })
  timestamp: Date;

  @ApiModelProperty({ required: true })
  identificationMethodId: number;

  @ApiModelProperty({ isArray: false, type: SequencesDto, required: false })
  sequence: SequencesDto;

  @ApiModelProperty({ isArray: false, type: ParticipantsDto, required: false })
  participant: ParticipantsDto;

  @ApiModelProperty({ isArray: true, type: SequenceIdentifiedObjectsDto, required: false })
  identifiedObjects: SequenceIdentifiedObjectsDto[];

  @ApiModelProperty({ isArray: false, type: IdentificationMethodsDto, required: true })
  identificationMethod: IdentificationMethodsDto[];
}
