import { ApiModelProperty } from '@nestjs/swagger';
import { InitiativesDto } from './initiatives.dto';
import { ParticipantsDto } from './participants.dto';
import { ProjectsDto } from './projects.dto';
import { DevicesDto } from './devices.dto';
import { OrganizationParticipantPivotDto } from './organization-participant-pivot.dto';
import { LocationsDto } from './locations.dto';

export class OrganizationsDto {

  @ApiModelProperty({ required: true })
  id: number;

  @ApiModelProperty({ required: true })
  name: string | null;

  @ApiModelProperty({ required: false })
  streetAddress: string | null;

  @ApiModelProperty({ required: false })
  city: string | null;

  @ApiModelProperty({ required: false })
  state: string | null;

  @ApiModelProperty({ required: false })
  postalCode: string | null;

  @ApiModelProperty({ required: false })
  phone: string | null;

  @ApiModelProperty({ required: false })
  email: string | null;

  @ApiModelProperty({ required: false })
  countryCode: string | null;

  @ApiModelProperty({ required: false })
  organizationUrl: string | null;

  @ApiModelProperty({ required: false })
  remarks: string | null;

  @ApiModelProperty({ isArray: true, type: InitiativesDto, required: false })
  initiativesOwner: InitiativesDto[];

  @ApiModelProperty({ isArray: true, type: InitiativesDto, required: false })
  initiativesMember: InitiativesDto[];

  @ApiModelProperty({ isArray: true, type: ProjectsDto, required: false })
  projects: ProjectsDto[];

  @ApiModelProperty({ isArray: true, type: DevicesDto, required: false })
  devices: DevicesDto[];

  @ApiModelProperty({ isArray: true, type: OrganizationParticipantPivotDto, required: false })
  organizationParticipantPivot: OrganizationParticipantPivotDto[];

}
