import { ApiModelProperty } from '@nestjs/swagger';
import { DevicesDto } from './devices.dto';
import { DeploymentsDto } from './deployments.dto';
import { MediaTypesDto } from './media-types.dto';

export class SensorsDto {

  @ApiModelProperty({ required: true })
  id: number;

  @ApiModelProperty({ required: true })
  name: string;

  @ApiModelProperty({ required: false })
  triggerSpeed: number | null;

  @ApiModelProperty({ required: false })
  gain: number | null;

  @ApiModelProperty({ required: false })
  remarks: string | null;

  @ApiModelProperty({ required: true })
  active: boolean;

  @ApiModelProperty({ required: true })
  deviceId: number;

  @ApiModelProperty({ isArray: false, type: DevicesDto, required: false })
  devices: DevicesDto | null;

  @ApiModelProperty({ isArray: true, type: DeploymentsDto, required: false })
  deployments: DeploymentsDto[];

  @ApiModelProperty({ isArray: true, type: MediaTypesDto, required: true })
  mediaTypes: MediaTypesDto[];

}
