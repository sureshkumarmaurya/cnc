import { ApiModelProperty } from '@nestjs/swagger';
import { SensorsDto } from './sensors.dto';
import { OrganizationsDto } from './organizations.dto';

export class DevicesDto {

  @ApiModelProperty({ required: true })
  id: number;

  @ApiModelProperty({ required: true })
  name: string;

  @ApiModelProperty({ required: false })
  purchaseDate: string;

  @ApiModelProperty({ required: false })
  make: string | null;

  @ApiModelProperty({ required: false })
  model: string | null;

  @ApiModelProperty({ required: false })
  modelNumber: string | null;

  @ApiModelProperty({ required: false })
  serialNumber: string | null;

  @ApiModelProperty({ required: false })
  purchaseYear: number | null;

  @ApiModelProperty({ required: false })
  remarks: string | null;

  @ApiModelProperty({ required: false })
  productUrl: string | null;

  @ApiModelProperty({ required: false })
  purchasePrice: number;

  @ApiModelProperty({ required: true })
  organizationId: number;

  @ApiModelProperty({ isArray: false, type: OrganizationsDto, required: false })
  organization: OrganizationsDto;

  @ApiModelProperty({ isArray: true, type: SensorsDto, required: false })
  sensors: SensorsDto[];

}
