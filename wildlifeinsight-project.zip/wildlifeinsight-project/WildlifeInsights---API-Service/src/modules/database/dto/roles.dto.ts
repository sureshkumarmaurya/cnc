import { ApiModelProperty } from '@nestjs/swagger';
import { PermissionsDto } from './permissions.dto';
import { OrganizationParticipantPivotDto } from './organization-participant-pivot.dto';
import { ParticipantTypeProjectPivotDto } from './participant-type-project-pivot.dto';
import { InitiativeParticipantPivotDto } from './initiative-participant-pivot.dto';

export class RolesDto {

  @ApiModelProperty({ required: true })
  id: number;

  @ApiModelProperty({ required: true })
  name: string;

  @ApiModelProperty({ required: true })
  slug: string;

  @ApiModelProperty({ required: true })
  superAdmin: boolean;

  @ApiModelProperty({ isArray: true, type: PermissionsDto, required: false })
  permissions: PermissionsDto[] | null;

  @ApiModelProperty({ isArray: true, type: OrganizationParticipantPivotDto, required: false })
  organizationParticipantPivot: OrganizationParticipantPivotDto[];

  @ApiModelProperty({ isArray: true, type: ParticipantTypeProjectPivotDto, required: false })
  participantTypeProjectPivot: ParticipantTypeProjectPivotDto[];

  @ApiModelProperty({ isArray: true, type: InitiativeParticipantPivotDto, required: false })
  initiativeParticipantPivot: InitiativeParticipantPivotDto[];

}
