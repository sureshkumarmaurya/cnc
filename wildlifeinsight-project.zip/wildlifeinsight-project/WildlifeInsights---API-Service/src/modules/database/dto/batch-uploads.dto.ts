import { ApiModelProperty } from '@nestjs/swagger';
import { OrganizationsDto } from './organizations.dto';

export class BatchUploadsDto {

  @ApiModelProperty({ required: true })
  id: number;

  @ApiModelProperty({ required: true })
  target: string;

  @ApiModelProperty({ required: true })
  status: string;

  @ApiModelProperty({ isArray: true, type: OrganizationsDto, required: false })
  organization: OrganizationsDto;
}
