import { ApiModelProperty } from '@nestjs/swagger';

export enum EBatchDownloadStatus {
  Requested = 'Requested',
  Running = 'Running',
  Finished = 'Finished',
  Failed = 'Failed',
}

export class BatchDownloadsDto {

  @ApiModelProperty({ required: true })
  id: number;

  @ApiModelProperty({ required: true })
  uuid: string;

  @ApiModelProperty({ required: true })
  status: EBatchDownloadStatus;

  @ApiModelProperty({ required: true })
  participant: number;
}
