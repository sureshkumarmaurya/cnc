import { ApiModelProperty } from '@nestjs/swagger';

import { ParticipantsDto } from './participants.dto';

export class ProvidersDto {

  @ApiModelProperty({ required: true })
  id: number;

  @ApiModelProperty({ required: true })
  provider: string;

  @ApiModelProperty({ required: true })
  providerId: string;

  @ApiModelProperty({ isArray: false, type: ParticipantsDto, required: false })
  participant: ParticipantsDto | null;

}
