import { ApiModelProperty } from '@nestjs/swagger';
import { ExifDataFilePivotDto } from './exif-data-file-pivot.dto';

export class ExifTagsDto {

  @ApiModelProperty({ required: true })
  id: number;

  @ApiModelProperty({ required: false })
  tagHex: string;

  @ApiModelProperty({ required: false })
  tagDec: string;

  @ApiModelProperty({ required: false })
  ifd: string;

  @ApiModelProperty({ required: false })
  key: string;

  @ApiModelProperty({ required: false })
  group: string;

  @ApiModelProperty({ required: true })
  tagName: string;

  @ApiModelProperty({ required: false })
  datatype: string;

  @ApiModelProperty({ required: false })
  description: string;

  @ApiModelProperty({ isArray: true, type: ExifDataFilePivotDto, required: false })
  exifDataFilePivots: ExifDataFilePivotDto[] | null;

}
