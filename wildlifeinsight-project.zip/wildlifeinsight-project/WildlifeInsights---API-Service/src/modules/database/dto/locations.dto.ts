import { ApiModelProperty } from '@nestjs/swagger';
import { DeploymentsDto } from './deployments.dto';
import { FeaturesDto } from './features.dto';
import { PlacementConfigurationDto } from './placement-configuration.dto';
import { OrganizationsDto } from './organizations.dto';
import { ProjectsDto } from './projects.dto';

export class LocationsDto {

  @ApiModelProperty({ required: true })
  id: number;

  @ApiModelProperty({ required: false })
  latitude: number | null;

  @ApiModelProperty({ required: false })
  longitude: number | null;
  
  @ApiModelProperty({ required: true })
  latitudeStr: string;

  @ApiModelProperty({ required: true })
  longitudeStr: string;

  @ApiModelProperty({ required: true })
  placename: string;

  @ApiModelProperty({ required: false })
  propertyType: string | null;

  @ApiModelProperty({ required: false })
  habitat: string | null;

  @ApiModelProperty({ required: false })
  remarks: string | null;

  @ApiModelProperty({ required: false })
  plotTreatment: string | null;

  @ApiModelProperty({ required: false })
  plotTreatmentDescription: string | null;

  @ApiModelProperty({ required: true })
  geodeticDatum: string;

  @ApiModelProperty({ required: false })
  fieldNumber: string;

  @ApiModelProperty({ required: false })
  country: string;

  @ApiModelProperty({ required: false })
  firstOrderDivision: string;

  @ApiModelProperty({ required: false })
  secondOrderDivision: string;

  @ApiModelProperty({ required: false })
  landcoverType: string;

  @ApiModelProperty({ required: false })
  igbpClimateClassification: string;

  @ApiModelProperty({ required: false })
  elevationGtopo30: number;

  @ApiModelProperty({ required: false })
  projectId: number;

  @ApiModelProperty({ isArray: true, type: DeploymentsDto, required: false })
  deployments: DeploymentsDto[];

  @ApiModelProperty({ isArray: true, type: FeaturesDto, required: false })
  features: FeaturesDto[];

  @ApiModelProperty({ isArray: true, type: PlacementConfigurationDto, required: false })
  placementConfigurations: PlacementConfigurationDto[];

  @ApiModelProperty({ isArray: false, type: OrganizationsDto, required: false })
  project: ProjectsDto;

}
