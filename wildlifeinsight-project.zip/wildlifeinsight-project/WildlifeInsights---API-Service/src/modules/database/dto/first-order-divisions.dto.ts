import { ApiModelProperty } from '@nestjs/swagger';
import { CountriesDto } from './countries.dto';

export class FirstOrderDivisionsDto {

  @ApiModelProperty({ required: true })
  id: number;

  @ApiModelProperty({ required: true })
  name: string;

  @ApiModelProperty({ required: true })
  type: string;

  @ApiModelProperty({ isArray: false, type: CountriesDto, required: false })
  country: CountriesDto | null;

}
