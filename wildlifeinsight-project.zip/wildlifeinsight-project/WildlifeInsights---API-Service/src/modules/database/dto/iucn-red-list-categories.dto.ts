import { ApiModelProperty } from '@nestjs/swagger';
import { TaxonomiesDto } from './taxonomies.dto';

export class IucnRedListCategoriesDto {

  @ApiModelProperty({ required: true })
  id: number;

  @ApiModelProperty({ required: true })
  categoryName: string;

  @ApiModelProperty({ required: true })
  abbreviation: string;

  @ApiModelProperty({ required: true })
  remarks: string;

  @ApiModelProperty({ isArray: true, type: TaxonomiesDto, required: false })
  taxonomies: TaxonomiesDto[];

}
