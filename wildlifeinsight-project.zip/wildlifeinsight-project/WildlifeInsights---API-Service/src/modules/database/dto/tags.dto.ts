import { ApiModelProperty } from '@nestjs/swagger';
import { ProjectsDto } from './projects.dto';
import { DeploymentsDto } from './deployments.dto';

export class TagsDto {

  @ApiModelProperty({ required: true })
  id: number;

  @ApiModelProperty({ required: true })
  tagName: string;

  @ApiModelProperty({ isArray: false, type: ProjectsDto, required: false })
  project: ProjectsDto | null;

  @ApiModelProperty({ isArray: true, type: DeploymentsDto, required: false })
  deploymentss: DeploymentsDto[];

}
