import { ApiModelProperty } from '@nestjs/swagger';
import { ParticipantsDto } from './participants.dto';
import { RolesDto } from './roles.dto';
import { InitiativesDto } from './initiatives.dto';

export class InitiativeParticipantPivotDto {

  @ApiModelProperty({ isArray: false, type: ParticipantsDto, required: false })
  participant: ParticipantsDto | null;

  @ApiModelProperty({ isArray: false, type: InitiativesDto, required: false })
  initiative: InitiativesDto | null;

  @ApiModelProperty({ isArray: false, type: RolesDto, required: false })
  role: RolesDto ;

  @ApiModelProperty({ required: true })
  isImplicit: boolean;
}
