import { ApiModelProperty } from '@nestjs/swagger';
import { IdentificationMetakeysDto } from './identification-metakeys.dto';
import { IdentifiedObjectsDto } from './identified-objects.dto';

export class IdentificationMetavaluesDto {

  @ApiModelProperty({ required: true })
  id: number;

  @ApiModelProperty({ isArray: false, type: IdentificationMetakeysDto, required: false })
  key: IdentificationMetakeysDto | null;

  @ApiModelProperty({ required: true })
  value: string;

  @ApiModelProperty({ required: true })
  remarks: string;

  @ApiModelProperty({ isArray: true, type: IdentifiedObjectsDto, required: false })
  identifiedObjects: IdentifiedObjectsDto[];

}
