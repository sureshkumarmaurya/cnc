import { ApiModelProperty } from '@nestjs/swagger';
import { ParticipantsDto } from './participants.dto';
import { ParticipantTypesDto } from './participant-types.dto';
import { ProjectsDto } from './projects.dto';
import { RolesDto } from './roles.dto';

export class ParticipantTypeProjectPivotDto {

  @ApiModelProperty({ required: true })
  startDate: Date;

  @ApiModelProperty({ required: true })
  endDate: Date;

  @ApiModelProperty({ required: true })
  status: string;

  @ApiModelProperty({ isArray: false, type: ParticipantsDto, required: false })
  participant: ParticipantsDto | null;

  @ApiModelProperty({ isArray: false, type: ParticipantTypesDto, required: false })
  participantType: ParticipantTypesDto | null;

  @ApiModelProperty({ isArray: false, type: ProjectsDto, required: false })
  project: ProjectsDto | null;

  @ApiModelProperty({ isArray: false, type: RolesDto, required: false })
  role: RolesDto ;

  @ApiModelProperty({ required: true })
  isImplicit: boolean;
}
