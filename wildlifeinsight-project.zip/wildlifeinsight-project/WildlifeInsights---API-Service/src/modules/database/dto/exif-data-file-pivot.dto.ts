import { ApiModelProperty } from '@nestjs/swagger';
import { DataFilesDto } from './data-files.dto';
import { ExifTagsDto } from './exif-tags.dto';

export class ExifDataFilePivotDto {

  @ApiModelProperty({ required: true })
  value: string;

  @ApiModelProperty({ isArray: false, type: DataFilesDto, required: false })
  dataFile: DataFilesDto | null;

  @ApiModelProperty({ isArray: false, type: ExifTagsDto, required: false })
  exifTag: ExifTagsDto | null;

}
