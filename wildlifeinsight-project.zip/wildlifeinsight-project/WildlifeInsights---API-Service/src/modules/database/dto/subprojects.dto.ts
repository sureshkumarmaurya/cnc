import { ApiModelProperty } from '@nestjs/swagger';
import { ProjectsDto } from './projects.dto';
import { DeploymentsDto } from './deployments.dto';

export class SubprojectsDto {

  @ApiModelProperty({ required: true })
  id: number;

  @ApiModelProperty({ required: true })
  name: string;

  @ApiModelProperty({ required: false })
  design: string;

  @ApiModelProperty({ required: false })
  metadata: object;

}
