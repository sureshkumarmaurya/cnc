import { ApiModelProperty } from '@nestjs/swagger';
import { SequenceIdentificationOutputsDto } from './sequence-identification-outputs.dto';
import { IdentificationMetavaluesDto } from './identification-metavalues.dto';
import { TaxonomiesDto } from './taxonomies.dto';
import { SequenceIdentifiedIndividualsDto } from './sequence-identified-individuals.dto';

export class SequenceIdentifiedObjectsDto {

  @ApiModelProperty({ required: true })
  id: number;

  @ApiModelProperty({ required: false })
  commonName: string;

  @ApiModelProperty({ required: false })
  relativeAge: string;

  @ApiModelProperty({ required: false })
  sex: string;

  @ApiModelProperty({ required: false })
  markings: string;

  @ApiModelProperty({ required: false })
  individualIdentified: boolean;

  @ApiModelProperty({ required: false })
  behavior: string;

  @ApiModelProperty({ required: false })
  remarks: string;

  @ApiModelProperty({ required: false })
  date: Date;

  @ApiModelProperty({ required: false })
  certainity: number;

  @ApiModelProperty({ required: true })
  sequenceIdentificationId: number;

  @ApiModelProperty({ required: false })
  identificationMetavalueId: number;

  @ApiModelProperty({ required: true })
  taxonomyId: string;

  @ApiModelProperty({ isArray: false, type: SequenceIdentificationOutputsDto, required: false })
  sequenceIdentifications: SequenceIdentificationOutputsDto | null;

  @ApiModelProperty({ isArray: false, type: IdentificationMetavaluesDto, required: false })
  identificationMetavalues: IdentificationMetavaluesDto | null;

  @ApiModelProperty({ isArray: false, type: TaxonomiesDto, required: false })
  taxonomies: TaxonomiesDto | null;

  @ApiModelProperty({ isArray: true, type: SequenceIdentifiedIndividualsDto, required: false })
  sequenceIdentifiedIndividuals: SequenceIdentifiedIndividualsDto[];

}
