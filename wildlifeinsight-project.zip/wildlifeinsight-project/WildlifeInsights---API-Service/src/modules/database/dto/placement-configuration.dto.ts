import { ApiModelProperty } from '@nestjs/swagger';
import { LocationsDto } from './locations.dto';
import { DeploymentsDto } from './deployments.dto';
import { FeaturesDto } from './features.dto';

export class PlacementConfigurationDto {

  @ApiModelProperty({ required: true })
  id: number;

  @ApiModelProperty({ required: true })
  orientationDescription: string;

  @ApiModelProperty({ required: true })
  numDeployments: number;

  @ApiModelProperty({ required: true })
  remarks: string;

  @ApiModelProperty({ isArray: false, type: LocationsDto, required: false })
  locations: LocationsDto | null;

  @ApiModelProperty({ isArray: false, type: DeploymentsDto, required: false })
  deployments: DeploymentsDto | null;

  @ApiModelProperty({ isArray: false, type: FeaturesDto, required: false })
  features: FeaturesDto | null;

}
