import { ApiModelProperty } from '@nestjs/swagger';
import { IdentificationOutputsDto } from './identification-outputs.dto';
import { IdentificationMetavaluesDto } from './identification-metavalues.dto';
import { TaxonomiesDto } from './taxonomies.dto';
import { IdentifiedIndividualsDto } from './identified-individuals.dto';

export class IdentifiedObjectsDto {

  @ApiModelProperty({ required: true })
  id: number;

  @ApiModelProperty({ required: false })
  relativeAge: string;

  @ApiModelProperty({ required: false })
  sex: string;

  @ApiModelProperty({ required: false })
  markings: string;

  @ApiModelProperty({ required: false })
  individualIdentified: boolean;

  @ApiModelProperty({ required: false })
  behavior: string;

  @ApiModelProperty({ required: false })
  remarks: string;

  @ApiModelProperty({ required: false })
  date: Date;

  @ApiModelProperty({ required: false })
  certainity: number;

  @ApiModelProperty({ required: true })
  identificationId: number;

  @ApiModelProperty({ required: false })
  identificationMetavalueId: number;

  @ApiModelProperty({ required: true })
  taxonomyId: string;

  @ApiModelProperty({ isArray: false, type: IdentificationOutputsDto, required: false })
  identifications: IdentificationOutputsDto | null;

  @ApiModelProperty({ isArray: false, type: IdentificationMetavaluesDto, required: false })
  identificationMetavalues: IdentificationMetavaluesDto | null;

  @ApiModelProperty({ isArray: false, type: TaxonomiesDto, required: false })
  taxonomies: TaxonomiesDto | null;

  @ApiModelProperty({ isArray: true, type: IdentifiedIndividualsDto, required: false })
  identifiedIndividuals: IdentifiedIndividualsDto[];

}
