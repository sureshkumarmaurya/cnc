import { ApiModelProperty } from '@nestjs/swagger';
import { TaxonomiesDto } from './taxonomies.dto';

export class CommonNamesDto {

  @ApiModelProperty({ required: true })
  id: number;

  @ApiModelProperty({ required: true })
  commonName: string;

  @ApiModelProperty({ required: true })
  primaryYn: boolean;

  @ApiModelProperty({ required: true })
  aliasYn: boolean;

  @ApiModelProperty({ required: true })
  remarks: string;

  @ApiModelProperty({ required: true })
  taxonomyId: string;

  @ApiModelProperty({ isArray: false, type: TaxonomiesDto, required: false })
  taxonomy: TaxonomiesDto | null;
}
