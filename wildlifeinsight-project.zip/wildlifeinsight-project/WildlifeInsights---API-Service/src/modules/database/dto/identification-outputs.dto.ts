import { ApiModelProperty } from '@nestjs/swagger';
import { DataFilesDto } from './data-files.dto';
import { IdentifiedObjectsDto } from './identified-objects.dto';
import { IdentificationMethodsDto } from './identification-methods.dto';
import { ParticipantsDto } from './participants.dto';

export class IdentificationOutputsDto {

  @ApiModelProperty({ required: true })
  id: number;

  @ApiModelProperty({ required: true })
  blankYn: boolean;

  @ApiModelProperty({ required: true })
  dataFileId: number;

  @ApiModelProperty({ required: true })
  participantId: number;

  @ApiModelProperty({ required: true })
  timestamp: Date;

  @ApiModelProperty({ required: true })
  identificationMethodId: number;

  @ApiModelProperty({ isArray: false, type: DataFilesDto, required: false })
  dataFile: DataFilesDto;

  @ApiModelProperty({ isArray: false, type: ParticipantsDto, required: false })
  participant: ParticipantsDto;

  @ApiModelProperty({ isArray: true, type: IdentifiedObjectsDto, required: false })
  identifiedObjects: IdentifiedObjectsDto[];

  @ApiModelProperty({ isArray: false, type: IdentificationMethodsDto, required: true })
  identificationMethod: IdentificationMethodsDto[];

}
