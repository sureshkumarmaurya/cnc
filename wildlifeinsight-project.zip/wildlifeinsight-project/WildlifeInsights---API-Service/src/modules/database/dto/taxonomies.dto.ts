import { ApiModelProperty } from '@nestjs/swagger';
import { IucnRedListCategoriesDto } from './iucn-red-list-categories.dto';
import { CommonNamesDto } from './common-names.dto';
import { IdentifiedObjectsDto } from './identified-objects.dto';
import { LocalTaxonomiesDto } from './local-taxonomies.dto';

export class TaxonomiesDto {

  @ApiModelProperty({ required: true })
  id: number;

  @ApiModelProperty({ required: false })
  class: string;

  @ApiModelProperty({ required: false })
  order: string;

  @ApiModelProperty({ required: false })
  suborder: string;

  @ApiModelProperty({ required: false })
  superfamily: string;

  @ApiModelProperty({ required: false })
  family: string;

  @ApiModelProperty({ required: false })
  subfamily: string;

  @ApiModelProperty({ required: false })
  genus: string;

  @ApiModelProperty({ required: false })
  species: string;

  @ApiModelProperty({ required: false })
  subspecies: string;

  @ApiModelProperty({ required: true })
  taxonLevel: string;

  @ApiModelProperty({ required: false })
  authority: string;

  @ApiModelProperty({ required: false })
  commonNameEnglish: string;

  @ApiModelProperty({ required: false })
  scientificName: string;

  @ApiModelProperty({ required: false })
  iucnCategoryId: number;

  @ApiModelProperty({ required: true })
  taxonomyType: string;

  @ApiModelProperty({ required: true })
  uniqueIdentifier: string;

  @ApiModelProperty({ required: false })
  referenceUrl: string;

  @ApiModelProperty({ isArray: false, type: IucnRedListCategoriesDto, required: false })
  iucnCategory: IucnRedListCategoriesDto | null;

  @ApiModelProperty({ isArray: true, type: CommonNamesDto, required: false })
  commonNamess: CommonNamesDto[];

  @ApiModelProperty({ isArray: true, type: IdentifiedObjectsDto, required: false })
  identifiedObjectss: IdentifiedObjectsDto[];

  @ApiModelProperty({ isArray: false, type: LocalTaxonomiesDto, required: false })
  localTaxonomies: LocalTaxonomiesDto | null;

}
