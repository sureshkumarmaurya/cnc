import { ApiModelProperty } from '@nestjs/swagger';
import { FirstOrderDivisionsDto } from './first-order-divisions.dto';

export class CountriesDto {

  @ApiModelProperty({ required: true })
  id: number;

  @ApiModelProperty({ required: true })
  bgnName: number;

  @ApiModelProperty({ required: true })
  bgnLongname: number;

  @ApiModelProperty({ required: true })
  iso3166A2: string;

  @ApiModelProperty({ required: true })
  iso3166A3: string;

  @ApiModelProperty({ required: true })
  maxLatitude: number;

  @ApiModelProperty({ required: true })
  minLatitude: number;

  @ApiModelProperty({ required: true })
  maxLongitude: number;

  @ApiModelProperty({ required: true })
  minLongitude: number;

  @ApiModelProperty({ required: true })
  firstOrderDivisionsId: number;

  @ApiModelProperty({ isArray: true, type: FirstOrderDivisionsDto, required: false })
  firstOrderDivisions: FirstOrderDivisionsDto[];

}
