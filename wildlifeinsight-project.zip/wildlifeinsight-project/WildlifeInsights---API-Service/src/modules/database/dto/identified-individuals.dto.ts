import { ApiModelProperty } from '@nestjs/swagger';
import { IdentifiedObjectsDto } from './identified-objects.dto';

export class IdentifiedIndividualsDto {

  @ApiModelProperty({ required: true })
  id: number;

  @ApiModelProperty({ required: true })
  name: number;

  @ApiModelProperty({ isArray: false, type: IdentifiedObjectsDto, required: false })
  identifiedAnimals: IdentifiedObjectsDto | null;

}
