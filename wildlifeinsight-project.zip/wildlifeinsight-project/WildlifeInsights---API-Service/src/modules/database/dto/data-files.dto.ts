import { ApiModelProperty } from '@nestjs/swagger';
import { DeploymentsDto } from './deployments.dto';
import { MediaTypesDto } from './media-types.dto';
import { DataFileAnnotationsDto } from './data-file-annotations.dto';
import { DataFileMetavaluesDto } from './data-file-metavalues.dto';
import { ExifDataFilePivotDto } from './exif-data-file-pivot.dto';
import { IdentificationOutputsDto } from './identification-outputs.dto';
import { SequencesDto } from './sequences.dto';
import { DataFileSequencePivotDto } from './data-file-sequence-pivot.dto';
import { ParticipantsDto } from './participants.dto';

export class DataFilesDto {

  @ApiModelProperty({ required: true })
  id: number;

  @ApiModelProperty({ required: true })
  dataFileId: string;

  @ApiModelProperty({ required: true })
  filepath: string;

  @ApiModelProperty({ required: true })
  originalLocationUrl: string;

  @ApiModelProperty({ required: true })
  filename: string;

  @ApiModelProperty({ required: true })
  filesize: string;

  @ApiModelProperty({ required: true })
  timestamp: Date;

  @ApiModelProperty({ required: true })
  createdAt: Date;

  @ApiModelProperty({ required: true })
  deploymentId: number;

  @ApiModelProperty({ required: true })
  mediaTypeId: number;

  @ApiModelProperty({ required: true })
  participantId: number;

  @ApiModelProperty({ required: false })
  status: string;

  @ApiModelProperty({ required: false })
  clientId: string;

  @ApiModelProperty({ required: false })
  metadata: object;

  @ApiModelProperty({ isArray: false, type: ParticipantsDto, required: false })
  participant: ParticipantsDto;

  @ApiModelProperty({ isArray: false, type: DeploymentsDto, required: false })
  deployment: DeploymentsDto;

  @ApiModelProperty({ isArray: false, type: MediaTypesDto, required: false })
  mediaType: MediaTypesDto | null;

  @ApiModelProperty({ isArray: true, type: DataFileAnnotationsDto, required: false })
  dataFileAnnotations: DataFileAnnotationsDto[];

  @ApiModelProperty({ isArray: true, type: DataFileMetavaluesDto, required: false })
  dataFileMetavalues: DataFileMetavaluesDto[];

  @ApiModelProperty({ isArray: false, type: ExifDataFilePivotDto, required: false })
  exifDataFilePivot: ExifDataFilePivotDto | null;

  @ApiModelProperty({ isArray: true, type: IdentificationOutputsDto, required: false })
  identificationOutputs: IdentificationOutputsDto[];

  @ApiModelProperty({ isArray: true, type: DataFileSequencePivotDto, required: false })
  dataFileSequencePivots: DataFileSequencePivotDto[];

}
