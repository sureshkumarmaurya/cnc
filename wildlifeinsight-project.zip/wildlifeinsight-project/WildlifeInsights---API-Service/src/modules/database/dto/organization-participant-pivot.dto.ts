import { ApiModelProperty } from '@nestjs/swagger';
import { ParticipantsDto } from './participants.dto';
import { RolesDto } from './roles.dto';
import { OrganizationsDto } from './organizations.dto';

export class OrganizationParticipantPivotDto {

  @ApiModelProperty({ isArray: false, type: ParticipantsDto, required: false })
  participant: ParticipantsDto | null;

  @ApiModelProperty({ isArray: false, type: OrganizationsDto, required: false })
  organization: OrganizationsDto | null;

  @ApiModelProperty({ isArray: false, type: RolesDto, required: false })
  role: RolesDto ;

}
