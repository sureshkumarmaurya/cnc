import { ApiModelProperty } from '@nestjs/swagger';
import { DataFilesDto } from './data-files.dto';
import { DataFileMetakeysDto } from './data-file-metakeys.dto';
import { SensorsDto } from './sensors.dto';

export class MediaTypesDto {

  @ApiModelProperty({ required: true })
  id: number;

  @ApiModelProperty({ required: false })
  mime: string | null;

  @ApiModelProperty({ isArray: true, type: DataFilesDto, required: false })
  dataFiles: DataFilesDto[];

  @ApiModelProperty({ isArray: true, type: DataFileMetakeysDto, required: false })
  dataFileMetakeys: DataFileMetakeysDto[];

  @ApiModelProperty({ isArray: true, type: SensorsDto, required: false })
  sensorss: SensorsDto[];

}
