import { Entity, Column, OneToMany, ManyToMany, JoinTable, PrimaryGeneratedColumn, Unique } from 'typeorm';
import { DataFiles } from './data-files.entity';
import { DataFileMetakeys } from './data-file-metakeys.entity';
import { Sensors } from './sensors.entity';

@Entity('media_types')
@Unique(['mime'])
export class MediaTypes {

  @PrimaryGeneratedColumn()
  id: number;

  @Column('varchar', {
    nullable: true,
    length: 255,
    name: 'mime',
  })
  mime: string | null;

  @OneToMany(() => DataFiles, dataFile => dataFile.mediaType)
  dataFiles: DataFiles[];

  @OneToMany(() => DataFileMetakeys, dataFileMetakeys => dataFileMetakeys.mediaTypes, { cascade: ['insert', 'update', 'remove'] })
  dataFileMetakeys: DataFileMetakeys[];

  @ManyToMany(() => Sensors, sensors => sensors.mediaTypes, { nullable: false })
  @JoinTable()
  sensors: Sensors[];

}
