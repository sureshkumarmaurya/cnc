import { Entity, Column, PrimaryColumn, AfterLoad } from 'typeorm';

@Entity('projects_operational_analytics_vw')
export class ProjectsOperationalAnalytics {

  @PrimaryColumn('integer', {
    nullable: false,
    unique: true,
    name: 'project_id',
  })
  projectId: number;

  @Column('integer', {
    name: 'images_number',
  })
  numImages: number;

  @Column('integer', {
    name: 'observations',
  })
  numObservations: number;

  @Column('integer', {
    name: 'unique_species',
  })
  numSpecies: number;

  @Column('integer', {
    name: 'unique_locations',
  })
  uniqueLocations: number;

  @Column('integer', {
    name: 'blank_images_count',
  })
  blankImagesCount: number;

  @Column('integer', {
    name: 'unknown_images_count',
  })
  unknownImagesCount: number;

  @Column('integer', {
    name: 'deployments_count',
  })
  numDeployments: number;

  @Column('jsonb', {
    name: 'countries',
    array: true,
  })
  countries: object;

  @Column('integer', {
    name: 'countries_count',
  })
  numCountries: number;

  @Column('integer', {
    name: 'devices_count',
  })
  numDevices: number;

  @Column('integer', {
    name: 'identifications_count',
  })
  numIdentifications: number;

  @Column('integer', {
    name: 'sampling_days_count',
  })
  samplingDaysCount: number;

  @Column('integer', {
    name: 'users_with_roles_on_project',
  })
  usersWithRolesOnProject: number;

  @Column('integer', {
    name: 'users_count',
  })
  numUsers: number;

  @Column('integer', {
    name: 'human_images_count',
  })
  humanImagesCount: number;

  @Column('integer', {
    name: 'wildlife_images_count',
  })
  wildlifeImagesCount: number;

  averageNumberOfImagesPerDeployment?: number;

  @Column('jsonb', {
    name: 'images_per_species',
    array: true,
  })
  imagesPerSpecies: object;

  @Column('jsonb', {
    name: 'images_per_location',
    array: true,
  })
  imagesPerLocation: object;

  @AfterLoad()
  computeAverageNumberOfImagesPerDeploy() {
    /**
     * calculate average number of images per deployment
     */
    if (this.numImages && this.numDeployments) {
      this.averageNumberOfImagesPerDeployment = Math.floor(this.numImages / this.numDeployments);
    } else {
      this.averageNumberOfImagesPerDeployment = 0;
    }
  }
}
