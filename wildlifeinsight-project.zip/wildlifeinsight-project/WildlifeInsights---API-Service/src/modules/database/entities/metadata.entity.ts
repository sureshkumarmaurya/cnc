import { Entity, Column, OneToOne, OneToMany, ManyToOne, ManyToMany, JoinColumn, JoinTable, PrimaryGeneratedColumn } from 'typeorm';

@Entity('metadata')
export abstract class Metadata {

  @PrimaryGeneratedColumn()
  id: number;

  @Column('jsonb', {
    nullable: true,
    name: 'metadata',
  })
  metadata: object;
}
