import { Entity, Column, OneToMany, ManyToMany, JoinTable, PrimaryGeneratedColumn, OneToOne, JoinColumn } from 'typeorm';
import { Participants } from './participants.entity';
import { Initiatives } from './initiatives.entity';
import { Projects } from './projects.entity';
import { Devices } from './devices.entity';
import { OrganizationParticipantPivot } from 'modules/database/entities/organization-participant-pivot.entity';
import { BatchUploads } from './batch-uploads.entity';

@Entity('organizations')
export class Organizations {

  @PrimaryGeneratedColumn()
  id: number;

  @Column('varchar', {
    nullable: false,
    length: 255,
    name: 'name',
    unique: true,
  })
  name: string | null;

  @Column('varchar', {
    nullable: true,
    length: 255,
    name: 'street_address',
  })
  streetAddress: string | null;

  @Column('varchar', {
    nullable: true,
    length: 255,
    name: 'city',
  })
  city: string | null;

  @Column('varchar', {
    nullable: true,
    length: 255,
    name: 'state',
  })
  state: string | null;

  @Column('varchar', {
    nullable: true,
    length: 255,
    name: 'postal_code',
  })
  postalCode: string | null;

  @Column('varchar', {
    nullable: true,
    length: 255,
    name: 'phone',
  })
  phone: string | null;

  @Column('varchar', {
    nullable: true,
    length: 255,
    name: 'email',
  })
  email: string | null;

  @Column('varchar', {
    nullable: true,
    length: 255,
    name: 'country_code',
  })
  countryCode: string | null;

  @Column('varchar', {
    nullable: true,
    length: 255,
    name: 'organization_url',
  })
  organizationUrl: string | null;

  @Column('text', {
    nullable: true,
    name: 'remarks',
  })
  remarks: string | null;

  @OneToMany(() => Initiatives, initiatives => initiatives.ownerOrganization)
  initiativesOwner: Initiatives[];

  @ManyToMany(() => Initiatives, initiatives => initiatives.members)
  @JoinTable()
  initiativesMember: Initiatives[];

  @OneToMany(() => Projects, projects => projects.organization, { nullable: false })
  projects: Projects[];

  @OneToMany(() => Devices, projects => projects.organization, { nullable: false })
  devices: Devices[];

  @OneToMany(() => OrganizationParticipantPivot, organizationParticipantPivot => organizationParticipantPivot.organization, { cascade: ['update', 'insert', 'remove'] })
  organizationParticipantPivot: OrganizationParticipantPivot[] | null;

  @OneToMany(() => BatchUploads, batchUploads => batchUploads.organization, { nullable: false })
  batchUploads: BatchUploads[];
}
