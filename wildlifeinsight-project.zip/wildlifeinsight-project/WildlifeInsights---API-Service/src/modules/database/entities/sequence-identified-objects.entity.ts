import { Index, Entity, PrimaryColumn, Column, OneToOne, OneToMany, ManyToOne, ManyToMany, JoinColumn, JoinTable, RelationId, PrimaryGeneratedColumn } from 'typeorm';
import { SequenceIdentificationOutputs } from './sequence-identification-outputs.entity';
import { IdentificationMetavalues } from './identification-metavalues.entity';
import { Taxonomies } from './taxonomies.entity';
// import { IdentifiedIndividuals } from './identified-individuals.entity';

@Entity('sequence_identified_objects')
export class SequenceIdentifiedObjects {

  @PrimaryGeneratedColumn()
  id: number;

  @Column('varchar', {
    nullable: true,
    length: 255,
    name: 'common_name',
  })
  commonName: string;

  @Column('varchar', {
    nullable: true,
    length: 255,
    name: 'relative_age',
  })
  relativeAge: string;

  @Column('varchar', {
    nullable: true,
    length: 255,
    name: 'sex',
  })
  sex: string;

  @Column('text', {
    nullable: true,
    name: 'markings',
  })
  markings: string;

  @Column('boolean', {
    nullable: true,
    name: 'individual_identified',
  })
  individualIdentified: boolean;

  @Column('text', {
    nullable: true,
    name: 'behavior',
  })
  behavior: string;

  @Column('text', {
    nullable: true,
    name: 'remarks',
  })
  remarks: string;

  @Column('timestamp without time zone', {
    nullable: true,
    name: 'date',
  })
  date: Date;

  @Column('integer', {
    nullable: true,
    name: 'certainity',
  })
  certainity: number;

  @Column('integer', {
    nullable: false,
    name: 'sequence_identifications_id',
  })
  sequenceIdentificationId: number;

  @Column('integer', {
    nullable: true,
    name: 'identification_metavalues_id',
  })
  identificationMetavalueId: number;

  /**
   * Mismatch between column name and variable name is due to the fact that
   * `taxonomyId` was originally mapping to the `taxonomy_id` column (which was
   * a foreign key to `taxonomies.id` - a db sequence for in the `taxonomies`
   * table), but in August 2019 we added UUIDs to taxonomies, and it made sense
   * to use those as the FK from `identifiedObjects` to `taxonomies` (see
   * https://www.pivotaltracker.com/story/show/168356443 for context).
   *
   * However, in order to preserve the general pattern used throughout the
   * API (`<entitytype>Id`), the actual variable name is left unchanged.
   */
  @Column('varchar', {
    nullable: false,
    name: 'taxonomies_uuid',
  })
  taxonomyId: string;

  @ManyToOne(type => SequenceIdentificationOutputs, sequenceIdentificationOutputs => sequenceIdentificationOutputs.identifiedObjects, { nullable: false ,  onDelete: 'CASCADE' })
  @JoinColumn({ name: 'sequence_identifications_id' })
  identification: SequenceIdentificationOutputs | null;

  @ManyToOne(type => IdentificationMetavalues, identificationMetavalues => identificationMetavalues.identifiedObjects, { nullable: true })
  @JoinColumn({ name: 'identification_metavalues_id' })
  identificationMetavalue: IdentificationMetavalues | null;

  @ManyToOne(type => Taxonomies, taxonomies => taxonomies.sequenceIdentifiedObjects, { nullable: false })
  @JoinColumn({ name: 'taxonomies_uuid' })
  taxonomy: Taxonomies | null;

  // @OneToMany(type => IdentifiedIndividuals, identifiedIndividuals => identifiedIndividuals.identifiedAnimals)
  // identifiedIndividuals: IdentifiedIndividuals[];

}
