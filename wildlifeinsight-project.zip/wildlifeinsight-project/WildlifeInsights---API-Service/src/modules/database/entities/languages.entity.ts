import { Entity, Column } from 'typeorm';

@Entity('languages')
export class Languages {

  @Column('varchar', {
    primary: true,
    nullable: false,
    unique: true,
    length: 2,
    name: 'code',
  })
  code: string;

  @Column('varchar', {
    nullable: false,
    unique: true,
    length: 255,
    name: 'name',
  })
  name: string;
}
