import { Entity, Column, ManyToMany, PrimaryGeneratedColumn } from 'typeorm';
import { Roles } from './roles.entity';

@Entity('permissions')
export class Permissions {

  @PrimaryGeneratedColumn()
  id: number;

  @Column('varchar', {
    nullable: false,
    length: 255,
    name: 'name',
  })
  name: string;

  @Column('varchar', {
    nullable: false,
    unique: true,
    length: 255,
    name: 'slug',
  })
  slug: string;

  @Column('text', {
    nullable: true,
    name: 'description',
  })
  description: string;

  @ManyToMany(() => Roles, roles => roles.permissions)
  roles: Roles[] | null;
}
