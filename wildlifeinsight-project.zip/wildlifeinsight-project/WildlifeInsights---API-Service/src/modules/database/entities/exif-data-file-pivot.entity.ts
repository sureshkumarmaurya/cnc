import { Index, Entity, PrimaryColumn, Column, OneToOne, OneToMany, ManyToOne, ManyToMany, JoinColumn, JoinTable, RelationId } from 'typeorm';
import { DataFiles } from './data-files.entity';
import { ExifTags } from './exif-tags.entity';

@Entity('exif_data_file_pivot')
export class ExifDataFilePivot {

  @Column('varchar', {
    nullable: false,
    length: 4096,
    name: 'value',
  })
  value: string;

  @Column('int', {
    nullable: false,
    name: 'data_file_id',
    primary: true,
  })
  dataFileId: number;

  @Column('int', {
    nullable: false,
    name: 'exif_tag_id',
    primary: true,
  })
  exifTagId: number;

  @ManyToOne(type => DataFiles, dataFile => dataFile.exifDataFilePivots, { nullable: false, onDelete: 'CASCADE' })
  @JoinColumn({ name: 'data_file_id' })
  dataFile: DataFiles | null;

  @ManyToOne(type => ExifTags, exifTags => exifTags.exifDataFilePivots, { nullable: false })
  @JoinColumn({ name: 'exif_tag_id' })
  exifTag: ExifTags | null;

}
