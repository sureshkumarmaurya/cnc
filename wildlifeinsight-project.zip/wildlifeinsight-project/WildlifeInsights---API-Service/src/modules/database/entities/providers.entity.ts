import { Entity, Column, ManyToOne, ManyToMany, JoinColumn, PrimaryGeneratedColumn, OneToMany } from 'typeorm';
import { Participants } from './participants.entity';

@Entity('providers')
export class Providers {

  @PrimaryGeneratedColumn()
  id: number;

  @Column('varchar', {
    nullable: false,
    length: 255,
    name: 'provider',
  })
  provider: string;

  @Column('varchar', {
    nullable: true,
    length: 255,
    name: 'provider_id',
  })
  providerId: string;

  @ManyToOne(() => Participants, participants => participants.providers)
  participant: Participants | null;

}
