import { Entity, Column, OneToMany, ManyToOne, JoinColumn, PrimaryGeneratedColumn, AfterInsert, AfterUpdate, getManager } from 'typeorm';
import { DataFiles } from './data-files.entity';
import { IdentifiedObjects } from './identified-objects.entity';
import { IdentificationMethods } from './identification-methods.entity';
import { Participants } from './participants.entity';

const logger = require('logger');

@Entity('identification_outputs')
export class IdentificationOutputs {

  @PrimaryGeneratedColumn()
  id: number;

  @Column('boolean', {
    nullable: false,
    name: 'blank_yn',
  })
  blankYn: boolean;

  @Column('decimal', {
    scale: 2,
    precision: 2,
    nullable: true,
  })
  confidence: number | null;

  @Column('integer', {
    nullable: false,
    name: 'data_file_id',
  })
  dataFileId: number;

  @Column('integer', {
    nullable: false,
    name: 'identification_methods_id',
  })
  identificationMethodId: number;

  @Column('timestamp without time zone', {
    nullable: false,
    name: 'timestamp',
    default: () => 'CURRENT_TIMESTAMP',
  })
  timestamp: Date;

  @Column('integer', {
    nullable: true,
    name: 'participants_id',
  })
  participantId: number;

  @ManyToOne(() => DataFiles, dataFile => dataFile.identificationOutputs, { nullable: false, onDelete: 'CASCADE' })
  @JoinColumn({ name: 'data_file_id' })
  dataFile: DataFiles;

  @ManyToOne(() => Participants, participant => participant.identificationOutputs, { nullable: false })
  @JoinColumn({ name: 'participants_id' })
  participant: Participants;

  @OneToMany(() => IdentifiedObjects, indentifiedObjects => indentifiedObjects.identification, { cascade: ['insert', 'remove', 'update'], onDelete: 'CASCADE' })
  identifiedObjects: IdentifiedObjects[];

  @ManyToOne(() => IdentificationMethods, identificationMethod => identificationMethod.identificationOutputs, { nullable: false })
  @JoinColumn({ name: 'identification_methods_id' })
  identificationMethod: IdentificationMethods;

  @AfterInsert()
  @AfterUpdate()
  /**
   * If a human is included in the identification, set the
   * `dataFile.humanIdentified` flag for the parent data file.
   *
   * Caveats: this cannot be done with entity listeners on the IdentifiedObjects
   * entity itself because of issues related to transaction isolation.
   *
   * Moreover, although the field gets set correctly when persisting the data to
   * db, the response from the API will carry the *previous value* of the
   * `humanIdentified` field for the parent data file.
   *
   * However, given the use case we want to cover (setting the field accurately
   * so that when retrieving lists of data files, users without an owner role on
   * a project will not be shown images of humans), this is unlikely to be an
   * actual problem.
   */
  private async setHumanIdentifiedFlag() : Promise<void> {
    const entityManager = getManager();

    // Get the numeric id of the parent data file, which we should update by
    // setting its `humanIdentified` flag
    const parentDataFile = await entityManager.getRepository<DataFiles>('DataFiles')
      .findOne({ id: this.dataFileId });

    /**
     * If we are creating an IdentificationOutput for a *new* data file (rather
     * than adding an IdentificationOutput to a data file which is already
     * persisted to database), `parentDataFile` will not be defined yet at this
     * stage, as the record will not be in the database yet. For new data files,
     * the `humanIdentified` flag needs to be set during the creation of the
     * data file itself (both for uploads via the API and for batch uploads).
     */
    if (!parentDataFile) {
      return;
    }

    if (
      Array.isArray(this.identifiedObjects) && this.identifiedObjects.find(i => i.taxonomy && i.taxonomy.genus === 'Homo' && i.taxonomy.species === 'sapiens')) {
      parentDataFile.humanIdentified = true;
    } else {
      parentDataFile.humanIdentified = false;
    }
    await entityManager.getRepository<DataFiles>('DataFiles').save(parentDataFile);
  }
}
