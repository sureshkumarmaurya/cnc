import { Entity, Column, OneToMany, PrimaryGeneratedColumn } from 'typeorm';
import { IdentificationMetavalues } from './identification-metavalues.entity';

@Entity('identification_metakeys')
export class IdentificationMetakeys {

  @PrimaryGeneratedColumn()
  id: number;

  @Column('varchar', {
    nullable: true,
    length: 255,
    name: 'key_variable',
  })
  keyVariable: string;

  @Column('varchar', {
    nullable: false,
    length: 255,
    name: 'key_name',
  })
  keyName: string;

  @Column('integer', {
    nullable: true,
    name: 'remarks',
  })
  remarks: number;

  @OneToMany(() => IdentificationMetavalues, identificationMetavalues => identificationMetavalues.key)
  identificationMetavaluess: IdentificationMetavalues[];

}
