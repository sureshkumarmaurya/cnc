import { Entity, Column, OneToMany, ManyToOne, JoinColumn, PrimaryGeneratedColumn } from 'typeorm';
import { Locations } from './locations.entity';
import { PlacementConfiguration } from './placement-configuration.entity';

@Entity('features')
export class Features {

  @PrimaryGeneratedColumn()
  id: number;

  @Column('varchar', {
    nullable: true,
    length: 255,
    name: 'feature_name',
  })
  featureName: string | null;

  @Column('text', {
    nullable: true,
    name: 'description',
  })
  description: string | null;

  @ManyToOne(() => Locations, locations => locations.features, { nullable: false })
  @JoinColumn({ name: 'locations_id' })
  locations: Locations;

  @OneToMany(() => PlacementConfiguration, placementConfiguration => placementConfiguration.features)
  placementConfigurations: PlacementConfiguration[];

}
