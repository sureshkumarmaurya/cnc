import { Entity } from 'typeorm';
import { IdentificationOutputs } from './identification-outputs.entity';

@Entity('latest_identification_outputs_by_data_file')
export class LatestIdentificationOutputs extends IdentificationOutputs { }
