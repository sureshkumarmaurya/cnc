import { Entity, Column, ManyToMany, PrimaryGeneratedColumn, JoinColumn, ManyToOne, OneToMany } from 'typeorm';
import { DataFiles } from './data-files.entity';
import { Deployments } from './deployments.entity';
import { SequenceIdentificationOutputs } from './sequence-identification-outputs.entity';
import { DataFileSequencePivot } from './data-file-sequence-pivot.entity';

@Entity('sequences')
export class Sequences {

  @PrimaryGeneratedColumn()
  id: number;

  @Column('varchar', {
    nullable: false,
    length: 255,
    name: 'name',
  })
  name: string;

  @Column('varchar', {
    nullable: true,
    length: 255,
    name: 'control_field',
  })
  controlField: string;

  @Column('integer', {
    nullable: true,
    name: 'rule',
  })
  rule: number;

  @Column('text', {
    nullable: true,
    name: 'remarks',
  })
  remarks: string;

  @Column('varchar', {
    nullable: true,
    length: 255,
    name: 'sequence_identifier',
  })
  sequenceIdentifier: string;

  @Column('integer', {
    nullable: false,
    name: 'deployment_id',
  })
  deploymentId: number;

  @ManyToOne(type => Deployments, deployments => deployments.dataFiles, { nullable: false, onDelete: 'CASCADE' })
  @JoinColumn({ name: 'deployment_id' })
  deployment: Deployments | null;

  @OneToMany(type => DataFileSequencePivot, dataFileSequencePivot => dataFileSequencePivot.dataFile, { cascade: ['insert', 'update', 'remove'] })
  dataFileSequencePivots: DataFileSequencePivot[] | null;

  @OneToMany(type => SequenceIdentificationOutputs, sequenceIdentificationOutputs => sequenceIdentificationOutputs.sequence, { cascade: ['insert', 'update', 'remove'], nullable: true })
  sequenceIdentificationOutputs: SequenceIdentificationOutputs[];

}
