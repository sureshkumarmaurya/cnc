import { Entity, Column, PrimaryColumn } from 'typeorm';

@Entity('cameras_batch_upload_vw')
export class BatchDownloadsCameras {
  @PrimaryColumn('int', {
    name: 'project_internal_id',
  })
  projectInternalId: number;

  @Column('int', {
    name: 'device_id',
  })
  cameraId: number;

  @Column('varchar', {
    nullable: true,
    name: 'project_id',
  })
  projectId: string | null;

  @Column('varchar', {
    nullable: true,
    name: 'device_make',
  })
  make: string | null;

  @Column('varchar', {
    nullable: true,
    name: 'device_model',
  })
  model: string | null;

  @Column('varchar', {
    nullable: true,
    name: 'device_serial_number',
  })
  serialNumber: string | null;

  @Column('int', {
    nullable: true,
    name: 'device_purchase_year',
  })
  yearPurchased: number;
}
