import { Entity, Column, ManyToOne, ManyToMany, JoinColumn, PrimaryGeneratedColumn } from 'typeorm';
import { Projects } from './projects.entity';
import { Deployments } from './deployments.entity';

@Entity('tags')
export class Tags {

  @PrimaryGeneratedColumn()
  id: number;

  @Column('varchar', {
    nullable: false,
    length: 255,
    name: 'tag_name',
  })
  tagName: string;

  @ManyToOne(() => Projects, projects => projects.tags, { nullable: false })
  @JoinColumn({ name: 'project_id' })
  project: Projects | null;

  @ManyToMany(() => Deployments, deployments => deployments.tags)
  deployments: Deployments[];

}
