import { Entity, Column, OneToMany, ManyToOne, ManyToMany, JoinColumn, PrimaryGeneratedColumn } from 'typeorm';
import { Devices } from './devices.entity';
import { MediaTypes } from './media-types.entity';

@Entity('sensors')
export class Sensors {

  @PrimaryGeneratedColumn()
  id: number;

  @Column('varchar', {
    nullable: false,
    length: 255,
    name: 'name',
  })
  name: string;

  @Column('float', {
    nullable: true,
    name: 'trigger_speed',
  })
  triggerSpeed: number | null;

  @Column('float', {
    nullable: true,
    name: 'gain',
  })
  gain: number | null;

  @Column('text', {
    nullable: true,
    name: 'remarks',
  })
  remarks: string | null;

  @Column('boolean', {
    nullable: false,
    name: 'active',
    default: true,
  })
  active: boolean;

  @Column('int', {
    nullable: false,
    name: 'devices_id',
  })
  deviceId: number;

  @ManyToOne(() => Devices, devices => devices.sensors, { nullable: false })
  @JoinColumn({ name: 'devices_id' })
  device: Devices | null;

  @ManyToMany(() => MediaTypes, mediaTypes => mediaTypes.sensors)
  mediaTypes: MediaTypes[];

}
