import { Entity, Column, OneToMany, ManyToOne, JoinColumn, PrimaryGeneratedColumn } from 'typeorm';
import { Sequences } from './sequences.entity';
import { SequenceIdentifiedObjects } from './sequence-identified-objects.entity';
import { IdentificationMethods } from './identification-methods.entity';
import { Participants } from './participants.entity';

@Entity('sequence_identification_outputs')
export class SequenceIdentificationOutputs {

  @PrimaryGeneratedColumn()
  id: number;

  @Column('boolean', {
    nullable: false,
    name: 'blank_yn',
  })
  blankYn: boolean;

  @Column('integer', {
    nullable: false,
    name: 'sequence_id',
  })
  sequenceId: number;

  @Column('integer', {
    nullable: false,
    name: 'identification_methods_id',
  })
  identificationMethodId: number;

  @Column('timestamp without time zone', {
    nullable: false,
    name: 'timestamp',
    default: () => 'CURRENT_TIMESTAMP',
  })
  timestamp: Date;

  @Column('integer', {
    nullable: true,
    name: 'participants_id',
  })
  participantId: number;

  @ManyToOne(() => Sequences, sequence => sequence.sequenceIdentificationOutputs, { nullable: false, onDelete: 'CASCADE' })
  @JoinColumn({ name: 'sequence_id' })
  sequence: Sequences;

  @ManyToOne(() => Participants, participant => participant.sequenceIdentificationOutputs, { nullable: false })
  @JoinColumn({ name: 'participants_id' })
  participant: Participants;

  @OneToMany(() => SequenceIdentifiedObjects, identifiedObjects => identifiedObjects.identification, { cascade: ['insert', 'remove', 'update'], onDelete: 'CASCADE' })
  identifiedObjects: SequenceIdentifiedObjects[];

  @ManyToOne(() => IdentificationMethods, identificationMethod => identificationMethod.identificationOutputs, { nullable: false })
  @JoinColumn({ name: 'identification_methods_id' })
  identificationMethod: IdentificationMethods;
}
