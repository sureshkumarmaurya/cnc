import { Entity, Column, PrimaryColumn } from 'typeorm';

/**
 * Entity definition for the `science_data` view
 */
@Entity('science_data_vw')
export class ProjectScienceData {

  @PrimaryColumn({
    name: 'id',
  })
  id: number;

  @Column({
    type: 'int',
    name: 'project_id',
  })
  projectId: number;

  @Column({
    type: 'int',
    name: 'organization_id',
  })
  organizationId: number;

  @Column({
    type: 'varchar',
    name: 'site_name',
  })
  siteName: string | null;

  @Column({
    type: 'varchar',
    name: 'deployment_name',
  })
  deploymentName: string | null;

  @Column({
    type: 'float',
    name: 'latitude',
  })
  latitude: number;

  @Column({
    type: 'float',
    name: 'longitude',
  })
  longitude: number;

  @Column({
    type: 'varchar',
    name: 'deployment_location_id',
  })
  deploymentLocationId: string | null;

  @Column({
    type: 'date',
    name: 'photo_date',
  })
  photoDate: string | null;

  @Column({
    type: 'time',
    name: 'photo_time',
  })
  photoTime: string | null;

  @Column({
    type: 'time',
    name: 'photo_datetime',
  })
  photoDateTime: string | null;

  @Column({
    type: 'varchar',
    name: 'raw_name',
  })
  rawName: string;

  @Column({
    type: 'varchar',
    name: 'class',
  })
  'class': string;

  @Column({
    type: 'varchar',
    name: 'order',
  })
  order: string;

  @Column({
    type: 'varchar',
    name: 'family',
  })
  family: string;

  @Column({
    type: 'varchar',
    name: 'genus',
  })
  genus: string;

  @Column({
    type: 'varchar',
    name: 'species',
  })
  species: string;

  @Column({
    type: 'varchar',
    name: 'sp_binomial',
  })
  spBinomial: string;

  @Column({
    type: 'int',
    name: 'wi_taxa_id',
  })
  wiTaxaId: number | null;

  @Column({
    type: 'int',
    name: 'number_of_animals',
  })
  numberOfAnimals: number;

  @Column({
    type: 'float',
    name: 'certainty',
  })
  certainty: number;

  @Column({
    type: 'varchar',
    name: 'camera_serial_number',
  })
  cameraSerialNumber: string;

  @Column({
    type: 'varchar',
    name: 'camera_notes',
  })
  cameraNotes: string;

  @Column({
    type: 'date',
    name: 'sensor_start_date_and_time',
  })
  sensorStartDateAndTime: string;

  @Column({
    type: 'date',
    name: 'sensor_end_date_and_time',
  })
  sensorEndDateAndTime: string;

  @Column({
    type: 'varchar',
    name: 'camera_make',
  })
  cameraMake: string;

  @Column({
    type: 'varchar',
    name: 'camera_model',
  })
  cameraModel: string;
}
