import { Entity, Column, PrimaryGeneratedColumn } from 'typeorm';
type RoleChangeType = 'create' | 'update' | 'delete';

@Entity('role_changes')
export class RoleChanges {

  @PrimaryGeneratedColumn()
  id: number;

  @Column('integer', {
    nullable: true,
    name: 'participants_id',
  })
  participantId: number;

  @Column('integer', {
    nullable: true,
    name: 'organizations_id',
  })
  organizationId: number;

  @Column('integer', {
    nullable: true,
    name: 'initiatives_id',
  })
  initiativeId: number;

  @Column('integer', {
    nullable: true,
    name: 'projects_id',
  })
  projectId: number;

  @Column('integer', {
    nullable: false,
    name: 'invitation_initiator_id',
  })
  invitationInitiatorId: number;

  @Column('integer', {
    nullable: false,
    name: 'role_id',
  })
  roleId: number;

  @Column('enum', {
    nullable: false,
    enum: ['create', 'update', 'delete'],
    name: 'change_type',
  })
  changeType: RoleChangeType;

  @Column('varchar', {
    nullable: false,
    name: 'activation_token',
  })
  activationToken: string;

  @Column('varchar', {
    nullable: false,
    name: 'status',
  })
  status: string;

  @Column('varchar', {
    nullable: true,
    name: 'email',
  })
  email: string | null;

  @Column('date', {
    nullable: false,
    name: 'change_timestamp',
  })
  changeTimestamp: Date;
}
