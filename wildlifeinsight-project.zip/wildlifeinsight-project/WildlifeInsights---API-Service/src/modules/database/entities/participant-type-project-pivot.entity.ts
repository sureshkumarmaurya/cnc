import { Entity, Column, ManyToOne, JoinColumn } from 'typeorm';
import { Participants } from './participants.entity';
import { ParticipantTypes } from './participant-types.entity';
import { Projects } from './projects.entity';
import { Roles } from './roles.entity';
import { EntityParticipantPivot } from 'utils/entities.utils';

@Entity('participant_type_project_pivot')
export class ParticipantTypeProjectPivot extends EntityParticipantPivot {
  constructor() {
    super('project');
  }

  @Column('date', {
    nullable: false,
    name: 'start_date',
    default: () => 'CURRENT_TIMESTAMP',
  })
  startDate: Date;

  @Column('date', {
    nullable: true,
    name: 'end_date',
  })
  endDate: Date;

  @Column('varchar', {
    nullable: true,
    length: 255,
    name: 'status',
  })
  status: string;

  @Column('integer', {
    nullable: false,
    name: 'participant_id',
    primary: true,
  })
  participantId: number;

  @Column('integer', {
    nullable: false,
    name: 'participant_type_id',
    primary: true,
  })
  participantTypeId: number;

  @Column('integer', {
    nullable: false,
    name: 'project_id',
    primary: true,
  })
  projectId: number;

  @Column('integer', {
    nullable: false,
    name: 'roles_id',
    primary: true,
  })
  roleId: number;

  @Column('boolean', {
    nullable: false,
    name: 'is_implicit',
    default: false,
  })
  isImplicit: boolean;

  @ManyToOne(() => Participants, participants => participants.participantTypeProjectPivot, { primary: true, nullable: false })
  @JoinColumn({ name: 'participant_id' })
  participant: Participants | null;

  @ManyToOne(() => ParticipantTypes, participantTypes => participantTypes.participantTypeProjectPivot, { primary: true, nullable: false })
  @JoinColumn({ name: 'participant_type_id' })
  participantType: ParticipantTypes | null;

  @ManyToOne(() => Projects, projects => projects.participantTypeProjectPivot, { primary: true, nullable: false, onDelete: 'CASCADE' })
  @JoinColumn({ name: 'project_id' })
  project: Projects | null;

  @ManyToOne(() => Roles, roles => roles.participantTypeProjectPivot, { primary: true, nullable: false })
  @JoinColumn({ name: 'roles_id' })
  role: Roles ;

}
