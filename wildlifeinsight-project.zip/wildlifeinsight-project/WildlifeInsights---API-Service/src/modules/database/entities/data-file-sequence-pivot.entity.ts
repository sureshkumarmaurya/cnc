import { Entity, Column, ManyToOne, JoinColumn } from 'typeorm';
import { Sequences } from './sequences.entity';
import { DataFiles } from './data-files.entity';

@Entity('data_file_sequence_pivot')
export class DataFileSequencePivot {

  @Column('integer', {
    nullable: false,
    name: 'position',
  })
  position: number;

  @Column('integer', {
    nullable: false,
    name: 'data_file_id',
    primary: true,
  })
  dataFileId: number;

  @Column('integer', {
    nullable: false,
    name: 'sequence_id',
    primary: true,
  })
  sequenceId: number;

  @ManyToOne(() => Sequences, sequence => sequence.dataFileSequencePivots, { primary: true, nullable: false, onDelete: 'CASCADE' })
  @JoinColumn({ name: 'sequence_id' })
  sequence: Sequences;

  @ManyToOne(() => DataFiles, dataFile => dataFile.dataFileSequencePivots, { primary: true, nullable: false, onDelete: 'CASCADE' })
  @JoinColumn({ name: 'data_file_id' })
  dataFile: DataFiles;

}
