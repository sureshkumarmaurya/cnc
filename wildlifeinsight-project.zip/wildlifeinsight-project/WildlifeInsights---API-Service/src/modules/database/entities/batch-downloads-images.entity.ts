import { Entity, Column, PrimaryColumn } from 'typeorm';
import { DataFilesLicenseType } from './projects.entity';

@Entity('images_batch_upload_vw')
export class BatchDownloadsImages {

  @PrimaryColumn('int', {
    nullable: false,
    name: 'image_id',
  })
  imageId: number;

  @Column('int', {
    nullable: false,
    name: 'project_internal_id',
  })
  projectInternalId: number | null;

  @Column('varchar', {
    nullable: true,
    name: 'project_id',
  })
  projectId: string | null;

  @Column('varchar', {
    nullable: false,
    name: 'deployment_id',
  })
  deploymentId: string;

  @Column('varchar', {
    nullable: false,
    name: 'filepath',
  })
  filepath: string;

  @Column('varchar', {
    nullable: false,
    name: 'project_slug',
  })
  projectSlug: string;

  @Column('boolean', {
    nullable: false,
    name: 'is_blank',
  })
  isBlank: boolean;

  @Column('varchar', {
    nullable: true,
    name: 'identified_by',
  })
  identifiedBy: string | null;

  @Column('uuid', {
    nullable: false,
    name: 'wi_taxon_id',
  })
  wiTaxonId: string;

  @Column('varchar', {
    nullable: true,
    name: 'class',
  })
  class: string | null;

  @Column('varchar', {
    nullable: true,
    name: 'order',
  })
  order: string | null;

  @Column('varchar', {
    nullable: true,
    name: 'family',
  })
  family: string | null;

  @Column('varchar', {
    nullable: true,
    name: 'genus',
  })
  genus: string | null;

  @Column('varchar', {
    nullable: true,
    name: 'species',
  })
  species: string | null;

  @Column('varchar', {
    nullable: true,
    name: 'common_name',
  })
  commonName: string | null;

  @Column('varchar', {
    nullable: true,
    name: 'uncertainty',
  })
  uncertainty: string | null;

  @Column('timestamp without time zone', {
    nullable: true,
    name: 'timestamp',
  })
  timestamp: string | null;

  @Column('varchar', {
    nullable: true,
    name: 'age',
  })
  age: string | null;

  @Column('varchar', {
    nullable: true,
    name: 'sex',
  })
  sex: string | null;

  @Column('boolean', {
    nullable: true,
    name: 'animal_recognizable',
  })
  animalRecognizable: boolean | null;

  @Column('varchar', {
    nullable: true,
    name: 'individual_id',
  })
  individualId: string | null;

  @Column('int', {
    nullable: true,
    name: 'number_of_animals',
  })
  numberOfAnimals: number | null;

  @Column('varchar', {
    nullable: true,
    name: 'individual_animal_notes',
  })
  individualAnimalNotes: string | null;

  @Column('boolean', {
    nullable: true,
    name: 'highlighted',
  })
  highlighted: boolean | null;

  @Column('varchar', {
    nullable: true,
    name: 'color',
  })
  color: string | null;

  @Column('enum', {
    nullable: true,
    enum: ['CC0', 'CC-BY', 'CC-BY-NC'],
    name: 'license',
  })
  license: DataFilesLicenseType | null;
}
