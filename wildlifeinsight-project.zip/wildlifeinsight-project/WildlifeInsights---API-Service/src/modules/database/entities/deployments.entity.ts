import { Index, Entity, PrimaryColumn, Column, OneToOne, OneToMany, ManyToOne, ManyToMany, JoinColumn, JoinTable, RelationId, PrimaryGeneratedColumn } from 'typeorm';
import { PairedDeployments } from './paired-deployments.entity';
import { Devices } from './devices.entity';
import { BaitTypes } from './bait-types.entity';
import { Locations } from './locations.entity';
import { Participants } from './participants.entity';
import { Projects } from './projects.entity';
import { Subprojects } from './subprojects.entity';
import { DataFiles } from './data-files.entity';
import { PlacementConfiguration } from './placement-configuration.entity';
import { Tags } from './tags.entity';
import { Sequences } from './sequences.entity';
import { Metadata } from './metadata.entity';

@Entity('deployments')
export class Deployments extends Metadata {

  @Column('varchar', {
    nullable: false,
    length: 255,
    name: 'deployment_identifier',
  })
  deploymentIdentifier: string;

  @Column('varchar', {
    nullable: false,
    length: 255,
    name: 'deployment_name',
  })
  deploymentName: string;

  @Column('varchar', {
    nullable: true,
    length: 255,
    name: 'sensor_height',
  })
  sensorHeight: string | null;

  @Column('integer', {
    nullable: true,
    name: 'quiet_period',
  })
  quietPeriod: number | null;

  @Column('float', {
    nullable: true,
    name: 'detection_distance',
  })
  detectionDistance: number | null;

  @Column('varchar', {
    nullable: true,
    length: 255,
    name: 'sample_rate',
  })
  sampleRate: string | null;

  @Column('varchar', {
    nullable: true,
    length: 255,
    name: 'sensor_orientation',
  })
  sensorOrientation: string | null;

  @Column('varchar', {
    nullable: true,
    length: 255,
    name: 'sensor_schedule',
  })
  sensorSchedule: string | null;

  @Column('varchar', {
    nullable: true,
    length: 255,
    name: 'sensor_resolution',
  })
  sensorResolution: string | null;

  @Column('varchar', {
    nullable: true,
    length: 255,
    name: 'sensor_sensitivity',
  })
  sensorSensitivity: string | null;

  @Column('text', {
    nullable: true,
    name: 'sensor_failure_details',
  })
  sensorFailureDetails: string | null;

  @Column('varchar', {
    nullable: true,
    length: 255,
    name: 'sensor_end_status',
  })
  sensorEndStatus: string | null;

  @Column('date', {
    nullable: true,
    name: 'start_datetime',
  })
  startDatetime: Date | null;

  @Column('date', {
    nullable: true,
    name: 'end_datetime',
  })
  endDatetime: Date | null;

  @Column('text', {
    nullable: true,
    name: 'remarks',
  })
  remarks: string | null;

  @Column('int', {
    nullable: false,
    name: 'projects_id',
  })
  projectId: number;

  @Column('int', {
    nullable: true,
    name: 'subproject_id',
  })
  subprojectId: number;

  @Column('int', {
    nullable: true,
    name: 'participant_remove_sensor_id',
  })
  participantRemoveSensorId: number;

  @Column('int', {
    nullable: true,
    name: 'participant_set_sensor_id',
  })
  participantSetSensorId: number;

  @Column('int', {
    nullable: true,
    name: 'bait_type_id',
  })
  baitTypeId: number;

  @Column('int', {
    nullable: true,
    name: 'device_id',
  })
  deviceId: number;

  @Column('int', {
    nullable: false,
    name: 'locations_id',
  })
  locationId: number;

  @ManyToOne(type => PairedDeployments, pairedDeployments => pairedDeployments.deployments, { nullable: true })
  @JoinColumn({ name: 'paired_deployments_id' })
  pairedDeployments: PairedDeployments | null;

  @ManyToOne(type => Devices, devices => devices.deployments, { nullable: false })
  @JoinColumn({ name: 'device_id' })
  device: Devices | null;

  @ManyToOne(type => BaitTypes, baitTypes => baitTypes.deployments, { nullable: true })
  @JoinColumn({ name: 'bait_type_id' })
  baitType: BaitTypes | null;

  @ManyToOne(type => Locations, locations => locations.deployments, { nullable: false })
  @JoinColumn({ name: 'locations_id' })
  location: Locations | null;

  @ManyToOne(type => Participants, participants => participants.deploymentsSeted, {})
  @JoinColumn({ name: 'participant_set_sensor_id' })
  participantSetSensor: Participants | null;

  @ManyToOne(type => Participants, participants => participants.deploymentsRemoved, {})
  @JoinColumn({ name: 'participant_remove_sensor_id' })
  participantRemoveSensor: Participants | null;

  @ManyToOne(type => Projects, projects => projects.deployments, { nullable: false,  onDelete: 'CASCADE' })
  @JoinColumn({ name: 'projects_id' })
  project: Projects | null;

  @OneToMany(type => DataFiles, dataFiles => dataFiles.deployment, { onDelete: 'CASCADE' })
  dataFiles: DataFiles[];

  @OneToMany(type => Sequences, sequence => sequence.deployment)
  sequences: Sequences[];

  @OneToMany(type => PlacementConfiguration, placementConfiguration => placementConfiguration.deployments)
  placementConfigurations: PlacementConfiguration[];

  @ManyToMany(type => Tags, tags => tags.deployments, { nullable: false })
  @JoinTable()
  tags: Tags[];

  @ManyToOne(type => Subprojects, subproject => subproject.deployments, { nullable: true })
  @JoinColumn({ name: 'subproject_id' })
  subproject: Subprojects | null;
}
