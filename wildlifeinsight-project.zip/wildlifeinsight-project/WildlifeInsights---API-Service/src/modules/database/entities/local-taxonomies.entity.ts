import { Entity, Column, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { Taxonomies } from './taxonomies.entity';
import { Projects } from './projects.entity';

@Entity('local_taxonomies')
export class LocalTaxonomies {

  @Column('varchar', {
    nullable: false,
    length: 255,
    name: 'local_common_name',
  })
  localCommonName: string;

  @OneToOne(() => Taxonomies, taxonomies => taxonomies.localTaxonomies, { primary: true, nullable: false })
  @JoinColumn({ name: 'taxonomies_uuid' })
  taxonomy: Taxonomies | null;

  @ManyToOne(() => Projects, projects => projects.localTaxonomies, { nullable: false })
  @JoinColumn({ name: 'projects_id' })
  projects: Projects | null;

}
