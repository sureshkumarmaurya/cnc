/* tslint:disable */

import { Entity, Column, OneToMany, PrimaryGeneratedColumn } from 'typeorm';
import { IdentificationOutputs } from './identification-outputs.entity';
import { IdentificationMethodTaxonomyPivot } from './identification-method-taxonomy-pivot.entity';

@Entity('identification_methods')
export class IdentificationMethods {

  @PrimaryGeneratedColumn()
  id: number;

  @Column('varchar', {
    nullable: false,
    unique: true,
    length: 255,
    name: 'type_name',
  })
  name: string;

  @Column('boolean', {
    nullable: true,
    unique: true,
    name: 'default_model',
  })
  default_model: string;

  @Column('varchar', {
    nullable: true,
    unique: false,
    name: 'endpoint',
  })
  endpoint: string;


  @Column('double precision', {
    nullable: true,
    unique: false,
    name: 'id_threshold',
  })
  id_threshold: number;

  @OneToMany(type => IdentificationOutputs, identificationOutputs => identificationOutputs.identificationMethod, { nullable: true, cascade: ['insert', 'remove', 'update'] })
  identificationOutputs: IdentificationOutputs[];

  @OneToMany(type => IdentificationMethodTaxonomyPivot, identificationMethodTaxonomyPivot => identificationMethodTaxonomyPivot.taxonomy, { cascade: ['remove'] })
  identificationMethodTaxonomyPivots: IdentificationMethodTaxonomyPivot[] | null;

}
