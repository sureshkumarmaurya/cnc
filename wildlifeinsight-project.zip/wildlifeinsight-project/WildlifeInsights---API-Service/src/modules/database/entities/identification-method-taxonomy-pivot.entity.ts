import { Entity, Column, ManyToOne, JoinColumn, Unique } from 'typeorm';
import { IdentificationMethods } from './identification-methods.entity';
import { Taxonomies } from './taxonomies.entity';

@Entity('identification_method_taxonomy_pivot')
@Unique(['identificationMethodId', 'taxonomyId', 'tag'])
export class IdentificationMethodTaxonomyPivot {

  @Column('integer', {
    nullable: false,
    name: 'identification_method_id',
    primary: true,
  })
  identificationMethodId: number;

  /**
   * Mismatch between column name and variable name is due to the fact that
   * `taxonomyId` was originally mapping to the `taxonomy_id` column (which was
   * a foreign key to `taxonomies.id` - a db sequence for in the `taxonomies`
   * table), but in August 2019 we added UUIDs to taxonomies, and it made sense
   * to use those as the FK from `identifiedObjects` to `taxonomies` (see
   * https://www.pivotaltracker.com/story/show/168356443 for context).
   *
   * However, in order to preserve the general pattern used throughout the
   * API (`<entitytype>Id`), the actual variable name is left unchanged.
   */
  @Column('varchar', {
    nullable: false,
    name: 'taxonomies_uuid',
    primary: true,
  })
  taxonomyId: string;

  @Column('varchar', {
    nullable: false,
    name: 'tag',
    primary: true,
  })
  tag: string;

  @ManyToOne(() => Taxonomies, taxonomy => taxonomy.identificationMethodTaxonomyPivots, { nullable: false })
  @JoinColumn({ name: 'taxonomies_uuid' })
  taxonomy: Taxonomies;

  @ManyToOne(() => IdentificationMethods, identificationMethod => identificationMethod.identificationMethodTaxonomyPivots, { primary: true, nullable: false })
  @JoinColumn({ name: 'identification_method_id' })
  identificationMethod: IdentificationMethods;
}
