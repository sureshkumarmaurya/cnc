import { Entity, Column, ManyToOne, JoinColumn, PrimaryGeneratedColumn } from 'typeorm';
import { DataFiles } from './data-files.entity';

@Entity('data_file_annotations')
export class DataFileAnnotations {

  @PrimaryGeneratedColumn()
  id: number;

  @Column('text', {
    nullable: false,
    name: 'description',
  })
  description: string;

  @Column('text', {
    nullable: false,
    name: 'remarks',
  })
  remarks: string;

  @Column('integer', {
    nullable: false,
    name: 'rating',
  })
  rating: number;

  @Column('boolean', {
    nullable: false,
    name: 'favorite_yn',
  })
  favoriteYn: boolean;

  @Column('varchar', {
    nullable: false,
    length: 255,
    name: 'identifications',
  })
  identifications: string;

  @Column('boolean', {
    nullable: false,
    name: 'flag_indentification',
  })
  flagIndentification: boolean;

  @ManyToOne(type => DataFiles, dataFile => dataFile.dataFileAnnotations, { nullable: false })
  @JoinColumn({ name: 'data_file_id' })
  dataFile: DataFiles | null;

}
