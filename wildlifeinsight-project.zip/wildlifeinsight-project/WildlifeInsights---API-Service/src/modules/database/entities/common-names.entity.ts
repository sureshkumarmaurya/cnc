import { Entity, Column, ManyToOne, JoinColumn, PrimaryGeneratedColumn } from 'typeorm';
import { Taxonomies } from './taxonomies.entity';

@Entity('common_names')
export class CommonNames {

  @PrimaryGeneratedColumn()
  id: number;

  @Column('varchar', {
    nullable: false,
    length: 255,
    name: 'common_name',
  })
  commonName: string;

  @Column('boolean', {
    nullable: false,
    name: 'primary_yn',
  })
  primaryYn: boolean;

  @Column('boolean', {
    nullable: false,
    name: 'alias_yn',
  })
  aliasYn: boolean;

  @Column('text', {
    nullable: true,
    name: 'remarks',
  })
  remarks: string;

  @Column('varchar', {
    nullable: false,
    name: 'language',
  })
  language: string;

  /**
   * Mismatch between column name and variable name is due to the fact that
   * `taxonomyId` was originally mapping to the `taxonomy_id` column (which was
   * a foreign key to `taxonomies.id` - a db sequence for in the `taxonomies`
   * table), but in August 2019 we added UUIDs to taxonomies, and it made sense
   * to use those as the FK from `identifiedObjects` to `taxonomies` (see
   * https://www.pivotaltracker.com/story/show/168356443 for context).
   *
   * However, in order to preserve the general pattern used throughout the
   * API (`<entitytype>Id`), the actual variable name is left unchanged.
   */
  @Column('varchar', {
    nullable: false,
    name: 'taxonomies_uuid',
  })
  taxonomyId: string;

  @ManyToOne(type => Taxonomies, taxonomies => taxonomies.commonNames, { nullable: false })
  @JoinColumn({ name: 'taxonomies_uuid' })
  taxonomy: Taxonomies;
}
