import { Entity, Column, OneToMany, ManyToOne, JoinColumn, PrimaryGeneratedColumn, AfterLoad } from 'typeorm';
import { Deployments } from './deployments.entity';
import { MediaTypes } from './media-types.entity';
import { DataFileAnnotations } from './data-file-annotations.entity';
import { DataFileMetavalues } from './data-file-metavalues.entity';
import { ExifDataFilePivot } from './exif-data-file-pivot.entity';
import { IdentificationOutputs } from './identification-outputs.entity';
import { DataFileSequencePivot } from './data-file-sequence-pivot.entity';
import { Participants } from './participants.entity';
import { Metadata } from './metadata.entity';
import { LatestIdentificationOutputs } from './latest-identification-outputs.entity';

@Entity('data_files')
export class DataFiles extends Metadata {

  @PrimaryGeneratedColumn({
    name: 'id',
  })
  id: number;

  @Column('text', {
    nullable: false,
    name: 'data_file_id',
  })
  dataFileId: string;

  @Column({
    type: 'boolean',
    nullable: false,
    default: false,
  })
  highlighted: boolean;

  @Column('varchar', {
    nullable: false,
    length: 255,
    name: 'filepath',
  })
  filepath: string;

  @Column('text', {
    nullable: true,
    name: 'original_location_url',
  })
  originalLocationUrl: string;

  @Column('varchar', {
    nullable: true,
    length: 255,
    name: 'thumbnail_url',
  })
  thumbnailUrl: string;

  @Column('varchar', {
    nullable: false,
    length: 255,
    name: 'filename',
  })
  filename: string;

  @Column('varchar', {
    nullable: true,
    length: 255,
    name: 'filesize',
  })
  filesize: string;

  @Column('timestamp without time zone', {
    nullable: true,
    name: 'timestamp',
  })
  timestamp: Date;

  @Column('timestamp without time zone', {
    nullable: false,
    name: 'createdAt',
    default: () => 'CURRENT_TIMESTAMP',
  })
  createdAt: Date;

  @Column('int', {
    nullable: false,
    name: 'deployment_id',
  })
  deploymentId: number;

  @Column('int', {
    nullable: false,
    name: 'media_types_id',
  })
  mediaTypeId: number;

  @Column('int', {
    nullable: true,
    name: 'participant_id',
  })
  participantId: number;

  @Column('varchar', {
    nullable: true,
    length: 255,
    name: 'status',
  })
  status: string;

  @Column('varchar', {
    nullable: true,
    length: 255,
    name: 'client_id',
  })
  clientId: string;

  @Column('boolean', {
    default: false,
    name: 'can_delete',
  })
  canDelete: boolean;

  @Column('boolean', {
    default: false,
    name: 'human_identified',
  })
  humanIdentified: boolean;

  @Column('boolean', {
    default: false,
    name: 'identified_by_expert',
  })
  identifiedByExpert: boolean;

  @AfterLoad()
  afterLoad(): void {
    const MAX_TIME_PASS_BEFORE_DELETE_END = 7200; // seconds

    const timeDiff = Math.floor(((new Date().getTime() - new Date(this.createdAt).getTime()) / 1000) / 60);

    if (timeDiff <= MAX_TIME_PASS_BEFORE_DELETE_END) {
      this.canDelete = true;
    }

  }

  @ManyToOne(type => Participants, participant => participant.dataFiles, { nullable: true })
  @JoinColumn({ name: 'participant_id' })
  participant: Participants;

  @ManyToOne(type => Deployments, deployments => deployments.dataFiles, { nullable: true, onDelete: 'CASCADE' })
  @JoinColumn({ name: 'deployment_id' })
  deployment: Deployments | null;

  @ManyToOne(type => MediaTypes, mediaTypes => mediaTypes.dataFiles, { nullable: false })
  @JoinColumn({ name: 'media_types_id' })
  mediaType: MediaTypes | null;

  @OneToMany(type => DataFileAnnotations, dataFileAnnotations => dataFileAnnotations.dataFile)
  dataFileAnnotations: DataFileAnnotations[];

  @OneToMany(type => DataFileMetavalues, dataFileMetavalues => dataFileMetavalues.dataFile, { onDelete: 'CASCADE' })
  dataFileMetavalues: DataFileMetavalues[];

  @OneToMany(type => ExifDataFilePivot, exifDataFilePivot => exifDataFilePivot.dataFile, { cascade: ['insert', 'update', 'remove'], onDelete: 'CASCADE' })
  exifDataFilePivots: ExifDataFilePivot[] | null;

  @OneToMany(type => DataFileSequencePivot, dataFileSequencePivot => dataFileSequencePivot.dataFile, { cascade: ['insert', 'update', 'remove'], onDelete: 'CASCADE' })
  dataFileSequencePivots: DataFileSequencePivot[] | null;

  @OneToMany(type => IdentificationOutputs, identificationOutputs => identificationOutputs.dataFile, { cascade: ['insert', 'update', 'remove'], nullable: true, onDelete: 'CASCADE' })
  identificationOutputs: IdentificationOutputs[];

  @OneToMany(type => LatestIdentificationOutputs, identificationOutputs => identificationOutputs.dataFile, { nullable: true })
  latestIdentificationOutputs: LatestIdentificationOutputs[];
}
