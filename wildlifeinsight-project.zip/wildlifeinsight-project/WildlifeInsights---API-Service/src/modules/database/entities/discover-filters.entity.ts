import { Entity, Column, PrimaryColumn } from 'typeorm';

@Entity('discover_filters_vw')
export class DiscoverFilters {

  @PrimaryColumn('varchar', {
    array: true,
    nullable: false,
    name: 'countries',
  })
  countries: string[];

  @Column('varchar', {
    array: true,
    nullable: true,
    name: 'geo_regions',
  })
  geoRegions: string[][];

  @Column('date', {
    array:true,
    nullable: true,
    name: 'timespan',
  })
  timespan: Date[];

  @Column('varchar', {
    array: true,
    nullable: true,
    name: 'initiatives',
  })
  initiatives: string[][];

  @Column('varchar', {
    array: true,
    nullable: true,
    name: 'projects',
  })
  projects: string[][];

  @Column('boolean', {
    array: true,
    nullable: true,
    name: 'endangered',
  })
  endangered: boolean[];
}
