import { Entity, Column, PrimaryGeneratedColumn } from 'typeorm';

@Entity('previous_identifiers')
export class PreviousIdentifiers {

  @PrimaryGeneratedColumn()
  id: number;

  @Column('varchar', {
    nullable: false,
    length: 255,
    name: 'prev_identifier_str',
  })
  prevIdentifierStr: string;

  @Column('integer', {
    nullable: false,
    name: 'prev_identifier_int',
  })
  prevIdentifierInt: number;

  @Column('text', {
    nullable: false,
    name: 'description',
  })
  description: string;

  @Column('text', {
    nullable: false,
    name: 'source',
  })
  source: string;

  @Column('varchar', {
    nullable: false,
    length: 255,
    name: 'associated_table',
  })
  associatedTable: string;

}
