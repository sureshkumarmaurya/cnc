import { Entity, Column, OneToOne, OneToMany, ManyToOne, ManyToMany, JoinColumn, PrimaryGeneratedColumn } from 'typeorm';
import { Organizations } from './organizations.entity';
import { Participants } from './participants.entity';

@Entity('batch_uploads')
export class BatchUploads {

  @PrimaryGeneratedColumn()
  id: number;

  @Column('varchar', {
    nullable: false,
    length: 255,
    unique: true,
    name: 'target',
  })
  target: string;

  @Column('varchar', {
    nullable: false,
    length: 255,
    name: 'status',
  })
  status: string;

  @Column('integer', {
    nullable: false,
    name: 'organizations_id',
  })
  organizationId: number;

  @ManyToOne(() => Organizations, organizations => organizations.batchUploads)
  @JoinColumn({ name: 'organizations_id' })
  organization: Organizations;

  @Column('integer', {
    nullable: false,
    name: 'participant_id',
  })
  participantId: number;

  @ManyToOne(() => Participants, participants => participants.batchUploads)
  @JoinColumn({ name: 'participant_id' })
  participant: Participants;
}
