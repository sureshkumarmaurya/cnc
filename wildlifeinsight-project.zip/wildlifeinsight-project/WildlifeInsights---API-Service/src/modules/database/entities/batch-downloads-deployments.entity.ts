import { Entity, Column, PrimaryColumn } from 'typeorm';

@Entity('deployments_batch_upload_vw')
export class BatchDownloadsDeployments {

  @PrimaryColumn('int', {
    nullable: false,
    name: 'deployment_internal_id',
  })
  deploymentInternalId: number;

  @Column('int', {
    nullable: false,
    name: 'project_internal_id',
  })
  projectInternalId: number;

  @Column('varchar', {
    nullable: false,
    name: 'project_id',
  })
  projectId: string;

  @Column('varchar', {
    nullable: false,
    name: 'deployment_id',
  })
  deploymentId: string;

  @Column('int', {
    nullable: false,
    name: 'camera_id',
  })
  cameraId: number;

  @Column('varchar', {
    name: 'placename',
  })
  placename: string | null;

  @Column({
    type: 'float',
    nullable: true,
    name: 'latitude',
  })
  latitude: number | null;

  @Column({
    type: 'float',
    nullable: true,
    name: 'longitude',
  })
  longitude: number | null;

  @Column({
    type: 'float',
    nullable: true,
    name: 'latitude_blurred',
  })
  latitudeBlurred: number | null;

  @Column({
    type: 'float',
    nullable: true,
    name: 'longitude_blurred',
  })
  longitudeBlurred: number | null;

  @Column('date', {
    nullable: true,
    name: 'start_date',
  })
  startDate: string | null;

  @Column('date', {
    nullable: true,
    name: 'end_date',
  })
  endDate: string | null;

  @Column('varchar', {
    nullable: true,
    name: 'array_name',
  })
  arrayName: string | null;

  @Column('varchar', {
    nullable: true,
    name: 'bait_type',
  })
  baitType: string | null;

  @Column('varchar', {
    nullable: true,
    name: 'bait_description',
  })
  baitDescription: string | null;

  @Column('varchar', {
    nullable: true,
    name: 'feature_type',
  })
  featureType: string | null;

  @Column('varchar', {
    nullable: true,
    name: 'feature_type_methodology',
  })
  featureTypeMethodology: string | null;

  @Column('int', {
    nullable: true,
    name: 'quiet_period',
  })
  quietPeriod: number | null;

  @Column('text', {
    nullable: true,
    name: 'camera_functioning',
  })
  cameraFunctioning: string | null;

  @Column('float', {
    nullable: true,
    name: 'sensor_height',
  })
  sensorHeight: string | null;

  @Column('float', {
    nullable: true,
    name: 'height_other',
  })
  heightOther: number | null;

  @Column('varchar', {
    nullable: true,
    length: 255,
    name: 'sensor_orientation',
  })
  sensorOrientation: string | null;

  @Column('varchar', {
    nullable: true,
    length: 255,
    name: 'orientation_other',
  })
  orientationOther: string | null;

  @Column('text', {
    nullable: true,
    name: 'recorded_by',
  })
  recordedBy: string | null;

  @Column('boolean', {
    nullable: true,
    name: 'embargo_free',
  })
  embargoFree: boolean | null;
}
