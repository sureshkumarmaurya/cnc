import { Entity, Column, OneToOne, OneToMany, ManyToOne, JoinColumn, PrimaryGeneratedColumn } from 'typeorm';
import { Providers } from './providers.entity';
import { Roles } from './roles.entity';
import { ParticipantTypeProjectPivot } from './participant-type-project-pivot.entity';
import { Deployments } from './deployments.entity';
import { Organizations } from './organizations.entity';
import { OrganizationParticipantPivot } from './organization-participant-pivot.entity';
import { InitiativeParticipantPivot } from './initiative-participant-pivot.entity';
import { IdentificationOutputs } from './identification-outputs.entity';
import { SequenceIdentificationOutputs } from './sequence-identification-outputs.entity';
import { DataFiles } from './data-files.entity';
import { BatchUploads } from './batch-uploads.entity';

export enum AgeVerification {
  NOT_VERIFIED = 'not_verified',
  SELF_CERTIFIED_13 = '13+_self_certified',
  VERIFIED_BY_ADMIN_13 = '13+_verified_by_admin',
}

@Entity('participants')
export class Participants {

  @PrimaryGeneratedColumn()
  id: number;

  @Column('varchar', {
    nullable: true,
    length: 255,
    name: 'first_name',
  })
  firstName: string | null;

  @Column('varchar', {
    nullable: true,
    length: 255,
    name: 'last_name',
  })
  lastName: string | null;

  @Column('varchar', {
    nullable: true,
    length: 255,
    name: 'phone',
  })
  phone: string | null;

  @Column('varchar', {
    nullable: true,
    length: 255,
    name: 'street_address',
  })
  streetAddress: string | null;

  @Column('varchar', {
    nullable: true,
    length: 255,
    name: 'city',
  })
  city: string | null;

  @Column('varchar', {
    nullable: true,
    length: 255,
    name: 'state',
  })
  state: string | null;

  @Column('varchar', {
    nullable: true,
    length: 255,
    name: 'country_code',
  })
  countryCode: string | null;

  @Column('varchar', {
    nullable: true,
    length: 255,
    name: 'postal_code',
  })
  postalCode: string | null;

  @Column('boolean', {
    nullable: true,
    name: 'use_common_names',
  })
  useCommonNames: boolean | null;

  @Column('text', {
    nullable: true,
    name: 'remarks',
  })
  remarks: string | null;

  @Column('varchar', {
    nullable: true,
    length: 255,
    name: 'email',
    unique: true,
  })
  email: string | null;

  @Column('varchar', {
    nullable: true,
    length: 64,
    name: 'password',
  })
  password: string | null;

  @Column({ type: 'boolean', nullable: false,  default: false })
  active: boolean;

  @Column({ type: 'boolean', nullable: false,  default: false })
  whitelisted: boolean;

  @Column('varchar', {
    nullable: true,
    length: 255,
    name: 'recover_token',
  })
  recoverToken: string | null;

  @Column('varchar', {
    nullable: true,
    length: 255,
    name: 'activate_token',
  })
  activateToken: string | null;

  @Column({
    type: 'enum',
    enum: AgeVerification,
    default: AgeVerification.NOT_VERIFIED,
    name: 'age_verification',
  })
  status: AgeVerification;

  @OneToMany(() => Providers, providers => providers.participant, { cascade: ['insert', 'update'] })
  providers: Providers[];

  @OneToMany(() => DataFiles, dataFiles => dataFiles.participant)
  dataFiles: DataFiles[];

  @ManyToOne(type => Roles, roles => roles.participants, { nullable: false })
  @JoinColumn({ name: 'role_id' })
  role: Roles | null;

  @OneToMany(() => OrganizationParticipantPivot, organizations => organizations.participant)
  organizationParticipantPivot: OrganizationParticipantPivot[] | null;

  @OneToMany(() => InitiativeParticipantPivot, initiative => initiative.participant, { nullable: true })
  initiativeParticipantPivot: InitiativeParticipantPivot[] | null;

  @OneToMany(() => ParticipantTypeProjectPivot, participantTypeProjectPivot => participantTypeProjectPivot.participant)
  participantTypeProjectPivot: ParticipantTypeProjectPivot[] | null;

  @OneToMany(() => Deployments, deployments => deployments.participantSetSensor)
  deploymentsSeted: Deployments[];

  @OneToMany(() => Deployments, deployments => deployments.participantRemoveSensor)
  deploymentsRemoved: Deployments[];

  @OneToMany(() => IdentificationOutputs, identificationOutputs => identificationOutputs.participant)
  identificationOutputs: IdentificationOutputs[];

  @OneToMany(() => SequenceIdentificationOutputs, sequenceIdentificationOutputs => sequenceIdentificationOutputs.participant)
  sequenceIdentificationOutputs: SequenceIdentificationOutputs[];

  @OneToMany(() => BatchUploads, batchUploads => batchUploads.participant, { nullable: false })
  batchUploads: BatchUploads[];
}
