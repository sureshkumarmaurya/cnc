import { Entity, Column, PrimaryColumn } from 'typeorm';

@Entity('discover_projects_vw')
export class DiscoverProjects {

  @PrimaryColumn('integer', {
    nullable: false,
    unique: true,
    name: 'project_id',
  })
  projectId: number;

  @Column('varchar', {
    nullable: false,
    length: 255,
    name: 'project_name',
  })
  projectName: string;

  @Column('varchar', {
    nullable: false,
    length: 255,
    name: 'slug',
  })
  slug: string;

  @Column('varchar', {
    nullable: true,
    name: 'thumbnail_url',
  })
  thumbnailUrl: string;

  @Column('integer', {
    nullable: true,
    name: 'initiative_id',
  })
  initiativeId: number;

  @Column('varchar', {
    nullable: true,
    name: 'initiative_name',
  })
  initiativeName: string;

  @Column('varchar', {
    nullable: false,
    name: 'organization_name',
  })
  organizationName: string;

  @Column('varchar', {
    nullable: true,
    name: 'country',
  })
  country: string;

  @Column('integer', {
    nullable: true,
    name: 'sampling_days',
  })
  samplingDays: number;

  @Column('varchar', {
    nullable: false,
    name: 'project_location',
  })
  projectLocation: string;

  @Column('float', {
    nullable: false,
    name: 'lat',
  })
  lat: number;

  @Column('float', {
    nullable: false,
    name: 'lng',
  })
  lng: number;
}
