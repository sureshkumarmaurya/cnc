import { Entity, Column, PrimaryGeneratedColumn, OneToMany } from 'typeorm';
import { ParticipantTypeProjectPivot } from './participant-type-project-pivot.entity';

@Entity('participant_types')
export class ParticipantTypes {

  @PrimaryGeneratedColumn()
  id: number;

  @Column('varchar', {
    nullable: true,
    length: 255,
    name: 'type_name',
    unique: true,
  })
  typeName: string | null;

  @Column('text', {
    nullable: true,
    name: 'remarks',
  })
  remarks: string | null;

  @Column('varchar', {
    nullable: true,
    length: 255,
    name: 'function',
  })
  function: string | null;

  @OneToMany(() => ParticipantTypeProjectPivot, participantTypeProjectPivot => participantTypeProjectPivot.participantType)
  participantTypeProjectPivot: ParticipantTypeProjectPivot[] | null;

}
