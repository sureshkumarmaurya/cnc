import { Entity, Column, OneToMany, PrimaryGeneratedColumn } from 'typeorm';
import { Deployments } from './deployments.entity';

@Entity('paired_deployments')
export class PairedDeployments {

  @PrimaryGeneratedColumn()
  id: number;

  @Column('varchar', {
    nullable: true,
    length: 255,
    name: 'name',
  })
  name: string | null;

  @Column('text', {
    nullable: true,
    name: 'description',
  })
  description: string | null;

  @Column('text', {
    nullable: true,
    name: 'remarks',
  })
  remarks: string | null;

  @Column('date', {
    nullable: false,
    name: 'start_date',
  })
  startDate: Date;

  @Column('date', {
    nullable: false,
    name: 'end_date',
  })
  endDate: Date;

  @OneToMany(() => Deployments, deployments => deployments.pairedDeployments)
  deployments: Deployments[];

}
