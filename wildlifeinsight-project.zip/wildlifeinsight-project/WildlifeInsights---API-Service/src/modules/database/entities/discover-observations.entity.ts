import { Entity, Column, PrimaryColumn } from 'typeorm';
import { DiscoverProjects } from './discover-projects.entity';

@Entity('discover_observations_meta_vw')
export class DiscoverObservations extends DiscoverProjects {

  @PrimaryColumn('integer', {
    select: false,
    nullable: false,
    unique: true,
    name: 'id',
  })
  id: number;

  @Column('integer', {
    nullable: false,
    unique: false,
    name: 'project_id',
  })
  projectId: number;

  @Column('boolean', {
    nullable: true,
    name: 'endangered',
  })
  endangeredSpecies: boolean;

  @Column('uuid', {
    nullable: false,
    name: 'taxonomy_uuid',
  })
  taxonomyId: string;

  @Column('double precision', {
    nullable: false,
    name: 'lng',
  })
  lng: number;

  @Column('double precision', {
    nullable: false,
    name: 'lat',
  })
  lat: number;

  @Column('integer', {
    nullable: false,
    unique: false,
    name: 'deployment_id',
  })
  deploymentId: number;

  @Column('boolean', {
    nullable: true,
    name: 'verified',
  })
  verified: boolean;

  @Column('boolean', {
    nullable: true,
    unique: false,
    name: 'is_wildlife',
  })
  isWildlife: boolean;

  @Column('boolean', {
    nullable: true,
    unique: false,
    name: 'is_human',
  })
  isHuman: boolean;
}
