import { Point } from 'geojson';
import { Index, Entity, PrimaryColumn, Column, OneToOne, OneToMany, ManyToOne, ManyToMany, JoinColumn, JoinTable, RelationId, PrimaryGeneratedColumn } from 'typeorm';
import { Deployments } from './deployments.entity';
import { Features } from './features.entity';
import { PlacementConfiguration } from './placement-configuration.entity';
import { Organizations } from './organizations.entity';
import { Projects } from 'modules/database/entities/projects.entity';

const logger = require('logger');

@Entity('locations')
export class Locations {

  @PrimaryGeneratedColumn()
  id: number;

  @Column('double precision', {
    nullable: true,
    name: 'latitude',
  })
  latitude: number | null;

  @Column('double precision', {
    nullable: true,
    name: 'longitude',
  })
  longitude: number | null;

  @Column('varchar', {
    nullable: true,
    length: 255,
    name: 'placename',
  })
  placename: string;

  @Column('varchar', {
    nullable: true,
    length: 255,
    name: 'property_type',
  })
  propertyType: string | null;

  @Column('varchar', {
    nullable: true,
    length: 255,
    name: 'habitat',
  })
  habitat: string | null;

  @Column('text', {
    nullable: true,
    name: 'remarks',
  })
  remarks: string | null;

  @Column('varchar', {
    nullable: true,
    length: 255,
    name: 'plot_treatment',
  })
  plotTreatment: string | null;

  @Column('text', {
    nullable: true,
    name: 'plot_treatment_description',
  })
  plotTreatmentDescription: string | null;

  @Column('varchar', {
    nullable: false,
    length: 255,
    name: 'geodetic_datum',
  })
  geodeticDatum: string;

  @Column('varchar', {
    nullable: true,
    length: 255,
    name: 'field_number',
  })
  fieldNumber: string;

  @Column('varchar', {
    nullable: true,
    length: 255,
    name: 'country',
  })
  country: string;

  @Column('varchar', {
    nullable: true,
    length: 255,
    name: 'first_order_division',
  })
  firstOrderDivision: string;

  @Column('varchar', {
    nullable: true,
    length: 255,
    name: 'second_order_division',
  })
  secondOrderDivision: string;

  @Column('varchar', {
    nullable: true,
    length: 255,
    name: 'landcover_type',
  })
  landcoverType: string;

  @Column('varchar', {
    nullable: true,
    length: 255,
    name: 'igbp_climate_classification',
  })
  igbpClimateClassification: string;

  @Column('integer', {
    nullable: true,
    name: 'elevation_gtopo30',
  })
  elevationGtopo30: number;

  @Column('integer', {
    nullable: false,
    name: 'projects_id',
  })
  projectId: number;

  @OneToMany(type => Deployments, deployments => deployments.location)
  deployments: Deployments[];

  @OneToMany(type => Features, features => features.locations,  { eager: true })
  features: Features[];

  @OneToMany(type => PlacementConfiguration, placementConfiguration => placementConfiguration.locations)
  placementConfigurations: PlacementConfiguration[];

  @ManyToOne(() => Projects, projects => projects.locations, { onDelete: 'CASCADE' })
  @JoinColumn({ name: 'projects_id' })
  project: Projects;

}
