import { Entity, Column, OneToOne, OneToMany, ManyToOne, JoinColumn, PrimaryColumn, PrimaryGeneratedColumn } from 'typeorm';
import { IucnRedListCategories } from './iucn-red-list-categories.entity';
import { CommonNames } from './common-names.entity';
import { IdentifiedObjects } from './identified-objects.entity';
import { SequenceIdentifiedObjects } from './sequence-identified-objects.entity';
import { LocalTaxonomies } from './local-taxonomies.entity';
import { IdentificationMethodTaxonomyPivot } from './identification-method-taxonomy-pivot.entity';

@Entity('taxonomies')
export class Taxonomies {

  @Column()
  id: number;

  @Column('varchar', {
    nullable: true,
    length: 255,
    name: 'class',
  })
  class: string;

  @Column('varchar', {
    nullable: true,
    length: 255,
    name: 'order',
  })
  order: string;

  @Column('varchar', {
    nullable: true,
    length: 255,
    name: 'suborder',
  })
  suborder: string;

  @Column('varchar', {
    nullable: true,
    length: 255,
    name: 'superfamily',
  })
  superfamily: string;

  @Column('varchar', {
    nullable: true,
    length: 255,
    name: 'family',
  })
  family: string;

  @Column('varchar', {
    nullable: true,
    length: 255,
    name: 'subfamily',
  })
  subfamily: string;

  @Column('varchar', {
    nullable: true,
    length: 255,
    name: 'genus',
  })
  genus: string;

  @Column('varchar', {
    nullable: true,
    length: 255,
    name: 'species',
  })
  species: string;

  @Column('varchar', {
    nullable: true,
    length: 255,
    name: 'subspecies',
  })
  subspecies: string;

  @Column('varchar', {
    nullable: false,
    length: 255,
    name: 'taxon_level',
  })
  taxonLevel: string;

  @Column('varchar', {
    nullable: true,
    length: 255,
    name: 'authority',
  })
  authority: string;

  @Column('varchar', {
    nullable: true,
    length: 255,
    name: 'common_name_english',
  })
  commonNameEnglish: string;

  @Column('varchar', {
    nullable: false,
    length: 255,
    name: 'taxonomy_type',
  })
  taxonomyType: string;

  @Column('integer', {
    nullable: true,
    name: 'iucn_category_id',
  })
  iucnCategoryId: number;

  @Column('varchar', {
    nullable: true,
    length: 255,
    name: 'scientific_name',
  })
  scientificName: string;

  @PrimaryColumn('uuid', {
    nullable: false,
    name: 'unique_identifier',
  })
  uniqueIdentifier: string;

  @Column('text', {
    nullable: true,
    name: 'reference_url',
  })
  referenceUrl: string | null;

  @ManyToOne(() => IucnRedListCategories, iucnRedListCategories => iucnRedListCategories.taxonomies, { nullable: true })
  @JoinColumn({ name: 'iucn_category_id' })
  iucnCategory: IucnRedListCategories | null;

  @OneToMany(() => CommonNames, commonNames => commonNames.taxonomyId)
  commonNames: CommonNames[];

  @OneToMany(() => IdentifiedObjects, identifiedObjects => identifiedObjects.taxonomyId)
  identifiedObjects: IdentifiedObjects[];

  @OneToMany(() => SequenceIdentifiedObjects, sequenceIdentifiedObjects => sequenceIdentifiedObjects.taxonomyId)
  sequenceIdentifiedObjects: SequenceIdentifiedObjects[];

  @OneToOne(() => LocalTaxonomies, localTaxonomies => localTaxonomies.taxonomy)
  localTaxonomies: LocalTaxonomies | null;

  @OneToMany(type => IdentificationMethodTaxonomyPivot, identificationMethodTaxonomyPivot => identificationMethodTaxonomyPivot.taxonomyId, { cascade: ['remove'] })
  identificationMethodTaxonomyPivots: IdentificationMethodTaxonomyPivot[] | null;
}
