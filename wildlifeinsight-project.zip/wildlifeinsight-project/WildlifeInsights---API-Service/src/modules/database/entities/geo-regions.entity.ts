import { Entity, Column, PrimaryGeneratedColumn } from 'typeorm';

@Entity('geo_regions')
export class GeoRegions {

  @PrimaryGeneratedColumn()
  id: number;

  @Column('varchar', {
    nullable: false,
    length: 255,
    name: 'name',
  })
  name: string;

  @Column('varchar', {
    nullable: true,
    length: 255,
    name: 'slug',
  })
  slug: string | null;

  @Column('geography', {
    nullable: false,
    name: 'region',
  })
  region: string;
}
