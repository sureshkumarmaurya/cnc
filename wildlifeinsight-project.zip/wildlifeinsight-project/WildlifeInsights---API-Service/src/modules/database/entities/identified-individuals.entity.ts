import { Entity, Column, ManyToOne, JoinColumn, PrimaryGeneratedColumn } from 'typeorm';
import { IdentifiedObjects } from './identified-objects.entity';

@Entity('identified_individuals')
export class IdentifiedIndividuals {

  @PrimaryGeneratedColumn()
  id: number;

  @Column('integer', {
    nullable: false,
    name: 'name',
  })
  name: number;

  @ManyToOne(() => IdentifiedObjects, indentifiedObjects => indentifiedObjects.identifiedIndividuals, { nullable: false })
  @JoinColumn({ name: 'identified_animals_id' })
  identifiedAnimals: IdentifiedObjects | null;

}
