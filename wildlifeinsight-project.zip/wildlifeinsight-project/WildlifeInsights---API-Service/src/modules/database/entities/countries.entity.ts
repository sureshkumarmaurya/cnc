import { Entity, Column, OneToMany, PrimaryGeneratedColumn, OneToOne, JoinColumn } from 'typeorm';
import { FirstOrderDivisions } from './first-order-divisions.entity';
import { GeoRegions } from './geo-regions.entity';

@Entity('countries')
export class Countries {

  @PrimaryGeneratedColumn()
  id: number;

  @Column('character', {
    nullable: false,
    name: 'name',
  })
  name: string;

  @Column('character', {
    nullable: true,
    name: 'official_name',
  })
  officialName: string | null;

  @Column('integer', {
    nullable: true,
    name: 'bgn_name',
  })
  bgnName: number | null;

  @Column('integer', {
    nullable: true,
    name: 'bgn_longname',
  })
  bgnLongname: number | null;

  @Column('character', {
    nullable: false,
    length: 10,
    name: 'iso3166_a2',
  })
  iso3166A2: string;

  @Column('character', {
    nullable: false,
    length: 10,
    name: 'iso3166_a3',
  })
  iso3166A3: string;

  @Column('float', {
    nullable: true,
    name: 'max_latitude',
  })
  maxLatitude: number | null;

  @Column('float', {
    nullable: true,
    name: 'min_latitude',
  })
  minLatitude: number | null;

  @Column('float', {
    nullable: true,
    name: 'max_longitude',
  })
  maxLongitude: number | null;

  @Column('float', {
    nullable: true,
    name: 'min_longitude',
  })
  minLongitude: number | null;

  @Column('integer', {
    nullable: true,
    name: 'first_order_divisions_id',
  })
  firstOrderDivisionsId: number | null;

  @OneToMany(type => FirstOrderDivisions, firstOrderDivisions => firstOrderDivisions.country)
  firstOrderDivisions: FirstOrderDivisions[];

  @OneToOne(type => GeoRegions)
  @JoinColumn({
    name: 'geo_region_id',
  })
  geoRegion: GeoRegions | null;
}
