import { Index, Entity, PrimaryColumn, Column, OneToOne, OneToMany, ManyToOne, ManyToMany, JoinColumn, JoinTable, RelationId, PrimaryGeneratedColumn } from 'typeorm';
import { Sensors } from './sensors.entity';
import { Organizations } from './organizations.entity';
import { Deployments } from './deployments.entity';

@Entity('devices')
export class Devices {

  @PrimaryGeneratedColumn()
  id: number;

  @Column('varchar', {
    nullable: false,
    length: 255,
    name: 'name',
  })
  name: string;

  @Column('date', {
    nullable: true,
    name: 'purchase_date',
  })
  purchaseDate: Date;

  @Column('varchar', {
    nullable: true,
    length: 255,
    name: 'make',
  })
  make: string | null;

  @Column('varchar', {
    nullable: true,
    length: 255,
    name: 'model',
  })
  model: string | null;

  @Column('varchar', {
    nullable: true,
    length: 255,
    name: 'model_number',
  })
  modelNumber: string | null;

  @Column('varchar', {
    nullable: true,
    length: 255,
    name: 'serial_number',
  })
  serialNumber: string | null;

  @Column('integer', {
    nullable: true,
    name: 'purchase_year',
  })
  purchaseYear: number | null;

  @Column('float', {
    nullable: true,
    name: 'purchase_price',
  })
  purchasePrice: number | null;

  @Column('varchar', {
    nullable: true,
    length: 255,
    name: 'product_url',
  })
  productUrl: string | null;

  @Column('text', {
    nullable: true,
    name: 'remarks',
  })
  remarks: string | null;

  @Column('integer', {
    nullable: false,
    name: 'organizations_id',
  })
  organizationId: number;

  @OneToMany(type => Sensors, sensors => sensors.device, { cascade: ['insert', 'update'] })
  sensors: Sensors[];

  @OneToMany(() => Deployments, deployments => deployments.device)
  deployments: Deployments[];

  @ManyToOne(() => Organizations, organizations => organizations.devices, { nullable: false })
  @JoinColumn({ name: 'organizations_id' })
  organization: Organizations;

}
