import { Entity, Column, OneToMany, PrimaryGeneratedColumn } from 'typeorm';
import { Taxonomies } from './taxonomies.entity';

@Entity('iucn_red_list_categories')
export class IucnRedListCategories {

  @PrimaryGeneratedColumn()
  id: number;

  @Column('varchar', {
    nullable: false,
    length: 255,
    name: 'category_name',
  })
  categoryName: string;

  @Column('varchar', {
    nullable: false,
    length: 2,
    name: 'abbreviation',
  })
  abbreviation: string;

  @Column('text', {
    nullable: true,
    name: 'remarks',
  })
  remarks: string;

  @OneToMany(() => Taxonomies, taxonomies => taxonomies.iucnCategory)
  taxonomies: Taxonomies[];

}
