import { Entity, Column, PrimaryGeneratedColumn, ManyToOne, JoinColumn, OneToMany } from 'typeorm';
import { BatchDownloads } from './batch-downloads.entity';

@Entity('public_download_requests')
export class PublicDownloadRequest {
  @PrimaryGeneratedColumn()
  id: number;

  @Column('varchar', {
    nullable: false,
    name: 'name',
  })
  name: string;

  @Column('varchar', {
    nullable: false,
    name: 'organization',
  })
  organization: string;

  @Column('varchar', {
    nullable: false,
    name: 'email',
  })
  email: string;

  @Column('timestamp without time zone', {
    nullable: false,
    name: 'downloaded_timestamp',
  })
  downloadedTimestamp: Date;

  @Column('int', {
    nullable: false,
    name: 'batch_download_job_id',
  })
  batchDownloadJobId: number;

  @ManyToOne(() => BatchDownloads, batchDownloads => batchDownloads.publicDownloadRequests)
  @JoinColumn({ name: 'batch_download_job_id' })
  batchDownloadBundle: BatchDownloads;
}
