import { Entity, Column, PrimaryColumn, UpdateDateColumn } from 'typeorm';

@Entity('users_acl_cache')
export class UsersACLCache {
  @PrimaryColumn('integer', {
    name: 'user_id',
  })
  userId: number;

  @Column('json', {
    name: 'acl',
  })
  acl: string;

  @UpdateDateColumn({
    type: 'timestamp',
    name: 'last_changed',
  })
  lastChanged: Date;
}
