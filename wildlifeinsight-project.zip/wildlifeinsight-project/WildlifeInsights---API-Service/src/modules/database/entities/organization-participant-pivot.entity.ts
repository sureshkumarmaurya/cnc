import { Entity, Column, ManyToOne, JoinColumn } from 'typeorm';
import { Participants } from './participants.entity';
import { Roles } from './roles.entity';
import { Organizations } from './organizations.entity';
import { EntityParticipantPivot } from 'utils/entities.utils';

@Entity('organization_participant_pivot')
export class OrganizationParticipantPivot extends EntityParticipantPivot {
  constructor() {
    super('organization');
  }

  @Column('integer', {
    nullable: false,
    name: 'participant_id',
    primary: true,
  })
  participantId: number;

  @Column('integer', {
    nullable: false,
    name: 'role_id',
    primary: true,
  })
  roleId: number;

  @Column('integer', {
    nullable: false,
    name: 'organization_id',
    primary: true,
  })
  organizationId: number;

  @ManyToOne(() => Participants, participants => participants.organizationParticipantPivot, { primary: true, nullable: false })
  @JoinColumn({ name: 'participant_id' })
  participant: Participants | null;

  @ManyToOne(() => Organizations, organization => organization.organizationParticipantPivot, { primary: true, nullable: false })
  @JoinColumn({ name: 'organization_id' })
  organization: Organizations | null;

  @ManyToOne(() => Roles, roles => roles.organizationParticipantPivot, { primary: true, nullable: false })
  @JoinColumn({ name: 'role_id' })
  role: Roles ;

}
