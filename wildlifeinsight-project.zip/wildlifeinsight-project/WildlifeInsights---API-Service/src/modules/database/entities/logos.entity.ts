import { Entity, Column, PrimaryGeneratedColumn, ManyToOne, JoinColumn } from 'typeorm';
import { Initiatives } from './initiatives.entity';

@Entity('logos')
export class Logos {

  @PrimaryGeneratedColumn()
  id: number;

  @Column('int', {
    nullable: false,
    name: 'initiative_id',
  })
  initiativeId: number;

  @Column('varchar', {
    nullable: false,
    length: 255,
    name: 'name',
  })
  name: string;

  @Column('varchar', {
    nullable: false,
    length: 255,
    name: 'linkPublic',
  })
  linkPublic: string;

  @Column('varchar', {
    nullable: true,
    length: 255,
    name: 'text',
  })
  text: string;

  @ManyToOne(type => Initiatives, initiatives => initiatives.partnerLogos, { nullable: false, onDelete: 'CASCADE' })
  @JoinColumn({ name: 'initiative_id' })
  initiative: Initiatives | null;
}
