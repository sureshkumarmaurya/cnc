import { Entity, Column, ManyToOne, JoinColumn, PrimaryGeneratedColumn } from 'typeorm';
import { Countries } from './countries.entity';

@Entity('first_order_divisions')
export class FirstOrderDivisions {

  @PrimaryGeneratedColumn()
  id: number;

  @ManyToOne(() => Countries, countries => countries.firstOrderDivisions, { nullable: false })
  @JoinColumn({ name: 'country_id' })
  country: Countries | null;

  @Column('varchar', {
    nullable: false,
    length: 255,
    name: 'name',
  })
  name: string;

  @Column('varchar', {
    nullable: false,
    length: 255,
    name: 'type',
  })
  type: string;

}
