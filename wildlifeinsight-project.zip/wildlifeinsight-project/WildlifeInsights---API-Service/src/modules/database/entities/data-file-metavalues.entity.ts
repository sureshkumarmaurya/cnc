import { Entity, Column, ManyToOne, JoinColumn, PrimaryGeneratedColumn, Index } from 'typeorm';
import { DataFileMetakeys } from './data-file-metakeys.entity';
import { DataFiles } from './data-files.entity';

@Entity('data_file_metavalues')
@Index('index_keyid_datafileid', ['keyId', 'dataFileId'], { unique: true })
export class DataFileMetavalues {

  @PrimaryGeneratedColumn()
  id: number;

  @Column('text', {
    nullable: false,
    name: 'value',
  })
  value: string;

  @Column('int', {
    nullable: false,
    name: 'data_file_id',
  })
  dataFileId: number;

  @Column('int', {
    nullable: false,
    name: 'key_id',
  })
  keyId: number;

  @Column('text', {
    nullable: true,
    name: 'remarks',
  })
  remarks: string;

  @ManyToOne(type => DataFileMetakeys, dataFileMetakeys => dataFileMetakeys.dataFileMetavalues, { nullable: false })
  @JoinColumn({ name: 'key_id' })
  key: DataFileMetakeys | null;

  @ManyToOne(type => DataFiles, dataFile => dataFile.dataFileMetavalues, { nullable: false, onDelete: 'CASCADE' })
  @JoinColumn({ name: 'data_file_id' })
  dataFile: DataFiles| null;

}
