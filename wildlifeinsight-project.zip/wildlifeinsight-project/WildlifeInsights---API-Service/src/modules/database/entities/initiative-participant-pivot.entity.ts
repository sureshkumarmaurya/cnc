import { Entity, Column, ManyToOne, JoinColumn } from 'typeorm';
import { Participants } from './participants.entity';
import { Roles } from './roles.entity';
import { Initiatives } from './initiatives.entity';
import { EntityParticipantPivot } from 'utils/entities.utils';

@Entity('initiative_participant_pivot')
export class InitiativeParticipantPivot extends EntityParticipantPivot {
  constructor() {
    super('initiative');
  }

  @Column('integer', {
    nullable: false,
    name: 'participant_id',
    primary: true,
  })
  participantId: number;

  @Column('integer', {
    nullable: false,
    name: 'role_id',
    primary: true,
  })
  roleId: number;

  @Column('integer', {
    nullable: false,
    name: 'initiative_id',
    primary: true,
  })
  initiativeId: number;

  @Column('boolean', {
    nullable: false,
    name: 'is_implicit',
    default: false,
  })
  isImplicit: boolean;

  @ManyToOne(() => Participants, participants => participants.initiativeParticipantPivot, { primary: true, nullable: false })
  @JoinColumn({ name: 'participant_id' })
  participant: Participants | null;

  @ManyToOne(() => Initiatives, initiative => initiative.initiativeParticipantPivot, { primary: true, nullable: false })
  @JoinColumn({ name: 'initiative_id' })
  initiative: Initiatives | null;

  @ManyToOne(() => Roles, roles => roles.initiativeParticipantPivot, { primary: true, nullable: false })
  @JoinColumn({ name: 'role_id' })
  role: Roles;

}
