import { Entity, Column, OneToMany, ManyToOne, JoinColumn, PrimaryGeneratedColumn, ManyToMany } from 'typeorm';
import { Organizations } from './organizations.entity';
import { Projects } from './projects.entity';
import { InitiativeParticipantPivot } from './initiative-participant-pivot.entity';
import { Photos } from './photos.entity';
import { Logos } from './logos.entity';
import { IFileUploadObject } from '../../../interfaces/fileUpload.interface';

@Entity('initiatives')
export class Initiatives {

  @PrimaryGeneratedColumn()
  id: number;

  @Column('varchar', {
    nullable: false,
    length: 255,
    name: 'name',
    unique: true,
  })
  name: string;

  @Column('text', {
    nullable: true,
    name: 'purpose',
  })
  purpose: string;

  @Column('text', {
    nullable: true,
    name: 'remarks',
  })
  remarks: string;

  @Column('boolean', {
    nullable: false,
    default: false,
    name: 'is_location_public',
  })
  isLocationPublic: boolean;

  @Column('int', {
    nullable: false,
    name: 'owner_organizations_id',
  })
  ownerOrganizationId: number;

  @Column('varchar', {
    nullable: true,
    name: 'contact_email',
    length: 255,
  })
  contactEmail: string;

  @Column('varchar', {
    nullable: true,
    name: 'contact_content',
    length: 255,
  })
  contactContent: string;

  @Column({
    nullable: true,
    name: 'logo',
    type: 'json',
  })
  logo: IFileUploadObject;

  @Column({
    nullable: true,
    name: 'coverImage',
    type: 'json',
  })
  coverImage: IFileUploadObject;

  @Column('varchar', {
    nullable: true,
    length: 255,
    name: 'video_url',
  })
  videoUrl: string;

  @Column('varchar', {
    nullable: true,
    length: 511,
    name: 'introduction',
  })
  introduction: string;

  @Column('varchar', {
    nullable: true,
    length: 1024,
    name: 'content',
  })
  content: string;

  @Column('varchar', {
    nullable: true,
    length: 255,
    name: 'description',
  })
  description: string;

  @ManyToOne(() => Organizations, organizations => organizations.initiativesOwner, { nullable: false })
  @JoinColumn({ name: 'owner_organizations_id' })
  ownerOrganization: Organizations | null;

  @ManyToMany(() => Organizations, organizations => organizations.initiativesMember, { nullable: false })
  members: Organizations | null;

  @OneToMany(() => Projects, projects => projects.initiative)
  projects: Projects[];

  @OneToMany(() => InitiativeParticipantPivot, initiativeParticipantPivot => initiativeParticipantPivot.initiative, { cascade: ['update', 'insert', 'remove'] })
  initiativeParticipantPivot: InitiativeParticipantPivot[] | null;

  @OneToMany(type => Photos, photos => photos.initiative, { onDelete: 'CASCADE' })
  photos: Photos[];

  @OneToMany(type => Logos, logos => logos.initiative, { onDelete: 'CASCADE' })
  partnerLogos: Logos[];
}
