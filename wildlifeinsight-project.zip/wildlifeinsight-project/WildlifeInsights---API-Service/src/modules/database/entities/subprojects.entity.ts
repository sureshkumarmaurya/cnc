import { Entity, Column, OneToOne, OneToMany, ManyToOne, ManyToMany, JoinColumn, PrimaryGeneratedColumn } from 'typeorm';
import { Deployments } from './deployments.entity';
import { Projects } from './projects.entity';
import { Metadata } from './metadata.entity';

@Entity('subprojects')
export class Subprojects extends Metadata {

  @Column('varchar', {
    nullable: false,
    length: 255,
    name: 'name',
  })
  name: string;

  @Column('text', {
    nullable: true,
    name: 'design',
  })
  design: string;

  @Column('int', {
    nullable: false,
    name: 'project_id',
  })
  projectId: number;

  @ManyToOne(type => Projects, projects => projects.subprojects, { nullable: true })
  @JoinColumn({ name: 'project_id' })
  project: Projects | null;

  @OneToMany(() => Deployments, deployment => deployment.subproject, { nullable: true })
  deployments: Deployments[];
}
