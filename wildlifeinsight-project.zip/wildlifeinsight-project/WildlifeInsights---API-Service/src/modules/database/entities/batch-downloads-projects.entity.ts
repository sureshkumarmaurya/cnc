import { Entity, Column, PrimaryColumn } from 'typeorm';

@Entity('projects_batch_upload_vw')
export class BatchDownloadsProjects {

  @PrimaryColumn('int', {
    name: 'project_internal_id',
  })
  projectInternalId: number;

  @Column('varchar', {
    name: 'project_id',
  })
  projectId: number;

  @Column('varchar', {
    nullable: true,
    name: 'project_name',
  })
  projectName: string | null;

  @Column('varchar', {
    nullable: true,
    name: 'slug',
  })
  slug: string | null;

  @Column('text', {
    nullable: true,
    name: 'project_objectives',
  })
  projectObjectives: string | null;

  @Column('text', {
    nullable: true,
    name: 'project_species',
  })
  projectSpecies: string | null;

  @Column('text', {
    nullable: true,
    name: 'project_species_individual',
  })
  projectSpeciesIndividual: string | null;

  @Column('text', {
    nullable: true,
    name: 'project_sensor_layout',
  })
  projectSensorLayout: string | null;

  @Column('text', {
    nullable: true,
    name: 'project_sensor_layout_targeted_type',
  })
  projectSensorLayoutTargetedType: string | null;

  @Column('text', {
    nullable: true,
    name: 'project_bait_use',
  })
  projectBaitUse: string | null;

  @Column('text', {
    nullable: true,
    name: 'project_bait_type',
  })
  projectBaitType: string | null;

  @Column('text', {
    nullable: true,
    name: 'project_stratification',
  })
  projectStratification: string | null;

  @Column('text', {
    nullable: true,
    name: 'project_stratification_type',
  })
  projectStratificationType: string | null;

  @Column('text', {
    nullable: true,
    name: 'project_sensor_method',
  })
  projectSensorMethod: string | null;

  @Column('text', {
    nullable: true,
    name: 'project_individual_animals',
  })
  projectIndividualAnimals: string | null;

  @Column('text', {
    nullable: true,
    name: 'project_blank_images',
  })
  projectBlankImages: string | null;

  @Column('text', {
    nullable: true,
    name: 'project_sensor_cluster',
  })
  projectSensorCluster: string | null;

  @Column('text', {
    nullable: true,
    name: 'project_admin',
  })
  projectAdmin: string | null;

  @Column('text', {
    nullable: true,
    name: 'project_admin_email',
  })
  projectAdminEmail: string | null;

  @Column('varchar', {
    nullable: true,
    name: 'project_admin_organization',
  })
  projectAdminOrganization : string | null;

  @Column('varchar', {
    nullable: true,
    name: 'country_code',
  })
  countryCode: string | null;

  @Column('integer', {
    nullable: true,
    name: 'embargo',
  })
  embargo: number | null;

  @Column('integer', {
    nullable: true,
    name: 'initiative_id',
  })
  initiativeId: number | null;

  @Column('varchar', {
    nullable: true,
    name: 'metadata_license',
  })
  metadataLicense: string | null;

  @Column('varchar', {
    nullable: true,
    name: 'image_license',
  })
  imageLicense: string | null;

  @Column('varchar', {
    nullable: true,
    length: 255,
    name: 'project_url',
  })
  projectUrl: string | null;

  @Column('varchar', {
    nullable: true,
    name: 'data_citation',
  })
  dataCitation: string | null;
}
