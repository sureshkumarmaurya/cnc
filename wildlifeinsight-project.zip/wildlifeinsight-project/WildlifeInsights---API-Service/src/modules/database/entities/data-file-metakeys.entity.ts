import { Entity, Column, OneToMany, ManyToOne, JoinColumn, PrimaryGeneratedColumn } from 'typeorm';
import { MediaTypes } from './media-types.entity';
import { DataFileMetavalues } from './data-file-metavalues.entity';

@Entity('data_file_metakeys')
export class DataFileMetakeys {

  @PrimaryGeneratedColumn()
  id: number;

  @Column('varchar', {
    nullable: true,
    length: 255,
    name: 'key_variable',
  })
  keyVariable: string;

  @Column('varchar', {
    nullable: false,
    length: 255,
    name: 'key_name',
  })
  keyName: string;

  @Column('text', {
    nullable: true,
    name: 'remarks',
  })
  remarks: string;

  @ManyToOne(type => MediaTypes, mediaTypes => mediaTypes.dataFileMetakeys, { nullable: false })
  @JoinColumn({ name: 'media_types_id' })
  mediaTypes: MediaTypes | null;

  @OneToMany(type => DataFileMetavalues, dataFileMetavalues => dataFileMetavalues.key)
  dataFileMetavalues: DataFileMetavalues[];

}
