import { Entity, Column, PrimaryColumn, UpdateDateColumn } from 'typeorm';

@Entity('data_cache')
export class DataCache {
  @PrimaryColumn('varchar', {
    name: 'key',
    length: 32,
  })
  key: string;

  @Column('jsonb', {
    name: 'data',
  })
  data: object;

  @UpdateDateColumn({
    type: 'timestamp',
    name: 'last_changed',
  })
  lastChanged: Date;
}
