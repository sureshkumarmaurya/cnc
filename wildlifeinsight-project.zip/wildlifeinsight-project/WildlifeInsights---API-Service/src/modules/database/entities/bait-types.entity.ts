import { Entity, Column, OneToMany, PrimaryGeneratedColumn } from 'typeorm';
import { Deployments } from './deployments.entity';

@Entity('bait_types')
export class BaitTypes {

  @PrimaryGeneratedColumn()
  id: number;

  @Column('varchar', {
    nullable: false,
    unique: true,
    length: 255,
    name: 'type_name',
  })
  typeName: string;

  @Column('text', {
    nullable: true,
    name: 'description',
  })
  description: string | null;

  @Column('varchar', {
    nullable: true,
    length: 255,
    name: 'schedule',
  })
  schedule: string;

  @Column('varchar', {
    nullable: true,
    length: 255,
    name: 'scheme',
  })
  scheme: string;

  @OneToMany(type => Deployments, deployments => deployments.baitType)
  deployments: Deployments[];

}
