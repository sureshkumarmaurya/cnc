import { Entity, Column, ManyToOne, JoinColumn, PrimaryGeneratedColumn } from 'typeorm';
import { Locations } from './locations.entity';
import { Deployments } from './deployments.entity';
import { Features } from './features.entity';

@Entity('placement_configuration')
export class PlacementConfiguration {

  @PrimaryGeneratedColumn()
  id: number;

  @Column('text', {
    nullable: false,
    name: 'orientation_description',
  })
  orientationDescription: string;

  @Column('integer', {
    nullable: false,
    name: 'num_deployments',
  })
  numDeployments: number;

  @Column('text', {
    nullable: false,
    name: 'remarks',
  })
  remarks: string;

  @ManyToOne(() => Locations, locations => locations.placementConfigurations, { nullable: false })
  @JoinColumn({ name: 'locations_id' })
  locations: Locations | null;

  @ManyToOne(() => Deployments, deployments => deployments.placementConfigurations, { nullable: false })
  @JoinColumn({ name: 'deployments_id' })
  deployments: Deployments | null;

  @ManyToOne(() => Features, features => features.placementConfigurations, { nullable: false })
  @JoinColumn({ name: 'features_id' })
  features: Features | null;

}
