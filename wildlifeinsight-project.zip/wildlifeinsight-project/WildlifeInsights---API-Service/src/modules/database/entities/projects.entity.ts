import { Entity, Column, OneToOne, OneToMany, ManyToOne, ManyToMany, JoinColumn, PrimaryColumn } from 'typeorm';
import { Initiatives } from './initiatives.entity';
import { Deployments } from './deployments.entity';
import { ParticipantTypeProjectPivot } from './participant-type-project-pivot.entity';
import { Tags } from './tags.entity';
import { LocalTaxonomies } from './local-taxonomies.entity';
import { Organizations } from './organizations.entity';
import { Locations } from './locations.entity';
import { Subprojects } from './subprojects.entity';
import { Metadata } from './metadata.entity';

export type ProjectMetadataLicenseType = 'CC0' | 'CC-BY';
export type DataFilesLicenseType = 'CC0' | 'CC-BY' | 'CC-BY-NC';

export enum ProjectPrivacy { Always = 'always' }

@Entity('projects')
export class Projects extends Metadata {

  @Column('varchar', {
    nullable: false,
    length: 47,
    name: 'name',
  })
  name: string;

  @Column('varchar', {
    nullable: false,
    length: 255,
    name: 'slug',
    unique: true,
  })
  slug: string;

  @Column('varchar', {
    nullable: true,
    length: 255,
    name: 'abbreviation',
  })
  abbreviation: string | null;

  @Column('varchar', {
    nullable: true,
    length: 40,
    name: 'short_name',
  })
  shortName: string | null;

  @Column('text', {
    nullable: true,
    name: 'design',
  })
  design: string | null;

  @Column('text', {
    nullable: true,
    name: 'objectives',
  })
  objectives: string | null;

  @Column('varchar', {
    nullable: true,
    length: 255,
    name: 'rights_holder',
  })
  rightsHolder: string | null;

  @Column('varchar', {
    nullable: true,
    length: 255,
    name: 'access_rights',
  })
  accessRights: string | null;

  @Column('varchar', {
    nullable: true,
    length: 255,
    name: 'project_url',
  })
  projectUrl: string | null;

  @Column('varchar', {
    nullable: true,
    length: 255,
    name: 'project_status',
  })
  projectStatus: string | null;

  @Column('text', {
    nullable: true,
    name: 'methodology',
  })
  methodology: string;

  @Column('varchar', {
    nullable: true,
    length: 255,
    name: 'status',
  })
  status: string;

  @Column('date', {
    nullable: true,
    name: 'start_date',
  })
  startDate: Date;

  @Column('date', {
    nullable: true,
    name: 'end_date',
  })
  endDate: Date;

  @Column('text', {
    nullable: true,
    name: 'remarks',
  })
  remarks: string | null;

  @Column('varchar', {
    nullable: true,
    length: 255,
    name: 'project_credit_line',
  })
  projectCreditLine: string;

  @Column('varchar', {
    nullable: true,
    length: 255,
    name: 'acknowledgements',
  })
  acknowledgements: string;

  @Column('varchar', {
    nullable: true,
    length: 255,
    name: 'data_citation',
  })
  dataCitation: string;

  @Column('integer', {
    nullable: true,
    name: 'embargo',
  })
  embargo: number;

  @Column('boolean', {
    nullable: true,
    name: 'delete_data_files_with_identified_humans',
  })
  deleteDataFilesWithIdentifiedHumans: boolean;

  @Column('enum', {
    nullable: true,
    enum: ['CC0', 'CC-BY'],
    name: 'metadata_license',
  })
  metadataLicense: ProjectMetadataLicenseType | null;

  @Column('enum', {
    nullable: true,
    enum: ['CC0', 'CC-BY', 'CC-BY-NC'],
    name: 'data_files_license',
  })
  dataFilesLicense: DataFilesLicenseType | null;

  @Column('integer', {
    nullable: false,
    name: 'organizations_id',
  })
  organizationId: number;

  @Column('integer', {
    nullable: true,
    name: 'initiative_id',
  })
  initiativeId: number;

  @Column('varchar', {
    nullable: true,
    length: 36,
    name: 'trigger',
  })
  trigger: string;

  @Column('boolean', {
    nullable: true,
    name: 'disable_analytics',
  })
  disableAnalytics: boolean;

  @Column('double precision', {
    nullable: true,
    name: 'public_latitude',
  })
  publicLatitude: number | null;

  @Column('double precision', {
    nullable: true,
    name: 'public_longitude',
  })
  publicLongitude: number | null;

  @Column('enum', {
    nullable: true,
    enum: [ProjectPrivacy.Always],
    name: 'privacy',
  })
  privacy: ProjectPrivacy | null;

  @ManyToOne(() => Initiatives, initiatives => initiatives.projects)
  @JoinColumn({ name: 'initiative_id' })
  initiative: Initiatives | null;

  @OneToMany(() => Deployments, deployments => deployments.project)
  deployments: Deployments[];

  @OneToMany(() => ParticipantTypeProjectPivot, participantTypeProjectPivot => participantTypeProjectPivot.project, { cascade: ['update', 'insert', 'remove'] })
  participantTypeProjectPivot: ParticipantTypeProjectPivot[] | null;

  @OneToMany(() => Tags, tags => tags.project)
  tags: Tags[];

  @OneToMany(() => LocalTaxonomies, localTaxonomies => localTaxonomies.projects)
  localTaxonomies: LocalTaxonomies[];

  @ManyToOne(() => Organizations, organizations => organizations.projects)
  @JoinColumn({ name: 'organizations_id' })
  organization: Organizations;

  @OneToMany(() => Projects, projects => projects.organization, { nullable: false, onDelete: 'CASCADE' })
  locations: Locations[];

  @OneToMany(() => Subprojects, subprojects => subprojects.project, { nullable: true })
  subprojects: Subprojects[];
}

@Entity('project_highlighted_photos_vw')
export class ProjectHighlightedPhotos {
  @PrimaryColumn('integer', {
    nullable: false,
    name: 'project_id',
  })
  projectId: number;

  @Column('varchar', {
    nullable: false,
    name: 'thumbnail_url',
  })
  thumbnailUrl: string;
}
