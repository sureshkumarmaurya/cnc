import { Entity, Column, OneToMany, ManyToOne, JoinColumn, PrimaryGeneratedColumn } from 'typeorm';
import { IdentificationMetakeys } from './identification-metakeys.entity';
import { IdentifiedObjects } from './identified-objects.entity';

@Entity('identification_metavalues')
export class IdentificationMetavalues {

  @PrimaryGeneratedColumn()
  id: number;

  @ManyToOne(() => IdentificationMetakeys, identificationMetakeys => identificationMetakeys.identificationMetavaluess, { nullable: false })
  @JoinColumn({ name: 'key_id' })
  key: IdentificationMetakeys | null;

  @Column('text', {
    nullable: false,
    name: 'value',
  })
  value: string;

  @Column('text', {
    nullable: false,
    name: 'remarks',
  })
  remarks: string;

  @OneToMany(() => IdentifiedObjects, indentifiedObjects => indentifiedObjects.identificationMetavalue)
  identifiedObjects: IdentifiedObjects[];

}
