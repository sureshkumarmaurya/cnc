import { Index, Entity, PrimaryColumn, Column, OneToOne, OneToMany, ManyToOne, ManyToMany, JoinColumn, JoinTable, RelationId, PrimaryGeneratedColumn } from 'typeorm';
import { ExifDataFilePivot } from './exif-data-file-pivot.entity';

@Entity('exif_tags')
export class ExifTags {

  @PrimaryGeneratedColumn()
  id: number;

  @Column('varchar', {
    nullable: true,
    length: 255,
    name: 'tag_hex',
  })
  tagHex: string;

  @Column('varchar', {
    nullable: true,
    length: 255,
    name: 'tag_dec',
  })
  tagDec: string;

  @Column('varchar', {
    nullable: true,
    length: 255,
    name: 'ifd',
  })
  ifd: string;

  @Column('varchar', {
    nullable: true,
    length: 255,
    name: 'key',
  })
  key: string;

  @Column('varchar', {
    nullable: true,
    length: 255,
    name: 'group',
  })
  group: string;

  @Column('varchar', {
    nullable: false,
    length: 255,
    name: 'tag_name',
  })
  tagName: string;

  @Column('varchar', {
    nullable: true,
    length: 255,
    name: 'datatype',
  })
  datatype: string;

  @Column('text', {
    nullable: true,
    name: 'description',
  })
  description: string;

  @OneToMany(type => ExifDataFilePivot, exifDataFilePivot => exifDataFilePivot.exifTag)
  exifDataFilePivots: ExifDataFilePivot[] | null;
}
