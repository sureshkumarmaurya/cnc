import { Entity, Column, PrimaryGeneratedColumn, ManyToOne, JoinColumn, OneToMany } from 'typeorm';
import { Participants } from './participants.entity';
import { Organizations } from './organizations.entity';
import { Initiatives } from './initiatives.entity';
import { Projects } from './projects.entity';
import { EBatchDownloadStatus } from '../dto/batch-downloads.dto';
import { PublicDownloadRequest } from './public-download-requests.entity';

@Entity('batch_downloads')
export class BatchDownloads {

  @PrimaryGeneratedColumn()
  id: number;

  @Column('uuid', {
    nullable: false,
    name: 'uuid',
  })
  uuid: string;

  @Column({
    type: 'enum',
    enum: EBatchDownloadStatus,
    default: EBatchDownloadStatus.Requested,
  })
  status: EBatchDownloadStatus;

  @Column('varchar', {
    nullable: true,
    name: 'data_checksum',
  })
  dataChecksum: string;

  @Column('timestamp without time zone', {
    nullable: false,
    name: 'requested_timestamp',
  })
  requestedTimestamp: Date;

  @Column('timestamp without time zone', {
    nullable: true,
    name: 'finished_timestamp',
  })
  finishedTimestamp: Date;

  @Column('boolean', {
    nullable: false,
    name: 'is_public',
  })
  isPublic: boolean;

  @Column('int', {
    nullable: false,
    name: 'participant_id',
  })
  participantId: number;

  @Column('int', {
    nullable: true,
    name: 'project_id',
  })
  projectId: number | null;

  @Column('int', {
    nullable: true,
    name: 'initiative_id',
  })
  initiativeId: number | null;

  @Column('int', {
    nullable: true,
    name: 'organization_id',
  })
  organizationId: number | null;

  @Column('int', {
    nullable: true,
    name: 'projects_in_download_bundle',
    array: true,
  })
  projectsInDownloadBundle: number[] | null;

  @ManyToOne(type => Projects, { nullable: true })
  @JoinColumn({ name: 'project_id' })
  project: Projects;

  @ManyToOne(type => Initiatives, { nullable: true })
  @JoinColumn({ name: 'initiative_id' })
  initiative: Initiatives;

  @ManyToOne(type => Organizations, { nullable: true })
  @JoinColumn({ name: 'organization_id' })
  organization: Organizations;

  @ManyToOne(type => Participants)
  @JoinColumn({ name: 'participant_id' })
  participant: Participants;

  @OneToMany(() => PublicDownloadRequest, publicDownloadRequests => publicDownloadRequests.batchDownloadBundle)
  publicDownloadRequests: PublicDownloadRequest[];
}
