import { Participants } from './participants.entity';
import { Entity, Column, ManyToOne, ManyToMany, JoinColumn, PrimaryGeneratedColumn, OneToMany, JoinTable } from 'typeorm';
import { ParticipantTypeProjectPivot } from './participant-type-project-pivot.entity';
import { Permissions } from './permissions.entity';
import { OrganizationParticipantPivot } from './organization-participant-pivot.entity';
import { InitiativeParticipantPivot } from './initiative-participant-pivot.entity';

@Entity('roles')
export class Roles {

  @PrimaryGeneratedColumn()
  id: number;

  @Column('varchar', {
    nullable: false,
    length: 255,
    name: 'name',
  })
  name: string;

  @Column('varchar', {
    nullable: false,
    length: 255,
    name: 'slug',
    unique: true,
  })
  slug: string;

  @Column('boolean', {
    nullable: false,
    name: 'super_admin',
    default: false,
  })
  superAdmin: boolean;

  @OneToMany(() => ParticipantTypeProjectPivot, participantTypeProjectPivot => participantTypeProjectPivot.role)
  participantTypeProjectPivot: ParticipantTypeProjectPivot[] | null;

  @OneToMany(() => OrganizationParticipantPivot, organizationParticipantPivot => organizationParticipantPivot.role)
  organizationParticipantPivot: OrganizationParticipantPivot[] | null;

  @ManyToMany(() => Permissions, permissions => permissions.roles, { cascade: ['insert', 'update'] })
  @JoinTable()
  permissions: Permissions[] | null;

  @OneToMany(() => Participants, participants => participants.role)
  participants: Participants[];

  @OneToMany(() => InitiativeParticipantPivot, initiativeParticipantPivot => initiativeParticipantPivot.role)
  initiativeParticipantPivot: InitiativeParticipantPivot[] | null;

}
