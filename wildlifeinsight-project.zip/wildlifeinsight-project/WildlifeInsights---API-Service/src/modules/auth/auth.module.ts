import { DatabaseModule } from '../database/database.module';
import { JwtStrategy } from './jwk.strategy';
import { AuthService } from './auth.service';
import { Module } from '@nestjs/common';

@Module({
  imports: [DatabaseModule],
  providers: [AuthService, JwtStrategy],
})
export class AuthModule {}
