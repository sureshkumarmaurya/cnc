import { ExtractJwt, Strategy } from 'passport-jwt';
import { AuthService } from './auth.service';
import { PassportStrategy } from '@nestjs/passport';
import { Injectable, UnauthorizedException } from '@nestjs/common';
import * as jwksRsa from 'jwks-rsa';

import * as config from 'config';

const logger = require('logger');

@Injectable()
export class JwtStrategy extends PassportStrategy(Strategy) {
  constructor(private readonly authService: AuthService) {
    super({
      jwtFromRequest: ExtractJwt.fromExtractors([ExtractJwt.fromAuthHeaderAsBearerToken(), ExtractJwt.fromUrlQueryParameter('token')]),
      secretOrKey: JwtStrategy.passportJwtSecret({
        cache: true,
        rateLimit: true,
        jwksRequestsPerMinute: 5,
        jwksUri: config.get('auth.jwks-url'),
      }),
      audience: config.get('auth.audience'),
      issuer: config.get('auth.issuer'),
      algorithms: ['RS256'],
    });
  }

  static handleSigningKeyError(err, cb) {
    if (err && err.name === 'SigningKeyNotFoundError') {
      return cb(null);
    }
    if (err) {
      return cb(err);
    }
  }

  static passportJwtSecret(options) {
    const client = jwksRsa(options);
    const onError = options.handleSigningKeyError || JwtStrategy.handleSigningKeyError;

    return function secretProvider(header, cb) {
      // Only RS256 is supported.
      if (!header || header.alg !== 'RS256') {
        return cb(null, null);
      }

      client.getSigningKey(header.kid, (err, key) => {
        if (err) {
          return onError(err, (newError) => {
            return cb(newError, null);
          });
        }

        const newKey: any = key;
        // Provide the key.
        return cb(null, newKey.publicKey || newKey.rsaPublicKey);
      });
    };
  }

  async validate(payload, done) {
    const user = await this.authService.validateUser(payload);
    if (!user) {
      return done(new UnauthorizedException(), false);
    }
    done(null, user);
  }
}
