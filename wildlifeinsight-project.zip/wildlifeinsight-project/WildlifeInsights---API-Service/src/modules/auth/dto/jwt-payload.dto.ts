export class JwtPayloadDto {
  data: {
    id: number;
    role: string;
    name: string;
  };
}
