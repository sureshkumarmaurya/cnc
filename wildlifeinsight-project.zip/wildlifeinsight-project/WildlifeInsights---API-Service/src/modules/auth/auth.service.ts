import { Inject } from '@nestjs/common';
import { Repository } from 'typeorm';
import { JwtPayloadDto } from './dto/jwt-payload.dto';
import { Participants } from '../database/entities/participants.entity';
import { Roles } from 'modules/database/entities/roles.entity';
import { UsersACLCache } from 'modules/database/entities/users-acl-cache.entity';

const logger = require('logger');
const config = require('config');

export class AuthService {

  constructor(
    @Inject('ParticipantsRepositoryToken') private readonly participantsRepository: Repository<Participants>,
    @Inject('RolesRepositoryToken') private readonly rolesRepository: Repository<Roles>,
    @Inject('UsersACLCacheRepositoryToken') private readonly usersACLCacheRepository: Repository<UsersACLCache>,
  ) {}

  async validateUser(payload: JwtPayloadDto): Promise<any> {
    if (payload.data.id.toString() === 'service') {
      return {
        name: payload.data.name,
        id: payload.data.id,
        role: await this.rolesRepository.findOne({ where: { slug: payload.data.role } }),
      };
    }

    const usersACLCacheExpirationInHours = config.get('usersACLCacheExpirationInHours');

    const userACL = await this.getCachedUsersACL(payload.data.id);

    if (userACL) {
      const recordTimestamp = new Date(userACL.lastChanged);
      const current = new Date();
      const diff = (current.getTime() - recordTimestamp.getTime()) / 3600000;
      if (usersACLCacheExpirationInHours > diff) { return JSON.parse(userACL.acl); }
    }

    const user = await this.calculateUsersACL(payload.data.id);
    await this.updateOrAddUsersACLToCache(payload.data.id, user);
    return user;
  }

  async calculateUsersACL(userId: number): Promise<any> {
    const user = await this.participantsRepository.createQueryBuilder('p')
      .where('p.id = :id')
      .andWhere('p.active is TRUE')
      .innerJoinAndSelect('p.role', 'role')
      // projects
      .leftJoinAndSelect('p.participantTypeProjectPivot', 'ptp')
      .leftJoinAndSelect('ptp.role', 'roleProject')
      .leftJoinAndSelect('ptp.project', 'project')
      // organizations
      .leftJoinAndSelect('p.organizationParticipantPivot', 'op')
      .leftJoinAndSelect('op.role', 'roleOrganization')
      .leftJoinAndSelect('op.organization', 'organization')
      // initiatives
      .leftJoinAndSelect('p.initiativeParticipantPivot', 'ip')
      .leftJoinAndSelect('ip.role', 'roleInitiative')
      .leftJoinAndSelect('ip.initiative', 'initiative')
      .setParameter('id', userId).getOne();

    return user;
  }

  async getCachedUsersACL(userId: number): Promise<UsersACLCache> {
    return await this.usersACLCacheRepository.findOne({ where: { userId } });
  }

  async updateOrAddUsersACLToCache(userId: number, acl: any): Promise<any> {
    const count = await this.usersACLCacheRepository.count({ userId });
    return (count === 0) ?
      await this.usersACLCacheRepository.insert({
        userId,
        acl: JSON.stringify(acl),
        lastChanged: new Date(),
      }) :
      await this.usersACLCacheRepository.update({ userId }, { acl: JSON.stringify(acl) },
      );
  }
}
