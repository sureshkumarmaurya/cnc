/**
 * Export all science data
 */
import { createConnection } from 'typeorm';

const storage = require('@google-cloud/storage');

const database = require('better-sqlite3');
const config = require('config');
const logger = require('logger');
const fs = require('fs');

run();

async function getScienceData() {
  const connection = await createConnection({
    type: 'postgres',
    url: config.get('postgres.url'),
    entities: [`${__dirname}../../../modules/database/entities/*.entity{.ts,.js}`],
    synchronize: false,
    migrationsRun: false,
  });

  const data = await connection.manager.query('SELECT * FROM science_data_vw');

  return data;
}

async function writeDataToBucket(dataFile, destinationBucket) {
  const file = new storage({
      keyFilename: process.env.GOOGLE_APPLICATION_CREDENTIALS_SCIENCE_DATA,
    })
    .bucket(destinationBucket)
    .file('science-data.sqlite');

  await file.save(fs.readFileSync(dataFile), (err) => {
    if (err) {
      console.log(err);
    } else {
      console.log(`science-data.sqlite successfully written to bucket ${destinationBucket}.`);
    }
  });
}

async function exportScienceData(data, dataFile) {

  const db = new database(dataFile);

  db.exec('DROP TABLE IF EXISTS science_data');
  db.exec(`
    CREATE TABLE science_data (
    id INTEGER,
    project_id INTEGER,
    organization_id INTEGER,
    site_name TEXT,
    deployment_name TEXT,
    latitude REAL,
    longitude REAL,
    deployment_location_id TEXT,
    photo_time TEXT,
    photo_date TEXT,
    photo_datetime TEXT,
    raw_name TEXT,
    class TEXT,
    "order" TEXT,
    family TEXT,
    genus TEXT,
    species TEXT,
    sp_binomial TEXT,
    wi_taxa_id INTEGER,
    number_of_animals INTEGER,
    certainty REAL,
    camera_serial_number TEXT,
    camera_notes TEXT,
    sensor_start_date_and_time TEXT,
    sensor_end_date_and_time TEXT,
    camera_make TEXT,
    camera_model TEXT
  )`);

  db.exec(`
    CREATE VIEW IF NOT EXISTS project_summary_metadata AS
      SELECT DISTINCT organization_id, project_id, count(*) AS data_file_count
      FROM science_data
      GROUP BY organization_id, project_id
  `);

  const insert = db.prepare(`INSERT INTO science_data (
    id,
    project_id,
    organization_id,
    site_name,
    deployment_name,
    latitude,
    longitude,
    deployment_location_id,
    photo_time,
    photo_date,
    photo_datetime,
    raw_name,
    class,
    "order",
    family,
    genus,
    species,
    sp_binomial,
    wi_taxa_id,
    number_of_animals,
    certainty,
    camera_serial_number,
    camera_notes,
    sensor_start_date_and_time,
    sensor_end_date_and_time,
    camera_make,
    camera_model
  ) VALUES (
    @id,
    @project_id,
    @organization_id,
    @site_name,
    @deployment_name,
    @latitude,
    @longitude,
    @deployment_location_id,
    @photo_date,
    @photo_time,
    @photo_datetime,
    @raw_name,
    @class,
    @order,
    @family,
    @genus,
    @species,
    @sp_binomial,
    @wi_taxa_id,
    @number_of_animals,
    @certainty,
    @camera_serial_number,
    @camera_notes,
    @sensor_start_date_and_time,
    @sensor_end_date_and_time,
    @camera_make,
    @camera_model
  )`);

  const insertMany = db.transaction((dataFiles) => {
    for (const df of dataFiles) { insert.run(df); }
  });

  insertMany(data);

  db.exec(`
      CREATE INDEX IF NOT EXISTS idx_org_proj
        ON science_data (organization_id, project_id)
  `);
}

async function run() {
  // Read path to destination file supplied on CLI; otherwise use default
  const dataFile = '/tmp/science-data.sqlite';

  const destinationBucket = process.argv && process.argv.length > 2 ?
    process.argv[2] :
    null;

  console.log(process.argv);

  if (destinationBucket === null) {
    console.error(`Usage: ${process.argv[0]} <destination_bucket_name>`);
    console.error(
      `<destination_bucket_name>: name of the Google Cloud Storage bucket where
      the sqlite file will be eventually written.`);

    process.exit(1);
  }

  logger.info('Querying science data from backend database...');

  const data = await getScienceData();

  logger.info(`${data.length} records retrieved.`);

  logger.info(`Exporting science data to ${dataFile}...`);

  exportScienceData(data, dataFile);

  logger.info(`Writing science data sqlite file to bucket ${destinationBucket}...`);

  writeDataToBucket(dataFile, destinationBucket);

}
