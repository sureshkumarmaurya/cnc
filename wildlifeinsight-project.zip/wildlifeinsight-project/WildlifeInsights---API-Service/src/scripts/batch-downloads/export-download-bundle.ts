import { BatchDownloads } from 'modules/database/entities/batch-downloads.entity';
import { createConnection } from 'typeorm';
import { ProjectExporter } from 'utils/project.exporter.utils';
import { BatchDownloadsProjects } from 'modules/database/entities/batch-downloads-projects.entity';
import { BatchDownloadsDeployments } from 'modules/database/entities/batch-downloads-deployments.entity';
import { BatchDownloadsCameras } from 'modules/database/entities/batch-downloads-cameras.entity';
import { BatchDownloadsImages } from 'modules/database/entities/batch-downloads-images.entity';
import { Projects } from 'modules/database/entities/projects.entity';
const argv = require('yargs').argv;
const config = require('config');
const batchDownloadJobId : number = argv.job_id;

run(batchDownloadJobId);

async function run(batchDownloadJobId: number) {
  const connection = await createConnection({
    type: 'postgres',
    url: config.get('postgres.url'),
    entities: [`${__dirname}/../../modules/database/entities/*.entity{.ts,.js}`],
    synchronize: false,
    migrationsRun: false,
  });

  const batchDownloadsRepository = connection.getRepository(BatchDownloads);
  const projectsRepository = connection.getRepository(Projects);
  const batchDownloadsProjectsRepository = connection.getRepository(BatchDownloadsProjects);
  const batchDownloadsDeploymentsRepository = connection.getRepository(BatchDownloadsDeployments);
  const batchDownloadsCamerasRepository = connection.getRepository(BatchDownloadsCameras);
  const batchDownloadsImagesRepository = connection.getRepository(BatchDownloadsImages);

  const batchDownloadJob = await batchDownloadsRepository.findOne(batchDownloadJobId);

  const projectExporter = new ProjectExporter(
    projectsRepository,
    batchDownloadsProjectsRepository,
    batchDownloadsDeploymentsRepository,
    batchDownloadsCamerasRepository,
    batchDownloadsImagesRepository);

  await projectExporter.export(batchDownloadJob);
}
