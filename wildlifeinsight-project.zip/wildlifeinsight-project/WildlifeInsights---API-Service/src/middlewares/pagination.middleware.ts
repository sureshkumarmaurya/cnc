import { Middleware, NestMiddleware, MiddlewareFunction, Injectable } from '@nestjs/common';

const logger = require('logger');

const defaultPagination = {
  pageSize: 10,
  pageNumber: 1,
  fields: [],
  includes: [],
  sort: [],
};

class ConfigPagination {
  includes?: string[] = [];
  allowIncludes?: string[] = [];
}

@Injectable()
export class PaginationMiddleware implements NestMiddleware {

  resolve(prePagination: ConfigPagination = {}): MiddlewareFunction {
    return (req, res, next) => {
      logger.debug('Checking pagination data');
      try {
        const pagination = { ...defaultPagination, ...prePagination };

        if (req.query.page) {
          if (req.query.page.size) {
            pagination.pageSize = parseInt(req.query.page.size, 10);
            if (pagination.pageSize < 0) {
              pagination.pageSize = 10;
            }
          }
          if (req.query.page.number) {
            pagination.pageNumber = parseInt(req.query.page.number, 10);
            if (pagination.pageNumber < 0) {
              pagination.pageNumber = 1;
            }
          }
        }

        if (req.query.fields) {
          pagination.fields = req.query.fields.split(',');
          if (pagination.fields.indexOf('id') < 0)  {
            pagination.fields.push('id');
          }
        }

        if (req.query.includes) {
          pagination.includes = req.query.includes.split(',').filter(inc => prePagination.allowIncludes.indexOf(inc) >= 0);
        }
        if (req.query.sort) {
          pagination.sort = req.query.sort.split(',').map((stat: string) => {
            if (stat.startsWith('-')) {
              return { column: stat.slice(1, stat.length), order: 'DESC' };
            }
            if (stat.startsWith('+'))  {
              return { column: stat.slice(1, stat.length), order: 'ASC' };
            }
            return { column: stat, order: 'ASC' };
          });
        }
        if (!req.locals) {
          req.locals = {};
        }
        req.locals.pagination = pagination;
        next();
      } catch (err) {
        logger.error(err);
        res.status(403).send('Not authorized');
      }
    };
  }
}
