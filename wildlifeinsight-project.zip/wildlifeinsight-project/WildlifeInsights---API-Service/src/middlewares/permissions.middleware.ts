import { ParticipantTypeProjectPivotDto } from 'modules/database/dto/participant-type-project-pivot.dto';
import { NestMiddleware, MiddlewareFunction, Injectable, UnauthorizedException, HttpService } from '@nestjs/common';
import { AuthenticatedUserDto } from 'dto/authenticated-user.dto';
import { RolesDto } from 'modules/database/dto/roles.dto';
import { ParticipantsDto } from 'modules/database/dto/participants.dto';
import { OrganizationParticipantPivotDto } from 'modules/database/dto/organization-participant-pivot.dto';

const logger = require('logger');
const config = require('config');

@Injectable()
export class PermissionsMiddleware implements NestMiddleware {

  constructor(private readonly httpService: HttpService) {}

  async getPermissionsOfRole(role: string): Promise<RolesDto> {
    logger.debug('Retrieving role: ', role);
    const headers = {
      Authorization: `Bearer ${config.get('auth.serviceToken')}`,
    };
    const result = await this.httpService.get(`${config.get('auth.ssoUrl')}/api/v1/role/${role}?includes=permissions`, { headers }).toPromise();
    return result.data;

  }

  resolve(): MiddlewareFunction {
    return async (req, res, next) => {
      logger.debug('Obtaining permissions');
      const user: ParticipantsDto = req.user;
      const authenticatedUser = new AuthenticatedUserDto();
      authenticatedUser.user = user;
      const rolesSet = new Set<string>();
      if (user && user.role) {
        authenticatedUser.generalRole = user.role;
        rolesSet.add(user.role.slug);
      }

      if (user && user.participantTypeProjectPivot) {
        authenticatedUser.projectRole = [];
        user.participantTypeProjectPivot.forEach((ptp: ParticipantTypeProjectPivotDto) => {
          if (ptp.role) {
            ptp.role.slug && rolesSet.add(ptp.role.slug);
            authenticatedUser.projectRole.push({
              project: ptp.project,
              role: ptp.role,
              isImplicit: ptp.isImplicit,
            });
          }
        });
      }

      if (user && user.organizationParticipantPivot) {
        authenticatedUser.organizationRole = [];
        user.organizationParticipantPivot.forEach((op: OrganizationParticipantPivotDto) => {
          if (op.role) {
            rolesSet.add(op.role.slug);
            authenticatedUser.organizationRole.push({
              organization: op.organization,
              role: op.role,
            });
          }
        });
      }
      logger.debug('Computing permissions of the user granted via these roles: ', rolesSet);
      try {
        const isStaging = config.get('logger.name') === 'wi-api(staging)';
        const roles = await Promise.all([...rolesSet].map(role => this.getPermissionsOfRole(role)));
        roles.forEach((r: RolesDto) => {
          if (authenticatedUser.generalRole && authenticatedUser.generalRole.id === r.id) {
            authenticatedUser.generalRole = r;
          }
          if (authenticatedUser.projectRole) {
            authenticatedUser.projectRole = authenticatedUser.projectRole.map((pr) => {
              if (pr.role.id === r.id) {
                pr.role = r;
              }
              return pr;
            });
          }
          if (authenticatedUser.organizationRole) {
            authenticatedUser.organizationRole = authenticatedUser.organizationRole.map((or) => {
              if (or.role.id === r.id) {
                or.role = r;
              }
              return or;
            });
          }
        });
        req.user = authenticatedUser;
        next();
      } catch (err) {
        logger.error(`Error while checking permissions of the current user: ${err}`);

        throw new UnauthorizedException(err, 'Error while checking permissions of the current user.');
      }
    };
  }
}
