import * as multer from 'multer';
import * as uuid from 'uuid/v4';

const regularFileUploadStorage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, '/tmp');
  },
  filename: (req, file, cb) => {
    const parts = file.originalname.split('.');
    cb(null, `${uuid()}.${parts[parts.length - 1]}`);
  },
});

export const uploadOptions = {
  storage: regularFileUploadStorage,
  limits: {
    /**
     * If the environment variable FILESTORAGE_SIZE_LIMIT_BYTES is set and is an
     * integer, use this as fileSize limit, otherwise fall back to hardcoded
     * default (5MiB)
     */
    fileSize:
      (process.env.FILESTORAGE_SIZE_LIMIT_BYTES && Number.isInteger(+process.env.FILESTORAGE_SIZE_LIMIT_BYTES)) ?
        +process.env.FILESTORAGE_SIZE_LIMIT_BYTES :
        5 * 1024 * 1024,
  },
};
