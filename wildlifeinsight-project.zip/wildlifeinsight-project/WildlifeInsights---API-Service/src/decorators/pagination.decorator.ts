import { createParamDecorator } from '@nestjs/common';

// tslint:disable-next-line:variable-name
export const Pagination = createParamDecorator((data, req) => {
  return req.locals.pagination;
});
