import { ReflectMetadata } from '@nestjs/common';

// tslint:disable-next-line:variable-name
export const Permissions = (...permissions: string[]) => ReflectMetadata('permissions', permissions);
