import { createParamDecorator } from '@nestjs/common';

// tslint:disable-next-line:variable-name
export const User = createParamDecorator((_, req) => {
  if (!req.user && Array.isArray(req)) {
    return req[2].req.user;
  }
  return req.user;
});
