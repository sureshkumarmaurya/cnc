import {registerDecorator, ValidationOptions, ValidatorConstraint, ValidatorConstraintInterface, ValidationArguments} from "class-validator";

var constraintIdx: number = -1;

@ValidatorConstraint({ name: "objHasProperty", async: false })
export class objHasProperty implements ValidatorConstraintInterface {

    validate(value: any, args: ValidationArguments) {
        return (typeof value === "object") && hasProperty(value, args.constraints[0]);
    }

    defaultMessage(args: ValidationArguments) { // here you can provide default error message if validation failed
        let constraintLoc = (constraintIdx != -1) ? args.constraints[0][constraintIdx] : args.constraints[0];
        return "$property must contain " + constraintLoc + " value";
    }

}

export function hasProperty(value: object, props:any): boolean {
    for (var i = 0; i < props.length; i++) {
        if (!value.hasOwnProperty(props[i])) {
            constraintIdx = i;            
            return false;
        }
    }
    return true;
}

export function IsMetaPropertyExists(property: string[], validationOptions?: ValidationOptions) {
    return function (object: Object, propertyName: string) {
         registerDecorator({
             target: object.constructor,
             propertyName: propertyName,
             options: validationOptions,
             constraints: [property],
             validator: objHasProperty
         });
    };
 }