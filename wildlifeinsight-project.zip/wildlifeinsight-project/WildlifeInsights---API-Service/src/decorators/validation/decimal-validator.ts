import { ValidatorConstraint, ValidatorConstraintInterface, ValidationArguments } from "class-validator";

@ValidatorConstraint({ name: "DecimalValidator", async: false })
export class DecimalChecker implements ValidatorConstraintInterface {

    validate(value: any, args: ValidationArguments) {
        return (typeof value === "string") && checkForFourDecimal(value);
    }

    defaultMessage(args: ValidationArguments) {
        return "Latitude/Longitude must be string and also contain at least four and maximum eight decimal digits";
    }

}

export function checkForFourDecimal(value: string): boolean {

    //if (Math.floor(value) !== value)
    if (value.indexOf(".") !== -1)
        return (value.toString().split(".")[1].length > 3) && (value.toString().split(".")[1].length < 9) || false;
    return false;
}