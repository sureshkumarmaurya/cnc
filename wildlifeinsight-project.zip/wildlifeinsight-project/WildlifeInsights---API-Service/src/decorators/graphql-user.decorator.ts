import { ParticipantTypeProjectPivotDto } from 'modules/database/dto/participant-type-project-pivot.dto';
import { createParamDecorator, HttpService } from '@nestjs/common';
import { ForbiddenError } from 'apollo-server-express';
import { PermissionsUtils } from 'utils/permissions.utils';
import { AuthenticatedUserDto } from 'dto/authenticated-user.dto';
import { RolesDto } from 'modules/database/dto/roles.dto';
import { ParticipantsDto } from 'modules/database/dto/participants.dto';
import { OrganizationParticipantPivotDto } from 'modules/database/dto/organization-participant-pivot.dto';
import { InitiativeParticipantPivotDto } from 'modules/database/dto//initiative-participant-pivot.dto';

import { parseGraphqlParams } from 'utils/params.graphql.util';
import { PERMISSIONS } from 'utils/permissions.enum';

const logger = require('logger');
const config = require('config');

const getPermissionsOfRole = async (role: string): Promise<RolesDto> => {
  logger.debug('Retrieving role: ', role);
  const headers = {
    Authorization: `Bearer ${config.get('auth.serviceToken')}`,
  };
  const httpService = new HttpService();
  const result = await httpService.get(`${config.get('auth.ssoUrl')}/api/v1/role/${role}?includes=permissions`, { headers }).toPromise();
  return result.data;
};

const hasPermissions = (user: AuthenticatedUserDto, entityType: string, entityId: number | null, permission: PERMISSIONS): boolean => {
  /**
   * entityId has TS type `entity | null` but in practice it is a string,
   * because this is what `parseGraphqlParams() returns values as for anything
   * in the GraphQL request's parameters that isn't an object, but as
   * PermissionUtils.validatePermissionsIn<Project|Initiative|Organization|GenericRole>()
   * expect and compare against a number, we cast this to a number here via the
   * + unary operator. Using `parseInt(entityId, 10)` would not go down well
   * with the TS type checker, as the first parameter would be expected to be a
   * string...
   */
  const numericEntityId = +entityId;

  logger.debug(`Checking if user has ${permission} permission on entity (type: ${entityType}) with id ${numericEntityId}`);

  let isUserAuthorized = false;

  if (entityType === 'project') {
    isUserAuthorized = PermissionsUtils.validatePermissionsInProject(user, numericEntityId, [permission]);
  } else if (entityType === 'initiative') {
    isUserAuthorized = PermissionsUtils.validatePermissionsInInitiative(user, numericEntityId, [permission]);
  } else if (entityType === 'organization') {
    isUserAuthorized = PermissionsUtils.validatePermissionsInOrganization(user, numericEntityId, [permission]);
  } else if (entityType === 'generic') {
    isUserAuthorized = PermissionsUtils.validatePermissionsInGenericRole(user, [permission]);
  }

  return isUserAuthorized;
};

// tslint:disable-next-line:variable-name
export const GraphqlUserWithPermissions = createParamDecorator(async (permission: PERMISSIONS, payload) => {
  logger.debug('Obtaining permissions');
  const [_, r, req, context] = payload;
  const qlParams = parseGraphqlParams(context);

  const user: ParticipantsDto = req.req.user.user || req.req.user;
  const authenticatedUser = new AuthenticatedUserDto();

  authenticatedUser.user = user;

  const rolesSet = new Set<string>();
  if (user && user.role) {
    authenticatedUser.generalRole = user.role;
    rolesSet.add(user.role.slug);
  }

  if (user && user.participantTypeProjectPivot) {
    authenticatedUser.projectRole = [];
    user.participantTypeProjectPivot.forEach((ptp: ParticipantTypeProjectPivotDto) => {
      if (ptp.role) {
        ptp.role.slug && rolesSet.add(ptp.role.slug);
        authenticatedUser.projectRole.push({
          project: ptp.project,
          role: ptp.role,
          isImplicit: ptp.isImplicit,
        });
      }
    });
  }

  if (user && user.organizationParticipantPivot) {
    authenticatedUser.organizationRole = [];
    user.organizationParticipantPivot.forEach((op: OrganizationParticipantPivotDto) => {
      if (op.role) {
        rolesSet.add(op.role.slug);
        authenticatedUser.organizationRole.push({
          organization: op.organization,
          role: op.role,
        });
      }
    });
  }

  if (user && user.initiativeParticipantPivot) {
    authenticatedUser.initiativeRole = [];
    user.initiativeParticipantPivot.forEach((ip: InitiativeParticipantPivotDto) => {
      if (ip.role) {
        rolesSet.add(ip.role.slug);
        authenticatedUser.initiativeRole.push({
          initiative: ip.initiative,
          role: ip.role,
          isImplicit: ip.isImplicit,
        });
      }
    });
  }

  logger.debug('Obtaining permissions of the roles', rolesSet);
  try {
    const roles = await Promise.all([...rolesSet].map(role => getPermissionsOfRole(role)));

    roles.forEach((r: RolesDto) => {
      if (authenticatedUser.generalRole && authenticatedUser.generalRole.id === r.id) {
        authenticatedUser.generalRole = r;
      }

      if (authenticatedUser.projectRole) {
        authenticatedUser.projectRole = authenticatedUser.projectRole.map((project) => {
          if (project.role.id === r.id) {
            project.role = r;
          }
          return project;
        });
      }

      if (authenticatedUser.organizationRole) {
        authenticatedUser.organizationRole = authenticatedUser.organizationRole.map((organization) => {
          if (organization.role.id === r.id) {
            organization.role = r;
          }
          return organization;
        });
      }

      if (authenticatedUser.initiativeRole) {
        authenticatedUser.initiativeRole = authenticatedUser.initiativeRole.map((initiative) => {
          if (initiative.role.id === r.id) {
            initiative.role = r;
          }
          return initiative;
        });
      }
    });
    req.user = authenticatedUser;
  } catch (err) {
    logger.error(err);
  }

  if (permission) {
    let isUserAuthorized: boolean = false;
    if (qlParams.projectId !== undefined) {
      isUserAuthorized = hasPermissions(authenticatedUser, 'project', qlParams.projectId, permission);
    } else if (qlParams.initiativeId !== undefined) {
      isUserAuthorized = hasPermissions(authenticatedUser, 'initiative', qlParams.initiativeId, permission);
    } else if (qlParams.organizationId !== undefined) {
      isUserAuthorized = hasPermissions(authenticatedUser, 'organization', qlParams.organizationId, permission);
    } else {
      isUserAuthorized = hasPermissions(authenticatedUser, 'generic', null, permission);
    }

    if (!isUserAuthorized) {
      throw new ForbiddenError('User does not have suitable permissions for the action requested');
    }
  }

  return authenticatedUser;
});
