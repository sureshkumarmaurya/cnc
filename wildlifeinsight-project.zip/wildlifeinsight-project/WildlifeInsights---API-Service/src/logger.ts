import * as bunyan from 'bunyan';
const config = require('config');

/**
 * Create Logger
 */
module.exports = (() => {
  const streams = [{
    level: config.get('logger.level') || 'debug',
    stream: process.stdout,
  }];
  const logger = bunyan.createLogger({
    streams,
    name: config.get('logger.name') || 'wi-api',
    src: true,
  });
  return logger;

})();
