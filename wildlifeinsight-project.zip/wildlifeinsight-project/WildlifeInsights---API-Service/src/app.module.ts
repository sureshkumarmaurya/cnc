import { DeploymentModule } from 'modules/api/v1/deployments/deployment.module';
import { OrganizationModule } from 'modules/api/v1/organizations/organization.module';
import { Module, RequestMethod, MiddlewareConsumer, HttpModule, HttpException } from '@nestjs/common';
import { GraphQLError } from 'graphql';
import { DatabaseModule } from 'modules/database/database.module';
import { AuthModule } from 'modules/auth/auth.module';
import * as passport from 'passport';
import { ParticipantTypeModule } from 'modules/api/v1/participantTypes/participant-type.module';
import { GraphQLModule } from '@nestjs/graphql';
import { InitiativeModule } from 'modules/api/v1/initiatives/initiative.module';
import { InitiativePublicModule } from 'modules/api/v1/initiatives/initiative-public.module';
import { PermissionsMiddleware } from 'middlewares/permissions.middleware';
import {
  GraphQLDate, GraphQLTime, GraphQLDateTime,
} from 'graphql-iso-date';
import { GraphQLJSONObject } from 'graphql-type-json';
import { ProjectModule } from 'modules/api/v1/projects/project.module';
import { DeviceModule } from 'modules/api/v1/devices/device.module';
import { BaitTypeModule } from 'modules/api/v1/bait-types/bait-type.module';
import { LocationModule } from 'modules/api/v1/locations/location.module';
import { LocationPublicModule } from 'modules/api/v1/locations/location-public.module';
import { DataFileModule } from 'modules/api/v1/data-files/data-file.module';
import { GoogleModule } from 'modules/google/google.module';
import { TaxonomyModule } from 'modules/api/v1/taxonomies/taxonomy.module';
import { IdentificationMethodModule } from 'modules/api/v1/identification-methods/identification-method.module';
import { SequenceIdentificationOutputModule } from 'modules/api/v1/sequence-identification-outputs/sequence-identification-output.module';
import { IdentificationOutputModule } from 'modules/api/v1/identification-outputs/identification-output.module';
import { IdentifiedObjectModule } from 'modules/api/v1/identified-objects/identified-object.module';
import { FunctionModule } from 'modules/function/function.module';
import { SequenceModule } from 'modules/api/v1/sequences/sequence.module';
import { ManageModule } from 'modules/api/v1/manage/manage.module';
import { DataFileMetavalueModule } from 'modules/api/v1/data-files/metavalues/data-file-metavalue.module';
import { AnalyticsModule } from 'modules/api/v1/analytics/analytics.module';
import { SubprojectModule } from 'modules/api/v1/subprojects/subproject.module';
import { BatchUploadModule } from 'modules/api/v1/batch-uploads/batch-upload.module';
import { BatchDownloadModule } from 'modules/api/v1/batch-downloads/batch-download.module';
import { ParticipantModule } from 'modules/api/v1/participants/participant.module';
import { AnalyticsPublicModule } from 'modules/api/v1/analytics/analytics-public.module';
import { TaxonomyPublicModule } from 'modules/api/v1/taxonomies/taxonomy-public.module';
import { RoleChangesModule } from 'modules/api/v1/role-changes/role-changes.module';
import { MiddlewareUtil } from 'utils/middleware.util';
import { BatchDownloadPublicModule } from 'modules/api/v1/batch-downloads/batch-download-public.module';
import { HealthModule } from 'modules/api/v1/health/health.module';
import { GeoRegionModule } from 'modules/api/v1/geo-regions/geo-regions.module';

const _ = require('lodash');
const middlewareUtil = new MiddlewareUtil();

@Module({
  imports: [
    AuthModule,
    DatabaseModule,
    OrganizationModule,
    ParticipantTypeModule,
    GoogleModule,
    /**
     * Protected endpoints
     */
    GraphQLModule.forRoot({
      typePaths: ['./**/*.graphql'],
      installSubscriptionHandlers: true,
      resolvers: {
        DateTime: GraphQLDateTime,
        Date: GraphQLDate,
        Time: GraphQLTime,
        JSONObject: GraphQLJSONObject,
      },
      context: ({ req }) => ({ req }),
      formatError: (error: GraphQLError) => {
        const message = (typeof error.message === 'string') ? error.message :_.get(error, 'message.message', 'Generic error');
        error.message = message;
        return error;
      },
    }),

    /**
     * Public GraphQL endpoints
     *
     * Dirty solution for public graphql endpoints
     * What else can be done is creating a new Apollo server manually, but a lot of changes will be implemented
     * For now NestJS doesn't provide with a smooth solution :(
     */
    GraphQLModule.forRoot({
      typePaths: ['./**/*.graphql'],
      path: '/graphql-public',
      installSubscriptionHandlers: true,
      resolvers: {},
      include: [InitiativePublicModule, LocationPublicModule, AnalyticsPublicModule, TaxonomyPublicModule, BatchDownloadPublicModule],
      context: ({ req }) => ({ req }),
      formatError: (error: GraphQLError) => {
        const message = (typeof error.message === 'string') ? error.message :_.get(error, 'message.message', 'Generic error');
        error.message = message;
        return error;
      },
    }),
    AnalyticsPublicModule,
    InitiativeModule,
    InitiativePublicModule,
    HttpModule,
    ProjectModule,
    DeviceModule,
    BaitTypeModule,
    LocationModule,
    LocationPublicModule,
    DeploymentModule,
    DataFileModule,
    TaxonomyModule,
    IdentificationMethodModule,
    IdentificationOutputModule,
    IdentifiedObjectModule,
    SequenceIdentificationOutputModule,
    FunctionModule,
    SequenceModule,
    ManageModule,
    DataFileMetavalueModule,
    AnalyticsModule,
    SubprojectModule,
    BatchUploadModule,
    BatchDownloadModule,
    ParticipantModule,
    RoleChangesModule,
    TaxonomyPublicModule,
    BatchDownloadPublicModule,
    HealthModule,
    GeoRegionModule,
  ],
  controllers: [],
  providers: [PermissionsMiddleware],
})
export class AppModule {
  constructor() { }
  public configure(consumer: MiddlewareConsumer) {
    consumer
      /**
       * NestJS doesn't provide functionality to exclude routes to get them avoided by middlewares
       * .exclude() method doesn't work for this
       * The way is to add manually endpoints inside .forRoutes(), but that's too annoying
       * Created a custom middleware to exclude needed routes
       */
      .apply(middlewareUtil.runMiddlewareWithExcludePathList(
        [
          { path: '/api/v1/initiative/:id', method: 'GET' },
          { path: '/api/v1/taxonomy', method: 'GET' },
          { path: '/api/v1/taxonomy/:id', method: 'GET' },
          { path: '/api/v1/project/discover', method: 'GET' },
          { path: '/api/v1/invitation', method: 'GET' },
          { path: '/api/v1/health', method: 'GET' },
        ],
        passport.authenticate('jwt', { session: false })))
      .forRoutes(
        { path: '/api*', method: RequestMethod.ALL },
        { path: '/graphql', method: RequestMethod.POST },
      );

    consumer
      .apply(PermissionsMiddleware)
      .forRoutes(
        { path: '/api*', method: RequestMethod.ALL },
        { path: '/graphql', method: RequestMethod.POST },
      );
  }
}
