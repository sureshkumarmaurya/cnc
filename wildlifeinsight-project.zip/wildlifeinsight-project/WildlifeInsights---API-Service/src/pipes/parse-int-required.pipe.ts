import { PipeTransform, ArgumentMetadata, BadRequestException, Injectable } from '@nestjs/common';

@Injectable()
export class ParseIntRequiredPipe implements PipeTransform<string> {

  constructor(private required: boolean = true) {
  }
  async transform(value: string) {
    const val = parseInt(value, 10);
    if (isNaN(val) && this.required) {
      throw new BadRequestException('Number string not valid');
    }
    return val;

  }
}
