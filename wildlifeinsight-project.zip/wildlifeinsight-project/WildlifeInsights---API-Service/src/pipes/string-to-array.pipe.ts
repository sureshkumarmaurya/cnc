import { PipeTransform, ArgumentMetadata, Injectable } from '@nestjs/common';

@Injectable()
export class StringToArrayPipe implements PipeTransform<any> {
  transform(value: any) {
    if (!value || value === '') {
      return [];
    }
    return value.split(',');
  }
}
