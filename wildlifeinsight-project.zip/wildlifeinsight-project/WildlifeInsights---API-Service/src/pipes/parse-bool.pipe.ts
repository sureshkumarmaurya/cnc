import { PipeTransform, ArgumentMetadata, BadRequestException, Injectable } from '@nestjs/common';

@Injectable()
export class ParseBoolPipe implements PipeTransform<string> {

  constructor(private required: boolean = true) {
  }
  async transform(value: string) {
    if (value === 'true') {
      return true;
    }
    if (value === 'false') {
      return false;
    }
    if (this.required) {
      throw new BadRequestException('Validation failed');
    }

  }
}
