import { PipeTransform, ArgumentMetadata, BadRequestException, Injectable } from '@nestjs/common';

@Injectable()
export class ParseDateRequiredPipe implements PipeTransform<string> {

  constructor(private required: boolean = true) {
  }
  async transform(value: string) {
    const regex = /^(-?(?:[1-9][0-9]*)?[0-9]{4})-(1[0-2]|0[1-9])-(3[01]|0[1-9]|[12][0-9])T(2[0-3]|[01][0-9]):([0-5][0-9]):([0-5][0-9])(.[0-9]+)?(Z)?$/;
    if (!regex.test(value)) {
      if (this.required) {
        throw new BadRequestException('Date string not valid');
      }
    }
    return new Date(value);

  }
}
