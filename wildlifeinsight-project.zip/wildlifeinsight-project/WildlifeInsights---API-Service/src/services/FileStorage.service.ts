import { Injectable } from '@nestjs/common';
import * as  Storage from '@google-cloud/storage';
import { IFileUploadObject } from '../interfaces/fileUpload.interface';

const config = { keyFilename: process.env.GOOGLE_APPLICATION_CREDENTIALS };

export interface IFileUploadService {
  uploadFile(bucketName: string, fileName: string, options?: any);
  removeFile(bucketName: string, filename: string);
  createBucket(bucketName: string);
  removeBucket(bucketName: string);
}

@Injectable()
export class FileUploadService implements IFileUploadService {

  private _uploadProvider: Storage;

  constructor() {
    this._uploadProvider = new Storage(config);
  }

  public createBucket(bucketName) {
    return this._uploadProvider.createBucket(bucketName, { location: 'ASIA', storageClass: 'COLDLINE' });
  }

  public removeBucket(bucketName) {
    return this._uploadProvider.bucket(bucketName).delete();
  }

  public async uploadFile(bucketName: string, fileName: string, options = {}) {
    const result = await this._uploadProvider.bucket(bucketName).upload(fileName, options);

    const fileDataFull: any = [...result][1];

    const fileDataOutput: IFileUploadObject = {
      id: fileDataFull.id,
      linkPublic: fileDataFull.mediaLink,
      contentType: fileDataFull.contentType,
      name: fileDataFull.name,
    };
    return fileDataOutput;
  }

  public async removeFile(bucketName: string, filename: string) {
    try {
      const result = await this._uploadProvider.bucket(bucketName).file(filename).delete();
      return result;
    } catch (err) {
      if (err && err.message) {
        if (err.message.includes('No such object') || err.message.includes('Not Found')) {
          return true;
        }
      }
      throw err;
    }
  }
}
