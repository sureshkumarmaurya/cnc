const logger = require('logger');
// const gm = require('gm');
const gm = require('gm').subClass({ imageMagick: true });
import { Injectable } from '@nestjs/common';

interface IImageInfo {
  resolution: string;
  height: number;
  width: number;
  size?: number;
}

@Injectable()
export class ImageManagementService {
  private serviceProvider;

  constructor() {
    this.serviceProvider = gm;
  }

  private formatFileSize(fileSizeString: string): number {
    let fileSize = 0;
    if (fileSizeString && fileSizeString.length) {
      const sizeStringArray = fileSizeString.split('');
      const sizeId = sizeStringArray.pop();

      const actionTable = {
        K: (value) => { return (value / 1024).toFixed(2); },
        M: (value) => { return value; },
        G: (value) => { return value * 1024; },
      };
      fileSize = actionTable[sizeId](sizeStringArray.join(''));
    }
    return fileSize;
  }

  public async getInfo(imagePath: string): Promise<IImageInfo> {
    const identificationResult = await new Promise<any>((resolve, reject) => {
      this.serviceProvider(imagePath).identify((err: Error, result: any) => {
        if (err) {
          return reject(err);
        }
        return resolve(result);
      });
    });
    logger.debug('identificationResult', identificationResult);
    // const fileSize = this.formatFileSize(identificationResult.Filesize);

    return {
      height: identificationResult.size.height,
      width: identificationResult.size.width,
      resolution: identificationResult.Resolution,
    };
  }
}
