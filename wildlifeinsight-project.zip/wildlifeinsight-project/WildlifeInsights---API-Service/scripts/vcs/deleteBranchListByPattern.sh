#!/bin/bash

if [ -z "$1" ]
then
  echo "Branch pattern is not provided. Example: 'sh <script path> feature/*'. This will remove all the 'feature/' based branches"
else
  echo $(`git branch --list $1 | xargs -r git branch -d`)
fi