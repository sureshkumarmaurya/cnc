
#!/bin/bash

case "$1" in
    test-unit)
        type docker-compose >/dev/null 2>&1 || { echo >&2 "docker-compose is required but it's not installed.  Aborting."; exit 1; }
        docker-compose -f docker-compose-test-unit.yml build && docker-compose -f docker-compose-test-unit.yml up
        ;;
    test-e2e)
        type docker-compose >/dev/null 2>&1 || { echo >&2 "docker-compose is required but it's not installed.  Aborting."; exit 1; }
        docker-compose -f docker-compose-test-e2e.yml build && docker-compose -f docker-compose-test-e2e.yml up
        ;;        
    start)
        type docker-compose >/dev/null 2>&1 || { echo >&2 "docker-compose is required but it's not installed.  Aborting."; exit 1; }
        docker-compose build --force-rm && docker-compose up -d
        ;;
    develop)
        type docker-compose >/dev/null 2>&1 || { echo >&2 "docker-compose is required but it's not installed.  Aborting."; exit 1; }
        docker-compose -f docker-compose-develop.yml build && docker-compose -f docker-compose-develop.yml up
        ;;
    test)
        type docker-compose >/dev/null 2>&1 || { echo >&2 "docker-compose is required but it's not installed.  Aborting."; exit 1; }
        docker-compose -f docker-compose-test.yml build && docker-compose -f docker-compose-test.yml up
        ;;
  *)
        echo "Usage: service.sh {test-e2e|test-unit|start|develop|test}" >&2
        exit 1
        ;;
esac

exit 0
