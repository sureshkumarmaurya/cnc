import { MigrationInterface, QueryRunner } from "typeorm";

/**
 * Create PostGIS extension;
 */
export class PostGISExtension1562009988642 implements MigrationInterface {

    async up(queryRunner: QueryRunner): Promise<any> {
        await queryRunner.query(`
        CREATE EXTENSION IF NOT EXISTS postgis;
        `);
    }

    async down(queryRunner: QueryRunner): Promise<any> {
        await queryRunner.query(`DROP EXTENSION IF EXISTS postgis;`);
    }
}
