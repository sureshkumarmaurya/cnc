import { MigrationInterface, QueryRunner } from 'typeorm';

export class ProjectLicenseColumn1567595924000 implements MigrationInterface {

  async up(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`
      ALTER TYPE projects_license_enum RENAME TO data_file_license_enum;
      ALTER TABLE projects RENAME COLUMN license TO data_files_license;

      CREATE TYPE project_metadata_license_enum AS ENUM ('CC0', 'CC BY-NC');
      ALTER TABLE projects ADD COLUMN IF NOT EXISTS metadata_license project_metadata_license_enum;
    `);
  }

  async down(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`
      ALTER TABLE projects DROP COLUMN IF EXISTS metadata_license;
      DROP TYPE IF EXISTS project_metadata_license_enum;

      ALTER TABLE projects RENAME COLUMN data_files_license TO license;
      ALTER TYPE data_file_license_enum RENAME TO projects_license_enum;
    `);
  }
}
