import { MigrationInterface, QueryRunner } from 'typeorm';

export class AddPrivateFlagToProjects1581083455000 implements MigrationInterface {
  async up(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`
CREATE TYPE project_privacy AS ENUM ('always');

ALTER TABLE projects ADD COLUMN IF NOT EXISTS privacy project_privacy NULL;
    `);
  }

  async down(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`
ALTER TABLE projects DROP COLUMN IF EXISTS privacy;

DROP TYPE project_privacy;
    `);
  }
}
