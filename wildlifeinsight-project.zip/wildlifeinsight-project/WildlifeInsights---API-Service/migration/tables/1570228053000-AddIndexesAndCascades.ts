import { MigrationInterface, QueryRunner } from 'typeorm';

/**
 * This migration adds a bunch of indexes that were missing so far but are good
 * to have in order to improve performance of SQL operations.
 *
 * Some delete operations, for example, were taking an inordinate amount of time
 * before adding these indexes.
 *
 * Deleting a single project, triggering deletion of all the associated
 * deployments, devices and data_files, would take ~30min in the staging Cloud
 * SQL database, for a project with ~110K data_files.
 *
 * Moreover, this deletion would not even be allowed until we added ON DELETE
 * CASCADE on the FK from features to locations, which this migration adds.
 */
export class AddIndexesAndCascades1570228053000 implements MigrationInterface {
  async up(queryRunner: QueryRunner): Promise<any> {
    // features: index and cascades
    await queryRunner.query(`CREATE INDEX IF NOT EXISTS features__locations_id_idx ON features(locations_id);

    -- Add ON DELETE CASCADE ON UPDATE CASCADE to features -> locations FK
    do $$
        declare constraint_name text;
        begin
            select conname into constraint_name
            from pg_constraint
            where conrelid = 'public.features'::regclass and confrelid = 'public.locations'::regclass;

            IF constraint_name IS NOT NULL THEN
                execute format ('alter table features drop constraint %I', constraint_name);
            END IF;

            DROP TABLE IF EXISTS constraint_name;
        end;
    $$;
    ALTER TABLE features ADD CONSTRAINT "FK_features__locations" foreign key (locations_id) REFERENCES locations(id) ON DELETE CASCADE ON UPDATE CASCADE;
    `);

    // data_file_annotations: index and constraints
    await queryRunner.query(`CREATE INDEX IF NOT EXISTS data_files_annotations__data_file_id_idx ON data_file_annotations(data_file_id);

    -- Add ON DELETE CASCADE ON UPDATE CASCADE to data_file_annotations -> data_files FK
    do $$
        declare constraint_name text;
        begin
            select conname into constraint_name
            from pg_constraint
            where conrelid = 'public.data_file_annotations'::regclass and confrelid = 'public.data_files'::regclass;

            IF constraint_name IS NOT NULL THEN
                execute format ('alter table data_file_annotations drop constraint %I', constraint_name);
            END IF;

            DROP TABLE IF EXISTS constraint_name;
        end;
    $$;
    ALTER TABLE data_file_annotations ADD CONSTRAINT "FK_data_file_annotations__data_files" foreign key (data_file_id) REFERENCES data_files(id) ON DELETE CASCADE ON UPDATE CASCADE;
    `);

    // data_file_metavalues: index and constraints
    await queryRunner.query(`
    CREATE INDEX IF NOT EXISTS data_file_metavalues__data_file_id_idx ON data_file_metavalues(data_file_id);
    CREATE INDEX IF NOT EXISTS data_file_metavalues__data_file_metakey_id_idx ON data_file_metavalues(key_id);

    -- Add ON DELETE CASCADE ON UPDATE CASCADE to data_file_metavalues -> data_files FK
    do $$
        declare constraint_name text;
        begin
            select conname into constraint_name
            from pg_constraint
            where conrelid = 'public.data_file_metavalues'::regclass and confrelid = 'public.data_files'::regclass;

            IF constraint_name IS NOT NULL THEN
                execute format ('alter table data_file_metavalues drop constraint %I', constraint_name);
            END IF;

            DROP TABLE IF EXISTS constraint_name;
        end;
    $$;
    ALTER TABLE data_file_metavalues ADD CONSTRAINT "FK_data_file_metavalues__data_files" foreign key (data_file_id) REFERENCES data_files(id) ON DELETE CASCADE ON UPDATE CASCADE;

    -- Add ON DELETE CASCADE ON UPDATE CASCADE to data_file_metavalues -> data_file_metakeys FK
    do $$
        declare constraint_name text;
        begin
            select conname into constraint_name
            from pg_constraint
            where conrelid = 'public.data_file_metavalues'::regclass and confrelid = 'public.data_file_metakeys'::regclass;

            IF constraint_name IS NOT NULL THEN
                execute format ('alter table data_file_metavalues drop constraint %I', constraint_name);
            END IF;

            DROP TABLE IF EXISTS constraint_name;
        end;
    $$;
    ALTER TABLE data_file_metavalues ADD CONSTRAINT "FK_data_file_metavalues__data_file_metakeys" foreign key (key_id) REFERENCES data_file_metakeys(id) ON DELETE CASCADE ON UPDATE CASCADE;
    `);

    // identified_objects: index and constraints
    await queryRunner.query(`
    CREATE INDEX IF NOT EXISTS identified_objects__identifications_id_idx ON identified_objects(identifications_id);
    CREATE INDEX IF NOT EXISTS identified_objects__identification_metavalues_id_idx ON identified_objects(identification_metavalues_id);

    -- Add ON DELETE CASCADE ON UPDATE CASCADE to identified_objects -> identification_metavalues FK
    do $$
        declare constraint_name text;
        begin
            select conname into constraint_name
            from pg_constraint
            where conrelid = 'public.identified_objects'::regclass and confrelid = 'public.identification_metavalues'::regclass;

            IF constraint_name IS NOT NULL THEN
                execute format ('alter table identified_objects drop constraint %I', constraint_name);
            END IF;

            DROP TABLE IF EXISTS constraint_name;
        end;
    $$;
    ALTER TABLE identified_objects ADD CONSTRAINT "FK_identified_objects__identification_metavalues" foreign key (identification_metavalues_id) REFERENCES identification_metavalues(id) ON DELETE CASCADE ON UPDATE CASCADE;
    `);

    // data_files: index and constraints
    await queryRunner.query(`
    DROP INDEX IF EXISTS data_files_deployments_idx;
    CREATE INDEX IF NOT EXISTS data_files__deployments_id_idx ON data_files(deployment_id);
    CREATE INDEX IF NOT EXISTS data_files__status_idx ON data_files(status);
    CREATE INDEX IF NOT EXISTS data_files__created_at_idx ON data_files (("createdAt"::date));
    `);
  }

  async down(queryRunner: QueryRunner): Promise<any> {
    // Seriously? Go back to the former royal mess? LOL...
  }
}
