import { MigrationInterface, QueryRunner } from 'typeorm';

/**
 * This migration have a documentation character
 * In order to ensure the integrity of the data we executed manually the statement
 *
 * The purpose of the index is avoid inserts emails with only lowercase or uppercase letter as difference
 * E.g. stored previously example@example.com will be not possible insert Example@example.com
 */
export class UpdateParticipantsTable1573159774000 implements MigrationInterface {

  async up(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`
      CREATE UNIQUE INDEX IF NOT EXISTS "uq_participants__email" ON participants (lower(email));
    `);
  }

  async down(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`
      DROP INDEX IF EXISTS "uq_participants__email";
    `);
  }

}
