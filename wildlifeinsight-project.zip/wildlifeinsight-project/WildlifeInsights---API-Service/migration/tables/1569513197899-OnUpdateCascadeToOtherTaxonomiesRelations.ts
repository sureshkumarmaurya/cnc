import { MigrationInterface, QueryRunner } from 'typeorm';

export class OnUpdateCascadeToOtherTaxonomiesRelations1569513197899 implements MigrationInterface {
  async up(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`
      ALTER TABLE common_names
        DROP CONSTRAINT common_names_taxonomies_uuid_fkey,
        ADD CONSTRAINT common_names_taxonomies_uuid_fkey
          FOREIGN KEY (taxonomies_uuid) REFERENCES taxonomies(unique_identifier) ON UPDATE CASCADE;
      ALTER TABLE identification_method_taxonomy_pivot
        DROP CONSTRAINT identification_method_taxonomy_pivot_taxonomies_uuid_fkey,
        ADD CONSTRAINT identification_method_taxonomy_pivot_taxonomies_uuid_fkey
          FOREIGN KEY (taxonomies_uuid) REFERENCES taxonomies(unique_identifier) ON UPDATE CASCADE;
      ALTER TABLE local_taxonomies
        DROP CONSTRAINT local_taxonomies_taxonomies_uuid_fkey,
        ADD CONSTRAINT local_taxonomies_taxonomies_uuid_fkey
          FOREIGN KEY (taxonomies_uuid) REFERENCES taxonomies(unique_identifier) ON UPDATE CASCADE;
      ALTER TABLE sequence_identified_objects
        DROP CONSTRAINT sequence_identified_objects_taxonomies_uuid_fkey,
        ADD CONSTRAINT sequence_identified_objects_taxonomies_uuid_fkey
          FOREIGN KEY (taxonomies_uuid) REFERENCES taxonomies(unique_identifier) ON UPDATE CASCADE;
    `);
  }

  async down(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`
      ALTER TABLE common_names
        DROP CONSTRAINT common_names_taxonomies_uuid_fkey,
        ADD CONSTRAINT common_names_taxonomies_uuid_fkey
          FOREIGN KEY (taxonomies_uuid) REFERENCES taxonomies(unique_identifier);
      ALTER TABLE identification_method_taxonomy_pivot
        DROP CONSTRAINT identification_method_taxonomy_pivot_taxonomies_uuid_fkey,
        ADD CONSTRAINT identification_method_taxonomy_pivot_taxonomies_uuid_fkey
          FOREIGN KEY (taxonomies_uuid) REFERENCES taxonomies(unique_identifier);
      ALTER TABLE local_taxonomies
        DROP CONSTRAINT local_taxonomies_taxonomies_uuid_fkey,
        ADD CONSTRAINT local_taxonomies_taxonomies_uuid_fkey
          FOREIGN KEY (taxonomies_uuid) REFERENCES taxonomies(unique_identifier);
      ALTER TABLE sequence_identified_objects
        DROP CONSTRAINT sequence_identified_objects_taxonomies_uuid_fkey,
        ADD CONSTRAINT sequence_identified_objects_taxonomies_uuid_fkey
          FOREIGN KEY (taxonomies_uuid) REFERENCES taxonomies(unique_identifier);

    `);
  }
}
