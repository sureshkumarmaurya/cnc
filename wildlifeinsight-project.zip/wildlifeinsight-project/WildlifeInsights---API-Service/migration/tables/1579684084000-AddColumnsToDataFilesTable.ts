import { MigrationInterface, QueryRunner } from 'typeorm';

export class AddColumnsToDataFilesTable1579684084000 implements MigrationInterface {
  async up(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`
      ALTER TABLE data_files
        ADD COLUMN IF NOT EXISTS data_file_id varchar(36) NOT NULL DEFAULT uuid_generate_v4()::text,
        ADD COLUMN IF NOT EXISTS original_location_url text;
    `);
  }

  async down(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`
      ALTER TABLE data_files
        DROP COLUMN IF EXISTS data_file_id,
        DROP COLUMN IF EXISTS original_location_url;
    `);
  }
}
