import { MigrationInterface, QueryRunner } from 'typeorm';

export class CreateGeoRegionsTable1568385751000 implements MigrationInterface {

  async up(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`
      CREATE TABLE IF NOT EXISTS geo_regions (
          id SERIAL PRIMARY KEY,
          name varchar(255) NOT NULL,
          slug varchar(255) NULL,
          region geography(MultiPolygon,4326) NOT NULL
      );
    `);
  }

  async down(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query('DROP TABLE IF EXISTS geo_regions;');
  }
}
