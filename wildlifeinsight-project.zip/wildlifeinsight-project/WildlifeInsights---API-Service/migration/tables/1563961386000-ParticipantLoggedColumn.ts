import { MigrationInterface, QueryRunner } from "typeorm";

export class ParticipantLoggedColumn1563961386000 implements MigrationInterface {

    async up(queryRunner: QueryRunner): Promise<any> {
        await queryRunner.query(`
              ALTER TABLE participants 
              ADD COLUMN logged boolean DEFAULT false;
        `);
    }

    async down(queryRunner: QueryRunner): Promise<any> {
        await queryRunner.query(`
            ALTER TABLE participants DROP COLUMN logged;`
        );
    }

}
