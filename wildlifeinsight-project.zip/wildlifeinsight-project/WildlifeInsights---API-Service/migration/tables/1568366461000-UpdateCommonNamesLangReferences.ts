import { MigrationInterface, QueryRunner } from 'typeorm';

export class UpdateCommonNamesLangReferences1568366461000 implements MigrationInterface {
  async up(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`
      UPDATE common_names SET language = 'EN' WHERE language = 'English';
      UPDATE common_names SET language = 'ES' WHERE language = 'Spanish';
      UPDATE common_names SET language = 'FR' WHERE language = 'French';
      ALTER TABLE common_names ADD CONSTRAINT common_names_language_fkey FOREIGN KEY(language) REFERENCES languages(code);
    `);
  }

  async down(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`
      ALTER TABLE common_names DROP CONSTRAINT common_names_language_fkey;
      UPDATE common_names SET language = 'English' WHERE language = 'EN';
      UPDATE common_names SET language = 'Spanish' WHERE language = 'ES';
      UPDATE common_names SET language = 'French' WHERE language = 'FR';
    `);
  }
}
