import { MigrationInterface, QueryRunner } from 'typeorm';

export class MakeCommonNameRemarksNonMandatory1566233833293  implements MigrationInterface {
  async up(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`
      ALTER TABLE common_names ALTER COLUMN remarks DROP NOT NULL;
    `);
  }

  async down(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`
      ALTER TABLE common_names ALTER COLUMN remarks SET NOT NULL;
    `);
  }
}
