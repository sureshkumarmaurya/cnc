import { MigrationInterface, QueryRunner } from 'typeorm';

export class UpdateOrganizationParticipantPivotForeignKey1579614596000 implements MigrationInterface {

  async up(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`
        ALTER TABLE organization_participant_pivot
        DROP CONSTRAINT "FK_af7a443c81d3ebc794fe29dd5f1",
        ADD CONSTRAINT "organization_participant_pivot_pkey"
        FOREIGN KEY (organization_id)
        REFERENCES organizations(id)
        ON DELETE CASCADE;
    `);
  }

  async down(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`
        ALTER TABLE organization_participant_pivot
        DROP CONSTRAINT "organization_participant_pivot_pkey",
        ADD CONSTRAINT "FK_af7a443c81d3ebc794fe29dd5f1"
        FOREIGN KEY (organization_id)
        REFERENCES organizations(id);
    `);
  }
}
