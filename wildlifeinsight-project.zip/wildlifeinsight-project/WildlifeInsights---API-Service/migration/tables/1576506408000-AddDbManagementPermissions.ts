import { MigrationInterface, QueryRunner } from 'typeorm';

export class AddDbManagementPermissions1576506408000  implements MigrationInterface {
  async up(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`
    INSERT INTO permissions(name, slug, description) VALUES
      ('PERFORM DB ADMIN OPERATIONS','db.perform_admin_operations','Perform database admin operations')
      ON CONFLICT DO NOTHING;

    INSERT INTO roles (name, slug) VALUES
      ('DB_OPERATIONS_ADMIN', 'DB_OPERATIONS_ADMIN')
      ON CONFLICT DO NOTHING;

    INSERT INTO roles_permissions_permissions ("rolesId", "permissionsId") VALUES
      (
        (SELECT id FROM roles WHERE slug = 'DB_OPERATIONS_ADMIN'),
        (SELECT id FROM permissions WHERE slug = 'db.perform_admin_operations')
      )
      ON CONFLICT DO NOTHING;
    `);
  }

  async down(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`
        DELETE FROM roles WHERE slug = 'DB_OPERATIONS_ADMIN';
        DELETE FROM permissions WHERE slug = 'db.perform_admin_operations';
    `);
  }
}
