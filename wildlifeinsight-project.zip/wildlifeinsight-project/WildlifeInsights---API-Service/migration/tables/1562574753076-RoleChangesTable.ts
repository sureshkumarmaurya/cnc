import { MigrationInterface, QueryRunner } from 'typeorm';

export class RoleChangesTable1562574753076 implements MigrationInterface {

  async up(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`
      DROP TYPE IF EXISTS role_change_type CASCADE;
      CREATE TYPE role_change_type AS ENUM ('create', 'update', 'delete');
      CREATE TABLE IF NOT EXISTS role_changes (
        id integer PRIMARY KEY NOT NULL,
        participants_id integer NOT NULL references participants(id),
        organizations_id integer references organizations(id),
        initiatives_id integer references initiatives(id),
        projects_id integer references projects(id),
        role_id integer references roles(id),
        change_type role_change_type NOT NULL,
        activation_token varchar(255),
        status varchar(255) NOT NULL,
        change_timestamp timestamp
      );
    `);
  }

  async down(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query('DROP TABLE IF EXISTS role_changes; DROP TYPE IF EXISTS role_change_type;');
  }
}
