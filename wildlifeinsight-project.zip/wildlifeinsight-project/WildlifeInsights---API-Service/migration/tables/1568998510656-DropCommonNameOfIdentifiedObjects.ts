import { MigrationInterface, QueryRunner } from 'typeorm';

export class DropCommonNameOfIdentifiedObjects1568998510656 implements MigrationInterface {
  async up(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`
      ALTER TABLE identified_objects DROP COLUMN IF EXISTS common_name;
    `);
  }

  async down(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`
      ALTER TABLE identified_objects CREATE COLUMN IF NOT EXISTS common_name varchar(255);
    `);
  }
}
