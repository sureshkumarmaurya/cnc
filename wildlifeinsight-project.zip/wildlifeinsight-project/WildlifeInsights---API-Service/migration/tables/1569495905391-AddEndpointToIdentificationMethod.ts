import { MigrationInterface, QueryRunner } from 'typeorm';

export class AddEndpointToIdentificationMethod1569495905391 implements MigrationInterface {

  async up(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`
      ALTER TABLE identification_methods ADD COLUMN endpoint VARCHAR;
    `);
  }

  async down(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`
      ALTER TABLE identification_methods DROP COLUMN IF EXISTS endpoint;
    `);
  }
}
