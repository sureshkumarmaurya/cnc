import { MigrationInterface, QueryRunner } from 'typeorm';

export class AddReferenceUrlField1579163106000 implements MigrationInterface {

  async up(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`
      ALTER TABLE taxonomies
      ADD COLUMN IF NOT EXISTS reference_url text;
    `);
  }

  async down(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`
      ALTER TABLE taxonomies DROP COLUMN IF EXISTS reference_url;
    `);
  }
}
