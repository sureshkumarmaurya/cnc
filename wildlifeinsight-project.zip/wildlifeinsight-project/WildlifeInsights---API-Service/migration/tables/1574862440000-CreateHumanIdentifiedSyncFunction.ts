import { MigrationInterface, QueryRunner } from 'typeorm';

export class CreateHumanIdentifiedSyncFunction1574862440000 implements MigrationInterface {
  async up(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`
        DROP FUNCTION IF EXISTS sync_human_identified_field_from_identifications();
        CREATE FUNCTION sync_human_identified_field_from_identifications() RETURNS void
        AS
        $$
        WITH data_files_with_humans AS
        (SELECT df.id
        FROM data_files df
            JOIN deployments dp ON dp.id = df.deployment_id
            JOIN identification_outputs ioutputs ON ioutputs.data_file_id = df.id
            JOIN identified_objects iobjects ON iobjects.identifications_id = ioutputs.id
            JOIN taxonomies tx ON tx.unique_identifier = iobjects.taxonomies_uuid
        WHERE tx.genus::text = 'Homo'::text)
        UPDATE data_files
        SET human_identified = (
            CASE
                WHEN id IN (SELECT id FROM data_files_with_humans) THEN true
                ELSE false
            END
        );
        $$
        LANGUAGE SQL;
    `);
  }

  async down(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`
        DROP FUNCTION IF EXISTS sync_human_identified_field_from_identifications();
    `);
  }
}
