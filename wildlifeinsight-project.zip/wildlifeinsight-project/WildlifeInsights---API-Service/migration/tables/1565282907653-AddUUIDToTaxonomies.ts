import { MigrationInterface, QueryRunner } from 'typeorm';

/**
 * Create PostGIS extension;
 */
export class AddUUIDToTaxonomies1565282907653 implements MigrationInterface {

  async up(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`
      ALTER TABLE taxonomies ADD COLUMN unique_identifier UUID DEFAULT uuid_generate_v4();
    `);
  }

  async down(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`
      ALTER TABLE taxonomies DROP COLUMN IF EXISTS unique_identifier;
    `);
  }
}
