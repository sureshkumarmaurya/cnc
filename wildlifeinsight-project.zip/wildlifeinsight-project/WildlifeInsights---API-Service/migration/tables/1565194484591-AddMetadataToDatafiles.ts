import { MigrationInterface, QueryRunner } from 'typeorm';

export class AddMetadataToDatafiles1565194484591 implements MigrationInterface { 
  async up(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`
    ALTER TABLE data_files
    ADD COLUMN metadata jsonb;
    `);
  }

  async down(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query('ALTER TABLE data_files DROP COLUMN IF EXISTS metadata;');
  }
}
