import { MigrationInterface, QueryRunner } from 'typeorm';

export class AddOnUpdateCascadeToInitiativeParticipantPivot1581083355000 implements MigrationInterface {
  async up(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`
ALTER TABLE initiative_participant_pivot
  DROP CONSTRAINT IF EXISTS "FK_fa323c0d0179e0ed94f73f2366d",
  DROP CONSTRAINT IF EXISTS "initiative_participant_pivot_initiatives_fkey",
  ADD CONSTRAINT "initiative_participant_pivot_initiatives_fkey"
  FOREIGN KEY (initiative_id)
  REFERENCES initiatives(id)
  ON UPDATE CASCADE
  ON DELETE CASCADE;
    `);
  }

  async down(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`
ALTER TABLE initiative_participant_pivot
  DROP CONSTRAINT IF EXISTS "initiative_participant_pivot_initiatives_fkey",
  DROP CONSTRAINT IF EXISTS "FK_fa323c0d0179e0ed94f73f2366d",
  ADD CONSTRAINT "FK_fa323c0d0179e0ed94f73f2366d"
  FOREIGN KEY (initiative_id)
  REFERENCES initiatives(id);
    `);
  }
}
