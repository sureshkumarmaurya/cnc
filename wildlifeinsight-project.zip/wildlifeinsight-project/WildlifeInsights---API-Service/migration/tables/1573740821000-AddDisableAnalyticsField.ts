import { MigrationInterface, QueryRunner } from 'typeorm';

export class AddDisableAnalyticsField1573740821000 implements MigrationInterface {
  async up(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`
      ALTER TABLE projects
        ADD COLUMN "disable_analytics" BOOLEAN DEFAULT FALSE;
    `);
  }

  async down(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`
      ALTER TABLE projects
        DROP COLUMN IF EXISTS "disable_analytics";
    `);
  }
}
