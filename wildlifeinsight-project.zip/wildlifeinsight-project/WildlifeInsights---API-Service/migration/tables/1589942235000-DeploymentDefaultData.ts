import { MigrationInterface, QueryRunner } from 'typeorm';

/**
 * This migration modifies deployments and devices table in order to apply various validations and correct data for NOT NULLs
 * successfully the data required and JOIN with geo_regions table
 */
export class DeploymentDefaultData1589942235000 implements MigrationInterface {
  async up(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`
    
    UPDATE deployments SET quiet_period = 0 WHERE quiet_period IS NULL;
    UPDATE deployments SET bait_type_id = (select id from bait_types where type_name = 'None') WHERE bait_type_id IS NULL;
    UPDATE deployments SET sensor_orientation = 'Parallel' WHERE sensor_orientation IS NULL;
    UPDATE deployments SET sensor_failure_details = 'Camera Functioning' WHERE sensor_failure_details IS NULL;
    UPDATE deployments SET sensor_height = 'Knee height' WHERE sensor_height IS NULL;
    UPDATE deployments SET metadata = '{"feature_type":["None"]}' WHERE metadata IS NULL;
    UPDATE deployments SET metadata = jsonb_set(metadata, '{feature_type}', '["None"]', TRUE) WHERE metadata->>'feature_type' IS NULL;
    
    ALTER TABLE deployments 
      ALTER COLUMN quiet_period SET NOT NULL,
      ALTER COLUMN quiet_period SET DEFAULT 0,
      ALTER COLUMN bait_type_id SET NOT NULL,
      ALTER COLUMN sensor_orientation SET NOT NULL,
      ALTER COLUMN sensor_orientation SET DEFAULT 'Parallel',
      ALTER COLUMN sensor_failure_details SET NOT NULL,
      ALTER COLUMN sensor_failure_details SET DEFAULT 'Camera Functioning',
      ALTER COLUMN sensor_height SET NOT NULL,
      ALTER COLUMN sensor_height SET DEFAULT 'Knee height',
      ALTER COLUMN metadata SET NOT NULL;
  `);
  }

  async down(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`
    ALTER TABLE deployments 
      ALTER COLUMN quiet_period DROP NOT NULL,
      ALTER COLUMN quiet_period DROP DEFAULT,
      ALTER COLUMN bait_type_id DROP NOT NULL,
      ALTER COLUMN sensor_orientation DROP NOT NULL,
      ALTER COLUMN sensor_orientation DROP DEFAULT,
      ALTER COLUMN sensor_failure_details DROP NOT NULL,
      ALTER COLUMN sensor_failure_details DROP DEFAULT,
      ALTER COLUMN sensor_height DROP NOT NULL,
      ALTER COLUMN sensor_height DROP DEFAULT,
      ALTER COLUMN metadata DROP NOT NULL;
    `);
  }
}
