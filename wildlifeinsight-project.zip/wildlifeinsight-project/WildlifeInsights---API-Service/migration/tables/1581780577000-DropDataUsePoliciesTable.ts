import { MigrationInterface, QueryRunner } from 'typeorm';

export class DropDataUsePoliciesTable1581780577000 implements MigrationInterface {
  async up(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`
ALTER TABLE projects DROP COLUMN IF EXISTS data_use_policies_id;

DROP TABLE IF EXISTS data_use_policies;
    `);
  }

  async down(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`
CREATE TABLE IF NOT EXISTS data_use_policies (
  id serial NOT NULL CONSTRAINT "PK_299c68e9067d7cbdbd6e352590d" PRIMARY KEY,
  license character varying(255) not null CONSTRAINT "UQ_7893b5b9fda31eae41a563a05e6" UNIQUE,
  policy text,
  description text
);

ALTER TABLE projects ADD COLUMN IF NOT EXISTS data_use_policies_id integer;

ALTER TABLE projects
  ADD CONSTRAINT projects_data_use_policies__fk
  FOREIGN KEY (data_use_policies_id)
  REFERENCES data_use_policies(id) ON DELETE SET NULL ON UPDATE CASCADE;
    `);
  }
}
