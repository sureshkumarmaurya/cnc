import { MigrationInterface, QueryRunner } from 'typeorm';

export class DiscoverDownloadsUserDataTable1569841385000 implements MigrationInterface {

  async up(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`
      DROP TABLE IF EXISTS discover_downloads_user_data;

      CREATE TABLE IF NOT EXISTS discover_downloads_user_data (
        id serial PRIMARY KEY,
        downloaded_timestamp timestamp NOT NULL DEFAULT now(),
        name varchar(255) NOT NULL,
        organization varchar(255) NOT NULL,
        email varchar(255) NOT NULL
      );
    `);
  }

  async down(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`
      DROP TABLE IF EXISTS discover_downloads_user_data;
    `);
  }
}
