import { MigrationInterface, QueryRunner } from 'typeorm';

export class LanguagesTable1568365894000 implements MigrationInterface {

  async up(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`
      CREATE TABLE IF NOT EXISTS languages (
        code varchar(2) PRIMARY KEY NOT NULL,
        name varchar(255) NOT NULL
      );
      INSERT INTO languages VALUES ('EN', 'English'), ('ES', 'Spanish'), ('FR', 'French') ON CONFLICT DO NOTHING;
    `);
  }

  async down(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query('DROP TABLE IF EXISTS languages;');
  }
}
