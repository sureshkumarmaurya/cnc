import { MigrationInterface, QueryRunner } from 'typeorm';

export class AddIsImplicitColumnToInitiativeParticipantPivotTable1575883111000 implements MigrationInterface {
  async up(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`
      ALTER TABLE initiative_participant_pivot ADD COLUMN IF NOT EXISTS is_implicit boolean NOT NULL DEFAULT false;
    `);
  }

  async down(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`
      ALTER TABLE initiative_participant_pivot DROP COLUMN IF EXISTS is_implicit;
    `);
  }
}
