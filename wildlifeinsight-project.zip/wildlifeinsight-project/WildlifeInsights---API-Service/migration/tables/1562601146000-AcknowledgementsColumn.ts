import { MigrationInterface, QueryRunner } from "typeorm";

export class AcknowledgementsColumn1562601146000 implements MigrationInterface {

    async up(queryRunner: QueryRunner): Promise<any> {
        await queryRunner.query(`
              ALTER TABLE projects
              RENAME COLUMN acknowledgments TO acknowledgements;
        `);
    }

    async down(queryRunner: QueryRunner): Promise<any> {
        await queryRunner.query(`
              ALTER TABLE projects
              RENAME COLUMN acknowledgements TO acknowledgments;`
	);
    }

}
