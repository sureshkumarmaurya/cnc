import { MigrationInterface, QueryRunner } from 'typeorm';

export class AddNewPermissionsToRoles1568413471000  implements MigrationInterface {
  async up(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`
    INSERT INTO permissions(name, slug, description) VALUES
      ('ADD DEVICE TO DEPLOYMENT','device.add_to_deployment','Add device to deployment')
      ON CONFLICT DO NOTHING;
    INSERT INTO permissions(name, slug, description) VALUES
      ('REMOVE DEVICE FROM DEPLOYMENT','device.remove_from_deployment','Remove device from deployment')
      ON CONFLICT DO NOTHING;
    INSERT INTO permissions(name, slug, description) VALUES
      ('ADD INITIATIVE TO ORGANIZATION','initiative.add_to_organization','Add initiative to organization')
      ON CONFLICT DO NOTHING;
    INSERT INTO permissions(name, slug, description) VALUES
      ('REMOVE INITIATIVE FROM ORGANIZATION','initiative.remove_from_organization','Remove initiative from organization')
      ON CONFLICT DO NOTHING;
    INSERT INTO permissions(name, slug, description) VALUES
      ('ADD PROJECT TO ORGANIZATION','project.add_to_organization','Add project to organization')
      ON CONFLICT DO NOTHING;
    INSERT INTO permissions(name, slug, description) VALUES
      ('REMOVE PROJECT FROM ORGANIZATION','project.remove_from_organization','Remove project from organization')
      ON CONFLICT DO NOTHING;
    INSERT INTO permissions(name, slug, description) VALUES
      ('ACTIVATE PARTICIPANT ACCOUNT','participant.activate_account','Activate participant account')
      ON CONFLICT DO NOTHING;
    `);

    await queryRunner.query(`
    INSERT INTO roles(name, slug, super_admin) VALUES
    ('PARTICIPANT_ADMIN', 'PARTICIPANT_ADMIN', false)
    ON CONFLICT DO NOTHING;
    `);

    await queryRunner.query(`
    INSERT INTO roles_permissions_permissions ("rolesId", "permissionsId") VALUES
    ((SELECT id FROM roles WHERE slug='ORGANIZATION_OWNER'), (SELECT id from permissions where slug='initiative.add_to_organization')),
    ((SELECT id FROM roles WHERE slug='ORGANIZATION_OWNER'), (SELECT id from permissions where slug='initiative.remove_from_organization')),
    ((SELECT id FROM roles WHERE slug='ORGANIZATION_OWNER'), (SELECT id from permissions where slug='project.add_to_organization')),
    ((SELECT id FROM roles WHERE slug='ORGANIZATION_OWNER'), (SELECT id from permissions where slug='project.remove_from_organization')),
    ((SELECT id FROM roles WHERE slug='ORGANIZATION_EDITOR'), (SELECT id from permissions where slug='initiative.add_to_organization')),
    ((SELECT id FROM roles WHERE slug='ORGANIZATION_EDITOR'), (SELECT id from permissions where slug='initiative.remove_from_organization')),
    ((SELECT id FROM roles WHERE slug='ORGANIZATION_EDITOR'), (SELECT id from permissions where slug='project.add_to_organization')),
    ((SELECT id FROM roles WHERE slug='ORGANIZATION_EDITOR'), (SELECT id from permissions where slug='project.remove_from_organization')),
    ((SELECT id FROM roles WHERE slug='PROJECT_OWNER'), (SELECT id from permissions where slug='device.add_to_deployment')),
    ((SELECT id FROM roles WHERE slug='PROJECT_OWNER'), (SELECT id from permissions where slug='device.remove_from_deployment')),
    ((SELECT id FROM roles WHERE slug='PROJECT_EDITOR'), (SELECT id from permissions where slug='device.add_to_deployment')),
    ((SELECT id FROM roles WHERE slug='PROJECT_EDITOR'), (SELECT id from permissions where slug='device.remove_from_deployment')),
    ((SELECT id FROM roles WHERE slug='PARTICIPANT_ADMIN'), (SELECT id from permissions where slug='participant.activate_account'))
    ON CONFLICT DO NOTHING;
    `);
  }

  async down(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`
    DELETE FROM roles_permissions_permissions WHERE
      "rolesId" = (SELECT id FROM roles WHERE name = 'ORGANIZATION_OWNER') AND
      "permissionsId" = (SELECT id FROM permissions WHERE slug = 'project.add_to_organization');
    DELETE FROM roles_permissions_permissions WHERE
      "rolesId" = (SELECT id FROM roles WHERE name = 'ORGANIZATION_OWNER') AND
      "permissionsId" = (SELECT id FROM permissions WHERE slug = 'project.remove_from_organization');
    DELETE FROM roles_permissions_permissions WHERE
      "rolesId" = (SELECT id FROM roles WHERE name = 'ORGANIZATION_OWNER') AND
      "permissionsId" = (SELECT id FROM permissions WHERE slug = 'initiative.add_to_organization');
    DELETE FROM roles_permissions_permissions WHERE
      "rolesId" = (SELECT id FROM roles WHERE name = 'ORGANIZATION_OWNER') AND
      "permissionsId" = (SELECT id FROM permissions WHERE slug = 'initiative.remove_from_organization');
    DELETE FROM roles_permissions_permissions WHERE
      "rolesId" = (SELECT id FROM roles WHERE name = 'ORGANIZATION_EDITOR') AND
      "permissionsId" = (SELECT id FROM permissions WHERE slug = 'project.add_to_organization');
    DELETE FROM roles_permissions_permissions WHERE
      "rolesId" = (SELECT id FROM roles WHERE name = 'ORGANIZATION_EDITOR') AND
      "permissionsId" = (SELECT id FROM permissions WHERE slug = 'project.remove_from_organization');
    DELETE FROM roles_permissions_permissions WHERE
      "rolesId" = (SELECT id FROM roles WHERE name = 'ORGANIZATION_EDITOR') AND
      "permissionsId" = (SELECT id FROM permissions WHERE slug = 'initiative.add_to_organization');
    DELETE FROM roles_permissions_permissions WHERE
      "rolesId" = (SELECT id FROM roles WHERE name = 'ORGANIZATION_EDITOR') AND
      "permissionsId" = (SELECT id FROM permissions WHERE slug = 'initiative.remove_from_organization');
    DELETE FROM roles_permissions_permissions WHERE
      "rolesId" = (SELECT id FROM roles WHERE name = 'PROJECT_OWNER') AND
      "permissionsId" = (SELECT id FROM permissions WHERE slug = 'device.add_to_deployment');
    DELETE FROM roles_permissions_permissions WHERE
      "rolesId" = (SELECT id FROM roles WHERE name = 'PROJECT_OWNER') AND
      "permissionsId" = (SELECT id FROM permissions WHERE slug = 'device.remove_from_deployment');
    DELETE FROM roles_permissions_permissions WHERE
      "rolesId" = (SELECT id FROM roles WHERE name = 'PROJECT_EDITOR') AND
      "permissionsId" = (SELECT id FROM permissions WHERE slug = 'device.add_to_deployment');
    DELETE FROM roles_permissions_permissions WHERE
      "rolesId" = (SELECT id FROM roles WHERE name = 'PROJECT_EDITOR') AND
      "permissionsId" = (SELECT id FROM permissions WHERE slug = 'device.remove_from_deployment');
    DELETE FROM roles_permissions_permissions WHERE
      "rolesId" = (SELECT id FROM roles WHERE name = 'PARTICIPANT_ADMIN') AND
      "permissionsId" = (SELECT id FROM permissions WHERE slug = 'participant.activate_account');
      `);
  }
}
