import { MigrationInterface, QueryRunner } from 'typeorm';

export class UsesACLCacheTable1570181091000 implements MigrationInterface {

  async up(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`
      DROP TABLE IF EXISTS users_acl_cache;
      CREATE TABLE IF NOT EXISTS users_acl_cache  (
        user_id int PRIMARY KEY references participants(id) ON DELETE CASCADE ON UPDATE CASCADE,
        acl json,
        last_changed timestamp
      );
    `);
  }

  async down(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query('DROP TABLE IF EXISTS users_acl_cache;');
  }
}
