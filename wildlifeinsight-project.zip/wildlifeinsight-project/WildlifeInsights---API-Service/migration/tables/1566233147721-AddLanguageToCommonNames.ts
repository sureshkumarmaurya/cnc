import { MigrationInterface, QueryRunner } from 'typeorm';

export class AddLanguageToCommonNames1566233147721  implements MigrationInterface {
  async up(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`
      ALTER TABLE common_names ADD COLUMN IF NOT EXISTS language VARCHAR NOT NULL;
    `);
  }

  async down(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`
      ALTER TABLE common_names DROP COLUMN IF EXISTS language;
    `);
  }
}
