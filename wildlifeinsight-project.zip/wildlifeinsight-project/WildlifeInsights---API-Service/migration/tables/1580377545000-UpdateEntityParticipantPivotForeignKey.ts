import { MigrationInterface, QueryRunner } from 'typeorm';

export class UpdateEntityParticipantPivotForeignKey1580377545000 implements MigrationInterface {

  async up(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`
        ALTER TABLE organization_participant_pivot
        DROP CONSTRAINT IF EXISTS "FK_6e6b2e8f84df86aa17218d07551",
        DROP CONSTRAINT IF EXISTS "organization_participant_pivot_participant_fkey",
        ADD CONSTRAINT "organization_participant_pivot_participant_fkey"
        FOREIGN KEY (participant_id)
        REFERENCES participants(id)
        ON DELETE CASCADE;

        ALTER TABLE initiative_participant_pivot
        DROP CONSTRAINT IF EXISTS "FK_93271fb8a24ebe08cb4c2191336",
        DROP CONSTRAINT IF EXISTS "initiative_participant_pivot_participant_fkey",
        ADD CONSTRAINT "initiative_participant_pivot_participant_fkey"
        FOREIGN KEY (participant_id)
        REFERENCES participants(id)
        ON DELETE CASCADE;

        ALTER TABLE participant_type_project_pivot
        DROP CONSTRAINT IF EXISTS "FK_754154edea8dead104054e90891",
        DROP CONSTRAINT IF EXISTS "project_participant_pivot_participant_fkey",
        ADD CONSTRAINT "project_participant_pivot_participant_fkey"
        FOREIGN KEY (participant_id)
        REFERENCES participants(id)
        ON DELETE CASCADE;
    `);
  }

  async down(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`
        ALTER TABLE organization_participant_pivot
        DROP CONSTRAINT IF EXISTS "organization_participant_pivot_participant_fkey",
        DROP CONSTRAINT IF EXISTS "FK_6e6b2e8f84df86aa17218d07551",
        ADD CONSTRAINT "FK_6e6b2e8f84df86aa17218d07551"
        FOREIGN KEY (participant_id)
        REFERENCES participants(id);

        ALTER TABLE initiative_participant_pivot
        DROP CONSTRAINT IF EXISTS "initiative_participant_pivot_participant_fkey",
        DROP CONSTRAINT IF EXISTS "FK_93271fb8a24ebe08cb4c2191336",
        ADD CONSTRAINT "FK_93271fb8a24ebe08cb4c2191336"
        FOREIGN KEY (participant_id)
        REFERENCES participants(id);

        ALTER TABLE participant_type_project_pivot
        DROP CONSTRAINT IF EXISTS "project_participant_pivot_participant_fkey",
        DROP CONSTRAINT IF EXISTS "FK_754154edea8dead104054e90891",
        ADD CONSTRAINT "FK_754154edea8dead104054e90891"
        FOREIGN KEY (participant_id)
        REFERENCES participants(id);
    `);
  }
}
