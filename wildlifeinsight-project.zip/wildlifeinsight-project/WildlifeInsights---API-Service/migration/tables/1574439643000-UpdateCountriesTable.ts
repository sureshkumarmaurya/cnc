import { MigrationInterface, QueryRunner } from 'typeorm';

/**
 * This migration modifies countries table in order to import
 * successfully the data required and JOIN with geo_regions table
 */
export class UpdateCountriesTable1574439643000 implements MigrationInterface {

  async up(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`
      ALTER TABLE countries ALTER COLUMN max_latitude DROP NOT NULL;
      ALTER TABLE countries ALTER COLUMN min_latitude DROP NOT NULL;
      ALTER TABLE countries ALTER COLUMN max_longitude DROP NOT NULL;
      ALTER TABLE countries ALTER COLUMN min_longitude DROP NOT NULL;

      ALTER TABLE countries ALTER COLUMN bgn_name DROP NOT NULL;
      ALTER TABLE countries ALTER COLUMN bgn_longname DROP NOT NULL;

      ALTER TABLE countries ALTER COLUMN iso3166_a2 TYPE varchar;
      ALTER TABLE countries ALTER COLUMN iso3166_a3 TYPE varchar;

      ALTER TABLE countries ADD COLUMN name VARCHAR NOT NULL;
      ALTER TABLE countries ADD COLUMN official_name VARCHAR;

      ALTER TABLE countries ALTER COLUMN first_order_divisions_id DROP NOT NULL;

      ALTER TABLE countries ADD COLUMN geo_region_id INTEGER REFERENCES geo_regions(id);
      CREATE UNIQUE INDEX countries_geo_regions_idx ON countries(geo_region_id);
    `);
  }

  async down(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`
      ALTER TABLE countries ALTER COLUMN max_latitude SET NOT NULL;
      ALTER TABLE countries ALTER COLUMN min_latitude SET NOT NULL;
      ALTER TABLE countries ALTER COLUMN max_longitude SET NOT NULL;
      ALTER TABLE countries ALTER COLUMN min_longitude SET NOT NULL;

      ALTER TABLE countries ALTER COLUMN bgn_name SET NOT NULL;
      ALTER TABLE countries ALTER COLUMN bgn_longname SET NOT NULL;

      ALTER TABLE countries ALTER COLUMN iso3166_a2 TYPE varchar(10);
      ALTER TABLE countries ALTER COLUMN iso3166_a3 TYPE varchar(10);

      ALTER TABLE countries DROP COLUMN IF EXISTS name;
      ALTER TABLE countries DROP COLUMN IF EXISTS official_name;

      ALTER TABLE countries ALTER COLUMN first_order_divisions_id SET NOT NULL;

      ALTER TABLE countries DROP COLUMN geo_region_id;
    `);
  }

}
