import { MigrationInterface, QueryRunner } from 'typeorm';

/**
 * This migration adds a bunch of indexes that were missing so far but are good
 * to have in order to improve performance of SQL operations.
 *
 * Some delete operations, for example, were taking an inordinate amount of time
 * before adding these indexes.
 */
export class AddIndexesOnSequencesAndIdentificationOutputs1570367058000 implements MigrationInterface {
  async up(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`
        CREATE INDEX identification_outputs__data_files_idx ON identification_outputs(data_file_id);
        CREATE INDEX data_file_sequence__data_file_idx ON data_file_sequence_pivot(data_file_id);
        CREATE INDEX data_file_sequence__sequence_idx ON data_file_sequence_pivot(sequence_id);
    `);
  }

  async down(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`
        DROP INDEX IF EXISTS identification_outputs__data_files_idx;
        DROP INDEX IF EXISTS data_file_sequence__data_file_idx;
        DROP INDEX IF EXISTS data_file_sequence__sequence_idx;
    `);
  }
}
