import { MigrationInterface, QueryRunner } from 'typeorm';

export class AddParticipantWhitelistedField1570362679000 implements MigrationInterface {
  async up(queryRunner: QueryRunner): Promise<any> {
    // add whitelisted field to participants table, for account verification MVP feature
    await queryRunner.query('ALTER TABLE participants ADD COLUMN IF NOT EXISTS whitelisted boolean NOT NULL default false;');
  }

  async down(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query('ALTER TABLE participants DROP COLUMN IF EXISTS whitelisted;');
  }
}
