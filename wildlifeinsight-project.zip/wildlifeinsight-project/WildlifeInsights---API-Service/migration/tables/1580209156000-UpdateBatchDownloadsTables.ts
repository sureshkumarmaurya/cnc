import { MigrationInterface, QueryRunner } from 'typeorm';

export class UpdateBatchDownloadsTables1580209156000 implements MigrationInterface {
  async up(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`
      ALTER TABLE batch_downloads
        DROP COLUMN IF EXISTS include_data_files,
        DROP CONSTRAINT IF EXISTS only_one_entity_type_per_export_job,
        DROP CONSTRAINT IF EXISTS at_most_one_entity_type_per_export_job,
        ADD CONSTRAINT at_most_one_entity_type_per_export_job CHECK (
          (CASE WHEN project_id IS NULL THEN 0 ELSE 1 END) +
          (CASE WHEN initiative_id IS NULL THEN 0 ELSE 1 END) +
          (CASE WHEN organization_id IS NULL THEN 0 ELSE 1 END)
          IN (0, 1)
        );
    `);
  }

  async down(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`
      ALTER TABLE batch_downloads
        ADD COLUMN IF NOT EXISTS include_data_files boolean NOT NULL DEFAULT false,
        DROP CONSTRAINT IF EXISTS at_most_one_entity_type_per_export_job,
        DROP CONSTRAINT IF EXISTS only_one_entity_type_per_export_job,
        ADD CONSTRAINT only_one_entity_type_per_export_job CHECK (
          (CASE WHEN project_id IS NULL THEN 0 ELSE 1 END) +
          (CASE WHEN initiative_id IS NULL THEN 0 ELSE 1 END) +
          (CASE WHEN organization_id IS NULL THEN 0 ELSE 1 END) = 1
        )
      );
    `);
  }
}
