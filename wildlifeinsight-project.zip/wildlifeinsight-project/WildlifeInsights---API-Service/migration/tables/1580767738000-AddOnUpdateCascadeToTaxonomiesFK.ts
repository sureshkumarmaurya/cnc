import { MigrationInterface, QueryRunner } from 'typeorm';

export class AddOnUpdateCascadeToTaxonomiesFK1580767738000 implements MigrationInterface {
  async up(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`
ALTER TABLE taxonomies
  DROP CONSTRAINT IF EXISTS "FK_638e7f65de266a38eacc20101c8",
  DROP CONSTRAINT IF EXISTS taxonomies_iucn_red_list_categories_fkey;

ALTER TABLE taxonomies
  ADD CONSTRAINT taxonomies_iucn_red_list_categories_fkey
  FOREIGN KEY (iucn_category_id)
  REFERENCES iucn_red_list_categories(id)
  ON UPDATE CASCADE;
    `);
  }

  async down(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`
ALTER TABLE taxonomies
  DROP CONSTRAINT IF EXISTS taxonomies_iucn_red_list_categories_fkey,
  DROP CONSTRAINT IF EXISTS "FK_638e7f65de266a38eacc20101c8";

ALTER TABLE taxonomies
  ADD CONSTRAINT "FK_638e7f65de266a38eacc20101c8"
  FOREIGN KEY (iucn_category_id)
  REFERENCES iucn_red_list_categories(id);
    `);
  }
}
