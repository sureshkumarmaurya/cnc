import { MigrationInterface, QueryRunner } from "typeorm";

export class DataFilesHumanIdentifiedColumn1568881544000 implements MigrationInterface {

    async up(queryRunner: QueryRunner): Promise<any> {
        await queryRunner.query(`
              ALTER TABLE data_files 
              ADD COLUMN human_identified boolean DEFAULT false;
        `);
    }

    async down(queryRunner: QueryRunner): Promise<any> {
        await queryRunner.query(`
            ALTER TABLE data_files DROP COLUMN human_identified;`
        );
    }

}
