import { MigrationInterface, QueryRunner } from 'typeorm';

export class AddEntityCascadesFromSubprojects1573565536000 implements MigrationInterface {
  async up(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`
      ALTER TABLE deployments DROP CONSTRAINT IF EXISTS FK_652fbb3d177c95d1e1bde5d545b;
      ALTER TABLE deployments DROP CONSTRAINT IF EXISTS FK_deployments__subprojects;
      ALTER TABLE deployments ADD CONSTRAINT FK_deployments__subprojects FOREIGN KEY (subproject_id) REFERENCES subprojects(id) ON UPDATE CASCADE ON DELETE CASCADE;

      ALTER TABLE subprojects DROP CONSTRAINT IF EXISTS FK_0b12374059ff1c68523c7c4e512;
      ALTER TABLE subprojects DROP CONSTRAINT IF EXISTS FK_subprojects__projects;
      ALTER TABLE subprojects ADD CONSTRAINT FK_subprojects__projects FOREIGN KEY (project_id) REFERENCES projects(id) ON UPDATE CASCADE ON DELETE CASCADE;
    `);
  }

  async down(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`
      ALTER TABLE deployments DROP CONSTRAINT IF EXISTS FK_deployments__subprojects;
      ALTER TABLE deployments DROP CONSTRAINT IF EXISTS FK_652fbb3d177c95d1e1bde5d545b;
      ALTER TABLE deployments ADD CONSTRAINT FK_652fbb3d177c95d1e1bde5d545b FOREIGN KEY (subproject_id) REFERENCES subprojects(id);

      ALTER TABLE subprojects DROP CONSTRAINT IF EXISTS FK_subprojects__projects;
      ALTER TABLE subprojects DROP CONSTRAINT IF EXISTS FK_0b12374059ff1c68523c7c4e512;
      ALTER TABLE subprojects ADD CONSTRAINT FK_0b12374059ff1c68523c7c4e512 FOREIGN KEY (project_id) REFERENCES projects(id);
    `);
  }
}
