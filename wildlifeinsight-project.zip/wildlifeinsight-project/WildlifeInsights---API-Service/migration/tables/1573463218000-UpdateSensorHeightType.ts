import { MigrationInterface, QueryRunner } from 'typeorm';

export class UpdateSensorHeightType1573463218000 implements MigrationInterface {
    async up(queryRunner: QueryRunner): Promise<any> {
        await queryRunner.query(`
        DROP VIEW IF EXISTS deployments_batch_upload_vw;
        
        ALTER TABLE deployments ALTER COLUMN sensor_height TYPE VARCHAR(255);
        
        CREATE VIEW deployments_batch_upload_vw AS
          SELECT dep.projects_id AS project_internal_id,
            dep.id AS deployment_internal_id,
            projects.short_name AS project_id,
            dep.deployment_name AS deployment_id,
            dep.metadata->>'recorded_by' AS recorded_by,
            dep.metadata->>'orientation_other' AS sensor_orientation_other,
            dep.metadata->>'height_other' AS sensor_height_other,
            dep.metadata->>'camera_functioning' AS camera_functioning,
            paired_deployments.name AS placement,
            locations.longitude,
            locations.latitude,
            trunc(locations.longitude::numeric, 1) AS longitude_blurred,
            trunc(locations.latitude::numeric, 1) AS latitude_blurred,
            dep.start_datetime::character varying AS start_date,
            dep.end_datetime::character varying AS end_date,
            bait_types.type_name AS bait_type,
            bait_types.description AS bait_description,
            features.feature_name AS feature_type,
            features.description AS feature_description,
            devices.id AS camera_id,
            dep.quiet_period,
            dep.sensor_height,
            dep.sensor_orientation,
            dep.sensor_sensitivity,
            dep.sensor_failure_details AS camera_failure_details,
            CASE
              WHEN projects.embargo = 0 THEN true
              WHEN projects.embargo IS NULL THEN true
              WHEN now()::timestamp without time zone >= ((( SELECT min(data_files."createdAt") AS min
                FROM data_files
                WHERE data_files.deployment_id = dep.id)) + '1 mon'::interval * projects.embargo::double precision) THEN true
              ELSE false
            END AS embargo_free
          FROM deployments dep
            JOIN locations ON dep.locations_id = locations.id
            LEFT JOIN features ON locations.id = features.locations_id
            LEFT JOIN paired_deployments ON paired_deployments.id = dep.paired_deployments_id
            LEFT JOIN bait_types ON dep.bait_type_id = bait_types.id
            LEFT JOIN projects ON projects.id = dep.projects_id
            LEFT JOIN devices ON dep.device_id = devices.id;
        `);
    }

    async down(queryRunner: QueryRunner): Promise<any> {
        await queryRunner.query(`
        DROP VIEW IF EXISTS deployments_batch_upload_vw;
        
        ALTER TABLE deployments ALTER COLUMN sensor_height TYPE float USING sensor_height::double precision;
        
        CREATE VIEW deployments_batch_upload_vw AS
          SELECT dep.projects_id AS project_internal_id,
            dep.id AS deployment_internal_id,
            projects.short_name AS project_id,
            dep.deployment_name AS deployment_id,
            dep.metadata->>'recorded_by' AS recorded_by,
            dep.metadata->>'orientation_other' AS sensor_orientation_other,
            dep.metadata->>'height_other' AS sensor_height_other,
            dep.metadata->>'camera_functioning' AS camera_functioning,
            paired_deployments.name AS placement,
            locations.longitude,
            locations.latitude,
            trunc(locations.longitude::numeric, 1) AS longitude_blurred,
            trunc(locations.latitude::numeric, 1) AS latitude_blurred,
            dep.start_datetime::character varying AS start_date,
            dep.end_datetime::character varying AS end_date,
            bait_types.type_name AS bait_type,
            bait_types.description AS bait_description,
            features.feature_name AS feature_type,
            features.description AS feature_description,
            devices.id AS camera_id,
            dep.quiet_period,
            dep.sensor_height,
            dep.sensor_orientation,
            dep.sensor_sensitivity,
            dep.sensor_failure_details AS camera_failure_details,
            CASE
              WHEN projects.embargo = 0 THEN true
              WHEN projects.embargo IS NULL THEN true
              WHEN now()::timestamp without time zone >= ((( SELECT min(data_files."createdAt") AS min
                FROM data_files
                WHERE data_files.deployment_id = dep.id)) + '1 mon'::interval * projects.embargo::double precision) THEN true
              ELSE false
            END AS embargo_free
          FROM deployments dep
            JOIN locations ON dep.locations_id = locations.id
            LEFT JOIN features ON locations.id = features.locations_id
            LEFT JOIN paired_deployments ON paired_deployments.id = dep.paired_deployments_id
            LEFT JOIN bait_types ON dep.bait_type_id = bait_types.id
            LEFT JOIN projects ON projects.id = dep.projects_id
            LEFT JOIN devices ON dep.device_id = devices.id;
        `);
    }
}
