import { MigrationInterface, QueryRunner } from 'typeorm';

export class AllowLongerUniqueDataFileIds1585863930000 implements MigrationInterface {
  async up(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`
DROP MATERIALIZED VIEW images_batch_upload_vw;
ALTER TABLE data_files ALTER COLUMN data_file_id TYPE varchar;

CREATE MATERIALIZED VIEW images_batch_upload_vw AS
WITH expert_identification AS (
  SELECT identification_methods.id
    FROM identification_methods
    WHERE identification_methods.type_name::text = 'Expert identification'::text
  )
SELECT nextval('materialized_views_unique_id_seq'::regclass) AS id,
   data_files.id AS image_internal_id,
   data_files.data_file_id AS image_id,
   projects.id AS project_internal_id,
   deployments.id AS deployment_internal_id,
   projects.short_name AS project_id,
   deployments.deployment_name AS deployment_id,
   data_files.filepath,
   projects.slug AS project_slug,
       CASE
           WHEN data_files.status::text = 'BLANK'::text THEN 1
           ELSE 0
       END AS is_blank,
   data_files.metadata ->> 'identified_by'::text AS identified_by,
   taxonomies.unique_identifier AS wi_taxon_id,
   taxonomies.class,
   taxonomies."order",
   taxonomies.family,
   taxonomies.genus,
   taxonomies.species,
   taxonomies.common_name_english AS common_name,
   data_files.metadata ->> 'uncertainty'::text AS uncertainty,
   data_files."timestamp"::character varying AS "timestamp",
   uio.relative_age AS age,
   uio.sex,
   NULL::boolean AS animal_recognizable,
   identified_individuals.name AS individual_id,
   uio.number_of_animals,
   uio.remarks AS individual_animal_notes,
   data_files.highlighted,
   uio.remarks AS color,
   projects.data_files_license AS license
  FROM projects
    JOIN deployments ON projects.id = deployments.projects_id
    JOIN data_files ON deployments.id = data_files.deployment_id
    LEFT JOIN latest_identification_outputs_by_data_file ON data_files.id = latest_identification_outputs_by_data_file.data_file_id
    LEFT JOIN unique_identified_objects_of_identification_outputs uio ON latest_identification_outputs_by_data_file.id = uio.identifications_id
    JOIN taxonomies ON uio.taxonomies_uuid = taxonomies.unique_identifier
    LEFT JOIN identified_individuals ON identified_individuals.identified_animals_id = uio.id
WITH NO DATA;
    `);
  }

  async down(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`
DROP MATERIALIZED VIEW images_batch_upload_vw;
ALTER TABLE data_files ALTER COLUMN data_file_id TYPE varchar(36);

CREATE MATERIALIZED VIEW images_batch_upload_vw AS
WITH expert_identification AS (
  SELECT identification_methods.id
    FROM identification_methods
    WHERE identification_methods.type_name::text = 'Expert identification'::text
  )
SELECT nextval('materialized_views_unique_id_seq'::regclass) AS id,
   data_files.id AS image_internal_id,
   data_files.data_file_id AS image_id,
   projects.id AS project_internal_id,
   deployments.id AS deployment_internal_id,
   projects.short_name AS project_id,
   deployments.deployment_name AS deployment_id,
   data_files.filepath,
   projects.slug AS project_slug,
       CASE
           WHEN data_files.status::text = 'BLANK'::text THEN 1
           ELSE 0
       END AS is_blank,
   data_files.metadata ->> 'identified_by'::text AS identified_by,
   taxonomies.unique_identifier AS wi_taxon_id,
   taxonomies.class,
   taxonomies."order",
   taxonomies.family,
   taxonomies.genus,
   taxonomies.species,
   taxonomies.common_name_english AS common_name,
   data_files.metadata ->> 'uncertainty'::text AS uncertainty,
   data_files."timestamp"::character varying AS "timestamp",
   uio.relative_age AS age,
   uio.sex,
   NULL::boolean AS animal_recognizable,
   identified_individuals.name AS individual_id,
   uio.number_of_animals,
   uio.remarks AS individual_animal_notes,
   data_files.highlighted,
   uio.remarks AS color,
   projects.data_files_license AS license
  FROM projects
    JOIN deployments ON projects.id = deployments.projects_id
    JOIN data_files ON deployments.id = data_files.deployment_id
    LEFT JOIN latest_identification_outputs_by_data_file ON data_files.id = latest_identification_outputs_by_data_file.data_file_id
    LEFT JOIN unique_identified_objects_of_identification_outputs uio ON latest_identification_outputs_by_data_file.id = uio.identifications_id
    JOIN taxonomies ON uio.taxonomies_uuid = taxonomies.unique_identifier
    LEFT JOIN identified_individuals ON identified_individuals.identified_animals_id = uio.id
WITH NO DATA;
    `);
  }
}
