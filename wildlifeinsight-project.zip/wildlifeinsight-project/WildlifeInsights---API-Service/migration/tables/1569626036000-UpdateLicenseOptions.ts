import { MigrationInterface, QueryRunner } from 'typeorm';

export class UpdateLicenseOptions1569626036000 implements MigrationInterface {
  async up(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`
      -- drop view so that we can change column type temporarily
      DROP VIEW IF EXISTS projects_batch_upload_vw;

      ALTER TABLE projects ALTER COLUMN metadata_license TYPE VARCHAR(15);
      ALTER TABLE projects ALTER COLUMN data_files_license TYPE VARCHAR(15);
      UPDATE projects SET metadata_license = 'CC-BY' WHERE metadata_license = 'CC-BY-NC';
      UPDATE projects SET data_files_license = 'CC-BY' WHERE data_files_license = 'CC BY 4.0';
      UPDATE projects SET data_files_license = 'CC-BY-NC' WHERE data_files_license = 'CC BY-NC';

      DROP TYPE IF EXISTS project_metadata_license_enum;
      DROP TYPE IF EXISTS data_file_license_enum;
      CREATE TYPE project_metadata_license_enum AS ENUM('CC0', 'CC-BY');
      CREATE TYPE data_file_license_enum AS ENUM('CC0', 'CC-BY', 'CC-BY-NC');
      ALTER TABLE projects ALTER COLUMN metadata_license TYPE project_metadata_license_enum USING metadata_license::project_metadata_license_enum;
      ALTER TABLE projects ALTER COLUMN data_files_license TYPE data_file_license_enum USING data_files_license::data_file_license_enum;

      CREATE OR REPLACE VIEW projects_batch_upload_vw AS
      SELECT
        id,
        slug,
        name,
        objectives,
        project_url,
        project_status,
        methodology,
        start_date,
        end_date,
        project_credit_line,
        acknowledgements,
        data_citation,
        embargo,
        metadata_license,
        data_files_license
      FROM projects;
    `);
  }

  async down(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`
      -- drop view so that we can change column type temporarily
      DROP VIEW IF EXISTS projects_batch_upload_vw;

      ALTER TABLE projects ALTER COLUMN metadata_license TYPE VARCHAR(15);
      ALTER TABLE projects ALTER COLUMN data_files_license TYPE VARCHAR(15);
      UPDATE projects SET metadata_license = 'CC BY-NC' WHERE metadata_license = 'CC BY 4.0+';
      UPDATE projects SET data_files_license = 'CC BY 4.0+' WHERE data_files_license = 'CC-BY';
      UPDATE projects SET data_files_license = 'CC BY-NC' WHERE data_files_license = 'CC-BY-NC';

      DROP TYPE IF EXISTS project_metadata_license_enum;
      DROP TYPE IF EXISTS data_file_license_enum;
      CREATE TYPE project_metadata_license_enum AS ENUM('CC0', 'CC BY-NC');
      CREATE TYPE data_file_license_enum AS ENUM('CC0', 'CC BY 4.0+', 'CC BY-NC');
      ALTER TABLE projects ALTER COLUMN metadata_license TYPE project_metadata_license_enum USING metadata_license::project_metadata_license_enum;
      ALTER TABLE projects ALTER COLUMN data_files_license TYPE data_file_license_enum USING data_files_license::data_file_license_enum;

      CREATE OR REPLACE VIEW projects_batch_upload_vw AS
      SELECT
        id,
        slug,
        name,
        objectives,
        project_url,
        project_status,
        methodology,
        start_date,
        end_date,
        project_credit_line,
        acknowledgements,
        data_citation,
        embargo,
        metadata_license,
        data_files_license
      FROM projects;
    `);
  }
}
