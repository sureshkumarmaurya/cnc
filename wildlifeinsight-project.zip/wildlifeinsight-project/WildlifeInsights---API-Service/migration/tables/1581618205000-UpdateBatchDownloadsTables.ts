import { MigrationInterface, QueryRunner } from 'typeorm';

export class UpdateBatchDownloadsTables1581618205000 implements MigrationInterface {
  async up(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`
ALTER TABLE discover_downloads_user_data RENAME TO public_download_requests;

ALTER TABLE public_download_requests ADD COLUMN IF NOT EXISTS batch_download_job_id integer;

ALTER TABLE public_download_requests
  DROP CONSTRAINT IF EXISTS public_download_requests_batch_downloads__fk,
  ADD CONSTRAINT public_download_requests_batch_downloads__fk
  FOREIGN KEY (batch_download_job_id)
  REFERENCES batch_downloads(id) ON DELETE SET NULL ON UPDATE CASCADE;

ALTER TABLE batch_downloads ADD COLUMN IF NOT EXISTS projects_in_download_bundle integer[];
    `);
  }

  async down(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`
ALTER TABLE batch_downloads DROP COLUMN IF EXISTS projects_in_download_bundle;

ALTER TABLE public_download_requests DROP COLUMN IF EXISTS batch_download_job_id;

ALTER TABLE public_download_requests RENAME TO discover_downloads_user_data;
    `);
  }
}
