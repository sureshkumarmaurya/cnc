import { MigrationInterface, QueryRunner } from 'typeorm';

export class AddIsImplicitColumnToParticipantTypeProjectsPivotTable1575545349000 implements MigrationInterface {
  async up(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`
      ALTER TABLE participant_type_project_pivot ADD COLUMN IF NOT EXISTS is_implicit boolean NOT NULL DEFAULT false;
    `);
  }

  async down(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`
      ALTER TABLE participant_type_project_pivot DROP COLUMN IF EXISTS is_implicit;
    `);
  }
}
