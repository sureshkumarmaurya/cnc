import { MigrationInterface, QueryRunner } from 'typeorm';

export class AddAgeVerificationToParticipants1566987620000 implements MigrationInterface {

  async up(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`
      DROP TYPE IF EXISTS age_verification;
      CREATE TYPE age_verification AS ENUM (
        'not_verified',
        '13+_self_certified',
        '13+_verified_by_admin'
      );
      ALTER TABLE participants ADD COLUMN age_verification age_verification NOT NULL DEFAULT 'not_verified';
    `);
  }

  async down(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`
      ALTER TABLE participants DROP COLUMN IF EXISTS age_verification;
      DROP TYPE IF EXISTS age_verification;
    `);
  }
}

