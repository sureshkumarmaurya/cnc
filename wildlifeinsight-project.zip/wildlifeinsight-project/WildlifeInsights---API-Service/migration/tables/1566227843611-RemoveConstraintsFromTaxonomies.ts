import { MigrationInterface, QueryRunner } from 'typeorm';

export class RemoveConstraintsFromTaxonomies1566227843611 implements MigrationInterface {
  async up(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`
      ALTER TABLE taxonomies ALTER COLUMN "family" DROP NOT NULL;
      ALTER TABLE taxonomies ALTER COLUMN "class" DROP NOT NULL;
      ALTER TABLE taxonomies ALTER COLUMN "order" DROP NOT NULL;
    `);
  }

  async down(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`
    ALTER TABLE taxonomies ALTER COLUMN "family" TYPE character varying(255) SET NOT NULL;
    ALTER TABLE taxonomies ALTER COLUMN "class" TYPE character varying(255) SET NOT NULL;
    ALTER TABLE taxonomies ALTER COLUMN "order" TYPE character varying(255) SET NOT NULL;
    `);
  }
}
