import { MigrationInterface, QueryRunner } from 'typeorm';

export class AddTaxonomyType1566384634572 implements MigrationInterface {
  async up(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`
      ALTER TABLE taxonomies ADD COLUMN IF NOT EXISTS taxonomy_type VARCHAR NOT NULL DEFAULT 'biological';
    `);
  }

  async down(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`
      ALTER TABLE taxonomies DROP COLUMN IF EXISTS taxonomy_type;
    `);
  }
}
