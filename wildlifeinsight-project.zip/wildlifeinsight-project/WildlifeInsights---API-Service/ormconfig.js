module.exports = {
    url: process.env.POSTGRES_URL,
    entities: [
        __dirname + '/src/modules/database/entities/*.entity.ts',
    ],
    migrations: [__dirname + '/../../../migration/**/*.ts',],
    synchronize: false,
    migrationsRun: true,
    logging: true,
    cache: false
}