# Changelog

## v0.8.2 - 2020-06-05

### Added
* `decimal-validator.ts` has been added for longitude and latitude validations.
  * Check for atleast four and max eight decimal digits is added.
  * Same validator is used in validating public location for Projects.
* `lat-long.ts` has been added for adding decimal zeros.
  * Utility function is added to handle latitude and longitude with zeros after decimal place.
* Added `metaProperty.ts` custom validator to validate `feature_type` in metadata for deployment
* Added `1589942235000-DeploymentDefaultData.ts` migration to implement NOT NULL and Default value constraints
  as well as updation of current data

### Changed
* `create-location.dto.ts` has been updated to support two new fields for logitude and latitude.
  * Two new fields for longitude and latitude are added to support minimum 4 decimal places.
  * Both new fields added are string, to avoid auto removal of decimal zeros.
  * New fields added are with names: latitudeStr and longitudeStr.
  * Validation for minimum 4 decimals and maximum 8 decimal is added in new fields.
  * Old fields latitude and longitude are still optional but deprecated.
  * placename field is made mandatory.
* `update-location.dto.ts` has been updated to support two new fields for logitude and latitude.
  * Two new fields for longitude and latitude are added to support minimum 4 decimal places.
  * Both new fields added are string, to avoid auto removal of decimal zeros.
  * New fields added are with names: latitudeStr and longitudeStr.
  * Validation for minimum 4 decimals and maximum 8 decimal is added in new fields.
  * Old fields latitude and longitude are still optional but deprecated.
  * placename field is made mandatory.
* `locations.dto.ts` has been updated for converting numeric fields to string.
  * Added conversion of numeric logitude and latitude to string and populating the new fields.
* `location.service.ts` has been updated to support new fields.
  * File is updated to populate values from new fields to old fields present in entity file.
  * Code to convert string value of longitude and latitude into numeric value is added before saving it in DB
  * Conversion code for converting numeric value to String value while retriving location from the DB is also added.
  * Code is also added in update service for conversion.
  * New check is added to find only allow adding new location name for a given project.
* `location.types.graphql` has been updated to add new fields.
  * Two new fields longitudeStr and latitudeStr are added.
  * Both fileds are made mandatory on the service layer.
  * Field placename is made mandatory.
* `create-project.dto.ts` has been updated to support two new fields for longitude and latitude.
  * Two new fields for longitude and latitude are added to support minimum 4 decimal places.
  * Both new fields added are string, to avoid auto removal of decimal zeros.
  * New fields added are with names: publicLatitudeStr and publicLongitudeStr.
  * Validation for minimum 4 decimals and maximum 8 decimal is added in new fields.
  * Old fields publicLatitude and publicLongitude are still optional but deprecated.
* `update-project.dto.ts` has been updated to support two new field for longitude and latitude.
  * Two new fields for longitude and latitude is added to support minimum 4 decimal places.
  * Both new fields added are string, to avoid auto removal of decimal zeros.
  * New fields added are with names: publicLatitudeStr and publicLongitudeStr.
  * Validation for minimum 4 decimals and maximum 8 decimal is added in new fields.
  * Old fields publicLatitude and publicLongitude are still optional but deprecated.
* `projects.dto.ts` has been updated to add code to convert numeric values to String values.
  * Added conversion of numeric logitude and latitude to string and populating the new fields.
* `project.service.ts` has been updated to support new fields added in the DTO files.
  * File is updated to populate values from new fields to old fields present in entity file.
  * Code to convert string value of longitude and latitude into numeric value is added before saving it in DB
  * Conversion code for converting numeric value to String value while retriving location from the DB is also added.
  * Code is also added in update service for conversion.
* `project.types.graphql` has been updated to add new fields.
  * Two new fields publicLongitudeStr and publicLatitudeStr is added.
  * Both fileds are made mandatory on the service layer.
* `sensorHeight, quietPeriod, sensorOrientation, sensorFailureDetails, startDatetime, endDatetime,
  deviceId, baitTypeName, metadata` updated to be mandatory fields in `deployment.types.graphql`, `create-deployment.dto.ts` and `update-deployment.dto.ts` files at API level
* Default values for certain suggested fields, at DB level, along with NOT NULL constraints:
  * `quietPeriod` = `0`
  * `sensor_orientation` = `Parallel`
  * `sensor_failure_details` = `Camera Functioning`
  * `sensor_height ` = `Knee height`

### Fixed

* Project creation fails while fetching participant type. In where clause property name shoule be `typeName`.

### Deprecated

* longitude and latitude fields are deprecated in all locations dto.
* publicLongitude and publicLatitude fields are deprecated in all projects dto.

### Removed


## v0.8.1 - unreleased

### Added

### Changed

* `science_data_vw` has been updated ([#69814957](https://www.pivotaltracker.com/story/show/169814957)):
  * this is now a materialized view for performance reasons
  * it also includes fields which have been recently added to the list of
    desirable ones to have
  * it also includes `initiative_id` and `initiative_name` for projects which
    are part of an initiative, to allow for initiative-level analytics to be
    added
  * and no filters are applied to the view anymore - all data files with
    identifications is included
  * data files with multiple unique identifications are now represented as
    multiple rows, each with unique identification data
  * `wi_taxa_id` is set to the UUID of each taxonomy
  * `number_of_animals` is correctly set for multiple animals of the same
    species (and other matching unique attributes)
  * TypeORM logging for the API's db connection is now configurable via config,
    and defaulting to false
* update staging deployment manifest to make the Cloud SQL Proxy containers to
  proxy to a new Cloud SQL instance
* update production deployment manifest to make the Cloud SQL Proxy containers
  to proxy to a new Cloud SQL instance
* Batch uploads jobs metadata now includes the id of the user who submitted the
  job (this can be changed later via `PATCH`)
  ([#172504301](https://www.pivotaltracker.com/story/show/172504301)).
* Initial owner of projects created via batch uploads is now set to the user
  associated to the batch uploads job itself
  ([#172504301](https://www.pivotaltracker.com/story/show/172504301)).
* Update blank/notblank filter to match latest spec
  ([#169944701](https://www.pivotaltracker.com/story/show/169944701)) and to
  only take into account the *latest* identification (as done for the species
  filter: see fix for #170884856 in the "Fixed" section of this release).
* New materialized view: `latest_identification_outputs` (same as existing view
  `latest_identification_outputs_by_data_file`, but materialized and using a CTE
  for the joined data)
  ([#172857697](https://www.pivotaltracker.com/story/show/172857697)).
* `projects_operational_analytics_vw` now relies on
  `latest_identification_outputs` to avoid reporting duplicate data
  ([#172857753](https://www.pivotaltracker.com/story/show/172857753)).

### Fixed

* When the `projects.disable_analytics` field was repurposed to (also) hide
  projects from the Explore map, this was done directly in the db as it had been
  requested urgently, but a migration was not created to make the change
  permanent; later migrations that included changes to the
  `discover_projects_vw` materialized view basically undid the change that had
  been hot-applied. This is now fixed with a new migration that adds the
  filtering of projects whose `projects.disable_analytics` field is set to true
  on top of the most recent version of the `discover_projects_vw` materialized
  view.
* When truncating a project's `shortName` during project creation, no check was
  done on whether this field was defined, leading to a failure of the operation;
  this is now fixed.
* When bulked identified, photos are not moved to the “Catalogued” tab.
  ([#171862038](https://www.pivotaltracker.com/story/show/171862038)).
* batch upload job status is set to `IMAGE_INGESTION_STARTED` just before
  starting triggering the `move_data_files` cloud function rather than once all
  the cloud function instances have been triggered, as this can take longer than
  the interval between checks of the job status done by Airflow.
* the type of the `data_files.data_file_id` column was set to `varchar(36)`,
  which accommodates a UUID just fine; however, when the value for this field is
  not auto-generated but set from the unique id of an image being imported via
  batch uploads, the length of this id can be much longer; the length limit has
  now been fully lifted (the type is now `text`).
* When trying to figure out whether camera's year of purchase is a year or a
  YYYY-MM-DD date, an incorrect regexp pattern was causing `-01-01` (for 1st of
  January) to be *always* appended to the year, even if this was in fact a
  YYYY-MM-DD date. This has now been fixed.
* When resolving properties of Deployments, if the relevant foreign key of the
  `deployments` entity was null, the first value of the relevant db table would
  be returned. This has now been fixed
  ([#171731225](https://www.pivotaltracker.com/story/show/171731225)).
* Debug output from CLI scripts that take care of importing projects/deployments
  and data files could cause each of these two steps to fail to complete for
  large projects, where the amount of output would be larged than what stdout
  could handle. This has now been fixed
  ([#172551014](https://www.pivotaltracker.com/story/show/172551014)).
* `/api/v1/batch-uploads/create-deployments` endpoint: execute CLI script
  asynchronously as sync execution may not complete within the time allowed by
  the reverse proxy, for large projects.
* When filtering data files by taxonomy of identified objects, all the
  taxonomies of objects identified in any identification output associated to an
  image were considered, leading to incorrect results being returned for data
  files whose identifications had been edited at least once. This is now fixed
  ([#170884856](https://www.pivotaltracker.com/story/show/170884856)).
* Images without an associated taxonomy (typically blanks or images that have
  not been identified even by the CV system) were not included in `images.csv`
  of download bundles; this is now fixed
  ([#173071375](https://www.pivotaltracker.com/story/show/173071375)).
* Images that have been last identified by a person via the web client did not
  get the `identified_by` field set on data export; this is now fixed
  ([#171988887](https://www.pivotaltracker.com/story/show/171988887)).

### Deprecated

### Removed


## v0.8.0 - 2020-02-28

### Added

* URL of placeholder image that is displayed for data files that have been
  deleted (when humans are identified in them in projects that are set up to
  delete such images) now references the final artwork as served off the
  frontend app service. Configuration of the URL to be used has been split per
  environment (default for local/dev environment, staging and production)
  ([#170237849](https://www.pivotaltracker.com/story/show/170237849)).

* A new field `dataFileId` has been added to the `DataFiles` entity. This is
  used to store the unique id of each data file which is provided in the
  `images.csv` file of batch uploads bundles. This is used to ensure full
  traceability of each data file imported via the batch uploads workflow. When
  adding data files via the API (rather than through the batch uploads workflow)
  this field is set by default to a UUIDv4, although in this scenario there is
  currently no expectation to use this randomly-generated identifier. This same
  PR adds a `originalLocationUrl` field to the same `DataFiles` entity, which
  again is used only in the batch uploads scenario and set to the URL of the
  source blob that is being imported
  ([#170902483](https://www.pivotaltracker.com/story/show/170902483)).

* New GraphQL mutation to delete users. This is only available to platform
  admins with the specific role `PARTICIPANT_ADMIN`, and is meant to be used
  mainly to delete users who signed up for an account but who cannot be
  whitelisted
  ([#170796211](https://www.pivotaltracker.com/story/show/170796211)).

* New field: `Projects.privacy`. This is a NULLable field in the db, using an
  enum type (`project_privacy`). The enum initially only includes the value
  `always` and this value of the field is meant to be used to exclude projects
  from the Explore interface altogether. This field will eventually replace the
  one we currently use to signal this (`Projects.disableAnalytics`): this field
  should of course only be used to signal that science data analytics for a
  project should not be calculated, but it has been temporarily hijacked to also
  provide a quick way to exclude projects until this feature is complete
  ([#170364935](https://www.pivotaltracker.com/story/show/170364935)).

* Expand refresh GCP reader members logic to organizations and initiatives
  ([#171166735](https://www.pivotaltracker.com/n/projects/2185366/stories/171166735)).

### Changed

* Add unique index to all the materialized views that are expensive to refresh,
  using a synthetic value (from a sequence). This allows to refresh these
  materialized views `CONCURRENTLY`. At the same time, these views are now
  created `WITH NO DATA`, in order to speed up migrations
  ([#170235498](https://www.pivotaltracker.com/story/show/170235498)).

* Add support for multiple identifications per image
  ([#170796716](https://www.pivotaltracker.com/story/show/170796716)).
  The existing data import code could already handle this, but in practice could
  only read one identification per image, as this is what was being provided by
  the validator service in its output payload. This change removes the technical
  debt that had been put in place to work around the shape of data being provided
  so far by the validator.

* Character limits on `Project.name` and `Project.shortName` are being enforced
  at the API level, both for batch uploads and for projects created via the API
  ([#169448943](https://www.pivotaltracker.com/story/show/169448943)).

* Refactoring of the batch downloads module to remove inconsistencies and
  technical debt:

  * The API endpoint that is used to trigger the creation of a new public global
    download bundle now returns the status of the latest valid bundle creation
    request, similarly to what is done in the endpoint to trigger creation of
    per-user, per-entity (organization, initiative or project) private download
    bundles
    ([#170846104](https://www.pivotaltracker.com/n/projects/2185366/stories/170846104))

  * Orthogonal concerns have been fully decoupled:
    * request to generate a bundle
    * request to download a bundle
    * public vs private downloads
    * global downloads as a distinct concern from public downloads (this also
      paves the way for the possible implementation of project-level public
      downloads in the future)

  * Authenticated requests for download bundles (whether via the GraphQL or the
    REST APIs) can now *force* the generation of a fresh bundle even if one
    matching the bundle being requested already exists and is still within the
    configured validity timeframe

  * Generation of public download bundles is now handled through a CLI script,
    therefore leaving the asynchronous scheduling of these tasks to the
    operating system

  * Batch download jobs now include (in the metadata persisted to database) a
    list of the projects whose data is being exported; this is used to simplify
    the way `ProjectExporter.export()` is invoked, which in turn makes it simple
    to wrap this function in the CLI script described above

  * The `ProjectExporter` class has been updated to avoid duplication of code

  * Documentation for the whole batch downloads feature has been updated and
    improved

* Delete DataUsePolicies module, as this is not needed anymore
  ([#168116486](https://www.pivotaltracker.com/story/show/168116486)).

* Delete code that was used to set up cloud functions and cloud build triggers
  for parts of the original Computer Vision workflow, which has lately been
  replaced with a single cloud function that uses AI Platform for predictions
  ([#171406967](https://www.pivotaltracker.com/story/show/171406967)).

* Apply feedback for CSV public downloads
  ([#170796517](https://www.pivotaltracker.com/story/show/170796517)).

* Update status of batch download jobs at the end of the task that creates
  projects and deployments (this was already implemented, but the relevant code
  was updating the wrong db field) and at the end of the task that creates data
  file metadata and queues binary blobs for ingestion.

* The CLI script that takes care of image ingestion is now run asynchronously,
  as it can easily take more than the API can keep the connection with the
  client open.

* User and developer documentation for the batch uploads process has been fully
  reviewed and updated to match the current functionality of the batch uploads
  process ([#169675830](https://www.pivotaltracker.com/story/show/169675830)).

* Add new field `data_files.identified_by_expert` to simplify data files
  classification under `Identify` and `Catalogued` sections. All related
  code has been modified: when a new identification output is created or
  removed. To update all previous records with the correct value for the new
  field a SQL query has been documented [here](/docs/README_database-notes.md).

### Fixed

* Passing lat/lon/country metadata from data file service to the cloud function
  that dispatches prediction requests to AI Platform had been prepared long ago,
  but part of the wiring to effectively enable this was missing. This is now
  fully enabled.
  ([#170879254](https://www.pivotaltracker.com/story/show/170879254))

* A missing route in the configuration of the pagination middleware for the
  `DeploymentModule` was preventing `GET /api/v1/deployment` from working. This
  has now been fixed
  ([#168116501](https://www.pivotaltracker.com/story/show/168116501)).

* The `GenericService.findAll()` function's signature signals that the `info`
  parameter is optional, but in practice relies on it not to be undefined. This
  change keeps the parameter as optional while setting one of its members in a
  way that doesn't trigger an error if `info` is undefined to start with. This
  change also incidentally fixes
  [#168116542](https://www.pivotaltracker.com/story/show/168116542).

* Fix a regression in private downloads for initiatives and organizations
  ([#170846500](https://www.pivotaltracker.com/n/projects/2185366/stories/170846500)).

* A missing `ON DELETE CASCADE` was preventing deletion of initiatives from
  being completed successfully. This has now been fixed
  ([#167950826](https://www.pivotaltracker.com/story/show/167950826)).

* When deleting deployments, a wrong bucket name was assembled because the
  project id (rather than its slug) was passed to the function that deletes a
  deployment's assets from storage bucket before deleting the deployment's
  metadata from the database. This has now been fixed
  ([#168116531](https://www.pivotaltracker.com/story/show/168116531)).

* The `DataFile.humanIdentified` field was not correctly set when attaching
  identifications to a data file via the API (or updating existing ones). This
  is now fixed
  ([#170345909](https://www.pivotaltracker.com/story/show/170345909)).

* Add participant email to `BatchDownloadJob` object necessary to try add the
  user to project's GCP bucket reader member custom role.
  ([#171363988](https://www.pivotaltracker.com/n/projects/2185366/stories/171363988)).

* Changed how we check if the user has permission to modify the `highlighted`
  field of data files. Users with `DATA_FILE_UPDATE` permission on a project can
  now highlight data files belonging to the project
  ([#171086032](https://www.pivotaltracker.com/n/projects/2185366/stories/171086032)).

* Bypass setting of `humanIdentified` flag within a TypeORM entity listener
  for `IdentificationOutput`s for new data files, because the parent data file
  will not be persisted to database yet. Instead, the `humanIdentified` field
  is set during the creation of the data file itself.

## v0.7.0 - 2020-01-23

### Added

* Implicit project roles are now managed as actual project roles persisted to
  db, rather than calculated at runtime. The earlier implementation based on
  runtime calculation had several shortcomings, which the new 'materialized'
  implementation fixes
  ([#169915759](https://www.pivotaltracker.com/story/show/169915759)).

* Package image blobs for data downloads
  ([#167895999](https://www.pivotaltracker.com/n/projects/2185366/stories/167895999)).

* When refusing to delete a data file uploaded more than 7200 seconds earlier,
  an error message is added to the 400 status returned by the API, to clarify
  why the request for deletion has been rejected.

* Added new PostgreSQL sequence `materialized_views_unique_id_seq` to be
  used for unique columns in materialized views.

* Added unique column to `images_batch_upload_vw` view to make it possible
  to refresh the view `CONCURRENTLY`.

* New column of type `text` in the `taxonomies` table: `reference_url`. This is
  meant to be used to help identify where the taxonomic authority/common names
  for a taxonomy entries comes from
  ([#170735126](https://www.pivotaltracker.com/n/projects/2185366/stories/170735126)).

### Changed

* `getIdentificationOutputs` GraphQL query now allows to retrieve identification
  outputs for a list of data files at once; the previous implementation only
  allowed to retrieve these for one data file at a time, forcing the frontend to
  issue potentially large numbers of requests when dealing with large bursts
  ([#170725060](https://www.pivotaltracker.com/story/show/170725060), and see
  [#168402113](https://www.pivotaltracker.com/story/show/168402113) for
  rationale).

* Generation of public download bundles is now done asynchronously
  ([#170768492](https://www.pivotaltracker.com/n/projects/2185366/stories/170768492)).

* `API_OPERATIONS_ADMIN` role is now required to trigger the creation of a
  global download bundle via REST (`/api/v1/batch-downloads/all-platform-data`),
  as a mitigation of possible attacks aimed at exhausting resources
  ([#170774362](https://www.pivotaltracker.com/story/show/170774362)).

### Fixed

* The Swagger doctype hack introduced in
  c9005ab5a4145c835507a10dbc19b539d23c8380 would break validation of the API
  definition in general, because of the invalid `openapi: "2.0"` doctype (for
  example, the Swagger documentation renderer embedded in the API service).
  This change reverts the commit above.

* Fix a bug that prevented data files from being deleted even within the allowed
  timeframe, when identifications without genus or species data were attached to
  the data file
  ([#170206460](https://www.pivotaltracker.com/story/show/170206460)).

* When an image has both expert and CV identifications, discard the CV ones when
  populating the `images_batch_upload_vw` materialized view
  ([#170071214](https://www.pivotaltracker.com/story/show/170071214)).

* When importing projects via batch uploads, set deployment location country
  by first trying to reverse geocode the location's coordinates, and if this
  fails, by using the country code of the deployment's parent project
  ([#169018659](https://www.pivotaltracker.com/n/projects/2185366/stories/169018659)).

* Computation of which roles can be changed and revoked by the currently
  logged-in user on a given entity was not correct in several cases: this has
  now been fixed and reviewed
  ([#168503378](https://www.pivotaltracker.com/n/projects/2185366/stories/168503378)).

* During batch import, the `status` flag of data files was being set to `BLANK`
  even for images that had identifications. This has now been fixed
  ([#168967245](https://www.pivotaltracker.com/story/show/168967245)).

* Deployments DTO was not marking the `locationId` field as required; this has
  now been fixed
  ([#168116570](https://www.pivotaltracker.com/story/show/168116570)).

* Deleting an "empty" organization (i.e. an organization which is not ancestor
  of any initiatives or projects) used to fail because of a missing cascade
  deletion of all the relevant roles in `organization_participant_pivot`. This
  is now fixed
  ([#168116597](https://www.pivotaltracker.com/story/show/168116597)).
  Deleting organizations which are not "empty" in the sense outlined above is
  still not allowed: such operations are rejected with a more informative error
  message than what the API used to return to the client.

* Fixed a bug in the precedence of routes in controller for batch downloads
  ([#170841815](https://www.pivotaltracker.com/story/show/170841815)).

* Create, update and delete operations (via GraphQL or REST APIs) on `BaitTypes`
  are now correctly protected by permissions guards. As `BaitTypes` are
  basically a static set (defined in the Wildlife Insights data dictionary),
  these operations are available only to admin users with `API_OPERATIONS_ADMIN`
  role.

## v0.6.0 - 2019-12-06

### Added

* New GraphQL query to search within taxonomies used within a given
  organization, initiative or project
  ([#169653775](https://www.pivotaltracker.com/story/show/169653775)).

* New GraphQL mutation to manage the `whitelisted` status of users
  ([#168116970](https://www.pivotaltracker.com/n/projects/2185366/stories/168116970)).

* New GraphQL query to reverse geocode from coordinates to countries
  ([#169652953](https://www.pivotaltracker.com/n/projects/2185366/stories/169652953)).

* New GraphQL query, only available to users with `PARTICIPANT_ADMIN` generic
  role, to retrieve lists of participants. This will be used initially by the
  admin section of the frontend app that allows participant admins to whitelist
  new participants
  ([#169974733](https://www.pivotaltracker.com/story/show/169974733)).

* Developer documentation of API Service data security features: human
  obfuscation and blurring of location of sensitive species.

* When batch uploading images, set `data_files.human_identified` flag on each
  data file according to whether humans have been identified.

* During batch uploads, `identificationOutputs` are associated with a data
  import bot user
  ([#169235589](https://www.pivotaltracker.com/story/show/169235589)).

* The current user's data as returned by the `getParticipantData` query now
  includes the user's "generic" role and associated information (slug,
  permissions)
  ([#170183871](https://www.pivotaltracker.com/story/show/170183871)).

* A new REST API endpoint, available only to users with general role
  `DB_OPERATIONS_ADMIN`, allows to trigger database operations such as
  refreshing materialized views and running PostgreSQL functions
  ([#167316399](https://www.pivotaltracker.com/story/show/167316399)).

### Changed

* Hack JSON Swagger document to use `openapi: "2.0"` as doctype instead of
  `swagger: "2.0"` as hardcoded in the NestJS Swagger module.

* Store deployment feature from batch upload data as
  `deployments.metadata.feature_type[0]`
  ([#169757483](https://www.pivotaltracker.com/story/show/169757483)).

### Fixed

* Fixed missing logo/photo id on `deleteInitiativePartnersLogoList`,
  `deleteInitiativePhotoList`, `updateInitiativeLogo` mutations, which was
  removed by mistake while adding checking of permissions on these mutations
  ([#168165580](https://www.pivotaltracker.com/story/show/168165580)).

* When importing data files via the batch uploads workflow, identifications of
  non-wildlife and non-human entities were erroneously dropped; this release
  include a fix for this
  ([#170100047](https://www.pivotaltracker.com/story/show/170100047)).

* Users who don't have any roles on the parent organization of a project were
  able to see data of the cameras of a project's deployments, while this should
  not be allowed according to the permissions matrix. This release includes a
  fix for this
  ([#167787427](https://www.pivotaltracker.com/story/show/167787427)).

## v0.5.0 - 2019-11-21

### Added

* Allow user to download Discover data
  ([#168474322](https://www.pivotaltracker.com/n/projects/2185366/stories/168474322)).

* `getDiscoverData` results are now cached for a configurable time (currently
  one hour), making recurring queries almost instantaneous.

* Data files with humans identified (whether by CV or expert identifications)
  are only visible to project owners
  ([#168278369](https://www.pivotaltracker.com/story/show/168278369)).

* Data files with humans identified are deleted (including their associated main
  and thumbnail blobs on storage buckets) once the identification has been
  verified by a user with suitable rights, for projects that choose to delete
  data files with humans
  ([#168278369](https://www.pivotaltracker.com/story/show/168278369)).

* Add `tsc` step to pre-commit ghook.

* Add support for setting and getting more fields when creating/updating/getting
  deployments
  ([#169449811](https://www.pivotaltracker.com/n/projects/2185366/stories/169449811)).

* Cloud function for CV is now invoked with extra metadata: lat/lon and country.

* Add support for storing key-value data in the JSONB `metadata` field of
  `data_files` and `deployments` entities.

* Location features can now be set and queried, via `create|update|getLocation`
  GraphQL mutation and queries.

* Add a new attribute to the project model to store if the user wants to disable its analysis
  ([#169654019](https://www.pivotaltracker.com/n/projects/2185366/stories/169654019)).

* Add support for implicit permissions: users with roles on a project's parent
  initiative or organization should implicitly be granted some specific
  permissions on the project, even if they don't have any explicit roles on the
  project itself
  ([#167840888](https://www.pivotaltracker.com/story/show/167840888)).

* Add ability to filter by project id through getDiscoverData
  ([#169810369](https://www.pivotaltracker.com/n/projects/2185366/stories/169810369)).

* Add ability to specify a 'public location' for a project: if both
  `projects.public_latitude` and `projects.public_longitude` are defined, these
  are used as the project's location in the `getDiscoverData` query, instead of
  the calculated blurred centroid of the project's deployment locations.

### Changed

* Update query strategies to fetch results for `getDiscoverData`, leading to a
  ~8x improvement in query times.

* New Relic integration.

* Timespan filter for discover interface (in `getDiscoverFilters`) now returns
  `1990-01-01` as lower bound and today's date as upper bound
  ([#169236956](https://www.pivotaltracker.com/story/show/169236956)).

* `getAnalytics` query ignores `organizationId` and `initiativeId` if a
  `projectId` is provided, and ignores `organizationId` if an `initiativeId` is
  provided. Basically only the id of the 'smallest' entity type is used, if more
  than one entity type's id is provided in the query parameters. Behaviour is
  unchanged if no entity types' ids are provided (we calculate global statistics
  for all the projects the user has access to).

* `getAnalytics` and `getAnalyticsPublic` GraphQL queries: `imagesPerSpecies`
  and `imagesPerLocation` now return results sorted by number of matching
  images, descending
  ([#169510196](https://www.pivotaltracker.com/story/show/169510196)).

* Generation of batch download bundles is now using streams. This massively
  reduces memory usage, and results in faster bundle preparation times (~50% in
  a dev enviroment).

* Enforce uniqueness  *lower-case* email addresses for the
  `participants.email` db field
  ([#169138892](https://www.pivotaltracker.com/story/show/169138892)).

* Photos that have been highlighted but contain humans (whether identified by CV
  or by expert identification) are excluded from the view that feeds results to
  the `getProjectHighlightedPhotos` GraphQL query
  ([#168279153](https://www.pivotaltracker.com/story/show/168279153))

* Projects returned by `getDiscoverData` now include the project's `slug` field
  ([#169836441](https://www.pivotaltracker.com/story/show/169836441)).

### Fixed

* Do not return human taxonomies in imagesPerSpecies array of getAnalyticsPublic
  ([#168968025](https://www.pivotaltracker.com/n/projects/2185366/stories/168968025)).

* Download CSV fixes
  ([#169042850](https://www.pivotaltracker.com/n/projects/2185366/stories/169042850)).

* Operational analytics queries: counts of human images and of wildlife images
  were returning the counts of *identifications*: these now return the counts
  of *images*.

* Correctly handle counting sampling days when resultset of projects, given
  applied filters, is zero (closes
  [#169394198](https://www.pivotaltracker.com/story/show/169394198)).

* Correctly handle deployment start and end date in batch uploads
  ([#169505936](https://www.pivotaltracker.com/story/show/169505936)).

* Correctly handle genus/species matching for taxonomy entries that have null
  genus or species (or both)
  ([#169547534](https://www.pivotaltracker.com/story/show/169547534)).

* Correctly count unique species at initiative and organization level
  (`getAnalytics`).

* Correctly count unique countries at initiative and organization level
  (`getAnalytics`).

* Various bug fixes and improvements to computation of operational analytics
  ([#169501467](https://www.pivotaltracker.com/story/show/169501467)).

* In batch uploads, while creating a new deployment, search for an existing
  location within the project that have the same location placename as the
  deployment being processed, and if it exists link it to the deployment being
  processed
  ([#169448940](https://www.pivotaltracker.com/story/show/169448940)).

* Fix bug in batch upload import code: a wrong variable was being used to look
  up existing features.

* Add cascades to allow deletion of projects with subprojects
  ([#167970916](https://www.pivotaltracker.com/story/show/167970916)).

* Fix bug in calculations of unique wildlife species, total wildlife images or
  images by wildlife species
  ([#169623296](https://www.pivotaltracker.com/story/show/169623296)).

## v0.4.1 - 2019-10-04

### Added

* Added per-user ACL cache to avoid expensive queries and computations on each
  permission check.
* New flag (`participants.whitelisted`): needs to be explicitly set to true
  (manually via `psql`, for the time being) before a new user can log in after
  having validated their email address.

### Changed

* Indexes and cascades on constraint to improve performance of certain db
  queries, as well as allowing deletion of projects and associated entities via
  a single SQL `DELETE`.
* Download bundles now include additional fields:
  * images.csv:
    * license (data file license, from project metadata)
    * wi_taxon_id (UUID from Wildlife Insights taxonomy)

## v0.4.0 - 2019-10-04

### Added

* new version of API query (and related views) for the Discover interface:
  * allow to filter by species
    ([#168107416](https://www.pivotaltracker.com/story/show/168107416))
  * allow to filter by timespan with day resolution
    ([#168109838](https://www.pivotaltracker.com/story/show/168109838))
  * allow to filter by geo region
    ([#168108558](https://www.pivotaltracker.com/story/show/168108558))
  * calculate a wider set of dimensions for matching observations
    ([#168110401](https://www.pivotaltracker.com/story/show/168110401)):
    * number of species
    * number of images
    * number of cameras
    * number of locations
    * number of projects
    * number of users
    * number of identified objects
    * number of organizations
    * number of initiatives

  * `getDiscoverFilters` now includes possible values for `geoRegions` and
    `timespans`; `years` was dropped as this is not used in the frontend anymore

  * Two new public GraphQL queries (no authentication required) to retrieve
    taxonomy data: `getTaxonomyPublic` and `getTaxonomiesPublic`.

* `get<EntityType>Participants` GraphQL queries now include information about
  whether each user's current role on the given entity:
  * can be revoked by the current user
  * can be changed by the current user, and if so to which other roles
  ([#168503378](https://www.pivotaltracker.com/n/projects/2185366/stories/168503378))

* `getAnalytics` now computes a wider set of metrics, platform-wide, for a
  given organization, initiative or project:
  * number of images
  * number of images per species
  * number of images per location
  * number of blank images
  * number of unknown images
  * number of wildlife images
  * number of human images
  * average number of images per deployment
  * sampling days
  * number of locations (subset of deployments)
  * number of users
  * number of organizations
  * number of initiatives
  * number of projects

### Changed

* Drop column `identified_objects.common_name`
  ([#168352878](https://www.pivotaltracker.com/n/projects/2185366/stories/168352878))

* Update license options according to amended specification.

* `getTaxonomy` and `getTaxonomies` now support lookup via UUID
  ([#168835480](https://www.pivotaltracker.com/story/show/168835480))

* Batch uploads:
  * API components and CLI scripts now support the full range of fields defined
    in the batch uploads dictionary.
  * Improved how data files are moved to each project's bucket through a cloud
    function

* Improve how image status is set on image upload, reflecting whether no CV
  identification has been requested, or - if it has been requested - whether
  it was successful or it failed.

### Fixed

* As a user, I expect all my uploaded photos to be located in the "Identify" tab
  ([#164338443](https://www.pivotaltracker.com/n/projects/2185366/stories/164338443))

* Photos and partner logos of initiatives are now retrieved correctly by the
  `getInitiative` query.

* Fixed incomplete transition to new labels for project licenses.

* Implement per-project and per-deployment embargo ([#169345678](https://www.pivotaltracker.com/n/projects/2185366/stories/169345678))

## v0.3.1 - 2019-09-19

### Added

No new features

### Changed

* use taxonomy UUIDs rather than db-generated sequence IDs as foreign key for
  tables that reference the `taxonomies` table
  ([#168356443](https://www.pivotaltracker.com/story/show/168356443))

### Fixed

* fix filtering of `dataFiles` by `notBlank` status
  ([#168543035](https://www.pivotaltracker.com/story/show/168543035))

## v0.3.0 - 2019-09-19

### Added

* Add support (db only, no API interface) for storing geographic regions as
  PostGIS multipolygon geographies
  ([#168108889](https://www.pivotaltracker.com/story/show/168108889))

* add new permissions and assign them to existing or new roles
  ([#168260527](https://www.pivotaltracker.com/story/show/168260527))

### Changed

* Update ts-node version

* projects can now set a different license for metadata and for data files
  ([#168278125](https://www.pivotaltracker.com/n/projects/2185366/stories/168278125))

### Fixed

* make `operationId`s of REST endpoints unique
  ([#29](https://github.com/ConservationInternational/WildlifeInsights---API-Service/pull/29))

* fix typo in where clause in `validateBeforeUpdate()` for bait types

* fix issue that prevented users with `PROJECT_VIEWER` role from listing data
  files for identification ([#168404469](https://www.pivotaltracker.com/story/show/168404469))

* add permissions that have been introduced recently
  ([#168260527](https://www.pivotaltracker.com/story/show/168260527)) to
  `src/utils/permissions.enum.ts`

## v0.2.0 - 2019-09-09

### Added

* JSONB `metadata` field for Projects is now supported via the GraphQL API
  (`createProject`, `getProject`, `updateProject`)

### Changed

* `getTaxonomies` GraphQL query now returns `taxonomyType` (allows to
  distinguish between biological entries vs vehicles vs domestic animals)

### Fixed

* remove non-nullable sigil from `Taxonomy` GraphQL type for fields that are
  actually nullable (db and entity definition)
  ([#168342801](https://www.pivotaltracker.com/story/show/168342801))
