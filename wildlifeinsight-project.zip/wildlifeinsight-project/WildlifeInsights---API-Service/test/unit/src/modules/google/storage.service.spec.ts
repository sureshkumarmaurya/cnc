import { StorageService } from './../../../../../src/modules/google/storage.service';

describe('StorageService', () => {

  describe('getImageUrl', () => {

    it('Get undefined if some of the parameters has length 0', () => {
      // Arrange
      const projectSlug = 'myProjectSlug';
      const imageFilePath = '';

      // Act
      const result = StorageService.getImageUrl(projectSlug, imageFilePath);

      // Assert
      expect(result).toEqual(undefined);
    });

    it('Returns the full google storage image file path', () => {
      // Arrange
      const projectSlug = 'foo';
      const imageFilePath = 'deployment/2011219/8168086c-fc39-4a1d-8c76-114a8460b8b8.jpg';

      // Act
      const result = StorageService.getImageUrl(projectSlug, imageFilePath);

      // Assert
      expect(result).toEqual('gs://foo__main/deployment/2011219/8168086c-fc39-4a1d-8c76-114a8460b8b8.jpg');
    });

  });

});
