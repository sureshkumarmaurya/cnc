import { PermissionsUtils } from './../../../../src/utils/permissions.utils';
import { UserAdmin } from './../../../test-utilities/user-admin';

describe('Permissions Utils', () => {

  describe('getProjectsInOrganizationWithPermission', () => {

    const authenticatedUser = UserAdmin.userAdmin;
    const permissions = 'project.update';

    it('Returns empty array if guard clause is not passed', () => {
      // Arrange
      const organizationId = undefined;

      // Act
      const result = PermissionsUtils.getProjectsInOrganizationWithPermission(authenticatedUser, permissions, organizationId);

      // Assert
      expect(result).toHaveLength(0);
    });

    it('Returns an array of projects for fake defined authenticatedUser', () => {
      // Arrange
      const organizationId = 1;

      // Act
      const result = PermissionsUtils.getProjectsInOrganizationWithPermission(authenticatedUser, permissions, organizationId);

      // Assert
      expect(result).not.toHaveLength(0);
    });

  });

});
