export class UserAdmin {

  static userAdmin = {
    "user":{
        "id":1,
        "firstName":"Rosinha",
        "lastName":null,
        "phone":null,
        "streetAddress":"One Madrid Street",
        "city":null,
        "state":null,
        "countryCode":null,
        "postalCode":null,
        "useCommonNames":true,
        "remarks":null,
        "email":"email@email.biz",
        "password":"my1234password",
        "active":true,
        "recoverToken":"recoverToken",
        "activateToken":null,
        "role":{
          "id":1,
          "name":"ADMIN",
          "slug":"ADMIN",
          "superAdmin":true
        },
        "participantTypeProjectPivot":[
          {
              "startDate":"2018-10-24",
              "endDate":"2019-10-24",
              "status":null,
              "participantId":1,
              "participantTypeId":1,
              "projectId":1,
              "roleId":7,
              "role":{
                "id":7,
                "name":"PROJECT_OWNER",
                "slug":"PROJECT_OWNER",
                "superAdmin":false
              },
              "project":{
                "id":1,
                "metadata":null,
                "name":"My first project 001",
                "slug":"refill_supplies_in_the_fridge",
                "abbreviation":null,
                "shortName":null,
                "design":null,
                "objectives":null,
                "rightsHolder":null,
                "accessRights":null,
                "projectUrl":"http://www.vizzuality.com",
                "projectStatus":null,
                "methodology":"Manual",
                "status":"CREATED",
                "startDate":"2018-10-07",
                "endDate":"2019-10-24",
                "remarks":null,
                "projectCreditLine":"Cash",
                "acknowledgements":"Ack",
                "dataCitation":"None",
                "embargo":null,
                "dataUsePolicyId":null,
                "deleteDataFilesWithIdentifiedHumans":null,
                "metadataLicense":null,
                "dataFilesLicense":null,
                "organizationId":1,
                "initiativeId":null,
                "trigger":null
              }
          },
          {
              "startDate":"2018-10-25",
              "endDate":null,
              "status":null,
              "participantId":1,
              "participantTypeId":1,
              "projectId":3,
              "roleId":7,
              "role":{
                "id":7,
                "name":"PROJECT_OWNER",
                "slug":"PROJECT_OWNER",
                "superAdmin":false
              },
              "project":{
                "id":3,
                "metadata":null,
                "name":"staging-My project 2",
                "slug":"my_project_2",
                "abbreviation":null,
                "shortName":null,
                "design":null,
                "objectives":null,
                "rightsHolder":null,
                "accessRights":null,
                "projectUrl":null,
                "projectStatus":null,
                "methodology":null,
                "status":"CREATED",
                "startDate":"2018-10-01",
                "endDate":null,
                "remarks":null,
                "projectCreditLine":null,
                "acknowledgements":null,
                "dataCitation":null,
                "embargo":null,
                "dataUsePolicyId":null,
                "deleteDataFilesWithIdentifiedHumans":null,
                "metadataLicense":null,
                "dataFilesLicense":null,
                "organizationId":4,
                "initiativeId":null,
                "trigger":null
              }
          },
          {
              "startDate":"2018-10-26",
              "endDate":null,
              "status":null,
              "participantId":1,
              "participantTypeId":1,
              "projectId":7,
              "roleId":7,
              "role":{
                "id":7,
                "name":"PROJECT_OWNER",
                "slug":"PROJECT_OWNER",
                "superAdmin":false
              },
              "project":{
                "id":7,
                "metadata":null,
                "name":"staging-Project 1",
                "slug":"staging_project_1",
                "abbreviation":null,
                "shortName":null,
                "design":null,
                "objectives":null,
                "rightsHolder":null,
                "accessRights":null,
                "projectUrl":null,
                "projectStatus":null,
                "methodology":null,
                "status":"CREATED",
                "startDate":"2018-10-25",
                "endDate":null,
                "remarks":null,
                "projectCreditLine":null,
                "acknowledgements":null,
                "dataCitation":null,
                "embargo":null,
                "dataUsePolicyId":null,
                "deleteDataFilesWithIdentifiedHumans":null,
                "metadataLicense":null,
                "dataFilesLicense":null,
                "organizationId":8,
                "initiativeId":null,
                "trigger":null
              }
          }
        ],
        "organizationParticipantPivot":[
          {
              "participantId":1,
              "roleId":4,
              "organizationId":1,
              "role":{
                "id":4,
                "name":"ORGANIZATION_OWNER",
                "slug":"ORGANIZATION_OWNER",
                "superAdmin":false
              },
              "organization":{
                "id":1,
                "name":"My first organization 001",
                "streetAddress":"C/ Fuencarral 123",
                "city":"Madrid",
                "state":"Spain",
                "postalCode":"28010",
                "phone":null,
                "email":"info@vizzuality.com",
                "countryCode":null,
                "organizationUrl":"http://vizzuality.com",
                "remarks":null
              }
          },
          {
              "participantId":1,
              "roleId":4,
              "organizationId":4,
              "role":{
                "id":4,
                "name":"ORGANIZATION_OWNER",
                "slug":"ORGANIZATION_OWNER",
                "superAdmin":false
              },
              "organization":{
                "id":4,
                "name":"Organization name changed",
                "streetAddress":"Calle de Fuencarral 12345",
                "city":null,
                "state":null,
                "postalCode":null,
                "phone":null,
                "email":null,
                "countryCode":null,
                "organizationUrl":null,
                "remarks":null
              }
          },
          {
              "participantId":1,
              "roleId":4,
              "organizationId":7,
              "role":{
                "id":4,
                "name":"ORGANIZATION_OWNER",
                "slug":"ORGANIZATION_OWNER",
                "superAdmin":false
              },
              "organization":{
                "id":7,
                "name":"Organization 3",
                "streetAddress":null,
                "city":null,
                "state":null,
                "postalCode":null,
                "phone":null,
                "email":null,
                "countryCode":null,
                "organizationUrl":null,
                "remarks":null
              }
          }
        ],
        "initiativeParticipantPivot":[
          {
              "participantId":1,
              "roleId":10,
              "initiativeId":13,
              "role":{
                "id":10,
                "name":"INITIATIVE_OWNER",
                "slug":"INITIATIVE_OWNER",
                "superAdmin":false
              },
              "initiative":{
                "id":13,
                "name":"Initiative Clément 1",
                "purpose":null,
                "remarks":null,
                "isLocationPublic":false,
                "ownerOrganizationId":1,
                "contactEmail":null,
                "contactContent":null,
                "logo":{
                    "id":"initiatives-files-public/cfe1bf3d-f5df-446c-867a-87d2b17730e5.jpg/1557755369192339",
                    "linkPublic":"https://www.googleapis.com/download/storage/v1/b/initiatives-files-public/o/cfe1bf3d-f5df-446c-867a-87d2b17730e5.jpg?generation=1557755369192339&alt=media",
                    "contentType":"image/jpeg",
                    "name":"cfe1bf3d-f5df-446c-867a-87d2b17730e5.jpg"
                },
                "coverImage":{
                    "id":"initiatives-files-public/e364a16b-92ee-4148-a33d-d1e440f4f2e6.jpg/1557755370712155",
                    "linkPublic":"https://www.googleapis.com/download/storage/v1/b/initiatives-files-public/o/e364a16b-92ee-4148-a33d-d1e440f4f2e6.jpg?generation=1557755370712155&alt=media",
                    "contentType":"image/jpeg",
                    "name":"e364a16b-92ee-4148-a33d-d1e440f4f2e6.jpg"
                },
                "videoUrl":null,
                "introduction":null,
                "content":null,
                "description":null
              }
          }
        ]
    },
    "generalRole":{
        "id":1,
        "name":"ADMIN",
        "slug":"ADMIN",
        "superAdmin":true,
        "permissions":[

        ]
    },
    "projectRole":[
        {
          "project":{
              "id":1,
              "metadata":null,
              "name":"My first project 001",
              "slug":"refill_supplies_in_the_fridge",
              "abbreviation":null,
              "shortName":null,
              "design":null,
              "objectives":null,
              "rightsHolder":null,
              "accessRights":null,
              "projectUrl":"http://www.vizzuality.com",
              "projectStatus":null,
              "methodology":"Manual",
              "status":"CREATED",
              "startDate":"2018-10-07",
              "endDate":"2019-10-24",
              "remarks":null,
              "projectCreditLine":"Cash",
              "acknowledgements":"Ack",
              "dataCitation":"None",
              "embargo":null,
              "dataUsePolicyId":null,
              "deleteDataFilesWithIdentifiedHumans":null,
              "metadataLicense":null,
              "dataFilesLicense":null,
              "organizationId":1,
              "initiativeId":null,
              "trigger":null
          },
          "role":{
              "id":7,
              "name":"PROJECT_OWNER",
              "slug":"PROJECT_OWNER",
              "superAdmin":false,
              "permissions":[
                {
                    "id":12,
                    "name":"UPDATE PROJECT",
                    "slug":"project.update",
                    "description":"Update project"
                },
                {
                    "id":13,
                    "name":"DELETE PROJECT",
                    "slug":"project.delete",
                    "description":"Delete project"
                },
                {
                    "id":14,
                    "name":"GET ALL PROJECTS",
                    "slug":"project.get_all",
                    "description":"Get all projects"
                },
                {
                    "id":15,
                    "name":"GET ONE PROJECT",
                    "slug":"project.get_one",
                    "description":"Get one project"
                },
                {
                    "id":16,
                    "name":"CREATE LOCATION",
                    "slug":"location.create",
                    "description":"Create location"
                },
                {
                    "id":17,
                    "name":"UPDATE LOCATION",
                    "slug":"location.update",
                    "description":"Update location"
                },
                {
                    "id":18,
                    "name":"DELETE LOCATION",
                    "slug":"location.delete",
                    "description":"Delete location"
                },
                {
                    "id":19,
                    "name":"GET ALL LOCATIONS",
                    "slug":"location.get_all",
                    "description":"Get all locations"
                },
                {
                    "id":20,
                    "name":"GET ONE LOCATION",
                    "slug":"location.get_one",
                    "description":"Get one location"
                },
                {
                    "id":21,
                    "name":"CREATE DEPLOYMENT",
                    "slug":"deployment.create",
                    "description":"Create deployment"
                },
                {
                    "id":22,
                    "name":"UPDATE DEPLOYMENT",
                    "slug":"deployment.update",
                    "description":"Update deployment"
                },
                {
                    "id":23,
                    "name":"DELETE DEPLOYMENT",
                    "slug":"deployment.delete",
                    "description":"Delete deployment"
                },
                {
                    "id":24,
                    "name":"GET ALL DEPLOYMENTS",
                    "slug":"deployment.get_all",
                    "description":"Get all deployments"
                },
                {
                    "id":25,
                    "name":"GET ONE DEPLOYMENT",
                    "slug":"deployment.get_one",
                    "description":"Get one deployment"
                },
                {
                    "id":26,
                    "name":"CREATE DATA FILE",
                    "slug":"dataFile.create",
                    "description":"Create data file"
                },
                {
                    "id":27,
                    "name":"UPDATE DATA FILE",
                    "slug":"dataFile.update",
                    "description":"Update data file"
                },
                {
                    "id":28,
                    "name":"DELETE DATA FILE",
                    "slug":"dataFile.delete",
                    "description":"Delete data file"
                },
                {
                    "id":29,
                    "name":"GET ALL DATA FILES",
                    "slug":"dataFile.get_all",
                    "description":"Get all data files"
                },
                {
                    "id":30,
                    "name":"GET ONE DATA FILE",
                    "slug":"dataFile.get_one",
                    "description":"Get one data file"
                },
                {
                    "id":31,
                    "name":"DOWNLOAD DATA FILE",
                    "slug":"dataFile.download",
                    "description":"Download data file"
                },
                {
                    "id":32,
                    "name":"CREATE IDENTIFICATION",
                    "slug":"identification.create",
                    "description":"Create identification"
                },
                {
                    "id":33,
                    "name":"UPDATE IDENTIFICATION",
                    "slug":"identification.update",
                    "description":"Update identification"
                },
                {
                    "id":34,
                    "name":"DELETE IDENTIFICATION",
                    "slug":"identification.delete",
                    "description":"Delete identification"
                },
                {
                    "id":35,
                    "name":"GET ALL IDENTIFICATIONS",
                    "slug":"identification.get_all",
                    "description":"Get all identifications"
                },
                {
                    "id":36,
                    "name":"GET ONE IDENTIFICATION",
                    "slug":"identification.get_one",
                    "description":"Get one identification"
                },
                {
                    "id":47,
                    "name":"CREATE SEQUENCE",
                    "slug":"sequence.create",
                    "description":"Create sequence"
                },
                {
                    "id":48,
                    "name":"UPDATE SEQUENCE",
                    "slug":"sequence.update",
                    "description":"Update sequence"
                },
                {
                    "id":49,
                    "name":"DELETE SEQUENCE",
                    "slug":"sequence.delete",
                    "description":"Delete sequence"
                },
                {
                    "id":50,
                    "name":"GET ALL SEQUENCES",
                    "slug":"sequence.get_all",
                    "description":"Get all sequences"
                },
                {
                    "id":51,
                    "name":"GET ONE SEQUENCE",
                    "slug":"sequence.get_one",
                    "description":"Get one sequence"
                },
                {
                    "id":57,
                    "name":"INVITE USER AS VIEWER",
                    "slug":"project.invite_user_as_viewer",
                    "description":"Invite user as Viewer"
                },
                {
                    "id":58,
                    "name":"INVITE USER AS EDITOR",
                    "slug":"project.invite_user_as_editor",
                    "description":"Invite user as Editor"
                },
                {
                    "id":59,
                    "name":"INVITE USER AS OWNER",
                    "slug":"project.invite_user_as_owner",
                    "description":"Invite user as Owner"
                },
                {
                    "id":60,
                    "name":"CHANGE USER ROLE",
                    "slug":"project.change_user_role",
                    "description":"Change user role"
                },
                {
                    "id":61,
                    "name":"REVOKE USER ACCESS",
                    "slug":"project.revoke_user_access",
                    "description":"Revoke user access"
                }
              ]
          }
        },
        {
          "project":{
              "id":3,
              "metadata":null,
              "name":"staging-My project 2",
              "slug":"my_project_2",
              "abbreviation":null,
              "shortName":null,
              "design":null,
              "objectives":null,
              "rightsHolder":null,
              "accessRights":null,
              "projectUrl":null,
              "projectStatus":null,
              "methodology":null,
              "status":"CREATED",
              "startDate":"2018-10-01",
              "endDate":null,
              "remarks":null,
              "projectCreditLine":null,
              "acknowledgements":null,
              "dataCitation":null,
              "embargo":null,
              "dataUsePolicyId":null,
              "deleteDataFilesWithIdentifiedHumans":null,
              "metadataLicense":null,
              "dataFilesLicense":null,
              "organizationId":4,
              "initiativeId":null,
              "trigger":null
          },
          "role":{
              "id":7,
              "name":"PROJECT_OWNER",
              "slug":"PROJECT_OWNER",
              "superAdmin":false,
              "permissions":[
                {
                    "id":12,
                    "name":"UPDATE PROJECT",
                    "slug":"project.update",
                    "description":"Update project"
                },
                {
                    "id":13,
                    "name":"DELETE PROJECT",
                    "slug":"project.delete",
                    "description":"Delete project"
                },
                {
                    "id":14,
                    "name":"GET ALL PROJECTS",
                    "slug":"project.get_all",
                    "description":"Get all projects"
                },
                {
                    "id":15,
                    "name":"GET ONE PROJECT",
                    "slug":"project.get_one",
                    "description":"Get one project"
                },
                {
                    "id":16,
                    "name":"CREATE LOCATION",
                    "slug":"location.create",
                    "description":"Create location"
                },
                {
                    "id":17,
                    "name":"UPDATE LOCATION",
                    "slug":"location.update",
                    "description":"Update location"
                },
                {
                    "id":18,
                    "name":"DELETE LOCATION",
                    "slug":"location.delete",
                    "description":"Delete location"
                },
                {
                    "id":19,
                    "name":"GET ALL LOCATIONS",
                    "slug":"location.get_all",
                    "description":"Get all locations"
                },
                {
                    "id":20,
                    "name":"GET ONE LOCATION",
                    "slug":"location.get_one",
                    "description":"Get one location"
                },
                {
                    "id":21,
                    "name":"CREATE DEPLOYMENT",
                    "slug":"deployment.create",
                    "description":"Create deployment"
                },
                {
                    "id":22,
                    "name":"UPDATE DEPLOYMENT",
                    "slug":"deployment.update",
                    "description":"Update deployment"
                },
                {
                    "id":23,
                    "name":"DELETE DEPLOYMENT",
                    "slug":"deployment.delete",
                    "description":"Delete deployment"
                },
                {
                    "id":24,
                    "name":"GET ALL DEPLOYMENTS",
                    "slug":"deployment.get_all",
                    "description":"Get all deployments"
                },
                {
                    "id":25,
                    "name":"GET ONE DEPLOYMENT",
                    "slug":"deployment.get_one",
                    "description":"Get one deployment"
                },
                {
                    "id":26,
                    "name":"CREATE DATA FILE",
                    "slug":"dataFile.create",
                    "description":"Create data file"
                },
                {
                    "id":27,
                    "name":"UPDATE DATA FILE",
                    "slug":"dataFile.update",
                    "description":"Update data file"
                },
                {
                    "id":28,
                    "name":"DELETE DATA FILE",
                    "slug":"dataFile.delete",
                    "description":"Delete data file"
                },
                {
                    "id":29,
                    "name":"GET ALL DATA FILES",
                    "slug":"dataFile.get_all",
                    "description":"Get all data files"
                },
                {
                    "id":30,
                    "name":"GET ONE DATA FILE",
                    "slug":"dataFile.get_one",
                    "description":"Get one data file"
                },
                {
                    "id":31,
                    "name":"DOWNLOAD DATA FILE",
                    "slug":"dataFile.download",
                    "description":"Download data file"
                },
                {
                    "id":32,
                    "name":"CREATE IDENTIFICATION",
                    "slug":"identification.create",
                    "description":"Create identification"
                },
                {
                    "id":33,
                    "name":"UPDATE IDENTIFICATION",
                    "slug":"identification.update",
                    "description":"Update identification"
                },
                {
                    "id":34,
                    "name":"DELETE IDENTIFICATION",
                    "slug":"identification.delete",
                    "description":"Delete identification"
                },
                {
                    "id":35,
                    "name":"GET ALL IDENTIFICATIONS",
                    "slug":"identification.get_all",
                    "description":"Get all identifications"
                },
                {
                    "id":36,
                    "name":"GET ONE IDENTIFICATION",
                    "slug":"identification.get_one",
                    "description":"Get one identification"
                },
                {
                    "id":47,
                    "name":"CREATE SEQUENCE",
                    "slug":"sequence.create",
                    "description":"Create sequence"
                },
                {
                    "id":48,
                    "name":"UPDATE SEQUENCE",
                    "slug":"sequence.update",
                    "description":"Update sequence"
                },
                {
                    "id":49,
                    "name":"DELETE SEQUENCE",
                    "slug":"sequence.delete",
                    "description":"Delete sequence"
                },
                {
                    "id":50,
                    "name":"GET ALL SEQUENCES",
                    "slug":"sequence.get_all",
                    "description":"Get all sequences"
                },
                {
                    "id":51,
                    "name":"GET ONE SEQUENCE",
                    "slug":"sequence.get_one",
                    "description":"Get one sequence"
                },
                {
                    "id":57,
                    "name":"INVITE USER AS VIEWER",
                    "slug":"project.invite_user_as_viewer",
                    "description":"Invite user as Viewer"
                },
                {
                    "id":58,
                    "name":"INVITE USER AS EDITOR",
                    "slug":"project.invite_user_as_editor",
                    "description":"Invite user as Editor"
                },
                {
                    "id":59,
                    "name":"INVITE USER AS OWNER",
                    "slug":"project.invite_user_as_owner",
                    "description":"Invite user as Owner"
                },
                {
                    "id":60,
                    "name":"CHANGE USER ROLE",
                    "slug":"project.change_user_role",
                    "description":"Change user role"
                },
                {
                    "id":61,
                    "name":"REVOKE USER ACCESS",
                    "slug":"project.revoke_user_access",
                    "description":"Revoke user access"
                }
              ]
          }
        },
        {
          "project":{
              "id":7,
              "metadata":null,
              "name":"staging-Project 1",
              "slug":"staging_project_1",
              "abbreviation":null,
              "shortName":null,
              "design":null,
              "objectives":null,
              "rightsHolder":null,
              "accessRights":null,
              "projectUrl":null,
              "projectStatus":null,
              "methodology":null,
              "status":"CREATED",
              "startDate":"2018-10-25",
              "endDate":null,
              "remarks":null,
              "projectCreditLine":null,
              "acknowledgements":null,
              "dataCitation":null,
              "embargo":null,
              "dataUsePolicyId":null,
              "deleteDataFilesWithIdentifiedHumans":null,
              "metadataLicense":null,
              "dataFilesLicense":null,
              "organizationId":8,
              "initiativeId":null,
              "trigger":null
          },
          "role":{
              "id":7,
              "name":"PROJECT_OWNER",
              "slug":"PROJECT_OWNER",
              "superAdmin":false,
              "permissions":[
                {
                    "id":12,
                    "name":"UPDATE PROJECT",
                    "slug":"project.update",
                    "description":"Update project"
                },
                {
                    "id":13,
                    "name":"DELETE PROJECT",
                    "slug":"project.delete",
                    "description":"Delete project"
                },
                {
                    "id":14,
                    "name":"GET ALL PROJECTS",
                    "slug":"project.get_all",
                    "description":"Get all projects"
                },
                {
                    "id":15,
                    "name":"GET ONE PROJECT",
                    "slug":"project.get_one",
                    "description":"Get one project"
                },
                {
                    "id":16,
                    "name":"CREATE LOCATION",
                    "slug":"location.create",
                    "description":"Create location"
                },
                {
                    "id":17,
                    "name":"UPDATE LOCATION",
                    "slug":"location.update",
                    "description":"Update location"
                },
                {
                    "id":18,
                    "name":"DELETE LOCATION",
                    "slug":"location.delete",
                    "description":"Delete location"
                },
                {
                    "id":19,
                    "name":"GET ALL LOCATIONS",
                    "slug":"location.get_all",
                    "description":"Get all locations"
                },
                {
                    "id":20,
                    "name":"GET ONE LOCATION",
                    "slug":"location.get_one",
                    "description":"Get one location"
                },
                {
                    "id":21,
                    "name":"CREATE DEPLOYMENT",
                    "slug":"deployment.create",
                    "description":"Create deployment"
                },
                {
                    "id":22,
                    "name":"UPDATE DEPLOYMENT",
                    "slug":"deployment.update",
                    "description":"Update deployment"
                },
                {
                    "id":23,
                    "name":"DELETE DEPLOYMENT",
                    "slug":"deployment.delete",
                    "description":"Delete deployment"
                },
                {
                    "id":24,
                    "name":"GET ALL DEPLOYMENTS",
                    "slug":"deployment.get_all",
                    "description":"Get all deployments"
                },
                {
                    "id":25,
                    "name":"GET ONE DEPLOYMENT",
                    "slug":"deployment.get_one",
                    "description":"Get one deployment"
                },
                {
                    "id":26,
                    "name":"CREATE DATA FILE",
                    "slug":"dataFile.create",
                    "description":"Create data file"
                },
                {
                    "id":27,
                    "name":"UPDATE DATA FILE",
                    "slug":"dataFile.update",
                    "description":"Update data file"
                },
                {
                    "id":28,
                    "name":"DELETE DATA FILE",
                    "slug":"dataFile.delete",
                    "description":"Delete data file"
                },
                {
                    "id":29,
                    "name":"GET ALL DATA FILES",
                    "slug":"dataFile.get_all",
                    "description":"Get all data files"
                },
                {
                    "id":30,
                    "name":"GET ONE DATA FILE",
                    "slug":"dataFile.get_one",
                    "description":"Get one data file"
                },
                {
                    "id":31,
                    "name":"DOWNLOAD DATA FILE",
                    "slug":"dataFile.download",
                    "description":"Download data file"
                },
                {
                    "id":32,
                    "name":"CREATE IDENTIFICATION",
                    "slug":"identification.create",
                    "description":"Create identification"
                },
                {
                    "id":33,
                    "name":"UPDATE IDENTIFICATION",
                    "slug":"identification.update",
                    "description":"Update identification"
                },
                {
                    "id":34,
                    "name":"DELETE IDENTIFICATION",
                    "slug":"identification.delete",
                    "description":"Delete identification"
                },
                {
                    "id":35,
                    "name":"GET ALL IDENTIFICATIONS",
                    "slug":"identification.get_all",
                    "description":"Get all identifications"
                },
                {
                    "id":36,
                    "name":"GET ONE IDENTIFICATION",
                    "slug":"identification.get_one",
                    "description":"Get one identification"
                },
                {
                    "id":47,
                    "name":"CREATE SEQUENCE",
                    "slug":"sequence.create",
                    "description":"Create sequence"
                },
                {
                    "id":48,
                    "name":"UPDATE SEQUENCE",
                    "slug":"sequence.update",
                    "description":"Update sequence"
                },
                {
                    "id":49,
                    "name":"DELETE SEQUENCE",
                    "slug":"sequence.delete",
                    "description":"Delete sequence"
                },
                {
                    "id":50,
                    "name":"GET ALL SEQUENCES",
                    "slug":"sequence.get_all",
                    "description":"Get all sequences"
                },
                {
                    "id":51,
                    "name":"GET ONE SEQUENCE",
                    "slug":"sequence.get_one",
                    "description":"Get one sequence"
                },
                {
                    "id":57,
                    "name":"INVITE USER AS VIEWER",
                    "slug":"project.invite_user_as_viewer",
                    "description":"Invite user as Viewer"
                },
                {
                    "id":58,
                    "name":"INVITE USER AS EDITOR",
                    "slug":"project.invite_user_as_editor",
                    "description":"Invite user as Editor"
                },
                {
                    "id":59,
                    "name":"INVITE USER AS OWNER",
                    "slug":"project.invite_user_as_owner",
                    "description":"Invite user as Owner"
                },
                {
                    "id":60,
                    "name":"CHANGE USER ROLE",
                    "slug":"project.change_user_role",
                    "description":"Change user role"
                },
                {
                    "id":61,
                    "name":"REVOKE USER ACCESS",
                    "slug":"project.revoke_user_access",
                    "description":"Revoke user access"
                }
              ]
          }
        }
    ],
    "organizationRole":[
        {
          "organization":{
              "id":1,
              "name":"My first organization 001",
              "streetAddress":"C/ Fuencarral 123",
              "city":"Madrid",
              "state":"Spain",
              "postalCode":"28010",
              "phone":null,
              "email":"info@vizzuality.com",
              "countryCode":null,
              "organizationUrl":"http://vizzuality.com",
              "remarks":null
          },
          "role":{
              "id":4,
              "name":"ORGANIZATION_OWNER",
              "slug":"ORGANIZATION_OWNER",
              "superAdmin":false,
              "permissions":[
                {
                    "id":6,
                    "name":"CREATE ORGANIZATION",
                    "slug":"organization.create",
                    "description":"Create organization"
                },
                {
                    "id":7,
                    "name":"UPDATE ORGANIZATION",
                    "slug":"organization.update",
                    "description":"Update organization"
                },
                {
                    "id":8,
                    "name":"DELETE ORGANIZATION",
                    "slug":"organization.delete",
                    "description":"Delete organization"
                },
                {
                    "id":9,
                    "name":"GET ALL ORGANIZATIONS",
                    "slug":"organization.get_all",
                    "description":"Get all organizations"
                },
                {
                    "id":10,
                    "name":"GET ONE ORGANIZATION",
                    "slug":"organization.get_one",
                    "description":"Get one organization"
                },
                {
                    "id":11,
                    "name":"CREATE PROJECT",
                    "slug":"project.create",
                    "description":"Create project"
                },
                {
                    "id":14,
                    "name":"GET ALL PROJECTS",
                    "slug":"project.get_all",
                    "description":"Get all projects"
                },
                {
                    "id":15,
                    "name":"GET ONE PROJECT",
                    "slug":"project.get_one",
                    "description":"Get one project"
                },
                {
                    "id":37,
                    "name":"CREATE DEVICE",
                    "slug":"device.create",
                    "description":"Create device"
                },
                {
                    "id":38,
                    "name":"UPDATE DEVICE",
                    "slug":"device.update",
                    "description":"Update device"
                },
                {
                    "id":39,
                    "name":"DELETE DEVICE",
                    "slug":"device.delete",
                    "description":"Delete device"
                },
                {
                    "id":40,
                    "name":"GET ALL DEVICES",
                    "slug":"device.get_all",
                    "description":"Get all devices"
                },
                {
                    "id":41,
                    "name":"GET ONE DEVICE",
                    "slug":"device.get_one",
                    "description":"Get one device"
                },
                {
                    "id":42,
                    "name":"CREATE SENSOR",
                    "slug":"sensor.create",
                    "description":"Create sensor"
                },
                {
                    "id":43,
                    "name":"UPDATE SENSOR",
                    "slug":"sensor.update",
                    "description":"Update sensor"
                },
                {
                    "id":44,
                    "name":"DELETE SENSOR",
                    "slug":"sensor.delete",
                    "description":"Delete sensor"
                },
                {
                    "id":45,
                    "name":"GET ALL SENSORS",
                    "slug":"sensor.get_all",
                    "description":"Get all sensors"
                },
                {
                    "id":46,
                    "name":"GET ONE SENSOR",
                    "slug":"sensor.get_one",
                    "description":"Get one sensor"
                },
                {
                    "id":52,
                    "name":"INVITE USER AS VIEWER",
                    "slug":"organization.invite_user_as_viewer",
                    "description":"Invite user as Viewer"
                },
                {
                    "id":53,
                    "name":"INVITE USER AS EDITOR",
                    "slug":"organization.invite_user_as_editor",
                    "description":"Invite user as Editor"
                },
                {
                    "id":54,
                    "name":"INVITE USER AS OWNER",
                    "slug":"organization.invite_user_as_owner",
                    "description":"Invite user as Owner"
                },
                {
                    "id":55,
                    "name":"CHANGE USER ROLE",
                    "slug":"organization.change_user_role",
                    "description":"Change user role"
                },
                {
                    "id":56,
                    "name":"REVOKE USER ACCESS",
                    "slug":"organization.revoke_user_access",
                    "description":"Revoke user access"
                }
              ]
          }
        },
        {
          "organization":{
              "id":4,
              "name":"Organization name changed",
              "streetAddress":"Calle de Fuencarral 12345",
              "city":null,
              "state":null,
              "postalCode":null,
              "phone":null,
              "email":null,
              "countryCode":null,
              "organizationUrl":null,
              "remarks":null
          },
          "role":{
              "id":4,
              "name":"ORGANIZATION_OWNER",
              "slug":"ORGANIZATION_OWNER",
              "superAdmin":false,
              "permissions":[
                {
                    "id":6,
                    "name":"CREATE ORGANIZATION",
                    "slug":"organization.create",
                    "description":"Create organization"
                },
                {
                    "id":7,
                    "name":"UPDATE ORGANIZATION",
                    "slug":"organization.update",
                    "description":"Update organization"
                },
                {
                    "id":8,
                    "name":"DELETE ORGANIZATION",
                    "slug":"organization.delete",
                    "description":"Delete organization"
                },
                {
                    "id":9,
                    "name":"GET ALL ORGANIZATIONS",
                    "slug":"organization.get_all",
                    "description":"Get all organizations"
                },
                {
                    "id":10,
                    "name":"GET ONE ORGANIZATION",
                    "slug":"organization.get_one",
                    "description":"Get one organization"
                },
                {
                    "id":11,
                    "name":"CREATE PROJECT",
                    "slug":"project.create",
                    "description":"Create project"
                },
                {
                    "id":14,
                    "name":"GET ALL PROJECTS",
                    "slug":"project.get_all",
                    "description":"Get all projects"
                },
                {
                    "id":15,
                    "name":"GET ONE PROJECT",
                    "slug":"project.get_one",
                    "description":"Get one project"
                },
                {
                    "id":37,
                    "name":"CREATE DEVICE",
                    "slug":"device.create",
                    "description":"Create device"
                },
                {
                    "id":38,
                    "name":"UPDATE DEVICE",
                    "slug":"device.update",
                    "description":"Update device"
                },
                {
                    "id":39,
                    "name":"DELETE DEVICE",
                    "slug":"device.delete",
                    "description":"Delete device"
                },
                {
                    "id":40,
                    "name":"GET ALL DEVICES",
                    "slug":"device.get_all",
                    "description":"Get all devices"
                },
                {
                    "id":41,
                    "name":"GET ONE DEVICE",
                    "slug":"device.get_one",
                    "description":"Get one device"
                },
                {
                    "id":42,
                    "name":"CREATE SENSOR",
                    "slug":"sensor.create",
                    "description":"Create sensor"
                },
                {
                    "id":43,
                    "name":"UPDATE SENSOR",
                    "slug":"sensor.update",
                    "description":"Update sensor"
                },
                {
                    "id":44,
                    "name":"DELETE SENSOR",
                    "slug":"sensor.delete",
                    "description":"Delete sensor"
                },
                {
                    "id":45,
                    "name":"GET ALL SENSORS",
                    "slug":"sensor.get_all",
                    "description":"Get all sensors"
                },
                {
                    "id":46,
                    "name":"GET ONE SENSOR",
                    "slug":"sensor.get_one",
                    "description":"Get one sensor"
                },
                {
                    "id":52,
                    "name":"INVITE USER AS VIEWER",
                    "slug":"organization.invite_user_as_viewer",
                    "description":"Invite user as Viewer"
                },
                {
                    "id":53,
                    "name":"INVITE USER AS EDITOR",
                    "slug":"organization.invite_user_as_editor",
                    "description":"Invite user as Editor"
                },
                {
                    "id":54,
                    "name":"INVITE USER AS OWNER",
                    "slug":"organization.invite_user_as_owner",
                    "description":"Invite user as Owner"
                },
                {
                    "id":55,
                    "name":"CHANGE USER ROLE",
                    "slug":"organization.change_user_role",
                    "description":"Change user role"
                },
                {
                    "id":56,
                    "name":"REVOKE USER ACCESS",
                    "slug":"organization.revoke_user_access",
                    "description":"Revoke user access"
                }
              ]
          }
        },
        {
          "organization":{
              "id":7,
              "name":"Organization 3",
              "streetAddress":null,
              "city":null,
              "state":null,
              "postalCode":null,
              "phone":null,
              "email":null,
              "countryCode":null,
              "organizationUrl":null,
              "remarks":null
          },
          "role":{
              "id":4,
              "name":"ORGANIZATION_OWNER",
              "slug":"ORGANIZATION_OWNER",
              "superAdmin":false,
              "permissions":[
                {
                    "id":6,
                    "name":"CREATE ORGANIZATION",
                    "slug":"organization.create",
                    "description":"Create organization"
                },
                {
                    "id":7,
                    "name":"UPDATE ORGANIZATION",
                    "slug":"organization.update",
                    "description":"Update organization"
                },
                {
                    "id":8,
                    "name":"DELETE ORGANIZATION",
                    "slug":"organization.delete",
                    "description":"Delete organization"
                },
                {
                    "id":9,
                    "name":"GET ALL ORGANIZATIONS",
                    "slug":"organization.get_all",
                    "description":"Get all organizations"
                },
                {
                    "id":10,
                    "name":"GET ONE ORGANIZATION",
                    "slug":"organization.get_one",
                    "description":"Get one organization"
                },
                {
                    "id":11,
                    "name":"CREATE PROJECT",
                    "slug":"project.create",
                    "description":"Create project"
                },
                {
                    "id":14,
                    "name":"GET ALL PROJECTS",
                    "slug":"project.get_all",
                    "description":"Get all projects"
                },
                {
                    "id":15,
                    "name":"GET ONE PROJECT",
                    "slug":"project.get_one",
                    "description":"Get one project"
                },
                {
                    "id":37,
                    "name":"CREATE DEVICE",
                    "slug":"device.create",
                    "description":"Create device"
                },
                {
                    "id":38,
                    "name":"UPDATE DEVICE",
                    "slug":"device.update",
                    "description":"Update device"
                },
                {
                    "id":39,
                    "name":"DELETE DEVICE",
                    "slug":"device.delete",
                    "description":"Delete device"
                },
                {
                    "id":40,
                    "name":"GET ALL DEVICES",
                    "slug":"device.get_all",
                    "description":"Get all devices"
                },
                {
                    "id":41,
                    "name":"GET ONE DEVICE",
                    "slug":"device.get_one",
                    "description":"Get one device"
                },
                {
                    "id":42,
                    "name":"CREATE SENSOR",
                    "slug":"sensor.create",
                    "description":"Create sensor"
                },
                {
                    "id":43,
                    "name":"UPDATE SENSOR",
                    "slug":"sensor.update",
                    "description":"Update sensor"
                },
                {
                    "id":44,
                    "name":"DELETE SENSOR",
                    "slug":"sensor.delete",
                    "description":"Delete sensor"
                },
                {
                    "id":45,
                    "name":"GET ALL SENSORS",
                    "slug":"sensor.get_all",
                    "description":"Get all sensors"
                },
                {
                    "id":46,
                    "name":"GET ONE SENSOR",
                    "slug":"sensor.get_one",
                    "description":"Get one sensor"
                },
                {
                    "id":52,
                    "name":"INVITE USER AS VIEWER",
                    "slug":"organization.invite_user_as_viewer",
                    "description":"Invite user as Viewer"
                },
                {
                    "id":53,
                    "name":"INVITE USER AS EDITOR",
                    "slug":"organization.invite_user_as_editor",
                    "description":"Invite user as Editor"
                },
                {
                    "id":54,
                    "name":"INVITE USER AS OWNER",
                    "slug":"organization.invite_user_as_owner",
                    "description":"Invite user as Owner"
                },
                {
                    "id":55,
                    "name":"CHANGE USER ROLE",
                    "slug":"organization.change_user_role",
                    "description":"Change user role"
                },
                {
                    "id":56,
                    "name":"REVOKE USER ACCESS",
                    "slug":"organization.revoke_user_access",
                    "description":"Revoke user access"
                }
              ]
          }
        }
    ]
  };
}
